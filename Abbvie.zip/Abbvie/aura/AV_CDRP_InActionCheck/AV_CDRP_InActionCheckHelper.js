({
    doInitialAction : function(component, event, helper) {        
        var userId = $A.get("$SObjectType.CurrentUser.Id");
        var recordId = component.get("v.recordId");
        var action = component.get("c.getRecords");        
        action.setParams({
            userId : userId,
            recordId : recordId
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var cardmap = [];
                var checkData = response.getReturnValue();
                component.set("v.IDRPStatus", checkData.IDRPStatus); 
                for(var key in checkData.mapOfCheckWrapper){
                    cardmap.push({value : checkData.mapOfCheckWrapper[key], key : key});
                }
                component.set("v.wrapperReturn",cardmap);
                helper.dateSort(component, event, helper);
            }
        });
        $A.enqueueAction(action);
    },
    dateSort : function(component, event, helper) {  
        var checkWrapper = component.get("v.wrapperReturn");
        var sortedChecks = [];
        var sortedChecksWithNoQueries = [];
        var sortedChecksWithQueries = [];
        sortedChecks = checkWrapper[0].value;
        sortedChecks.sort(function(a, b){
            var varA = a['checkAssigned'].AV_CDRP_Earliest_Query_Due_By__c;
            var varB = b['checkAssigned'].AV_CDRP_Earliest_Query_Due_By__c;
            return varA - varB || b['checkAssigned'].AV_CDRP_Number_Of_Overdue_Check__c-a['checkAssigned'].AV_CDRP_Number_Of_Overdue_Check__c;
        });
        checkWrapper[0].value = sortedChecks;
        sortedChecks = checkWrapper[1].value;
        sortedChecks.sort(function(a, b){
            var varA = a['checkAssigned'].AV_CDRP_Earliest_Query_Due_By__c;
            //const vA =  varA >= 0 ? varA : -1*varA;
            var varB = b['checkAssigned'].AV_CDRP_Earliest_Query_Due_By__c;
            //const vB =  varB >= 0 ? varB : -1*varB;
            return varA - varB || b['checkAssigned'].AV_CDRP_Number_Of_InReview_Check__c-a['checkAssigned'].AV_CDRP_Number_Of_InReview_Check__c;
        });
        checkWrapper[1].value = sortedChecks;
        sortedChecks = checkWrapper[2].value;
        for (var i = 0; i < sortedChecks.length; i++) {
            var queriesSum = sortedChecks[i]['checkAssigned'].AV_CDRP_Number_Of_DataAccumulation_Check__c + sortedChecks[i]['checkAssigned'].AV_CDRP_Number_Of_InReview_Check__c +sortedChecks[i]['checkAssigned'].AV_CDRP_Number_Of_Overdue_Check__c;
            if (queriesSum <= 0 ) {
                sortedChecksWithNoQueries.push(sortedChecks[i]);
            }else if(queriesSum >= 1){
                sortedChecksWithQueries.push(sortedChecks[i]);
            }
        }
        var sortedChecksDataAccumulation = [];
        sortedChecksWithQueries.sort(function(a, b){
            var varA = a['checkAssigned'].AV_CDRP_Earliest_Query_Due_By__c;
            //const vA =  varA >= 0 ? varA : -1*varA;
            var varB = b['checkAssigned'].AV_CDRP_Earliest_Query_Due_By__c;
            //const vB =  varB >= 0 ? varB : -1*varB;
            return varA - varB || b['checkAssigned'].AV_CDRP_Number_Of_DataAccumulation_Check__c-a['checkAssigned'].AV_CDRP_Number_Of_DataAccumulation_Check__c;
        });
         for (var i = 0; i < sortedChecksWithQueries.length; i++) {
             sortedChecksDataAccumulation.push(sortedChecksWithQueries[i]);
         }
         for (var i = 0; i < sortedChecksWithNoQueries.length; i++) {
             sortedChecksDataAccumulation.push(sortedChecksWithNoQueries[i]);
         }
        sortedChecks = sortedChecksDataAccumulation;
        checkWrapper[2].value = sortedChecks;
        sortedChecks = checkWrapper[3].value;
        sortedChecks.sort(function(a, b){
            var varA = a['checkAssigned'].Name;
            const vA = varA.substring(varA.length - 5, varA.length);
            var varB = b['checkAssigned'].Name;
            const vB = varB.substring(varB.length - 5, varB.length);
            return vA - vB;
        });
        var wrapper = component.get("v.wrapperReturn");
        wrapper[3].value = sortedChecks;
        component.set("v.wrapperReturn",wrapper);
    },
    dataAccumulationSort : function(component, event, helper) {  
        var checkWrapper = component.get("v.wrapperReturn");
        for (var key = 0; key < 2; key++) { 
            var sortedChecks = [];
            sortedChecks = checkWrapper[key].value;
            sortedChecks.sort(function(a, b){
                var col1 = a['checkAssigned'].AV_CDRP_Number_Of_Overdue_Check__c + a['checkAssigned'].AV_CDRP_Number_Of_InReview_Check__c;
                var col2 = b['checkAssigned'].AV_CDRP_Number_Of_Overdue_Check__c + b['checkAssigned'].AV_CDRP_Number_Of_InReview_Check__c;
                var varA = a['checkAssigned'].AV_CDRP_Earliest_Query_Due_By__c;
                var varB = b['checkAssigned'].AV_CDRP_Earliest_Query_Due_By__c;
                return col2 - col1 || varA - varB;
            });
            checkWrapper[key].value = sortedChecks;
         
        }
        var sortedChecks = [];
        sortedChecks = checkWrapper[2].value;
        sortedChecks.sort(function(a, b){
            var col1 = a['checkAssigned'].AV_CDRP_Number_Of_DataAccumulation_Check__c;
            var col2 = b['checkAssigned'].AV_CDRP_Number_Of_DataAccumulation_Check__c;
            var varA = a['checkAssigned'].AV_CDRP_Earliest_Query_Due_By__c;
            var varB = b['checkAssigned'].AV_CDRP_Earliest_Query_Due_By__c;
            return col2 - col1 || varA - varB;
        });
        checkWrapper[2].value = sortedChecks;
        component.set("v.wrapperReturn",checkWrapper);
	},
})