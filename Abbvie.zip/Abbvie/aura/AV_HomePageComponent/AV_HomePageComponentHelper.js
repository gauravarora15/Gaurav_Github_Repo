({
	initHelper : function(component, event, helper) {
		var action = component.get("c.sendBooleanValues");
        action.setCallback(this, function(response) {
            if (response.getState() == "SUCCESS") {
                var wrapperRec = response.getReturnValue();
                console.log('values'+wrapperRec.ApprovalList+'--'+wrapperRec.MMActionItems+'--'+wrapperRec.ObsActionItems+'--'+wrapperRec.Obs+'--'+wrapperRec.MonAct+'--'+wrapperRec.StudyRel+'--'+wrapperRec.Studies);
                component.set("v.displayApprovalList",wrapperRec.ApprovalList);
                component.set("v.displayMMActionItems",wrapperRec.MMActionItems);
                component.set("v.displayObsActionItems",wrapperRec.ObsActionItems);
                component.set("v.displayObs",wrapperRec.Obs);
                component.set("v.displayMonAct",wrapperRec.MonAct);
                component.set("v.displayStudyRel",wrapperRec.StudyRel);
                component.set("v.displayStudies",wrapperRec.Studies);
            }
        });
        $A.enqueueAction(action);
	}
})