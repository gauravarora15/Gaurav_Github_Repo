({
	recordUpdated : function(component, event, helper) {
    	helper.recordUpdatedHelper(component, event, helper);
    },
})