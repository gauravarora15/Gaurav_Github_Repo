({
    getlist : function(component, event, helper) {
        var action = component.get("c.recordlist");//get data from server side controller 
        // action.setStorable();
        action.setCallback(this, function(a) {
            var state = a.getState();
            if(state == "SUCCESS")
            {
                var records = a.getReturnValue();
                records.forEach(function(record){
                    record.linkName = '/'+record.Id;
                }); 
		component.set("v.data", records);
                component.set("v.slist", a.getReturnValue());//set data in the page variable            
                component.set("v.totalPages", Math.ceil(a.getReturnValue().length/component.get("v.pageSize")));
                component.set("v.allData", records);
                component.set("v.currentPageNumber",1);
                component.set("v.itemcount",records.length);
                this.buildData(component, helper);
            }
        });
        $A.enqueueAction(action);
    },
    buildData : function(component, helper) {
        console.log('In builData function');
        var data = [];
        var pageNumber = component.get("v.currentPageNumber");
        var pageSize = component.get("v.pageSize");
        var allData = component.get("v.allData");
        var totalRec = component.get("v.itemcount");
        var x = (pageNumber-1)*pageSize;
        var recSrt= ((pageNumber - 1) * pageSize)+1 ;
        var recEnd = pageSize * pageNumber;
        //creating data-table data
        for(; x<(pageNumber)*pageSize; x++){
            if(allData[x]){
                data.push(allData[x]);
            }
        }
        component.set("v.RecordStart", totalRec != 0 ? recSrt : 0);
        component.set("v.RecordEnd",totalRec >= recEnd ? recEnd : totalRec);
        component.set("v.data", data);
    }
})