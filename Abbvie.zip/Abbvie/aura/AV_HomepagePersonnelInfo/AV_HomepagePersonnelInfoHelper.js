({
	doInitHelper : function(component, event, helper) {
		var userId = $A.get("$SObjectType.CurrentUser.Id");
        var userRec = component.find("UserRecord");
        userRec.set("v.recordId", userId);
        userRec.reloadRecord();
	},
	handleClickHelper: function (component, event, helper) {
        var navEvt = $A.get("e.force:editRecord");
        console.log(component.get("v.User"));
        var ContactId = component.get("v.User.AV_ContactID__c") != null? 
            component.get("v.User.AV_ContactID__c") : component.get("v.User.ContactId");
        navEvt.setParams({
            "recordId": ContactId
        });
        navEvt.fire();
    }
})