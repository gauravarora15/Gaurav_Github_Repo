({
    getStudyReleases : function(component, event, helper) {
        var actions = [
            { label: $A.get('$Label.c.AV_SPT_Edit'), name: 'Edit' }
        ]   
        component.set('v.columns', [ 		
            {label: $A.get('$Label.c.AV_Study_Release_c_Record_Name'), fieldName: 'linkName', type: 'url', 
             typeAttributes: {label: { fieldName: 'Name' }, target: '_blank'}}, 
            {label: $A.get('$Label.c.AV_AssignIRB_ProtoNumLabel'), fieldName: 'linkName1', type: 'url', 
             typeAttributes: {label: { fieldName: 'AV_Protocol_Name__c'}, target: '_blank'}},
            {label: $A.get('$Label.c.AV_Study_Release_Disclosure_Type'), fieldName: 'AV_Disclosure_Type__c', type: 'string'},
            {label: $A.get('$Label.c.AV_Study_Release_Type'), fieldName: 'AV_Study_Release_Type__c', type: 'text'}, 
            {label: $A.get('$Label.c.AV_Compound'), fieldName: 'AV_Compound__c', type: 'string'},
            {label: $A.get('$Label.c.AV_Study_Release_Recruitment_Status'), fieldName: 'AV_Recruitment_Status__c', type: 'text'},
            {label: $A.get('$Label.c.AV_Status'), fieldName: 'AV_Status__c', type: 'text'},
            {label: $A.get('$Label.c.AV_Study_Release_Date_Last_Modified'), fieldName: 'LastModifiedDate', type: 'text' },           
            {type: 'action', typeAttributes: { rowActions: actions } } 
        ]); 
         
    },
    
    handleRowAction: function (component, event, helper) {
        var action = event.getParam('action');
        var row = event.getParam('row');
        switch (action.name) {
            case 'Edit':
                var editRecordEvent = $A.get("e.force:navigateToComponent");                 
                editRecordEvent.setParams({
                    componentDef : "c:AV_EditButtonOverride",
                    componentAttributes: {
                        "recordId": row.Id
                    }
                });
                editRecordEvent.fire();
                $A.get('e.force:refreshView').fire(); 
        }
    },
    
    onNext : function(component, event, helper) {        
        var pageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", pageNumber+1);
        helper.buildData(component, helper);
    },
    
    onPrev : function(component, event, helper) {        
        var pageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", pageNumber-1);
        helper.buildData(component, helper);
    },
    
    processMe : function(component, event, helper) {
        component.set("v.currentPageNumber", parseInt(event.target.name));
        helper.buildData(component, helper);
    },

    onScriptLoad: function(component, event, helper) {    
    helper.getStudyReleases(component, event, helper);//get data from the helper    
    }
})