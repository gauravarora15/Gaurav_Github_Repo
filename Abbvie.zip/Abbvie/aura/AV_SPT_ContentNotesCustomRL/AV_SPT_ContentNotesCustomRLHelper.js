({
    initHelper : function(component, event, helper){
        component.set("v.currentTZ", $A.get("$Locale.timezone"));
        var recordSize = component.get("v.recordLimit");
        var numRecSize = Number(component.get('v.recordLimit'));
        var action = component.get("c.fetchRelatedNotes");
        action.setParams({
            "documentFolderId" : component.get("v.recordId"),
            "recordLimit" : recordSize
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log('response ',response.getReturnValue());
            console.log(state);
            if(state === 'SUCCESS'){
                component.set("v.allNoteList", response.getReturnValue().noteList);
                    component.set("v.hasMoreRecs",response.getReturnValue().hasMoreRecs);
            }
        }); 
        
        $A.enqueueAction(action);

    },
    
    saveNote : function(component, event, helper){
        var action = component.get("c.saveContentNote");
        
        var contentNote=component.get("v.note");
        if(helper.validateInput(component, event, helper)){
        action.setParams({            
            "contentNote" : contentNote,
            "LinkedEntityId" : component.get("v.recordId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log('response ',response.getReturnValue());
            console.log(state);
            if(state === 'SUCCESS'){
                component.set("v.isOpen", false);
                location.reload();                
            }
        }); 
        
            $A.enqueueAction(action);
        }
    },
    
      editNote : function(component, event, helper){
        var action = component.get("c.getNoteById");
        action.setParams({            
            "id" : event.currentTarget.getAttribute("data-id")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log('response ',response.getReturnValue());
            console.log(state);
            if(state === 'SUCCESS'){
                var noteWrapper=response.getReturnValue();
                var note=noteWrapper.note;
                note.Content=noteWrapper.encodedContent;
                component.set("v.note",note);
                component.set("v.isOpen", true);
                component.set("v.hasDeletePer", noteWrapper.hasDeletePer);  
            }
        }); 
        
        $A.enqueueAction(action);
    },
    validateInput:function(component, event, helper){ 
        var title=component.find("title").get("v.value");
        if(title==null || title==""){
            return false;
        }
        return true
    },
    
    deleteNote : function(component, event, helper){
        var action = component.get("c.deleteContentNote");        
        var contentNote=component.get("v.note");
            action.setParams({            
            "contentNote" : contentNote,
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(state);
            if(state === 'SUCCESS'){
                location.reload();                
            }
        }); 
            $A.enqueueAction(action);
    },
    showAll : function (component, event, helper) {
        var currentVal = component.get('v.showViewAll');
         if((currentVal == false) || (component.get("v.hasMoreRecs"))){
        if(currentVal == false) {
                component.set('v.showViewAll', true);
                var tempLst = [];
                var recLst = component.get("v.allNoteList");
            	var size=component.get('v.recordLimit');
            if(size>=component.get("v.allNoteList").length)
                size=component.get("v.allNoteList").length;
                for(var i=0; i<size; i++){
                    tempLst.push(recLst[i]);
                }
                component.set("v.allNoteList", tempLst);
            component.set("v.hasMoreRecs", true);
        }else{
        var action = component.get("c.fetchRelatedNotes");
        action.setParams({
            "documentFolderId" : component.get("v.recordId"),            
            "recordLimit" : ""
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log('response ',response.getReturnValue());
            console.log(state);
            if(state === 'SUCCESS'){                
                component.set("v.showViewAll", false);
                component.set("v.allNoteList", response.getReturnValue().noteList);
                component.set("v.hasMoreRecs",false);
            }
        });         
        $A.enqueueAction(action);
    }
        }
	    }
})