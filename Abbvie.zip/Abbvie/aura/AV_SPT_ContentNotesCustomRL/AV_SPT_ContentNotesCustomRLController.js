({
    doInit : function(component, event, helper){
        helper.initHelper(component, event, helper);
    },

        
    openModel: function(component, event, helper) {
        component.set("v.isOpen", true); 
      },

    editNote: function(component, event, helper) {
       helper.editNote(component, event, helper);       
    },

    saveNote:function(component, event, helper){
        helper.saveNote(component, event, helper);
    },
    closeModel : function (component, event, helper) {
         component.set("v.isOpen", false);
        component.set("v.note",{'sobjectType':'ContentNote',
                'Title': '',
                'Content': ''
      });
    },
    
    hideDeletePopUp : function(component, event, helper) {
        component.set("v.openDelete", false); 
        component.set("v.isOpen", true); 
      },
 
 showDeletePopup : function(component, event, helper) {
        component.set("v.openDelete", true); 
     component.set("v.isOpen", false); 
      },
    
    deleteNote : function(component, event, helper) {
       helper.deleteNote(component, event, helper); 
      }, 
    
    showAll: function(component, event, helper) {
       helper.showAll(component, event, helper); 
      }, 

    
})