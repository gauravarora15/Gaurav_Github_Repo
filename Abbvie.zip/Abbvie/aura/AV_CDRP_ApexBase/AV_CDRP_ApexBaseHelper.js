({
    /*
     * This method will call the server side action and will execute callback method
     * it will also show error if generated any
     * @param component (required) - Calling component
     * @param method (required) - Server side methos name
     * @param callback (required) - Callback function to be executed on server response
     * @param params (optional) - parameter values to pass to server
     * @param setStorable(optional) - if true, action response will be stored in cache
     * */
    callServer : function(component, method, callback, params, setStorable) {
        var action = component.get(method);
        
        //Set params if any
        if (params) {
            action.setParams(params);
        }
        
        if(setStorable){
            action.setStorable();
        }
        
        action.setCallback(this,function(response) {
            var state = response.getState();
            if (state === "SUCCESS") { 
                // pass returned value to callback function
                callback.call(this,response.getReturnValue());   
            } else if (state === "ERROR") {
                // generic error handler
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                    helper.showToast('ERROR', 'ERROR', errors[0].message);
                    }
                } else {
                    helper.showToast('ERROR', 'ERROR', $A.get("$Label.c.AV_CDRP_ErrorMessage"));
                }
            }
        });
        
        $A.enqueueAction(action);
    },


    followRecord: function (cmp,event, helper, row) {
        var rows = cmp.get('v.rawData');
        var rowIndex = rows.indexOf(row);
        //var recordId = component.get("v.recordId");
        var action=cmp.get("c.setFollowRecord");
        action.setParams({
            "recordId" : rows[rowIndex]['Id'],
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS")
            {
                rows[rowIndex]['isFollowed'] = true;
                helper.showToast('SUCCESS', 'SUCCESS', $A.get("$Label.c.AV_CDRP_FollowSuccess"));

            }
            else if(state === "ERROR")
            {
                helper.showToast('ERROR', 'ERROR', $A.get("$Label.c.AV_CDRP_ErrorMessage"));
            }
        });
        $A.enqueueAction(action);
    },
    unFollowRecord: function (cmp,event, helper, row) {
        var rows = cmp.get('v.rawData');
        var rowIndex = rows.indexOf(row);
        //var recordId = component.get("v.recordId");
        var action=cmp.get("c.setUnFollowRecord");
        action.setParams({
            "recordId" : rows[rowIndex]['Id'],
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS")
            {
                rows[rowIndex]['isFollowed'] = false;
                helper.showToast('SUCCESS', 'SUCCESS', $A.get("$Label.c.AV_CDRP_UnFollowSuccess"));
            }
            else if(state === "ERROR")
            {
                helper.showToast('ERROR', 'ERROR', $A.get("$Label.c.AV_CDRP_ErrorMessage"));
            }
        });
        $A.enqueueAction(action);
    },

    /*
     * This function displays toast based on the parameter values passed to it
     * */
    showToast: function (toastTitle, toastType, toastMessage) {
	var toastEvent = $A.get("e.force:showToast");
	toastEvent.setParams({
		"title": toastTitle,
		"type": toastType,
		"message": toastMessage
	});
	toastEvent.fire();
},
})