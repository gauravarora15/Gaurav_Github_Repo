({
	getObservations : function(component, event, helper) {
        var actions = [
            { label: $A.get('$Label.c.AV_SPT_Edit'), name: 'Edit' }
        ]
        component.set('v.columns', [ 		
            {label: $A.get('$Label.c.AV_Observation_c_Observation_Risk_Name'), fieldName: 'linkName', type: 'url', 
            typeAttributes: {label: { fieldName: 'Name' }, target: '_blank'}},
            {label: $A.get('$Label.c.AV_Related_Study_MM'), fieldName: 'AV_Related_Study_Name_ET__c', type: 'text'},
        	{label: $A.get('$Label.c.AV_Category'), fieldName: 'AV_Category__c', type: 'string'},
            {label: $A.get('$Label.c.AV_Subcategory'), fieldName: 'AV_Subcategory__c', type: 'text'},
            {label: $A.get('$Label.c.AV_Additional_Information'), fieldName: 'AV_Additional_Information__c', type: 'string'},
            {label: $A.get('$Label.c.AV_Isthisanissue'), fieldName: 'AV_Is_this_an_issue__c', type: 'text'},
            {label: $A.get('$Label.c.AV_Observation_c_Observation_Risk_Status'), fieldName: 'AV_Status__c', type: 'text'},
            //{label: $A.get('$Label.c.AV_Observation_c_Age_From_Creation_Date'), fieldName: 'AV_Age_from_creation_date__c', type: 'number'},
           	{label: $A.get('$Label.c.AV_Observation_c_Age_From_Creation_Date'), fieldName: 'linkName2', type: 'text', 
             typeAttributes: {label: { fieldName: 'AV_Age_from_creation_date__c' }}},
            {type: 'action', typeAttributes: { rowActions: actions } } 
        ]);
       helper.getObservations(component);//get data from the helper
            },
           
        handleRowAction: function (component, event, helper) {
        var action = event.getParam('action');
        var row = event.getParam('row');
        switch (action.name) {
            case 'Edit':
            var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
              "url": "/apex/AV_CreateEditObservationsPage?id="+row.Id+"&homePageEdit="+true,
              "isredirect": "true"
            });
            urlEvent.fire();
                break;
        }
    },
   handleSelect: function (component, event, helper) {
    var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
              "url": "/apex/AV_CreateEditObservationsPage?retURL="+"/"+"&homePageEdit="+true,
              "isredirect": "true"
            });
            urlEvent.fire();
    },
     onNext : function(component, event, helper) {        
        var pageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", pageNumber+1);
        helper.buildData(component, helper);
    },
    
    onPrev : function(component, event, helper) {        
        var pageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", pageNumber-1);
        helper.buildData(component, helper);
    },
    
    processMe : function(component, event, helper) {
        component.set("v.currentPageNumber", parseInt(event.target.name));
        helper.buildData(component, helper);
    }
})