({
    toggleMore: function (component, event) {
        var moreClicked = component.get("v.moreClicked");
        moreClicked = moreClicked ? false : true;
        component.set("v.moreClicked", moreClicked);
    },

    doInit: function (component, event, helper) {
        helper.doInitialAction(component, event, helper);
    },

    handleSelect: function (cmp, event, helper) {
        // This will contain the string of the "value" attribute of the selected
        // lightning:menuItem
        var selectedMenuItemValue = event.getParam("value");
        if (selectedMenuItemValue === 'SearchQuery') {
            helper.handleSearchQuery(cmp, event, helper);
        } else if (selectedMenuItemValue === 'NewTask') {
            helper.handleNewTask(cmp, event, helper);
        } else if (selectedMenuItemValue === 'NewObservation') {
            helper.createNewObservation(cmp, event, helper);
        } else if (selectedMenuItemValue === 'SearchObservation') {
            helper.createSearchObservation(cmp, event, helper);
        } else if (selectedMenuItemValue === 'CompleteIDRPCheck') {
            helper.completeIDRPCheck(cmp, event, helper);
        }
        //alert("Menu item selected with value: " + selectedMenuItemValue);
    },
    navigationToPage: function (component, event, helper) {
        helper.navigationToPage(component, event, helper);
    },

    openRecord: function (component, event, helper) {
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
            "recordId": component.get("v.checkData.Id")
        });
        navEvt.fire();
    },
    launchQueryPageOnButtonClick: function (component, event, helper) {
        var key = event.getSource().getLocalId();
        if (key == 'inreview')
            var reviewstatusIA = 'In Review';
        if (key == 'overdue')
            var reviewstatusIA = 'Overdue';
        if (key == 'inacc')
            var reviewstatusIA = 'In Data Accumulation';
        helper.launchQueryPage(component, event, helper, reviewstatusIA);
    },
    launchQueryPage: function (component, event, helper) {
        helper.launchQueryPage(component, event, helper, '');
    },
    // this function automatic call by aura:waiting event  
    showSpinner: function (component, event, helper) {
        // make Spinner attribute true for display loading spinner 
        component.set("v.Spinner", true);
    },

    // this function automatic call by aura:doneWaiting event 
    hideSpinner: function (component, event, helper) {
        // make Spinner attribute to false for hide loading spinner    
        component.set("v.Spinner", false);
    }

})
