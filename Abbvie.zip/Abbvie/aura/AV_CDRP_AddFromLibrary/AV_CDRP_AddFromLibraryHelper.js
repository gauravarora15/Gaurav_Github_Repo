({
	//doInit method to call server side method and load values
	doInitHelper : function(component,event,helper) {
		var recordId = component.get("v.recordId");
		//component.set("v.Spinner",true);
		 component.set("v.messageText", '');
        component.set("v.totalRecords", 0);
        component.set("v.pageNumber", 0);
        component.set("v.endPage", 0);
		component.set("v.startPage", 0);
		component.set("v.lstLibraryChecks",'');
		component.find("select").set("v.value", "All");
		helper.clearLookup(component, event, helper);

		helper.callServer(component, "c.getValuesOnLoad",
		function(response){
			 var result = response;
			component.set("v.libCheckDetails",response);
			component.set('v.myColumns', [	
				{
						label: 'IDRP LIBRARY CHECK ID',
						fieldName: 'idrpLibraryCheckIdLink',
						type: 'url',
						cellAttributes: {
								class: {
										fieldName: 'ClassName'
								}
						},
						typeAttributes: {
								label: {
										fieldName: 'name'
								}
						},
						sortable: true
				},
				{
						label: 'PURPOSE',
						fieldName: 'purpose',
						type: 'text',
						cellAttributes: {
								class: {
										fieldName: 'ClassName'
								}
						},
						sortable: true
				},
				{
						label: 'DATA CATEGORY',
						fieldName: 'dataCategory',
						type: 'text',
						cellAttributes: {
								class: {
										fieldName: 'ClassName'
								}
						},
						sortable: true
				},
				{
					label: 'DESCRIPTION',
					fieldName: 'description',
					type: 'text',
					cellAttributes: {
							class: {
									fieldName: 'ClassName'
							}
					},
					sortable: true
			},
			{
				label: 'QUERY TEXT',
				fieldName: 'queryText',
				type: 'text',
				cellAttributes: {
						class: {
								fieldName: 'ClassName'
						}
				},
				sortable: false
	    	},
				{
						label: 'ROLE',
						fieldName: 'role',
						type: 'text',
						cellAttributes: {
								class: {
										fieldName: 'ClassName'
								}
						},
						sortable: true
				},
				{
						label: 'METHOD',
						fieldName: 'method',
						type: 'text',
						cellAttributes: {
								class: {
										fieldName: 'ClassName'
								}
						},
						sortable: true
				},
				{
						label: 'FREQUENCY',
						fieldName: 'frequency',
						type: 'text',
						cellAttributes: {
								class: {
										fieldName: 'ClassName'
								}
						},
						sortable: true
				}
		]);
		    component.set("v.selectedValues", result.filterWrapRec);
			helper.showMultiSelectOptions(component, event , helper);
			
		}
			
		);
	},
	//Clear lookup
	clearLookup : function (component, event, helper) {   
        var appEvent = $A.get("e.c:AV_CDRP_GenericLookupClearEvent"); 
        // set the Selected sObject Record to the event attribute.  
        //appEvent.setParams({"action" : "clear" }); 
        appEvent.setParams({ "action" : "clear" });
 
        // fire the event  
        appEvent.fire(); 
    },
		// Method to show the Multi Select Picklist values
		showMultiSelectOptions: function(component, event, helper){
			var libCheckDetails = component.get("v.libCheckDetails");
			var stdcheckgroupingOptions = libCheckDetails.stdcheckgrouping;
			var purposeOptions = libCheckDetails.purpose; 
			var methodOptions = libCheckDetails.method;

			var optionspurpose = [];
			var optionsstdcheckgrouping = [];
			var optionsmethod =[];
			for(var i = 0;i<stdcheckgroupingOptions.length;i++){
			 		var Option = {};
					Option.Name = stdcheckgroupingOptions[i];
					Option.isSelected = false;
					Option.Id = stdcheckgroupingOptions[i];
					optionsstdcheckgrouping.push(Option);
			} 
			for(var i = 0;i<purposeOptions.length;i++){
					var Option = {};
					Option.Name = purposeOptions[i];
					Option.isSelected = false;
					Option.Id = purposeOptions[i];
					optionspurpose.push(Option);
			}
			for(var i = 0;i<methodOptions.length;i++){
				var Option = {};
				Option.Name = methodOptions[i];
				Option.isSelected = false;
				Option.Id = methodOptions[i];
				optionsmethod.push(Option);
			}
			component.set("v.stdCheckGroupingLst", optionsstdcheckgrouping);
			component.set("v.purposeList",optionspurpose);
			component.set("v.methodList",optionsmethod);
		}, 
	//Method to handle all the button actions according to the User Selection
	userSelect: function(component, event, helper){
	  var key = event.getSource().getLocalId();
	  if (key === 'addCon' || key === 'addExit') {
		let button = event.getSource();
    button.set('v.disabled',true);
		helper.handleAddCon(component, event, helper, key);
		}
      else if(key === 'exit' || key === 'cancel'){
				//window.history.back();
          		var recordId = component.get("v.recordId");
          		window.location.assign('/'+component.get("v.recordId"));
			 }
	  else if (key === 'search') {
			helper.handleSearch(component, event, helper);
		}
	  else if(key === 'clear'){
		  helper.doInitHelper(component,event,helper);
	  } 
		
   },
		

   //Handling adding of IDRP Checks
   handleAddCon:function(component,event,helper,key)
   {
		component.set("v.messageText", '');
		component.set("v.Spinner", true);
		var action = component.get("c.createIDRPCheck");
		action.setParams({
            "response": JSON.stringify(component.get("v.selectedCheckList")),
            "parentId": component.get("v.recordId")
		});
		action.setCallback(this, function (response) {
			var state = response.getState();
			let button = event.getSource();
			button.set('v.disabled',false);
				if (state === "SUCCESS") {
						var resp = response.getReturnValue();
						
						if(resp.substring(0, 141) ===$A.get("$Label.c.AV_CDRP_Lib_Check_General_Error") + ' ' + $A.get("$Label.c.AV_CDRP_Data_Category_not_present_in_IDRP")){ 
							
							component.set("v.messageType", 'error');
							component.set("v.messageText", resp);

						}else{
						if (key === 'addCon')
						{
							

							component.set("v.messageText", resp); 
							if(resp === $A.get("$Label.c.AV_CDRP_ErrorMessage"))
								component.set("v.messageType", 'error');
							else if(resp.substring(0, 120) === $A.get("$Label.c.AV_CDRP_Lib_Check_General_Error") + ' ' + $A.get("$Label.c.AV_CDRP_Checks_already_present_in_IDRP")) 
								component.set("v.messageType", 'error');
							else if(resp === $A.get("$Label.c.AV_CDRP_Associated_Risk_Success_Message")){
								var selectedList = component.get("v.selectedCheckList");
								var objList = [];
								for (var i = 0; i < selectedList.length; i++) {
										objList.push(selectedList[i].libraryCheckId);
								}
								var totalList = component.get("v.lstLibraryChecks");
								for (var i = 0; i < totalList.length; i++) {
										if (objList.indexOf(totalList[i].libraryCheckId) !== -1) {
												totalList[i].ClassName = "table-rowColor";
										}

								}
								component.set("v.messageType", 'confirm'); 
								component.set("v.lstLibraryChecks", totalList);

							}
                            else
                            {
                                component.set("v.messageType",'error');
                            }
						} 
						else if(key === 'addExit')
						
						{
						
							if(resp === $A.get("$Label.c.AV_CDRP_ErrorMessage"))
							{
								component.set("v.messageType", 'error');
								component.set("v.messageText", resp);
							}
							else if(resp.substring(0, 120) === $A.get("$Label.c.AV_CDRP_Lib_Check_General_Error") + ' ' + $A.get("$Label.c.AV_CDRP_Checks_already_present_in_IDRP"))
							{
								component.set("v.messageType", 'error');
								component.set("v.messageText", resp);
							}
                                else if(component.get("v.selectedCheckList").length==0){
                                   // window.history.back();
                                   window.location.assign('/'+component.get("v.recordId"));
                                }
							else if(resp===$A.get("$Label.c.AV_CDRP_Associated_Risk_Success_Message"))
							{
								//window.history.back();
								window.location.assign('/'+component.get("v.recordId"));
								helper.showToast('SUCCESS', 'SUCCESS', $A.get("$Label.c.AV_CDRP_Associated_Risk_Success_Message"));
							}                          
							else{
								component.set("v.messageType", 'error');
								component.set("v.messageText", resp);
							}
						}
				}
			}
		});
		$A.enqueueAction(action);
   },

// Event Method to handle the Multiseelect Picklist values
handleMultiSelect: function (component, event, helper) {
	if (event.getSource().get("v.multiselectLabel") == "Standard Check Grouping") {
			var standardGroupings = event.getParam("optionIds");
			var selectedStandardGroupingsIds;
			for (var i in standardGroupings) {
					if (i == 0) {
						selectedStandardGroupingsIds = standardGroupings[i];
					} else {
							if (selectedStandardGroupingsIds.indexOf(standardGroupings[i]) === -1) {
								selectedStandardGroupingsIds = selectedStandardGroupingsIds + ',' + standardGroupings[i];
							}
					}
			}
			component.set("v.selectedValues.standadCheckGrouping", selectedStandardGroupingsIds); 
	}

	if (event.getSource().get("v.multiselectLabel") == "Purpose") {
			//var subCategoryPLIds = event.getParam("selectedItem");
			var purposeData = event.getParam("optionIds");
			var purposeIds;
			for (var i in purposeData) {
					if (i == 0) {
						purposeIds = purposeData[i];
					} else {
							if (purposeIds.indexOf(purposeData[i]) === -1) {
								purposeIds = purposeIds + ',' + purposeData[i];
							}
					}
			}
			component.set("v.selectedValues.cdrpCheckPurpose", purposeIds); 
	}

	if (event.getSource().get("v.multiselectLabel") == "Method") {
			var methodData = event.getParam("optionIds");
			var methodIds;

			for (var i in methodData) {
					if (i == 0) {
						methodIds = methodData[i];
					} else {
							if (methodIds.indexOf(methodData[i]) === -1) {
								methodIds = methodIds + ',' + methodData[i];
							}
					}
			}
			component.set("v.selectedValues.cdrpCheckMethod", methodIds);
	}
},

// Method to get the library checks Records according to the search criteria
handleSearch: function (component, event, helper) {
	
	component.set("v.messageText",'');  
 
	component.set("v.completeLibraryChecks" , []); 
	component.set('v.lstLibraryChecks', []);
	component.set("v.selectedCheckList",[]);

	component.set("v.selectedValues.cdrpCheckRole", component.get("v.selectedRoleRecords"));
	component.set("v.selectedValues.cdrpDataCategory", component.get("v.selectedCategoryRecords"));
	var includeChecks = component.find('select').get('v.value');

	var selectedFilters = JSON.stringify(component.get("v.selectedValues"));
	var idrpId = component.get("v.recordId");
	var action = component.get("c.getSearchResults");
	action.setParams({ 
			"searchFilters": selectedFilters,
			"idrpId" :idrpId,
			"includeChecks" :includeChecks
	});
	action.setCallback(this, function (response) { 
			var state = response.getState();
			if (state === "SUCCESS") {
					var responseVar = response.getReturnValue();
					if ($A.util.isEmpty(responseVar.errorMessage) || $A.util.isUndefinedOrNull(responseVar.errorMessage)) {
							component.set("v.messageText", '');


							var pageSize = component.get("v.pageSize");
							var completeList = responseVar.searchResults;
							component.set("v.totalRecords", completeList.length);
							component.set("v.startPage", 0);
							component.set("v.endPage", pageSize);
							component.set("v.pageNumber", 1);
							var objList = [];
							for (var j = 0; j < completeList.length; j++) {
									var obj = {};
									obj = completeList[j];
									if (completeList[j].isSelected) {
											obj.ClassName = "table-rowColor";

									} else {
											obj.ClassName = "";
									}
									objList.push(obj);
							}
							component.set("v.completeLibraryChecks", objList);

							var completeRecords = component.get("v.completeLibraryChecks");
							var paginationList = [];
							for (var i = 0; i < pageSize; i++) {
									if (objList.length > i)
											paginationList.push(objList[i]);
							}
							component.set("v.selectedCheckList" , []); 
							component.set('v.lstLibraryChecks', paginationList);


					} else {
							component.set("v.messageText", responseVar.errorMessage);
							component.set("v.messageType", 'error');
							component.set("v.lstLibraryChecks", []);
							component.set("v.totalRecords", 0);
							component.set("v.pageNumber", 0);
							component.set("v.endPage", 0);
                            component.set("v.startPage", 0);
					}
			} else if (state === "INCOMPLETE") {

					component.set("v.Spinner", false);
					helper.showToast('ERROR', 'ERROR', $A.get("$Label.c.AV_CDRP_ErrorMessage"));
			} else if (state === "ERROR") {
					component.set("v.Spinner", false);
					helper.showToast('ERROR', 'ERROR', $A.get("$Label.c.AV_CDRP_ErrorMessage"));

			}
			component.set("v.Spinner", false);

	});
	$A.enqueueAction(action);

},


showToast: function (toastTitle, toastType, toastMessage) {
	var toastEvent = $A.get("e.force:showToast");
	toastEvent.setParams({
		"title": toastTitle,
		"type": toastType,
		"message": toastMessage
	});
	toastEvent.fire();
},

//Method for sorting the each columnn

handleSort: function (component, event, helper) {
	component.set('v.Spinner', true);
	// We use the setTimeout method here to simulate the async
	// process of the sorting data, so that user will see the
	// spinner loading when the data is being sorted.
	setTimeout(function () {
		var fieldName = event.getParam('fieldName');
		var sortDirection = event.getParam('sortDirection');
		component.set("v.sortedBy", fieldName);
		component.set("v.sortedDirection", sortDirection);
		helper.sortData(component, helper, fieldName, sortDirection);
		component.set('v.Spinner', false);
	}, 0);

},
sortData: function (component, helper, fieldName, sortDirection) {
	var data = component.get("v.lstLibraryChecks");
	var reverse = sortDirection !== 'asc';

	data = Object.assign([],
		data.sort(this.sortBy(fieldName, reverse ? -1 : 1))
	);
	component.set("v.lstLibraryChecks", data);
},
sortBy: function (field, reverse, primer) {
	var key = primer ?
		function (x) {
			return primer(x[field])
		} :
		function (x) {
			return x[field]
		};

	return function (a, b) {
		var A = key(a);
		var B = key(b);
		return reverse * ((A > B) - (B > A));
	};
},

//Handle the Previous Button Pagination
handlePrevious: function (component, event, helper) {
	component.set("v.messageText", '');
	component.set("v.Spinner", true);
	var sObjectList = component.get("v.completeLibraryChecks");
	var end = component.get("v.endPage");
	var start = component.get("v.startPage");
	var pageSize = component.get("v.pageSize");
	var previousPageNumber = component.get("v.pageNumber") - 1;
	component.set("v.pageNumber", previousPageNumber);
	var paginationList = [];
	var counter = 0;
	for (var i = start - pageSize; i < start; i++) {
		if (i > -1) {
			paginationList.push(sObjectList[i]);
			counter++;
		} else {
			start++;
		}
	}
	start = start - counter;
	end = end - counter;
	component.set("v.startPage", start);
	component.set("v.endPage", end);
	component.set("v.lstLibraryChecks", []);
	component.set("v.lstLibraryChecks", paginationList);
	component.set("v.Spinner", false);
	document.getElementsByClassName('modal-dialog')[0].scrollTop=0;
},

// Handle the Next button Pagination
handleNext: function (component, event, helper) {
	component.set("v.messageText", '');
	component.set("v.Spinner", true);
	var sObjectList = component.get("v.completeLibraryChecks");
	var end = component.get("v.endPage");
	var start = component.get("v.startPage");
	var pageSize = component.get("v.pageSize");
	var pageNumber = end / pageSize;
	var nextPageNumber = component.get("v.pageNumber") + 1;
	component.set("v.pageNumber", nextPageNumber);
	var paginationList = [];
	var counter = 0;
	for (var i = end; i < end + pageSize; i++) {
		if (sObjectList.length > i) {
			paginationList.push(sObjectList[i]);
		}
		counter++;
	}
	start = start + counter;
	end = end + counter;
	component.set("v.startPage", start);
	component.set("v.endPage", end);
	component.set("v.lstLibraryChecks", []);
	component.set('v.lstLibraryChecks', paginationList);
	component.set("v.Spinner", false);
	document.getElementsByClassName('modal-dialog')[0].scrollTop=0;
},
// Event Method to get the selected rows
handleRowsSelection: function (component, event, helper) {
	var selectedRows = event.getParam('selectedRows');
	component.set("v.selectedCheckList", selectedRows);
},


})