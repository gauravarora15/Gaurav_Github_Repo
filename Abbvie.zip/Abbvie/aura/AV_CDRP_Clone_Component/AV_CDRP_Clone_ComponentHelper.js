({
    //method is called on the click of the button and makes a server call to make the cloned record
    doInit: function (component, event, helper) {
        var action = component.get("c.cloneRecord");
        var recordIdVar = component.get("v.recordId");
        action.setParams({
            'recordId': recordIdVar
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.displaySpinner", false);

                var responseVar = response.getReturnValue();
                if (!$A.util.isEmpty(responseVar) && !$A.util.isUndefined(responseVar)) {
                    if (responseVar.message == $A.get("$Label.c.AV_CDRP_Plan_Clone_In_Not_Approved_Status_Error")) {
                        helper.showToast('ERROR', 'ERROR', $A.get("$Label.c.AV_CDRP_Plan_Clone_In_Not_Approved_Status_Error"));
                    } else if (responseVar.message == $A.get("$Label.c.AV_CDRP_Clone_Trajectory_Access_Error")) {
                        helper.showToast('ERROR', 'ERROR', $A.get("$Label.c.AV_CDRP_Clone_Trajectory_Access_Error"));
                    } else if (responseVar.message == $A.get("$Label.c.AV_CDRP_IDRP_More_Than_One_Clone_In_Draft")) {
                        helper.showToast('ERROR', 'ERROR', $A.get("$Label.c.AV_CDRP_IDRP_More_Than_One_Clone_In_Draft"));
                    } else if (responseVar.message == $A.get("$Label.c.AV_CDRP_Data_Trajectory_Edit_Validation_Message")) {
                        helper.showToast('ERROR', 'ERROR', $A.get("$Label.c.AV_CDRP_Data_Trajectory_Edit_Validation_Message"));
                    }
                    //in success clone record creation scenario 
                    else if (responseVar.message != $A.get("$Label.c.AV_CDRP_ErrorMessage")) {
                        // page reference is used to navigate to the newly generated cloneed record.
                        var pageReference = {
                            type: "standard__recordPage",
                            attributes: {
                                "recordId": responseVar.recordId,
                                "objectApiName": responseVar.objectRecordName,
                                "actionName": "view"
                            }
                        };
                        component.set("v.pageReference", pageReference);
                        var navService = component.find("navService");
                        var pageReference = component.get("v.pageReference");
                        navService.navigate(pageReference);
                        if (responseVar.objectRecordName == 'AV_CDRP_Data_Trajectory__c') {
                            helper.showToast('SUCCESS', 'SUCCESS', $A.get("$Label.c.AV_CDRP_Trajectory_Modify_Success_Message")); 
                        } else {
                            helper.showToast('SUCCESS', 'SUCCESS', $A.get("$Label.c.AV_CDRP_IDRP_Modify_Success_Message"));
                        }
                    } else {
                        helper.showToast('ERROR', 'ERROR', responseVar.message);
                    }
                }
            } else if (state === "INCOMPLETE") {
                component.set("v.displaySpinner", false);
                helper.showToast('ERROR', 'ERROR', $A.get("$Label.c.AV_CDRP_ErrorMessage"));
            } else if (state === "ERROR") {
                component.set("v.displaySpinner", false);
                let errors = response.getError();
                helper.showToast('ERROR', 'ERROR', errors[0].message);
            }
        });
        $A.enqueueAction(action);
    },

    showToast: function (toastTitle, toastType, toastMessage) {
        $A.get("e.force:closeQuickAction").fire();
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": toastTitle,
            "type": toastType,
            "message": toastMessage
        });
        toastEvent.fire();
    }
})