({
	fromAddress : function(component, event, helper) {
		var action = component.get("c.getFromEmailList");
        action.setCallback(this, function(response) {
        	if (response.getState() == "SUCCESS") {
                var fromValues = response.getReturnValue();
                component.set("v.fromEmail",'"'+fromValues.name + '"' +'<' + fromValues.emailAdd +'>');
            }
        });
        var action2 = component.get("c.sendEmailFields");
        action2.setParams({
            Id : component.get("v.recordId")
        });
        
        action2.setCallback(this, function(response) {
            if (response.getState() == "SUCCESS") {
                var wrapperRec = response.getReturnValue();
                component.set("v.objRecord",wrapperRec.objRec);
                component.set("v.body",wrapperRec.previewEmail);
                //component.set("v.name",wrapperRec.obsRec.AV_Principal_Investigator_Name_ET__c);
                if(wrapperRec.bccAddr!= undefined || wrapperRec.bccAddr!= null){
                	component.set("v.bccEmail",wrapperRec.bccAddr);
                    var strBcc = wrapperRec.bccAddr;
                    var splitStringBcc = [];
                    splitStringBcc = strBcc.split(',');
                    component.set("v.BCCList",splitStringBcc);
                    console.log('BCC List :' + component.get('v.BCCList'));

                }else{
                    component.set("v.bccEmail",null);
                }
                if(wrapperRec.toAddr!= undefined || wrapperRec.toAddr!= null){
                    component.set("v.toEmail",wrapperRec.toAddr);
                    var strTo = wrapperRec.toAddr;
                    var splitStringTo = [];
                    splitStringTo = strTo.split(',');
                    component.set("v.ToList",splitStringTo);
                }else{
                    component.set("v.toEmail",null);
                }
                if(wrapperRec.ccAddr!= undefined || wrapperRec.ccAddr!= null){
                    component.set("v.ccEmail",wrapperRec.ccAddr);
                    var strCC = wrapperRec.ccAddr;
                    var splitStringcc = [];
                    splitStringcc = strCC.split(',');
                    component.set("v.CCList",splitStringcc);
                }else{
                    component.set("v.ccEmail",null);
                }               
            
                component.set("v.subject",wrapperRec.subject);
                component.set("v.Returl",wrapperRec.Returl);

             }
        });
        $A.enqueueAction(action);
        $A.enqueueAction(action2);
	},
    handleSendEmail : function(component, event, helper) {
        var csvString = '';
        var toEmailLst = [];
        toEmailLst = component.get("v.ToList");
        if(!$A.util.isEmpty(toEmailLst)){
            for(var i=0; i<toEmailLst.length; i++){
                csvString = csvString + toEmailLst[i] + ',';
            }
            if(csvString.length>0){
                csvString = csvString.substr(0, csvString.length-1);
                component.set("v.toEmail", csvString);
            }
        }
        else{
            component.set("v.toEmail", '');
        }
        csvString = '';
        var ccEmailLst = [];
        ccEmailLst = component.get("v.CCList");
        if(!$A.util.isEmpty(ccEmailLst)){
            for(var i=0; i<ccEmailLst.length; i++){
                csvString = csvString + ccEmailLst[i] + ',';
            }
            if(csvString.length>0){
                csvString = csvString.substr(0, csvString.length-1);
                component.set("v.ccEmail", csvString);
            }
        }
        else{
            component.set("v.ccEmail", '');
        }
        csvString = '';
        var bccEmailLst = [];
        bccEmailLst = component.get("v.BCCList");
        if(!$A.util.isEmpty(bccEmailLst)){
            for(var i=0; i<bccEmailLst.length; i++){
                csvString = csvString + bccEmailLst[i] + ',';
            }
            if(csvString.length>0){
                csvString = csvString.substr(0, csvString.length-1);
                component.set("v.bccEmail", csvString);
            }
        }
        else{
            component.set("v.bccEmail", '');
        }

    	var toaddr = component.get("v.toEmail");
        var ccaddr = component.get("v.ccEmail");
        var atCountTo,comCountTo,atCountCc,comCountCc;
        var check=false;

        if(toaddr != '' && toaddr != null){
            atCountTo = toaddr.split('@').length-1;
            comCountTo = toaddr.split(',').length;
        }
        if(ccaddr != '' && ccaddr != null){
            atCountCc = ccaddr.split('@').length-1;
            comCountCc = ccaddr.split(',').length;
        }
        console.log('to-'+toaddr+'-cc-'+ccaddr);
        if((toaddr == '' || toaddr == null) && (ccaddr == '' || ccaddr == null)){
            component.set("v.error",true);
            component.set("v.errorMsg",$A.get("$Label.c.AV_Obs_Send_Report_Error_Message"));
            check=true;
        }else{
    		if((toaddr != '' && toaddr != null) && (atCountTo != comCountTo)){
                console.log('--'+atCountTo+'--'+comCountTo+'--'+toaddr);
                component.set("v.error",true);
                component.set("v.errorMsg",$A.get("$Label.c.AV_Obs_Send_Report_valid_Email"));
    			check=true;
			}if((ccaddr != '' && ccaddr != null) && (atCountCc != comCountCc)){
    			console.log('--'+atCountCc+'--'+comCountCc+'--'+ccaddr);
    			component.set("v.error",true);
            	component.set("v.errorMsg",$A.get("$Label.c.AV_Obs_Send_Report_valid_Email"));
    			check=true;
			}
		}
        if(!check){
            component.set("v.error",false);
            var select = component.find("a_opt1");
            var from = select.get("v.value");
            console.log('--from--'+from);
            var action3 = component.get("c.sendEmailController");
            
        	action3.setParams({
                'objRecord' : component.get("v.objRecord"),
                'fromAddress' : from,
            	'toAddress' : component.get("v.toEmail"),
                'ccAddress' : component.get("v.ccEmail"),
                'bccAdress' : component.get("v.bccEmail"),
                'subject' : component.get("v.subject"),
                'bodyString' : component.get("v.body")
            });
            action3.setCallback(this, function(response) {
                if (response.getState() == "SUCCESS") {
                	   $A.get("e.force:closeQuickAction").fire();
                        $A.get('e.force:refreshView').fire();
                }else if(response.getState() == "ERROR"){
                    component.set("v.error",true);
                    var errorMsg = action3.getError();
                    console.log('Error:'+errorMsg[0].message);
                    if(errorMsg[0].message.indexOf('INVALID_EMAIL_ADDRESS') > -1){
                        
                        var startpos = errorMsg[0].message.lastIndexOf("Email");
                        var endpos = errorMsg[0].message.lastIndexOf("[");
                        var res = errorMsg[0].message.slice(startpos,(endpos-2));
                        var ErrorMessage;
                        if(errorMsg[0].message.indexOf('to') > -1){
                            ErrorMessage = res + ' ' + $A.get("$Label.c.AV_SendReportToadd");
                        }
                        else if(errorMsg[0].message.indexOf('bcc') > -1){
                            ErrorMessage = res + ' ' + $A.get("$Label.c.AV_SendReportBccadd");
                        }
                        else if(errorMsg[0].message.indexOf('cc') > -1){
                            ErrorMessage = res + ' ' + $A.get("$Label.c.AV_SendReportCCadd");
                        }
                        console.log(ErrorMessage);
                        component.set("v.errorMsg",ErrorMessage);
                    }
                    else{
                        component.set("v.errorMsg",errorMsg[0].message);
                    }
                }
            });
            $A.enqueueAction(action3);
        }
    },
    handleClosePopup : function(component, event, helper) {
    	$A.get("e.force:closeQuickAction").fire();
    }
})