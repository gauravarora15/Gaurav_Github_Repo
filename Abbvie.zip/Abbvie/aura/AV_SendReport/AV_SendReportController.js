({
	doInit : function(component, event, helper) {
		helper.fromAddress(component, event, helper);
    },
    previewEmail : function(component, event, helper) {
    	component.set("v.isOpen",true);	
    },
    closeModel : function(component, event, helper) {
    	component.set("v.isOpen",false);	
    },
    sendEmail : function(component, event, helper) {
        helper.handleSendEmail(component, event, helper);
    },
    closePopup : function(component, event, helper) {
        helper.handleClosePopup(component, event, helper);
    }
})