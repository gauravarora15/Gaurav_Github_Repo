({
    createReviewRecord: function(component, event, helper) { 
        let button = event.getSource();
        button.set('v.disabled', true);
        var reviewRec = component.get("v.reviewCompletionRecord");
        var getComments = component.get("v.reviewCompletionRecord.AV_CDRP_Review_Completion_Comments__c");
        var frequency = component.get("v.frequency");
        var checkWindow = component.get("v.checkWindow");
        var unreviewedCount = component.get("v.unreviewedCount");
        if (getComments == null || typeof getComments == 'undefined') {
            component.set("v.showerrormessage", true);
            component.set("v.errorMessage", $A.get("$Label.c.AV_CDRP_Review_Completion_Comments_Required"));
            let button = event.getSource();
            button.set('v.disabled', false);
        }else{
            var action = component.get("c.saveReviewCompletionHistory");
            action.setParams({
                'reviewRec': reviewRec,
                'frequency' : frequency,
                'checkWindow' : checkWindow,
                'unreviewedCount' : unreviewedCount
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if(state === "SUCCESS"){
                    $A.get("e.force:closeQuickAction").fire();
                    $A.get('e.force:refreshView').fire();
                }else if(state === "ERROR"){                
                    var errors = action.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            component.set("v.showerrormessage", true);
                            component.set("v.errorMessage", errors[0].message);
                            let button = event.getSource();
                            button.set('v.disabled', false);
                        }
                    }
                }
            });
            $A.enqueueAction(action);            
        }   
    },
})