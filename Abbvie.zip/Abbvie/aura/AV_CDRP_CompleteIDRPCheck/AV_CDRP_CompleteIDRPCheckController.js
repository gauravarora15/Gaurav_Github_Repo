({
	closeModel: function(component, event, helper) { 
      component.set("v.isOpen", false);
   },
    createReviewRecord: function(component, event, helper){
        helper.createReviewRecord(component, event, helper);
    }
})