({
    //Method cal;led on Page Load
    doInitHelper : function(component, event, helper) {
        component.set("v.Spinner", true);
        component.set("v.messageText", '');
        component.set("v.totalRecords", 0);
        component.set("v.pageNumber", 0);
        component.set("v.endPage", 0);
        component.set("v.startPage", 0);
        var recordId = component.get("v.checkId");
        var action = component.get("c.getValuesOnLoad");
        action.setParams({
            'recordId': recordId
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                component.set("v.Spinner", false);
               
                var responseVar = response.getReturnValue();
                component.set("v.riskDetails", responseVar);
                component.set("v.riskFilter", {'AV_Related_Study_For_Risk__r.Name':responseVar.studyName});
                component.set('v.myColumns', [
                {label: 'Observation/Risk Name', fieldName: 'url', type: 'url', cellAttributes: { class:{ 
                     fieldName:'ClassName'}}, typeAttributes : { label: { fieldName: 'name' }}, sortable: true},
                {label: 'Related Risk Study', fieldName: 'study', type: 'text', cellAttributes: { class:{ 
                     fieldName:'ClassName'}}, sortable: true},
                {label: 'Category', fieldName: 'category', type: 'text', cellAttributes: { class:{ 
                     fieldName:'ClassName'}}, sortable: true},
                {label: 'Subcategory', fieldName: 'subCategory', type: 'text', cellAttributes: { class:{ 
                     fieldName:'ClassName'}}, sortable: true},
                {label: 'Additional Informaton', fieldName: 'addInformation', type: 'text', cellAttributes: { class:{ 
                     fieldName:'ClassName'}}, sortable: false},
                 {label: 'Observation/Risk Status', fieldName: 'riskStatus', type: 'text', cellAttributes: { class:{ 
                     fieldName:'ClassName'}},  sortable: true},
                  {label: 'Observation/Risk Owner', fieldName: 'riskOwner', type: 'text', cellAttributes: { class:{ 
                     fieldName:'ClassName'}}, sortable: true},
                   {label: 'Awareness Date (Local Format)', fieldName: 'awarenessDate', type: 'text', cellAttributes: { class:{ 
                     fieldName:'ClassName'}}, sortable: true}  
             ]);
                component.set("v.selectedValues", responseVar.filterWrapRec);
                component.set("v.selectedValues.studyValue", responseVar.studyName);
                component.set("v.lstRisks", []);
                helper.showMultiSelectOptions(component, event , helper);
               
                } else if(state === "INCOMPLETE"){
                component.set("v.Spinner", false);
                helper.showToast('ERROR','ERROR',$A.get("$Label.c.AV_CDRP_ErrorMessage"));
                
           }
            else if(state === "ERROR"){
                component.set("v.Spinner", false);
                helper.showToast('ERROR','ERROR',$A.get("$Label.c.AV_CDRP_ErrorMessage"));
                
            }
        });
        $A.enqueueAction(action);

    },

    // Method to show the Multi Select Picklist values
    showMultiSelectOptions: function(component, event, helper){
        var riskDetails = component.get("v.riskDetails");
        var catogoryOptions = riskDetails.category;
                 var optionsCategory = [];
            for(var i = 0;i<catogoryOptions.length;i++){
                
                var catOption = {};
                catOption.Name = catogoryOptions[i];
                catOption.isSelected = false;
                catOption.Id = catogoryOptions[i];
                optionsCategory.push(catOption);
            } 
                component.set("v.catogoryList", optionsCategory);


                var subCatogoryOptions = riskDetails.subCategory;
                 var optionsSubCategory = [];
            for(var i = 0;i<subCatogoryOptions.length;i++){
                
                var subCatOption = {};
                subCatOption.Name = subCatogoryOptions[i];
                subCatOption.isSelected = false;
                subCatOption.Id = subCatogoryOptions[i];
                optionsSubCategory.push(subCatOption);
            } 
                component.set("v.subCategoryList", optionsSubCategory);

                var riskStatusOptions = riskDetails.riskStatus;
                 var optionsRiskStatus = [];
            for(var i = 0;i<riskStatusOptions.length;i++){
                
                var riskOption = {};
                riskOption.Name = riskStatusOptions[i];
                riskOption.isSelected = false;
                riskOption.Id = riskStatusOptions[i];
                optionsRiskStatus.push(riskOption);
            } 
                component.set("v.riskStatusList", optionsRiskStatus);
    }, 


    // Event Method to handle the Multiseelect Picklist values
    handleMultiSelect : function(component, event, helper){
        if(event.getSource().get("v.multiselectLabel") == "Category"){
            var categoryData = event.getParam("optionIds");
            var selectedCatIds;
        for (var i in categoryData) {
            if(i == 0){
                selectedCatIds = categoryData[i];
            }else{
                if(selectedCatIds.indexOf(categoryData[i]) === -1){
                    selectedCatIds = selectedCatIds + ',' + categoryData[i];
                }
            }
        }
            component.set("v.selectedValues.categoryValue" , selectedCatIds);
        }

        if(event.getSource().get("v.multiselectLabel") == "Sub Category"){
            //var subCategoryPLIds = event.getParam("selectedItem");
            var subCategoryData = event.getParam("optionIds");
            var selectedSubCatIds;
            for (var i in subCategoryData) {
            if(i == 0){
                selectedSubCatIds = subCategoryData[i];
            }else{
                if(selectedSubCatIds.indexOf(subCategoryData[i]) === -1){
                    selectedSubCatIds = selectedSubCatIds + ',' + subCategoryData[i];
                }
            }
        }
            component.set("v.selectedValues.subCategoryValue" , selectedSubCatIds);
        }

        if(event.getSource().get("v.multiselectLabel") == "Status"){
            var statusData = event.getParam("optionIds");
            var selectedStatusIds;
            
            for (var i in statusData) {
            if(i == 0){
                selectedStatusIds = statusData[i];
            }else{
                if(selectedStatusIds.indexOf(statusData[i]) === -1){
                    selectedStatusIds = selectedStatusIds + ',' + statusData[i];
                }
            }
        }
            component.set("v.selectedValues.statusValue" , selectedStatusIds);
        }
    }, 



    //Handle Risk Lookup
    handleRiskChange : function(component, event, helper){
        if(!$A.util.isEmpty(component.get("v.selectedRiskRecord")) && !$A.util.isUndefinedOrNull(component.get("v.selectedRiskRecord")) && !$A.util.isEmpty(component.get("v.selectedRiskRecord.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedRiskRecord.Id"))){
            component.set("v.selectedValues.riskValue" , component.get("v.selectedRiskRecord.Id"));
        }else{
            component.set("v.selectedValues.riskValue" , '');
        }
    },

    // Method to geet the Risks Records according to the search criteria
    handleSearch: function (component, event, helper) {
        component.set("v.messageText", '');
        component.set("v.completeRisks", []);
        component.set('v.lstRisks', []);
        component.set("v.selectedRiskList", []);
        var selectedFilters = JSON.stringify(component.get("v.selectedValues"));
        var checkId = component.get("v.checkId");
        var action = component.get("c.getSearchResults");
            action.setParams({
                "searchFilters" : selectedFilters,
                "checkId" : checkId
            });
        action.setCallback(this, function(response){
                var state = response.getState();
                if(state === "SUCCESS"){
                    var responseVar  = response.getReturnValue();
                    if($A.util.isEmpty(responseVar.errorMessage) || $A.util.isUndefinedOrNull(responseVar.errorMessage)){
                        component.set("v.messageText", '');

                        
                        var pageSize = component.get("v.pageSize");
                                  var completeList = responseVar.searchResults; 
                                  component.set("v.totalRecords", completeList.length);
                                  component.set("v.startPage",0);
                                  component.set("v.endPage",pageSize);
                                  component.set("v.pageNumber",1);
                                  var objList = [];
                    for(var j=0;j<completeList.length;j++){
                        var obj = {};
                        obj = completeList[j];
                        if(completeList[j].isSelected){
                            obj.ClassName="table-rowColor";
                            
                        }else{
                            obj.ClassName="";
                        }
                        objList.push(obj);
                    }
                     component.set("v.completeRisks", objList);

                     var completeRecords = component.get("v.completeRisks");
                                  var paginationList = [];
                                  for(var i=0; i< pageSize; i++){
                                      if(objList.length> i)
                                          paginationList.push(objList[i]);    
                                  }
                                  component.set('v.lstRisks', paginationList);
                       
                        
                    }else{
                        component.set("v.messageText", responseVar.errorMessage);
                        component.set("v.messageType", 'error');
                        component.set("v.lstRisks", []);
                        component.set("v.totalRecords", 0);
                        component.set("v.pageNumber", 0);
                        component.set("v.endPage", 0);
                        component.set("v.startPage", 0);
                    }
            } else if (state === "INCOMPLETE") {
                    
                    component.set("v.Spinner", false);
                helper.showToast('ERROR','ERROR',$A.get("$Label.c.AV_CDRP_ErrorMessage"));
                } else if(state === "ERROR"){
                    component.set("v.Spinner", false);
                helper.showToast('ERROR','ERROR',$A.get("$Label.c.AV_CDRP_ErrorMessage"));
                    
                }
               component.set("v.Spinner", false);
                
            });
            $A.enqueueAction(action);

    }, 

    //Method to handle the cancel function
    handleCancel: function(component, event, helper){
        window.history.back();

    },

    //Method to handle the clear function
    handleClear: function(component, event, helper){
        helper.doInitHelper(component, event, helper);

    },

    showToast: function(toastTitle, toastType, toastMessage){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": toastTitle,
            "type": toastType,
            "message": toastMessage
        });
        toastEvent.fire();
    }, 

    //Method for sorting the each columnn

    handleSort: function(component, event, helper){
        component.set('v.Spinner', true);
        // We use the setTimeout method here to simulate the async
        // process of the sorting data, so that user will see the
        // spinner loading when the data is being sorted.
        setTimeout(function() {
            var fieldName = event.getParam('fieldName');
            var sortDirection = event.getParam('sortDirection');
            component.set("v.sortedBy", fieldName);
            component.set("v.sortedDirection", sortDirection);
            helper.sortData(component, helper, fieldName, sortDirection);
            component.set('v.Spinner', false);
        }, 0);
    
    }, 
    sortData: function (component, helper, fieldName, sortDirection) {
        var data = component.get("v.lstRisks");
        var reverse = sortDirection !== 'asc';

        data = Object.assign([],
            data.sort(this.sortBy(fieldName, reverse ? -1 : 1))
        );
        component.set("v.lstRisks", data);
    },
    sortBy: function (field, reverse, primer) {
        var key = primer
            ? function(x) { return primer(x[field]) }
            : function(x) { return x[field] };

        return function (a, b) {
            var A = key(a);
            var B = key(b);
            return reverse * ((A > B) - (B > A));
        };
    },

    //Handle the Previous Button Pagination
    handlePrevious: function(component, event, helper){
        component.set("v.messageText", '');
        component.set("v.Spinner", true);
        var sObjectList = component.get("v.completeRisks");
            var end = component.get("v.endPage");
            var start = component.get("v.startPage");
            var pageSize = component.get("v.pageSize");
            var previousPageNumber = component.get("v.pageNumber") - 1;
            component.set("v.pageNumber",previousPageNumber);
            var paginationList = [];
            var counter = 0;
            for(var i= start-pageSize; i < start ; i++){
                if(i > -1){
                    paginationList.push(sObjectList[i]);
                    counter ++;
                }else{
                    start++;
                }
            }
            start = start - counter;
            end = end - counter;
            component.set("v.startPage",start);
            component.set("v.endPage",end);
            component.set("v.lstRisks",[]);
            component.set("v.lstRisks", paginationList);
            component.set("v.Spinner", false);

    },

    // Handle the Next button Pagination
    handleNext: function(component, event, helper){
        component.set("v.messageText", '');
        component.set("v.Spinner", true);
        var sObjectList = component.get("v.completeRisks");
        var end = component.get("v.endPage");
        var start = component.get("v.startPage");
        var pageSize = component.get("v.pageSize");
        var pageNumber = end/pageSize;
        var nextPageNumber = component.get("v.pageNumber") + 1;
        component.set("v.pageNumber",nextPageNumber);
        var paginationList = [];
        var counter = 0;
        for(var i=end; i<end+pageSize; i++){
            if(sObjectList.length > i){
                paginationList.push(sObjectList[i]);
            }
            counter ++ ;
        }
        start = start + counter;
        end = end + counter;
        component.set("v.startPage",start);
        component.set("v.endPage",end);
        component.set("v.lstRisks",[]);
        component.set('v.lstRisks', paginationList);
        component.set("v.Spinner", false);

    }, 
    // Event Meethod to get the selected rows
     handleRowsSelection : function(component, event, helper){
        var selectedRows = event.getParam('selectedRows');
        component.set("v.selectedRiskList" ,selectedRows);
    }, 

    //Method to handle all the button actions according to the User Selection
    userSelect: function(component, event, helper){
        var key = event.getSource().getLocalId();
        if (key === 'addCon' || key === 'addExit') {
            helper.handleAddCon(component, event, helper, key);
        }else if(key === 'exit' || key === 'cancel'){
            helper.handleCancel(component, event, helper);
        }else if(key === 'clear'){
            helper.doInitHelper(component, event, helper);
        }else if(key === 'search'){
            helper.handleSearch(component, event, helper);
        }
    },

    //Method to handle Add and Exit and Add and continue buttons to create the Associated Risk records
    handleAddCon: function(component, event, helper, key){
        component.set("v.messageText", '');
        component.set("v.Spinner" , true);
        
        var action = component.get("c.riskCreation");
        action.setParams({"response" : JSON.stringify(component.get("v.selectedRiskList")),
                        "parentId" : component.get("v.checkId")});
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var resp = response.getReturnValue();
                if($A.util.isEmpty(resp) || $A.util.isUndefinedOrNull(resp)){
                    if(key === 'addCon'){
                        var selectedRisks = component.get("v.selectedRiskList");
                         if (component.get("v.selectedRiskList").length !=0){
                        var objList = [];
                        for (var i = 0; i < selectedRisks.length; i++) {
                            objList.push(selectedRisks[i].riskRecordId);
                        }
                        var totalList = component.get("v.lstRisks");
                        for (var i = 0; i < totalList.length; i++) {
                            if (objList.indexOf(totalList[i].riskRecordId) !== -1) {
                                totalList[i].ClassName = "table-rowColor";
                            }

                    }

                        component.set("v.lstRisks", totalList);
                        component.set("v.messageText", $A.get("$Label.c.AV_CDRP_Associated_Risk_Success_Message"));
                        component.set("v.messageType", 'confirm');
                        }else{
                            component.set("v.messageText", '');
                            component.set("v.messageType", '');

                        }

                    } else if (key === 'addExit') {
                        if (component.get("v.selectedRiskList").length !=0){
                            helper.showToast('SUCCESS', 'SUCCESS', $A.get("$Label.c.AV_CDRP_Associated_Risk_Success_Message"));
                        }else{
                            component.set("v.messageText", '');
                            component.set("v.messageType", '');
                        }
                        //window.history.back();
                        window.location.assign('/'+component.get("v.checkId"));
                    }
                    
                    
                }else{
                    if(key === 'addCon' || key === 'addExit'){
                        component.set("v.messageText", resp);
                        component.set("v.messageType", 'error');
                    }
                }  
            } else if(state === "ERROR"){
                    helper.showToast('ERROR','ERROR',$A.get("$Label.c.AV_CDRP_ErrorMessage"));
            }
            component.set("v.Spinner" , false);
        });
        $A.enqueueAction(action);   

    }

   
    
})
