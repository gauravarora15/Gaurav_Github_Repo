({
    handleOnLoad: function(component, event, helper){
        component.set("v.displaySpinner",true);
        var action = component.get("c.getQueryRec");
        action.setParams({
            "IdrpCheck": component.get("v.idrpCheck")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var response = response.getReturnValue();
                if(response.errorMessage != null && response.errorMessage != ''){
                    helper.showToast('','Error',response.errorMessage);
                    window.history.go(-1);
                }else{
                    component.set("v.showModal",response);
                    component.set("v.queryWrapperRec",response);
                    var queryWrapper =  component.get("v.queryWrapperRec");
                }
            }else {
                
            }
            
        });
        $A.enqueueAction(action);
         component.set("v.displaySpinner",false);
    },
    trimSpacePadding : function(component, event, helper){
        var valueField = event.getSource().get("v.value");
        var labelField = event.getSource().get("v.label");
        if(!$A.util.isEmpty(valueField) && !$A.util.isUndefinedOrNull(valueField)){
            if(labelField == 'Query Text'){
                component.set("v.queryWrapperRec.idrpCheckRec.AV_CDRP_Query_Text__c",valueField.trim());
            }else if(labelField == 'Subject'){
                component.set("v.Subject",valueField.trim());
            }else if (labelField == 'Visit'){
                component.set("v.visit",valueField.trim());
            }else if(labelField == 'Dataset Label'){
                component.set("v.DatasetLabel",valueField.trim());
            }else if(labelField == 'Field Name'){
                component.set("v.fieldName",valueField.trim());
            }else if(labelField == 'Field Value'){
                component.set("v.fieldValue",valueField.trim());
            }else if(labelField == 'User Comments'){
                component.set("v.QueryRecord.AV_CDRP_User_Comments__c",valueField.trim());
            }else if(labelField == 'SPID'){
                component.set("v.spid",valueField.trim());
            }
        }
    },
    autoPopulateDataPoints : function(component, event, helper){
        component.set("v.isErrorForSelectField",false);
        component.set("v.displaySpinner",true);
        var datasets;
        var status = component.get("v.QueryRecord.AV_CDRP_Query_Status__c");
        if(!$A.util.isEmpty(status) && !$A.util.isUndefined(status) && status== $A.get("$Label.c.AV_CDRP_Forward_to_EDC")){
            var action = component.get("c.getSelectFieldFromRaveEDC");
            action.setParams({
                "SPID": component.get("v.spid"),
                "planSource":component.get("v.queryWrapperRec").idrpCheckRec.AV_CDRP_Data_Review_Plan__r.AV_CDRP_Study_Primary_Data_Source__c
            });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    if(response.getReturnValue().errorMessage == null || response.getReturnValue().errorMessage== ''){
                    	component.set("v.dataPoints",response.getReturnValue().datasetPoints);
                    }else{
                        component.set("v.isErrorForSelectField",true);
                        component.set('v.errorMessage',response.getReturnValue().errorMessage);
                        component.set("v.messageType",'error');
                        document.getElementsByClassName('slds-modal__content')[0].scrollTop=0;
                    }
                     component.set("v.displaySpinner",false);
                }else {
                    
                }
            });
            $A.enqueueAction(action);
        }else{
            component.set("v.dataPoints",'');
            component.set("v.displaySpinner",false);
        }
    },
    // method to save the record in system
    handleSave: function(component, event, helper) {
        component.set("v.showError", false);
        component.set("v.isErrorForSelectField",false);
        var isError = false;
        component.find('queryText').setCustomValidity("");
        component.find('queryText').reportValidity();
        var formValid = component.find('field').reduce(function (validSoFar, inputCmp) {
            // Displays error messages for invalid fields
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && inputCmp.get('v.validity').valid;
        }, true);
        if ($A.util.isEmpty(component.find('queryText').get("v.value")) || $A.util.isEmpty(component.find('queryText').get("v.value"))) {
            component.find('queryText').setCustomValidity("Complete this field.");
            component.find('queryText').reportValidity();
            isError = true;
        }
        if(!formValid || isError){
            component.set("v.showError", true);
            document.getElementsByClassName('slds-modal__content')[0].scrollTop=0;
        }
        if(formValid && !isError){
            if(component.get("v.QueryRecord").AV_CDRP_Query_Status__c == $A.get("$Label.c.AV_CDRP_Forward_to_EDC") &&($A.util.isEmpty(component.get("v.QueryRecord").AV_CDRP_Rave_Field__c) || $A.util.isUndefined(component.get("v.QueryRecord").AV_CDRP_Rave_Field__c) || component.get("v.QueryRecord").AV_CDRP_Rave_Field__c == '--None--')){
            	component.set("v.isErrorForSelectField",true);
                component.set('v.errorMessage','The \'Select Field\' cannot be blank for a new discrepancy/query in status \'Forward to EDC\'');
            	component.set("v.messageType",'error');
                document.getElementsByClassName('slds-modal__content')[0].scrollTop=0;
            }
            else 
            	helper.saveQuery(component, event, helper);
        }
    },
    // method to save the record in system
    saveQuery: function(component, event, helper) {
        component.set("v.displaySpinner",true);
        var queryWrapper = component.get("v.queryWrapperRec");
        var queryRecord = component.get("v.QueryRecord");
        queryRecord.AV_CDRP_Country__c = component.get("v.country");
        queryRecord.AV_CDRP_Investigator_Name__c = component.get("v.investigatorId");
		queryRecord.AV_CDRP_Study__c = component.get("v.studyId");
        queryRecord.AV_CDRP_Study_Name__c = component.get("v.studyName");
        queryRecord.AV_CDRP_Data_Form__c = component.get("v.dataForm");
        queryRecord.AV_CDRP_Query_Text__c = queryWrapper.idrpCheckRec.AV_CDRP_Query_Text__c;
        queryRecord.AV_CDRP_Subject_Name__c = component.get("v.subject");
        queryRecord.AV_CDRP_Visit__c = component.get("v.visit");
        queryRecord.AV_CDRP_Dataset_Label__c = component.get("v.DatasetLabel");
        queryRecord.AV_CDRP_Data_Field_Name__c = component.get("v.fieldName");
        queryRecord.AV_CDRP_Data_Field_Value__c = component.get("v.fieldValue");
        queryRecord.AV_CDRP_SPID__c = component.get("v.spid");
        queryRecord.AV_CDRP_Related_IDRP_Check__c = queryWrapper.idrpCheckRec.Id;
        queryRecord.AV_CDRP_Related_IDRP__c = queryWrapper.idrpCheckRec.AV_CDRP_Data_Review_Plan__c;
        queryRecord.AV_CDRP_Investigator_Id__c = component.get("v.InvNumber");
        var action = component.get("c.saveQueryRec");
        action.setParams({
            "queryRecord": JSON.stringify(component.get("v.QueryRecord"))
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var response = response.getReturnValue();
                component.set("v.wrapperRec",response);
                if(!response.hasError){
                    var navEvt = $A.get("e.force:navigateToSObject");
                    navEvt.setParams({
                        "recordId": response.returnRecordId,
                        "slideDevName": "detail"
                    });
                    navEvt.fire();
                    helper.showToast('','Success','Query was created');
                }
                else{
                    helper.showToast('','Error',response.errorString);
                }
            }else {
                
            }
            
        });
        $A.enqueueAction(action);
       component.set("v.displaySpinner",false);
    },
    showToast: function(toastTitle, toastType, toastMessage){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": toastTitle,
            "type": toastType,
            "message": toastMessage
        });
        toastEvent.fire();
    },
    
})