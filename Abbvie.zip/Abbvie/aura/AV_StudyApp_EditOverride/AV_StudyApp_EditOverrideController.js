({
	openModel: function(component, event, helper) {
        var url = window.location.href;
        if(url.indexOf('abbviemedicalresearch') > 0 ){
            var recordId = url.split('?id=').pop().split('&')[0];
            console.log(recordId);
            component.set("v.recordId",recordId);
        } 
    	helper.openModelHelper(component, event, helper);
	},
    closeModel: function(component, event, helper) {
    	helper.closeModelHelper(component, event, helper);
    },
    save : function(component, event, helper) {
        helper.handleSave(component, event, helper);
    },
    handleSaveSuccess : function(component, event, helper) {
        helper.handleSaveSuccess(component, event, helper);
    },
    onError : function(component, event, helper) {
        helper.handleError(component, event, helper);
    },
    cancel : function(component, event, helper) {
    	helper.handleCancel(component, event, helper);
    },
    handleDoneWaiting : function(component, event, helper) {
    	helper.doneWaiting(component, event, helper);
    },
})