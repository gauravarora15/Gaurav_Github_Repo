({
	doInit : function(component, event, helper) {
		helper.doInit(component,event,helper);
	},
    handleMultiSelect: function(component, event, helper){
		helper.handleMultiSelect(component, event, helper);
	},
	handleLookupSelect : function(component, event, helper){
		helper.handleLookupSelect(component, event, helper);
	},
    handlePrevious : function(component, event, helper){
		helper.handlePrevious(component, event, helper);
	}, 
	handleNext : function(component, event, helper){
		helper.handleNext(component, event, helper);
	}, 	
    handleSearch : function(component, event, helper) {
        //alert('in handle search function');
		helper.handleSearch(component,event,helper);
	},
    handleQuerySourceChange : function(component,event,helper){
        helper.handleQuerySourceChange(component,event,helper);
    },
    onCancel :  function(component,event,helper){
        if(component.get("v.operationName") == $A.get("$Label.c.AV_CDRP_Add_Query_Action"))
       		 window.location.assign('/'+component.get("v.taskId"));
        else
       		window.history.back();
    },
    handleSort:function(component,event,helper){
        helper.handleSort(component,event,helper);
    },
    clearAll : function(component,event,helper){
        helper.clearAll(component,event,helper);
    },
	reinit: function (component, event, helper) {
		$A.get('e.force:refreshView').fire();
	},
    userSelect : function(component, event, helper){
		helper.userSelect(component, event, helper);
	}, 
    handleRowAction : function(component, event, helper){
        helper.handleRowAction(component, event, helper)
    },
    handleRowsSelection :function(component, event, helper){
        helper.handleRowsSelection(component, event, helper);
    }
})