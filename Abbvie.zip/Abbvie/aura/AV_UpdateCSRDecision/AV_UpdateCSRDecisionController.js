({
	doinit : function(component, event, helper) {
        helper.fetchPickListVal(component, "AV_Include_in_CSR__c");
        helper.helperMethod(component, event, helper);
        
    },
    handleSaveRecord: function(component, event, helper) {
        helper.handleSaveRecord(component, event, helper);
    },
    handleClose : function(component, event, helper) {
        $A.get("e.force:closeQuickAction").fire();
    },
    showSpinner: function(component, event, helper) {
    	helper.handleShowSpinner(component, event, helper);
    },
    hideSpinner : function(component,event,helper){
    	helper.handleHideSpinner(component, event, helper);
    },
    updateButton : function(component,event,helper){
        helper.updateButton(component,event,helper);
    }
})