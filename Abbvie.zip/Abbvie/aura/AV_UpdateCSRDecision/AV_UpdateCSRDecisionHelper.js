({
    helperMethod : function(component, event, helper) {
        var action = component.get("c.updateCsr");
        action.setParams({ obsId : component.get("v.recordId") });
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var observation=response.getReturnValue();
                component.set("v.obsRecord",observation );
                if(observation.AV_Status__c=='Closed')
                    component.set("v.pageRet",true);
                else
                    component.set("v.pageRet",false);
                component.set("v.includeCSR",observation.AV_Include_in_CSR__c);
                
                if(!component.get("v.pageRet"))
                    $A.util.removeClass(component.find("errormsgcontainerId"), 'slds-hide');
                 
            }
            else if (state === "INCOMPLETE") {
            }
                else if (state === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            console.log("Error message: " + 
                                        errors[0].message);
                        }
                    } else {
                        console.log("Unknown error");
                    }
                }
        });
        $A.enqueueAction(action);
    },
    handleSaveRecord: function(component, event, helper) {
        var validated=true;
        var newincludeCsr = component.get("v.obsRecord.AV_Include_in_CSR__c");
        var includeCsr = component.get("v.includeCSR");
        var textarea=component.find("reasonFor");
        if(component.find("reasonFor") != undefined && includeCsr == "Yes" && newincludeCsr != includeCsr){
            var reasonfor = component.find("reasonFor").get("v.value");
            if((reasonfor != null && reasonfor.replace(/\s/g, '').length==0) || reasonfor == null){
                textarea.setCustomValidity('Complete this field.');
                textarea.reportValidity();
                validated = false;
            }
        }
        if(validated){
            component.find("recordEditor").saveRecord($A.getCallback(function(saveResult) {
                if (saveResult.state === "SUCCESS" || saveResult.state === "DRAFT") {
                    console.log("Save completed successfully.");
                    $A.get("e.force:closeQuickAction").fire();
                } else if (saveResult.state === "INCOMPLETE") {
                    console.log("User is offline, device doesn't support drafts.");
                } else if (saveResult.state === "ERROR") {
                    console.log('Problem saving record, error: ' + 
                                JSON.stringify(saveResult.error));
                } else {
                    console.log('Unknown problem, state: ' + saveResult.state + ', error: ' + JSON.stringify(saveResult.error));
                }
            })); 
        }
    },
    fetchPickListVal: function(component, fieldName) {
        var action = component.get("c.getselectOptions");
        action.setParams({
            "fld": fieldName
        });
        var opts = [];
        action.setCallback(this, function(response) {
            if (response.getState() == "SUCCESS") {
                var allValues = response.getReturnValue();
                for (var i = 0; i < allValues.length; i++) {
                    opts[allValues.length-i-1] = allValues[i];
                }
                component.set("v.pickVal", opts);
            }
        });
        $A.enqueueAction(action);
    },
    handleShowSpinner : function(component, event, helper) {
        // make Spinner attribute true for display loading spinner 
        component.set("v.Spin", true); 
    },
    handleHideSpinner : function(component, event, helper) {
        // make Spinner attribute to false for hide loading spinner    
        component.set("v.Spin", false);
    },
    updateButton : function(component,event,helper){
        var includeCSR = component.get("v.includeCSR");
        if(component.find("include").get("v.value") != includeCSR && includeCSR =='Yes'){
            $A.util.removeClass(component.find("reasonFor"), 'slds-hide');         
        }else{
           $A.util.addClass(component.find("reasonFor"), 'slds-hide');
        }
    }
})