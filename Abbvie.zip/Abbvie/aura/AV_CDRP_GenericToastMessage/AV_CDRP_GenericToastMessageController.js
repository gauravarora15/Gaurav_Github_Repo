({
    handleCloseClick: function (cmp, event, helper) {
        var navEvt = $A.get("e.force:navigateToSObject");
        var checkId = cmp.get("v.recordId");
        navEvt.setParams({
        "recordId": checkId,
        "slideDevName": "related"
        });
        navEvt.fire();
        $A.get('e.force:refreshView').fire(); 
    }
})