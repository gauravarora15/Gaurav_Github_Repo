({
    init: function (cmp, event, helper) {
        var actions = [
            { label: 'Search Query', name: 'search_query' },
            { label: 'Search Observation', name: 'search_observation' },
            { label: 'New Query', name: 'new_query' },
            { label: 'New Observation', name: 'new_observation' }
        ];
        cmp.set('v.columns', [
            {label: 'Study', fieldName: 'study', type: 'text'},
            {label: 'Country', fieldName: 'country', type: 'text'},
            {label: 'Investigator Name', fieldName: 'investigatorName', type: 'text'},
            {label: 'Subject Name', fieldName: 'subjects', type: 'text'},
            {label: 'Visit', fieldName: 'visit', type: 'text'},
            {label: 'Data Form', fieldName: 'dataForm', type: 'text'},
            {label: 'Dataset Label', fieldName: 'dataset', type: 'text'},
            {label: 'Field Name', fieldName: 'fieldName', type: 'text'},
            {label: 'Field Value', fieldName: 'fieldValue', type: 'text'},
            {label: 'SPID', fieldName: 'spid', type: 'Integer'},
            {label: 'Log Line(Optional)', fieldName: 'logLine', type: 'text'},
            {label: 'Comments', fieldName: 'comments', type: 'text'},
            {label: 'Related IDRP Check', fieldName: 'idrpCheckURL', type: 'url', typeAttributes: {label: { fieldName: 'idrpCheck' }, target: '_blank'}},
            {label: 'User Name', fieldName: 'userName', type: 'text'},
            { type: 'action', typeAttributes: { rowActions: actions } }
        ]);
        helper.fetchData(cmp, event, helper);
    },
    handleClick : function(component, event, helper){
		component.set("v.disableRefresh", true);
        component.set("v.showTable", true);
        helper.fetchData(component, event, helper);
    },
    handleSelected : function(component, event, helper){
		component.set("v.disableReview", true);
        helper.reviewData(component, event, helper);
		helper.fetchData(component, event, helper);
    },
    handleSelect : function(component, event, helper) {
        var selectedRows = event.getParam('selectedRows'); 
        var setRows = [];
        for ( var i = 0; i < selectedRows.length; i++ ) {
            setRows.push(selectedRows[i]);
        }
        component.set("v.selectedRows", setRows);
    },
    handleRowAction : function(component, event, helper){
        var action = event.getParam('action');
        switch (action.name) {
            case 'search_query':                
                var evt = $A.get("e.force:navigateToComponent");
                evt.setParams({
                    componentDef : "c:AV_CDRP_SearchQuery",
                    componentAttributes: {
                        subjectDPI : event.getParam('row').subjects,
                        studyDPI : component.get("v.planRecord"),
                        idrpCheckDPI : event.getParam('row').idrpCheckDPI
                    }
                });
                evt.fire();                
                break;    
            case 'new_query':     
                var evt = $A.get("e.force:navigateToComponent");
                evt.setParams({
                    componentDef : "c:AV_CDRP_CreateQuery",
                    componentAttributes: {
                        idrpCheck : event.getParam('row').idrpCheckDPI,
                        subject : event.getParam('row').subjects,
                        visit : event.getParam('row').visit,
                        DatasetLabel : event.getParam('row').dataset,
                        fieldName : event.getParam('row').fieldName,
                        fieldValue : event.getParam('row').fieldValue,
                        spid : event.getParam('row').spid,
                        country : event.getParam('row').country,
                        investigatorId : event.getParam('row').investigatorId,
                        dataForm : event.getParam('row').dataForm,
						studyName : event.getParam('row').study,
                        studyId : event.getParam('row').studyID,
                        InvNumber : event.getParam('row').investigatorIdNumber,
                    }
                });
                evt.fire();                
                break; 
                
            case 'search_observation':  
                var evt = $A.get("e.force:navigateToComponent");
                evt.setParams({
                    componentDef : "c:AV_CDRP_ObservationSearch",
                    componentAttributes: {
                        studyName : event.getParam('row').study,
                        studyId : event.getParam('row').studyID,
                        recordId : component.get("v.planRecord").Id,
                        IDRPCheckDPI :  event.getParam('row').idrpCheckDPI, 
                        countryValue : event.getParam('row').country
                    }
                });
                evt.fire();                
                break;   
            case 'new_observation':
                var IDRPCheckRec = event.getParam('row').idrpCheckDPI;
                var recordId = IDRPCheckRec.Id;
                var url = '/apex/AV_CreateEditObservationsPage?_lkid='+recordId;
                var urlEvent = $A.get("e.force:navigateToURL");
                urlEvent.setParams({
                    "url": url
                });
                urlEvent.fire();
                break;
        }
    }
})
