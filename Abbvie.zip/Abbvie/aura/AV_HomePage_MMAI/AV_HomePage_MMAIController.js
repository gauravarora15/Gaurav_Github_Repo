({
	getMMAItems : function(component, event, helper) {
	var actions = [
            { label: $A.get('$Label.c.AV_SPT_Edit'), name: 'Edit' }
        ]
        component.set('v.columns', [ 		
            {label: $A.get('$Label.c.AV_Name'), fieldName: 'linkName', type: 'url', 
            typeAttributes: {label: { fieldName: 'Name' }, target: '_blank'}},
            {label: $A.get('$Label.c.AV_Due_Date'), fieldName: 'AV_Due_Date__c', type: 'text'},
            {label: $A.get('$Label.c.AV_ActionItem_Description'), fieldName: 'AV_Action_Item_Description__c', type: 'text'},
            {label: $A.get('$Label.c.AV_Related_Meeting_Minute_Record_Label'), fieldName: 'linkName1', type: 'url',
			typeAttributes: {label: { fieldName: 'AV_RelatedMM__c' }, target: '_blank'}},
            {label: $A.get('$Label.c.AV_Meeting_Type'), fieldName: 'AV_RelatedMMMeetingType__c', type: 'text'},
            {label: $A.get('$Label.c.AV_Meeting_Title'), fieldName: 'AV_RelatedMMMeetingTitle__c', type: 'text'},
            {type: 'action', typeAttributes: { rowActions: actions } } 
        ]);
      
	},
	handleRowAction: function (component, event, helper) {
        var action = event.getParam('action');
        var row = event.getParam('row');
        var isHomePage = true;
        switch (action.name) {
            case 'Edit':
            var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
              "url": "/apex/AV_ActionItemCreateEditPage?id="+row.Id+"&homePageEdit="+true,
              "isredirect": "true"
            });
            urlEvent.fire();
                break;
        }
    },
   
     onNext : function(component, event, helper) {        
        var pageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", pageNumber+1);
        helper.buildData(component, helper);
    },
    
    onPrev : function(component, event, helper) {        
        var pageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", pageNumber-1);
        helper.buildData(component, helper);
    },
    
    processMe : function(component, event, helper) {
        component.set("v.currentPageNumber", parseInt(event.target.name));
        helper.buildData(component, helper);
    },
    onScriptLoad: function(component, event, helper) {    
    helper.getMMAItems(component);//get data from the helper	
  	},
})