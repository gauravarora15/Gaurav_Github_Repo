({
	save : function(component, event, helper) {
        helper.handleSave(component, event, helper);
    },
    handleSaveSuccess : function(component, event, helper) {
        helper.handleSaveSuccess(component, event, helper);
    },
    onError : function(component, event, helper) {
        helper.handleError(component, event, helper);
    },
    cancel : function(component, event, helper) {
    	helper.handleCancel(component, event, helper);
    },
    showSpinner: function(component, event, helper) {
    	helper.handleShowSpinner(component, event, helper);
    },
    hideSpinner : function(component,event,helper){
    	helper.handleHideSpinner(component, event, helper);
    }
   
})