({
	handleSave : function(component, event, helper) {
        //navigate to the detail page on save
		component.find("edit").get("e.recordSave").fire();
	},
    handleSaveSuccess : function(component, event, helper) {
        //show toast message on success 
    	var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "type": "success",
            "message": "The record has been Saved successfully."
        });
        toastEvent.fire();
        var rec  = component.get("v.recordId");
		var sObectEvent = $A.get("e.force:navigateToSObject");
    		sObectEvent .setParams({
    		"recordId": rec  ,
    		"slideDevName": "detail"
        });
  		sObectEvent.fire();
    },
    handleError : function(component, event, helper) {
        //show toast message on error
    	var toastEvent = $A.get("e.force:showToast");
        	toastEvent.setParams({
            "title": "Error!",
           	"message": "There was an error while saving your record."
        });
        toastEvent.fire();
    },
    handleCancel : function(component, event, helper) {
        //redirect to the page from where it is triggered
        
     	window.history.back();
        
    },
    handleShowSpinner : function(component, event, helper) {
        // make Spinner attribute true for display loading spinner 
        component.set("v.Spinner", true); 
    },
    handleHideSpinner : function(component, event, helper) {
        // make Spinner attribute to false for hide loading spinner    
    	component.set("v.Spinner", false);
    }
})