({
	 selectstudy : function(component, event, helper){      
    // get the selected Account from list  
      var getstudy = component.get("v.study");
    // call the event   
      var compEvent = component.getEvent("oSelectedStudyEvent");
    // set the Selected Account to the event attribute.  
         compEvent.setParams({"studyByEvent" : getstudy });  
    // fire the event  
         compEvent.fire();
    },
})