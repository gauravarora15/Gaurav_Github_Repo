({
	closeModel: function (component, event, helper) {
		helper.closeModel(component, event, helper);
	},

	doInit: function (component, event, helper) {
		helper.doInitHelper(component, event, helper);
	},

	onchange: function (component, event, helper) {
		helper.onchange(component, event, helper);
	},
	onSave: function (component, event, helper) {
		helper.onSave(component, event, helper);
	},
	reinit: function (component, event, helper) {
		$A.get('e.force:refreshView').fire();
	}
})