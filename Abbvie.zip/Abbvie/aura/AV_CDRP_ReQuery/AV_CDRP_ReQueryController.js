({
	onLoad : function(component, event, helper) {
		helper.handleOnLoad(component, event, helper);
    },
    fetchDataPoints : function(component, event, helper){
         helper.autoPopulateDataPoints(component, event, helper);
    },
    trimSpacePadding : function(component, event, helper){
       helper.trimSpacePadding(component, event, helper);
    },
    saveRecord : function(component, event, helper) {
        if(!component.get("v.isErrorForSelectField"))
			helper.handleSave(component, event, helper);
	},
    getSelectedField : function(component, event, helper) {
      if(($A.util.isEmpty(component.get("v.QueryRecord").AV_CDRP_Rave_Field__c) || $A.util.isUndefined(component.get("v.QueryRecord").AV_CDRP_Rave_Field__c) || component.get("v.QueryRecord").AV_CDRP_Rave_Field__c == '--None--'))
       		component.set("v.isErrorForSelectField",true);
        else{
            component.set("v.isErrorForSelectField",false);
        } 	
	},
    closeModal : function(component) {
       window.history.back();
    },
	reinit: function (component, event, helper) {
		$A.get('e.force:refreshView').fire();
	}
})