({ 
    
    doInit : function(component, event, helper) {  
        
        
       
         if(component.get('v.SectionName')===$A.get("$Label.c.AV_CDRP_Queries_Action_Header")){
            if(component.get('v.PageName')===$A.get("$Label.c.AV_CDRP_Record_Track")){
                component.set('v.SubSectionName',$A.get("$Label.c.AV_CDRP_Queries_Track_SubHeader"));
                component.set('v.SectionName',$A.get("$Label.c.AV_CDRP_Queries_Action_Header").substring(0, 21));
            }else{
                component.set('v.SubSectionName',$A.get("$Label.c.AV_CDRP_Queries_Action_SubHeader"));
            }
            helper.queriesBuildDatatable(component, event, helper);
        }

        if(component.get('v.SectionName')=== $A.get("$Label.c.AV_CDRP_Observation_Header")){
            component.set('v.SubSectionName',$A.get("$Label.c.AV_Homepage_Owned_by_me"));
            helper.observationsBuildDatatable(component, event, helper);
        } 

        if(component.get('v.SectionName')===$A.get("$Label.c.AV_Homepage_OpenTask_to_me")){
            component.set('v.SubSectionName',$A.get("$Label.c.AV_Homepage_Assigned_to_me"));
            helper.taskBuildDatatable(component, event, helper);
        }
         
     },
     /** reInit : function(component,event,helper) {
       if(component.get("v.PageName") === $A.get("$Label.c.AV_CDRP_Record_Action") || component.get("v.PageName") === $A.get("$Label.c.AV_CDRP_Record_Track"))
       {
                      helper.queriesBuildDatatable(component, event, helper);
        
         
       }
     },*/
    handleSaveSuccess: function (component, event, helper) {
        helper.handleSaveSuccessfunction(component, event, helper);  
     },
    handleNext: function (component, event, helper) {
         helper.handleNext(component, event, helper);        
     },
     handlePrev: function (component, event, helper) {
         helper.handlePrev(component, event, helper);        
     },
     handleRowAction: function (component, event, helper) {
         helper.handleRowAction(component, event, helper);        
     },
     handleSaveSuccess: function (component, event, helper) {
         helper.handleSaveSuccess(component, event, helper);      }
     
 })