({
    buildDatatable: function(component, event, helper) {
        var rowActions = helper.getRowActions.bind(this, component);
        var userId = $A.get("$SObjectType.CurrentUser.Id");
        var action = component.get("c.getRecords");
        action.setParams({
            userId : userId
        });	
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var pageSize = component.get("v.pageSize");
                var planData = response.getReturnValue(); 
                component.set("v.idrpPlans",planData);
                component.set("v.totalRecords", planData.length);
                component.set("v.startPage",0);
                component.set("v.endPage",pageSize);
                var PaginationList = [];
                for(var i=0; i< pageSize; i++){
                    if(planData.length> i)
                        PaginationList.push(response.getReturnValue()[i]);    
                }                
                for(var i=0;i<planData.length;i++){
                    planData[i].linkName = '/'+planData[i].Id; 
                     
                    if(planData[i].AV_CDRP_Overdue_IDRP_Checks__c){						                       
                        planData[i].highlightCell = 'indicationColumn';
                    }
                }
                component.set('v.PaginationList', PaginationList);
                component.set("v.idrpPlanSize",planData.length);
            }
        });
        component.set('v.idrpColumns', [
            {label: '', fieldName: '', type: 'text', cellAttributes:{class: { fieldName: 'highlightCell' }},initialWidth: 34},
            {label: 'Plan Name', fieldName: 'linkName', type: 'url', typeAttributes: {label: { fieldName: 'Name' }, target: '_blank'}},
            {label: 'Therapeutic Area', fieldName: 'AV_CDRP_Therapeutic_Area__c', type: 'text'},
            {label: 'Compound', fieldName: 'AV_CDRP_Compound__c', type: 'text'},
            {label: 'Indication', fieldName: 'AV_CDRP_Indication__c', type: 'text'},
            {label: 'Plan Owner', fieldName: 'AV_CDRP_Plan_Owner_Name__c', type: 'text'},
            {label: 'Version', fieldName: 'AV_CDRP_Plan_Version__c', type: 'text'},
            {label: 'Status', fieldName: 'AV_CDRP_Plan_Status__c', type: 'text'},
            { type: 'action', typeAttributes: { rowActions: rowActions } }
        ]);
        $A.enqueueAction(action);
    },
    getRowActions: function (cmp, row, doneCallback) {
        var actions = [];
        var ModifyAction = {
            'label': 'Modify',
            'name': 'Modify'
        };
        
        if (row['AV_CDRP_Plan_Status__c'] != 'Approved') {            
            ModifyAction['disabled'] = 'true';
        }
        
        actions.push(ModifyAction);
        
        // simulate a trip to the server
        setTimeout($A.getCallback(function () {
            doneCallback(actions);
        }), 200);
    },
    toggleMore : function(component, event) { 
        var bIsDefaultOpen = component.get("v.bIsDefaultOpen");        
        bIsDefaultOpen = bIsDefaultOpen ? false : true;
        component.set("v.bIsDefaultOpen", bIsDefaultOpen);        
    },
    createRecord: function(component, event, helper) {
        
       component.set("v.isOpen", true);
    },
    next: function (component, event, helper) {
        var sObjectList = component.get("v.idrpPlans");
        var end = component.get("v.endPage");
        var start = component.get("v.startPage");
        var pageSize = component.get("v.pageSize");
        var Paginationlist = [];
        var counter = 0;
        for(var i=end; i<end+pageSize-1; i++){
            if(sObjectList.length > i){
                Paginationlist.push(sObjectList[i]);
            }
            counter ++ ;
        }
        start = start + counter;
        end = end + counter;
        component.set("v.startPage",start);
        component.set("v.endPage",end);
        component.set('v.PaginationList', Paginationlist);
    },
    previous: function (component, event, helper) {
        var sObjectList = component.get("v.idrpPlans");
        var end = component.get("v.endPage");
        var start = component.get("v.startPage");
        var pageSize = component.get("v.pageSize");
        var Paginationlist = [];
        var counter = 0;
        for(var i= start-pageSize; i < start ; i++){
            if(i > -1){
                Paginationlist.push(sObjectList[i]);
                counter ++;
            }else{
                start++;
            }
        }
        start = start - counter;
        end = end - counter;
        component.set("v.startPage",start);
        component.set("v.endPage",end);
        component.set('v.PaginationList', Paginationlist);
    },
    handleRowAction: function (component, event, helper) {
        var action = event.getParam('action');
        var row = event.getParam('row');
        
        switch (action.name) {
            case 'Modify':                
                /*var editRecordEvent = $A.get("e.force:editRecord");
                editRecordEvent.setParams({
                    "recordId": row['Id']
                });
                editRecordEvent.fire();   */
                helper.cloneRecord(component,row,
                function(response){
					var state = response.getState();
					if(state === "SUCCESS"){
						component.set("v.displaySpinner", false);
						var responseVar = response.getReturnValue();
						if(!$A.util.isEmpty(responseVar) && !$A.util.isUndefined(responseVar)){
							if(responseVar.message == $A.get("$Label.c.AV_CDRP_Plan_Clone_In_Not_Approved_Status_Error")){
								helper.showToast('ERROR','ERROR',$A.get("$Label.c.AV_CDRP_Plan_Clone_In_Not_Approved_Status_Error"));
							}else if(responseVar.message == $A.get("$Label.c.AV_CDRP_IDRP_More_Than_One_Clone_In_Draft")){
								helper.showToast('ERROR','ERROR',$A.get("$Label.c.AV_CDRP_IDRP_More_Than_One_Clone_In_Draft"));
							}
							//in success clone record creation scenario 
							else if(responseVar.message != $A.get("$Label.c.AV_CDRP_ErrorMessage")){
								// page reference is used to navigate to the newly generated cloneed record.
							
                                var navEvt = $A.get("e.force:navigateToSObject");
                                navEvt.setParams({
                                    "recordId": responseVar.recordId,
                                    "slideDevName": "detail"
                                });
                                navEvt.fire();
                                $A.get('e.force:refreshView').fire(); 
                                helper.showToast('SUCCESS','SUCCESS',responseVar.message);
							}else{
								 
								helper.showToast('ERROR','ERROR',responseVar.message);
							}
						}
					}else if(state === "INCOMPLETE"){
						component.set("v.displaySpinner", false);
						helper.showToast('ERROR','ERROR',$A.get("$Label.c.AV_CDRP_ErrorMessage"));
					}else if(state === "ERROR"){
						component.set("v.displaySpinner", false);
						helper.showToast('ERROR','ERROR',$A.get("$Label.c.AV_CDRP_ErrorMessage"));
					}
				});
          break;            
        }
    },
    handleSaveSuccess: function (component, event, helper) {
        $A.get("e.force:refreshView").fire();
    },
    cloneRecord : function(component, row,callback) {
        var action= component.get("c.cloneRecord");
        var recordIdVar = row['Id'];
        action.setParams({
            'recordId': recordIdVar
        });
        action.setCallback(this, function(response){
            callback.call(this,response);
        });
        $A.enqueueAction(action);
    },
    showToast: function(toastTitle, toastType, toastMessage){
        $A.get("e.force:closeQuickAction").fire();
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": toastTitle,
            "type": toastType,
            "message": toastMessage
        });
        toastEvent.fire();
    }
})