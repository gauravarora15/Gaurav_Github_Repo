({
    doInit: function (component, event, helper) {
        helper.buildDatatable(component, event, helper);
    },
    toggleMore: function (component, event, helper) {
        helper.toggleMore(component, event);
    },
    createRecord: function (component, event, helper) {
        helper.createRecord(component, event, helper);
    },
    next: function (component, event, helper) {
        helper.next(component, event, helper);
    },
    previous: function (component, event, helper) {
        helper.previous(component, event, helper);
    },
    handleRowAction: function (component, event, helper) {
        helper.handleRowAction(component, event, helper);
    },
    handleSaveSuccess: function (component, event, helper) {
        $A.get("e.force:refreshView").fire();
    },
    onreturn: function (component, event, helper) {
        component.set("v.isOpen", false);
    },
    handleComponentEvent: function (component, event, helper) {

        // get the selected Account record from the COMPONETN event 	 
        var selectedStudyGetFromEvent = event.getParam("studyByEvent");

        component.set("v.selectedRecord", selectedStudyGetFromEvent);

        var forclose = component.find("lookup-pill");
        $A.util.addClass(forclose, 'slds-show');
        $A.util.removeClass(forclose, 'slds-hide');

        var forclose = component.find("searchRes");
        $A.util.addClass(forclose, 'slds-is-close');
        $A.util.removeClass(forclose, 'slds-is-open');

        var lookUpTarget = component.find("lookupField");
        $A.util.addClass(lookUpTarget, 'slds-hide');
        $A.util.removeClass(lookUpTarget, 'slds-show');

    },
})