({
    getStudyApplications : function(component, event, helper) {
        var action = component.get("c.getStudyApplRecords");//get data from server side controller
        action.setStorable();
        action.setCallback(this, function(response) { 
            var state = response.getState();
            if (state === "SUCCESS") {
                var records =response.getReturnValue();
                    records.forEach(function(record){
                        if(component.get("v.isExternalSubmitter")){                            
                             record.linkName = component.get("v.communityURL") +'/s/detail/'+ record.Id; 
                        }
                        else{
                            //sforce.one.navigateToURL('detail/'+ record.Id);
                            record.linkName = '/'+ record.Id;
                        }
                    });               
                
                component.set("v.data", records);//set data in the page variable
                
                component.set("v.totalPages", Math.ceil(response.getReturnValue().length/component.get("v.pageSize")));
                component.set("v.allData", records);
                component.set("v.currentPageNumber",1);	
                component.set("v.itemcount",records.length);
                this.buildData(component, helper);
            }
        });	
       
        $A.enqueueAction(action);
    },
    /*
     * this function will build table data
     * based on current page selection
     * */
    buildData : function(component, helper) {
        var data = [];
        var pageNumber = component.get("v.currentPageNumber");
        var pageSize = component.get("v.pageSize");
        var allData = component.get("v.allData");
        var totalRec = component.get("v.itemcount");
        var x = (pageNumber-1)*pageSize;
        var recSrt= ((pageNumber - 1) * pageSize)+1 ;
        var recEnd = pageSize * pageNumber;
        //creating data-table data
        for(; x<(pageNumber)*pageSize; x++){
            if(allData[x]){
                data.push(allData[x]);
            }
        }
        component.set("v.RecordStart", totalRec != 0 ? recSrt : 0);
        component.set("v.RecordEnd",totalRec >= recEnd ? recEnd : totalRec);
        component.set("v.data", data);
    },
    
    isExternalPortalUser : function(component, event, helpe) {
        var action = component.get("c.isExternalPortalUser");//get data from server side controller
        action.setCallback(this, function(response) { 
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.isExternalSubmitter",response.getReturnValue());
                this.getCommunityURL(component, event, helpe);                         
            }
        }); 
       
        $A.enqueueAction(action);
       
    },
	
    getCommunityURL : function(component, event, helpe) {
        var action = component.get("c.getCommunityURL");//get data from server side controller
        action.setCallback(this, function(response) { 
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.communityURL",response.getReturnValue());
                this.getStudyApplications(component, event, helpe);                         
            }
        });        
        $A.enqueueAction(action);       
    },
   
})