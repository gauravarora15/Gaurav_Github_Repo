({
    doInitHelper: function (component, event, helper) {
        var myPageRef = component.get("v.pageReference");
        var planStatus = myPageRef.state.c__planStatus;
        component.set("v.dataTrajNameId", myPageRef.state.c__dataTrajNameId);
        component.set("v.dataTrajName", myPageRef.state.c__dataTrajName);
        component.set("v.recordId", myPageRef.state.c__recordId);
        var recId = component.get("v.recordId");
        var action = component.get("c.getPlanStatus");
        action.setParams({
            'recordId' : recId
        }); 
        action.setCallback(this,function(response){
            if (response.getState() == "SUCCESS") {
                var resp = response.getReturnValue();
                if(resp[$A.get("$Label.c.AV_CDRP_Plan_Owner")]){
                    helper.showToast('ERROR', 'ERROR', $A.get("$Label.c.AV_CDRP_New_Data_Category_Access_Error"));
                    var navEvt = $A.get("e.force:navigateToSObject");
                    navEvt.setParams({
                        "recordId": recId,
                        "slideDevName": "related"
                    });
                    navEvt.fire();
                    $A.get('e.force:refreshView').fire();
                }
                else if (planStatus == $A.get("$Label.c.AV_CDRP_Status_InApproval") || planStatus == $A.get("$Label.c.AV_CDRP_Data_Check_Status_Completed") || planStatus == $A.get("$Label.c.AV_CDRP_Data_Review_Plan_Status_Cancelled") || planStatus == $A.get("$Label.c.AV_CDRP_Data_Check_Status_Superseded") || planStatus == $A.get("$Label.c.AV_CDRP_Data_Review_Plan_Status_Approved")) {
                    helper.showToast('ERROR', 'ERROR', $A.get("$Label.c.AV_CDRP_Data_Trajectory_Edit_Validation_Message"));
                    var navEvt = $A.get("e.force:navigateToSObject");
                    navEvt.setParams({
                        "recordId": recId,
                        "slideDevName": "related"
                    });
                    navEvt.fire();
                    $A.get('e.force:refreshView').fire();
                }
                else {
                    component.set("v.showModal", true);
                }
            }
        });
        $A.enqueueAction(action);
    },
	
    onchange: function (component, event, helper) {
        var planId = component.get("v.recordId");
        var trajId = component.get("v.dataTrajNameId");
        var nav;
        if (trajId != null) {
            nav = trajId;
        } else {
            nav = planId;
        }
        //$A.get("e.force:closeQuickAction"); 
        var pageReference = {
            type: "standard__recordPage",
            attributes: {
                "recordId": nav,
                "objectApiName": 'AV_CDRP_Data_Review_Plan__c',
                "actionName": "view"

            }
        };
        component.set("v.pageReference", pageReference);
        var navService = component.find("navService");
        var pageReference = component.get("v.pageReference");
        navService.navigate(pageReference);

        //$A.get("e.force:closeQuickAction"); 

        //window.history.back();
        window.location.reload();



    },
    showToast: function (toastTitle, toastType, toastMessage) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": toastTitle,
            "type": toastType,
            "message": toastMessage
        });
        toastEvent.fire();
    }


})
