({
	doInitHelper: function(component) {
        var objectTypeVar = component.get("v.assistObjectType");
        var currentRecordVar = component.get("v.oRecord");

        if(component.get("v.showAssist")){
            if (!$A.util.isEmpty(objectTypeVar) && !$A.util.isUndefinedOrNull(objectTypeVar)) {
            	var listVar = [];
                
            }
        }

    },
    selectRecord: function(component) {
        console.log('firing event');
        // get the selected record from list  
        var getSelectRecord = component.get("v.oRecord");
        // call the event   
        var compEvent = component.getEvent("oSelectedRecordEvent");
        // set the Selected sObject Record to the event attribute.  
        compEvent.setParams({
            "recordByEvent": getSelectRecord
        });
        // fire the event  
        compEvent.fire();
    },
    
    toggleHelper: function(component, event) {
        var objTypeVar = component.get("v.assistObjectType");
        if (!$A.util.isEmpty(objTypeVar) && !$A.util.isUndefined(objTypeVar)) {
            var toggleText = component.find("tooltip");
            $A.util.toggleClass(toggleText, "slds-hide");
        }
    }
})