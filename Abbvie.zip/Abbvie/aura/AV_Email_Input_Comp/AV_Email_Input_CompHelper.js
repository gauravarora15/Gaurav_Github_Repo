({
    createEmailPill : function(component, event, helper) {
        var preSelectedEmailLst = component.get("v.selectedEmailLst");
        preSelectedEmailLst.push(component.get("v.emailInputVal"));
        console.log('preSelectedEmailLst: '+preSelectedEmailLst);
        component.set("v.selectedEmailLst", preSelectedEmailLst);
        //helper.pillGenerator(component, event, helper, component.get("v.emailInputVal"));
    },
    pillGenerator : function(component, event, helper, emailId){
        var currentEmailPillsLst = [];
        currentEmailPillsLst = component.get("v.emailPillLst");
        currentEmailPillsLst.push({
            label: emailId,
            name: emailId,
        });
        component.set("v.emailPillLst", currentEmailPillsLst);
        component.set("v.emailInputVal", "");
    }
})