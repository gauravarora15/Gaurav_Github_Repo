({
    doInitHelper : function(component, event, helper) {
        var action = component.get("c.returnRecentRec");
        action.setCallback(this, function(response) {
            var state = response.getState();             
            if (state === "SUCCESS") {
                component.set("v.RItems", response.getReturnValue());
				helper.getCommunityURL(component, event, helper);
            }
            else {
                console.log("Failed with state: " + state);
            }
        });
        // Send action off to be executed
        $A.enqueueAction(action);
    },
    handleClickHelper: function (component, event, helper) {
        var domainUrl =component.get("v.communityURL") ;    	
        var rec = event.currentTarget.getAttribute("data-recId");
        window.open(domainUrl+'/s/detail/'+rec,'_self');
        //sforce.one.navigateToSObject(event.currentTarget.getAttribute("data-recId"));		
    },
    getCommunityURL : function(component, event, helpe) {
        var action = component.get("c.getCommunityURL");//get data from server side controller
        action.setCallback(this, function(response) { 
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.communityURL",response.getReturnValue());                      
            }
        });        
        $A.enqueueAction(action);       
    },
})