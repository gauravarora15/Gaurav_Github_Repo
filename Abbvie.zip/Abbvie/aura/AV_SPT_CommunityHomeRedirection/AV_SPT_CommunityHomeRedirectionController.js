({
	doInit : function(component, event, helper) {	   
        //Redirecting to Home url in community when on task relatedlist
        var url = window.location.href;
        if(url.indexOf('00T') > 0 || url.indexOf('\/task\/') > 0){
            window.location.href = window.location.origin;
        }
    }
})