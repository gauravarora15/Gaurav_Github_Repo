({
              getActionItems : function(component, event, helper) {
        var actions = [
            { label: 'Edit', name: 'Edit' }
        ]
        component.set('v.columns', [                          
            {label: $A.get('$Label.c.AV_Name'), fieldName: 'linkName', type: 'url', 
            typeAttributes: {label: { fieldName: 'Name' }, target: '_blank'}},
            
            {label: $A.get('$Label.c.AV_Due_Date'), fieldName: 'AV_Due_Date__c', type: 'text'},
            
            {label: $A.get('$Label.c.AV_ActionItem_Description'), fieldName: 'AV_Action_Item_Description__c', type: 'text'},
            
            {label: $A.get('$Label.c.AV_Related_Study_MM'), fieldName: 'linkName2', type: 'url', 
            typeAttributes: {label: { fieldName: 'AV_Related_Study_ET__c' }, target: '_blank'}},
            
            {label: $A.get('$Label.c.AV_RelPI_PrimaryInstitution'), fieldName: 'linkName3', type: 'url', 
            typeAttributes: {label: { fieldName: 'AV_Related_PI_Primary_Facility_ET__c'}, target: '_blank'}},
            
            {label: $A.get('$Label.c.AV_Related_Observation_Risk_Label'), fieldName: 'linkName4', type: 'url', 
            typeAttributes: {label: { fieldName: 'AV_Related_Observation_Name__c'}, target: '_blank'}},
            
            {label: $A.get('$Label.c.AV_Record_Type_Label'), fieldName: 'linkName1', type: 'text', 
            typeAttributes: {label: { fieldName: 'AV_Record_Type_Name__c'}}},
            
            {type: 'action', typeAttributes: { rowActions: actions } } 
        ]);
       //helper.getActionItems(component);//get data from the helper
            },
           
        handleRowAction: function (component, event, helper) {
        var action = event.getParam('action');
        var row = event.getParam('row');
        switch (action.name) {
            case 'Edit':
            var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
               "url": "/apex/AV_ActionItemCreateEditPage?id="+row.Id+"&homePageEdit="+true,
              "isredirect": "true"
            });
            urlEvent.fire();
                break;
        }
    },
   handleSelect: function (component, event, helper) {
    var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
              "url": "/apex/AV_ActionItemCreateEditPage",
              "isredirect": "true"
            });
            urlEvent.fire();
    },
     onNext : function(component, event, helper) {        
        var pageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", pageNumber+1);
        helper.buildData(component, helper);
    },
    
    onPrev : function(component, event, helper) {        
        var pageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", pageNumber-1);
        helper.buildData(component, helper);
    },
    
    processMe : function(component, event, helper) {
        component.set("v.currentPageNumber", parseInt(event.target.name));
        helper.buildData(component, helper);
    },
    onScriptLoad: function(component, event, helper) {    
    helper.getActionItems(component);//get data from the helper 
    },
})