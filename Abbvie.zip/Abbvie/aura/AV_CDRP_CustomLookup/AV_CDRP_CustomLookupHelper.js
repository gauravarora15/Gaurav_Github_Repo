({
    doInit: function(component,event,helper){
         component.set('v.Spinner', true);
         var action = component.get("c.getPicklistvalues");
        action.setParams({
            'objectName': "AV_CDRP_Data_Review_Plan__c",
            'field_apiname': "AV_CDRP_Study_Primary_Data_Source__c"
           
        });
        action.setCallback(this, function(a) {
            var state = a.getState();
            if (state === "SUCCESS"){
                var sourceValues = [];
                var resp = a.getReturnValue();
                for(var i=0; i<resp.length; i++)
                {
                    var Option = {};
                    Option.Name = resp[i];
                    if(resp[i]=='Rave X'){
                          Option.isSelected = true;
                    }else{
                    Option.isSelected = false;
                    }
                   
                    sourceValues.push(Option);
                }
                
             
               component.set("v.sourcePicklist", sourceValues);
                component.set("v.sourceValue", 'Rave X');
                 component.set('v.Spinner', false);
              
            } 
        });
        $A.enqueueAction(action);
        
    },
    
    onblur : function(component, event, helper) {
        component.set("v.lstofstudies", null );
        var forclose = component.find("searchRes");
        $A.util.addClass(forclose, 'slds-is-close');
        $A.util.removeClass(forclose, 'slds-is-open');
    },
    closeModel: function(component, event, helper) {          
        var fromHomePage = component.get("v.fromHomePage");
       
        if(fromHomePage == true)
        {
            var compEvent = component.getEvent("return");
            compEvent.fire(); 
        }
        else{
            window.history.back();
        } 
    },
    
    onSave: function(component,event,helper) {       
        var getInputkeyWord = component.get("v.selectedRecord");
        if (getInputkeyWord == null || typeof getInputkeyWord == 'undefined') {
            component.set("v.showerrormessage", true);
            component.set("v.errorMessage", $A.get("$Label.c.AV_CDRP_IDRP_Enter_Valid_Study_Number"));
            let button = event.getSource();
            button.set('v.disabled', false);
        }
        else {
            let button = event.getSource();
            button.set('v.disabled', true);
            var saveAndNew = component.get("v.saveAndNew");     
           if(saveAndNew){
                button.set('v.disabled', false);                
           }
            helper.saverec(component, event, helper);
        }
    },
    keyPressController: function(component,event,helper) {
        var getInputkeyWord = component.get("v.SearchKeyWord");
      
        if(getInputkeyWord.length > 2){
            var forOpen = component.find("searchRes");
            $A.util.addClass(forOpen, 'slds-is-open');
            $A.util.removeClass(forOpen, 'slds-is-close');
            helper.searchHelper(component,event,getInputkeyWord);
        }
        else{  
            component.set("v.listOfSearchRecords", null ); 
            var forclose = component.find("searchRes");
            $A.util.addClass(forclose, 'slds-is-close');
            $A.util.removeClass(forclose, 'slds-is-open');
        }
        
    },    
    clear :function(component,event,helper){
        
        var pillTarget = component.find("lookup-pill");
        var lookUpTarget = component.find("lookupField"); 
        
        $A.util.addClass(pillTarget, 'slds-hide');
        $A.util.removeClass(pillTarget, 'slds-show');
        
        $A.util.addClass(lookUpTarget, 'slds-show');
        $A.util.removeClass(lookUpTarget, 'slds-hide');
        
        component.set("v.SearchKeyWord",null);
        component.set("v.listOfSearchRecords", null );
        component.set("v.selectedRecord", null ); 
        component.set("v.showerrormessage",false);  
    },
    
    handleComponentEvent : function(component, event, helper) {
        // get the selected Account record from the COMPONETN event 	 
        var selectedStudyGetFromEvent = event.getParam("studyByEvent");
        
        component.set("v.selectedRecord" , selectedStudyGetFromEvent); 
        
        var forclose = component.find("lookup-pill");
        $A.util.addClass(forclose, 'slds-show');
        $A.util.removeClass(forclose, 'slds-hide');  

        
        var forclose = component.find("searchRes");
        $A.util.addClass(forclose, 'slds-is-close');
        $A.util.removeClass(forclose, 'slds-is-open');
        
        var lookUpTarget = component.find("lookupField");
        $A.util.addClass(lookUpTarget, 'slds-hide');
        $A.util.removeClass(lookUpTarget, 'slds-show');  
        
    },       
    searchHelper : function(component,event,getInputkeyWord) {
        // call the apex class method 
        var getInputkeyWord = component.get("v.SearchKeyWord");
        var action = component.get("c.fetchvalues"); 
        action.setParams({
            'searchKeyWord': getInputkeyWord
        });
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                
                // set searchResult list with return value from server.
                
                component.set("v.lstofstudies", storeResponse); 
            }
            
           
        });
        // enqueue the Action  
        $A.enqueueAction(action);
        
    },
    onchange : function(component,event,helper){
        var source = event.getSource().get("v.value");
        component.set("v.sourceValue", source);
    },
    saverec: function(component,event,helper) {
        
        var rec = component.get("v.selectedRecord.Id");  
        var saveAndNew = component.get("v.saveAndNew");      
        var action = component.get("c.SaveDataReviewPlan");        
        action.setParams({
            'Nameofrec': rec,
            'source' : component.get("v.sourceValue")   
        });
        action.setCallback(this, function(response){                        
            var state = response.getState();
            if(state === "SUCCESS"){
                if(!saveAndNew){
                    var record = response.getReturnValue(); 
                    
                    var recordid = record[0].Id;
                    var navEvt = $A.get("e.force:navigateToSObject");   
                    navEvt.setParams({
                    "recordId": recordid,
                    "slideDevName": "Detail"
                    });
                    navEvt.fire(); 
                    //var compEvent = component.getEvent("return");
                    //compEvent.fire(); */
                }                
            } else if(state === "ERROR"){                
                var errors = action.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        component.set("v.showerrormessage", true);
                        component.set("v.errorMessage", errors[0].message);
                        let button = event.getSource();
                        button.set('v.disabled', false);
                    }
                }
            }else if (status === "INCOMPLETE") {
                alert('No response from server or client is offline.');
            }
        });
        $A.enqueueAction(action);
    }
})