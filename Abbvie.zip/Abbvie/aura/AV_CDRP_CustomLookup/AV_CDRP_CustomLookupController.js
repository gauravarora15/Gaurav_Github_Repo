({
    doInit : function(component, event, helper) {
		helper.doInit(component,event,helper);
	},
	onblur : function(component,event,helper){ 
        helper.onblur(component,event,helper);
    }, 
    onchange : function(component,event,helper){
        helper.onchange(component,event,helper);
    },
    closeModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "False" 
        helper.closeModel(component,event,helper);
    },
    onSave: function(component,event,helper) {
        component.set("v.saveAndNew",false);
        helper.onSave(component,event,helper);
    },
    onSaveAndNew: function(component,event,helper) {
        component.set("v.saveAndNew",true);
        component.set("v.showerrormessage",false);        
        helper.onSave(component,event,helper);
        if(!component.get("v.showerrormessage"))
         {helper.clear(component,event,helper); }     
    },    
    keyPressController: function(component,event,helper) {
        helper.keyPressController(component,event,helper);
    },
    
    clear :function(component,event,helper){
        helper.clear(component,event,helper);  
    },
    
    handleComponentEvent : function(component, event, helper) {
        helper.handleComponentEvent(component,event,helper);
        // get the selected Account record from the COMPONETN event 	 
    },
})