({
   openModel: function(component, event, helper) {
      // for Display Model,set the "isOpen" attribute to "true"
      component.set("v.isOpen", true);
   },

   closeModel: function(component, event, helper) {
     // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
      component.set("v.isOpen", false);
   },
   closeModelCancel: function(component, event, helper) {
      component.set("v.isOpen", false);
      var myEvent = $A.get("e.c:AV_DeleteOverrideEvent");
        myEvent.setParams({"recordid":"cancelBtn"});
        myEvent.fire();
   },

   likenClose: function(component, event, helper) {
     component.set("v.isOpen", false);
      component.set("v.isChang", true);
     var myEvent = $A.get("e.c:AV_DeleteOverrideEvent");
        myEvent.setParams({"recordid":"deleteBtn"});
        myEvent.fire();
   },
 })