({
    afterRender : function(component, helper) {
        this.superAfterRender();
        console.log('inside render');
        $A.get('e.force:refreshView').fire();
    }
})