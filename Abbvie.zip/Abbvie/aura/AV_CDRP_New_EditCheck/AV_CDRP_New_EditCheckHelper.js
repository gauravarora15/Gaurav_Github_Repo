({
	
	doInitHelper: function(component, event, helper) {
		var myPageRef = component.get("v.pageReference");
         
         component.set("v.checkId", myPageRef.state.c__checkId);
         var recId = myPageRef.state.c__checkId;
         var checkStatus = myPageRef.state.c__checkStatus; 
        if(checkStatus==$A.get("$Label.c.AV_CDRP_Status_InApproval") || checkStatus==$A.get("$Label.c.AV_CDRP_Data_Check_Status_Completed") || checkStatus==$A.get("$Label.c.AV_CDRP_Data_Review_Plan_Status_Cancelled") || checkStatus==$A.get("$Label.c.AV_CDRP_Data_Check_Status_Superseded")) {
            helper.showToast('ERROR', 'ERROR', $A.get("$Label.c.AV_CDRP_Data_Trajectory_Edit_Validation_Message"));
            var navEvt = $A.get("e.force:navigateToSObject");
                    navEvt.setParams({
                        "recordId": recId,
                        "slideDevName": "related"
                    });
                    navEvt.fire();
                    $A.get('e.force:refreshView').fire();
        }
        else if(checkStatus===$A.get("$Label.c.AV_CDRP_Business_Rule_Status_Inactive")) {
          helper.showToast('ERROR', 'ERROR', $A.get("$Label.c.AV_CDRP_Check_Field_Inactive_Error"));
          var navEvt = $A.get("e.force:navigateToSObject"); 
                    navEvt.setParams({
                        "recordId": recId,
                        "slideDevName": "related"
                    });
                    navEvt.fire();
                    $A.get('e.force:refreshView').fire();
      }
        else {
        component.set("v.showModal", true);
        component.set("v.checkId", myPageRef.state.c__checkId);	
        component.set("v.relatedDataCheck", myPageRef.state.c__relatedCheck);	
        component.set("v.purpose", myPageRef.state.c__purpose);	
        component.set("v.dataCategoryFilter", {'AV_CDRP_IDRP_Data_Category__c.AV_CDRP_IDRP_Data_Category_Status__c':'Active',
                                                'AV_CDRP_IDRP_Data_Category__c.AV_CDRP_Related_IDRP__c':myPageRef.state.c__plan});



  }
},
showToast: function (toastTitle, toastType, toastMessage) {
  var toastEvent = $A.get("e.force:showToast");
  toastEvent.setParams({
      "title": toastTitle,
      "type": toastType,
      "message": toastMessage
  });
  toastEvent.fire();
},
onSave: function(component,event,helper) {  

      let button = event.getSource();
      button.set('v.disabled', true);
 
  component.set("v.isErrorForSelectField", false);
  component.set("v.showError", false);
  component.set("v.errorMessage", '');

  
    var purpose = component.get("v.purpose");
    var getInputkeyWord = component.get("v.relatedDataCategory");
    var editCheckName = component.get("v.EditCheckName");
    if(typeof editCheckName != $A.get("$Label.c.AV_Undefined")){
      editCheckName=editCheckName.trimLeft();
    }
    if(editCheckName===null || editCheckName === "" || typeof editCheckName == $A.get("$Label.c.AV_Undefined") ){
      component.set("v.showError", true);
      let button = event.getSource();
      button.set('v.disabled', false);
    }
   else if ((getInputkeyWord == null || typeof getInputkeyWord == $A.get("$Label.c.AV_Undefined")) && purpose===$A.get("$Label.c.AV_CDRP_Missing_Data_Picklist")) {
      component.set("v.isErrorForSelectField", true);
      component.set("v.errorMessage", $A.get("$Label.c.AV_CDRP_Missing_Data_DataCategory_Blank_Error"));
      let button = event.getSource();
      button.set('v.disabled', false);
  }
  else {
       
      helper.saverec(component, event, helper, editCheckName, $A.get("$Label.c.AV_CDRP_Save"));

  }
},

onSaveAndNew: function(component,event,helper) {  
 
  component.set("v.isErrorForSelectField", false);
  component.set("v.showError", false);
  component.set("v.errorMessage", '');

  
  var purpose = component.get("v.purpose");
  var getInputkeyWord = component.get("v.relatedDataCategory");
  var editCheckName = component.get("v.EditCheckName");
  if(typeof editCheckName != $A.get("$Label.c.AV_Undefined")){
    editCheckName=editCheckName.trimLeft();
  }
  if(editCheckName===null || editCheckName === "" || typeof editCheckName == $A.get("$Label.c.AV_Undefined") ){
    component.set("v.showError", true);
    let button = event.getSource();
    button.set('v.disabled', false);
  }
 else if ((getInputkeyWord == null || typeof getInputkeyWord == $A.get("$Label.c.AV_Undefined")) && purpose===$A.get("$Label.c.AV_CDRP_Missing_Data_Picklist")) {
    component.set("v.isErrorForSelectField", true);
    component.set("v.errorMessage", $A.get("$Label.c.AV_CDRP_Missing_Data_DataCategory_Blank_Error"));
    let button = event.getSource();
    button.set('v.disabled', false);
}
  else {
      let button = event.getSource();
      button.set('v.disabled', true);
      var buttonclick =$A.get("$Label.c.AV_CDRP_SaveNew");
      helper.saverec(component, event, helper, editCheckName, buttonclick);
      button.set('v.disabled',false);

  }
},

// method to save the record in system
saverec: function(component, event, helper,editCheckName,buttonclick) {
  component.set("v.displaySpinner",true);
 // var queryWrapper = component.get("v.queryWrapperRec");
  var editCheckRecord = component.get("v.EditCheckRecord");
  var editCheckWrapperRec = component.get("v.editCheckWrapperRec");
  var getInputkeyWord = component.get("v.relatedDataCategory");
  if(getInputkeyWord != null){
  editCheckRecord.AV_CDRP_IDRP_Data_Category__c = component.get("v.relatedDataCategory").Id;
}
  editCheckRecord.AV_CDRP_Edit_Check_Name__c = editCheckName;
  editCheckRecord.AV_CDRP_Related_IDRP_Check__c = component.get("v.checkId");
  
  var action = component.get("c.saveEditCheckRec");
  action.setParams({
      "editCheckRecord": JSON.stringify(component.get("v.EditCheckRecord"))
  });
  action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === "SUCCESS") {
          var response = response.getReturnValue();
          if(buttonclick===$A.get("$Label.c.AV_CDRP_Save")){
          component.set("v.wrapperRec",response);
          if(!response.hasError){
              window.location.assign('/'+component.get("v.checkId"));
              helper.showToast('','Success',$A.get("$Label.c.AV_CDRP_EditCheck_Success"));
            }
            else{
              helper.showToast('ERROR','ERROR',response.errorString);
          }
          let button = event.getSource();
          button.set('v.disabled',false); 
          }
            else{
              if(!response.hasError){
              component.set("v.relatedDataCategory",null);
              component.set("v.EditCheckName","");
              var childCmp = component.find("relatedDataCategory");
              childCmp.invokeClose();
              helper.showToast('','Success',$A.get("$Label.c.AV_CDRP_EditCheck_Success"));
              }
              else{
                helper.showToast('ERROR','ERROR',response.errorString);
            }
            }
          
          
          

      }else if (response.getState() ===  "ERROR") {
        var errors = response.getError();                      
        component.set("v.showError",true);
        component.set("v.errorMessage",errors[0].message);
        component.set("v.messageType", 'error');
    }
      
  });
  $A.enqueueAction(action);
 component.set("v.displaySpinner",false);
},

onCancel :function(component, event, helper){
  window.location.assign('/'+component.get("v.checkId"));

},   

})