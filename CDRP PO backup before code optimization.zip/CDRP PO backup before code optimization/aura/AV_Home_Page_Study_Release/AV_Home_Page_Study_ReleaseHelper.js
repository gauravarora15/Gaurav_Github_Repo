({
    getStudyReleases : function(component, event, helper) {
        var locale = $A.get("$Locale.langLocale");
        //console.log('locale is'+locale);
        var format = _utilityLightning.getDtFormat(locale);   
        //console.log('format'+format);
        var action = component.get("c.getStudyReleaseRecords");//get data from server side controller
        action.setStorable();
        action.setCallback(this, function(response) { 
            var state = response.getState();
            if (state === "SUCCESS") {
                var records =response.getReturnValue();
                records.forEach(function(record){
                    record.linkName = '/' + record.Id; 
                    record.linkName1= '/' + record.AV_Protocol_Number__c; 
                });  
                for (var record of records)  
                 {                      
                     record.LastModifiedDate = $A.localizationService.formatDate(record.LastModifiedDate, format); 
                     console.log('lastmodified'+ record.LastModifiedDate);                 
                 } 
                component.set("v.data", records);//set data in the page variable
                component.set("v.totalPages", Math.ceil(response.getReturnValue().length/component.get("v.pageSize")));
                component.set("v.allData", records);
                component.set("v.currentPageNumber",1);	
                component.set("v.itemcount",records.length);
                this.buildData(component, helper);
            }
        });	
        var requestInitiatedTime = new Date().getTime();
        $A.enqueueAction(action);
    },
    /*
     * this function will build table data
     * based on current page selection
     * */
    buildData : function(component, helper) {
        var data = [];
        var pageNumber = component.get("v.currentPageNumber");
        var pageSize = component.get("v.pageSize");
        var allData = component.get("v.allData");
        var totalRec = component.get("v.itemcount");
        var x = (pageNumber-1)*pageSize;
        var recSrt= ((pageNumber - 1) * pageSize)+1 ;
        var recEnd = pageSize * pageNumber;
        //creating data-table data
        for(; x<(pageNumber)*pageSize; x++){
            if(allData[x]){
                data.push(allData[x]);
            }
        }
        component.set("v.RecordStart", totalRec != 0 ? recSrt : 0);
        component.set("v.RecordEnd",totalRec >= recEnd ? recEnd : totalRec);
        component.set("v.data", data);
    }
})