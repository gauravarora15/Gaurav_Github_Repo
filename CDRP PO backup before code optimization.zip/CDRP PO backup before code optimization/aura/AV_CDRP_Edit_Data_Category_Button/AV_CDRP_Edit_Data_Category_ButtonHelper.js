({
	doInitHelper: function(component, event,helper) {
        var rec = component.get("v.recordId");
        var action = component.get("c.getPlanStatus");
        action.setParams({
            'recordId':rec
        }); 
        action.setCallback(this,function(response){
            if (response.getState() == "SUCCESS") {
                var resp = response.getReturnValue();
                if(resp[$A.get("$Label.c.AV_CDRP_Plan_Owner")]){
                    helper.showToast('ERROR', 'ERROR', $A.get('$Label.c.AV_CDRP_Edit_Data_Category_Access_Error'));
                    window.history.back();
                }
                else if(resp[$A.get("$Label.c.AV_CDRP_Plan_Status")]){
                    helper.showToast('ERROR', 'ERROR', $A.get("$Label.c.AV_CDRP_Data_Trajectory_Edit_Validation_Message"));
                    window.history.back();
                }
                else {
                    component.set("v.showModal", true);
                }    
            }
        });
        $A.enqueueAction(action);
    },
    showToast: function (toastTitle, toastType, toastMessage) {
		var toastEvent = $A.get("e.force:showToast");
		toastEvent.setParams({
				"title": toastTitle,
				"type": toastType,
				"message": toastMessage
		});
		toastEvent.fire();
    },
    onchange :  function(component, event, helper) {
        var planId = component.get("v.recordId");
        var pageReference = {    
            type: "standard__recordPage",
            attributes: {
                "recordId": planId,
                "objectApiName": 'AV_CDRP_Data_Review_Plan__c',
                "actionName": "view"   
            }
        };
        component.set("v.pageReference", pageReference);
        var navService = component.find("navService");
        var pageReference = component.get("v.pageReference");
        navService.navigate(pageReference);
        window.location.reload();
	 }
})