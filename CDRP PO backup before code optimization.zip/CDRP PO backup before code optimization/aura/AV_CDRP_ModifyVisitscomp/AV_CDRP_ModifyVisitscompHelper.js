({
    doInitHelper: function (component, event, helper) {
        var self = this;
        self.getvalues(component, event, helper);
		var currentDate = new Date();
        component.set("v.loadDateTime", currentDate);
    },
    showToast: function (toastTitle, toastType, toastMessage) {
		var toastEvent = $A.get("e.force:showToast");
		toastEvent.setParams({
				"title": toastTitle,
				"type": toastType,
				"message": toastMessage
		});
		toastEvent.fire();
    },	

    closeModel: function (component, event, helper) {
        var navEvt = $A.get("e.force:navigateToSObject");
        var checkId = component.get("v.recordId");
        navEvt.setParams({
            "recordId": checkId,
            "slideDevName": "related"
        });
        navEvt.fire();
        $A.get('e.force:refreshView').fire();
    },

    onchange: function (component, event, helper) {
        var selectedRec = event.getSource().get("v.value");
        var lstofselectedrecords = component.get("v.selectedvisits");
        var checkedlst = component.get("v.finalcheck");
        var uncheckedlst = component.get("v.finaluncheck");
        if (event.getSource().get("v.checked") == true) {
            if (uncheckedlst.includes(selectedRec)) {
                var index = uncheckedlst.indexOf(selectedRec);
                uncheckedlst.splice(index, 1);
            }
            checkedlst.push(selectedRec);
        } else {
            if (checkedlst.includes(selectedRec)) {
                var index = checkedlst.indexOf(selectedRec);
                checkedlst.splice(index, 1);
            }
            uncheckedlst.push(selectedRec);
        }
        component.set("v.finalcheck", checkedlst);
        component.set("v.finaluncheck", uncheckedlst);
    },
	
	onSave: function (component, event, helper) {
        var selectedRec = component.get("v.selectedvisits");
        var checkId = component.get("v.recordId");
        var action = component.get("c.delRecords");
        var checkedlst = component.get("v.finalcheck");
        var uncheckedlst = component.get("v.finaluncheck");
        action.setParams({
            'loadTime': component.get("v.loadDateTime"),
            'name': selectedRec,
            'recID': checkId,
            'finalcheck': checkedlst,
            'finaluncheck': uncheckedlst
        });
        action.setCallback(this,function(response){
            if (response.getState() ==="ERROR") {
                var errors = response.getError();
                helper.showToast('ERROR', 'ERROR',errors[0].message);
            }
            else if (response.getState() ==="SUCCESS"){
                var checkModifiedDateStr = response.getReturnValue().substring(0,19) + 'Z';
                var loadDate = component.get("v.loadDateTime");
                var checkModifiedDate = new Date(checkModifiedDateStr);
                if(loadDate < checkModifiedDate){
                    helper.showToast('ERROR', 'ERROR', $A.get("$Label.c.AV_CDRP_Record_Modified_Error"));
                }
                else{
                   /* var pageReference = {
                        type: "standard__recordPage",
                        attributes: {
                            "recordId": component.get("v.recordId"),
                            "objectApiName": 'AV_CDRP_Data_Checks__c',
                            "actionName": "view"
                        }
                    };
                    component.set("v.pageReference", pageReference);
                    var navService = component.find("navService");
                    var pageReference = component.get("v.pageReference");
                    navService.navigate(pageReference);
                    setTimeout(function(){$A.get('e.force:refreshView').fire();},1500);*/
                    window.location.assign('/'+component.get("v.recordId"));
                }
            }
        });
        $A.enqueueAction(action);
    },

    getvalues: function (component, event, helper) {
        var myPageRef = component.get("v.pageReference");
        var firstname = myPageRef.state.c__recordId;
        var isCheckBoxChecked = myPageRef.state.c__updateVisits;
        var checkStatus = myPageRef.state.c__checkStatus;
        if(checkStatus==$A.get("$Label.c.AV_CDRP_Status_InApproval") || checkStatus==$A.get("$Label.c.AV_CDRP_Data_Check_Status_Completed") || checkStatus==$A.get("$Label.c.AV_CDRP_Data_Review_Plan_Status_Cancelled") || checkStatus==$A.get("$Label.c.AV_CDRP_Data_Check_Status_Superseded")) {
            helper.showToast('ERROR', 'ERROR', $A.get("$Label.c.AV_CDRP_Data_Trajectory_Edit_Validation_Message"));
            window.history.back();
        }
        else {
            component.set("v.showModal", true);
        }
        if (isCheckBoxChecked == 0) {
            isCheckBoxChecked = false;
        } else {
            isCheckBoxChecked = true;
        }
        component.set("v.isCheckBoxChecked", isCheckBoxChecked);
        component.set("v.recordId", firstname);
        var checkId = component.get("v.recordId");
        //TO GET UNLINKED VISITS
        if (!isCheckBoxChecked) {
            var action = component.get("c.getallVisits");
            action.setParams({
                'recID': checkId
            });
            action.setCallback(this, function (response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    var storeResponse = response.getReturnValue();
                    // set searchResult list with return value from server.
                    component.set("v.allvisits", storeResponse);
                    var result = component.get("v.allvisits");
                }
            });
            // enqueue the Action  
            $A.enqueueAction(action);

            //TO GET LINKED VISITS
            var action1 = component.get("c.getRecords");
            action1.setParams({
                'recID': checkId
            });
            action1.setCallback(this, function (response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    var storeResponse = response.getReturnValue();

                    // set searchResult list with return value from server.
                    component.set("v.Listofvisits", storeResponse);
                    var result1 = component.get("v.Listofvisits");
                    var self = this;
                    self.separatelists(component, event, helper);
                }

            });
            // enqueue the Action  
            $A.enqueueAction(action1);
        }
    },
    separatelists: function (component, event, helper) {
        var result = component.get("v.allvisits");
        var result1 = component.get("v.Listofvisits");
        var check = component.get("v.checkedvisits");
        var uncheck = component.get("v.uncheckedvisits");
        for (var i = 0; i < result.length; i++) {
            if (result1.includes(result[i]))
                check.push(result[i]);
            else
                uncheck.push(result[i]);
        }
        component.set("v.checkedvisits", check);
        component.set("v.uncheckedvisits", uncheck);
        component.set("v.finalcheck", check);
        component.set("v.finaluncheck", uncheck);

        //get names of check id:
        var action1 = component.get("c.getnames");
        action1.setParams({
            'lstofids': component.get("v.finalcheck")
        });
        action1.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();

                // set searchResult list with return value from server.
                component.set("v.nameofcheck", storeResponse);
            }

        });
        $A.enqueueAction(action1);
        //get names of uncheck id
        var action = component.get("c.getnames");
        action.setParams({
            'lstofids': component.get("v.finaluncheck")
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                // set searchResult list with return value from server.
                component.set("v.nameofuncheck", storeResponse);
            }
        });
        $A.enqueueAction(action);
    }
})