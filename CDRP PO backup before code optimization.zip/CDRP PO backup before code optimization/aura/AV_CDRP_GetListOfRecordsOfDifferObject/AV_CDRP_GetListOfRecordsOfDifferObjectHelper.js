({


 observationsBuildDatatable: function(component, event, helper) {
    component.set('v.showSection',false);
    var userId = $A.get("$SObjectType.CurrentUser.Id").substring(0, 15);
    var pageName = component.get("v.PageName");
     
    
    var relatedIdrp = '';
    if(component.get("v.PageName")!==$A.get("$Label.c.AV_CDRP_Home")){
        relatedIdrp = component.get("v.recordId");
    }
    
    
    helper.callServer(component,"c.getTotalObservations", 
    function(response){
        component.set("v.SectionSize",response);  
        if(component.get("v.SectionSize")>0){
        component.set('v.showSection',true); 
        }
    
    },{userId : userId,
        relatedIdrp :relatedIdrp,
        pageName : pageName
        },true);
     
    var pageSize = component.get("v.pageSize").toString();
    var pageNumber = component.get("v.pageNumber").toString();
    helper.showSpinner(component);
    if(component.get("v.PageName")===$A.get("$Label.c.AV_CDRP_Home")){
        helper.callServer(component,"c.getObservationsRecords",
                        function(response){
                            helper.hideSpinner(component);
                        //re-initialize
                        var completeList = [];
                        component.set('v.rowSection',false);
                        // component.set('v.showSection',false);
                        component.set("v.completeList",completeList);
                        component.set("v.rawData",completeList);  
                        component.set("v.totalRecords", 0);
                        component.set("v.startPage",0);
                        component.set("v.endPage",0);
                        var paginationList = [];
                        component.set('v.paginationList', paginationList);
                        //  component.set("v.SectionSize",0);
                            
                        if(response.length>0){
                                component.set('v.rowSection',false);
                                var pageSize = component.get("v.pageSize");
                                var completeList = response; 
                                component.set("v.totalRecords", completeList.length);
                                component.set("v.rawData",completeList);  
    
                                
                                for(var i=0;i<completeList.length;i++){
                                    completeList[i].linkName = '/'+completeList[i].Id;
                                    
                                }
                                if(completeList.length <component.get("v.pageSize")){
                                    component.set("v.isLastPage", true);
                                } else{
                                    var remSize = (component.get("v.SectionSize"))-((completeList.length)*component.get("v.pageNumber"));
                                    if(remSize<component.get("v.pageSize")&&remSize>0){
                                        component.set("v.isLastPage", false);
                                    }
                                    else if(remSize>component.get("v.pageSize")){
                                        component.set("v.isLastPage", false);
                                    }
                                    else{
                                    component.set("v.isLastPage", true);
                                    }
                                }
                            
                                
                                for(var i=0;i<completeList.length;i++){
                                    completeList[i].linkName = '/'+completeList[i].Id;
                                }
                                component.set("v.dataSize", completeList.length);
                                component.set('v.paginationList', completeList);
                            }
                            component.set('v.columns', [
                            {label: 'OBSERVATION ID', fieldName: 'linkName', type: 'url', typeAttributes: {label: { fieldName: 'Name' }, target: '_blank'}},
                            {label: 'CATEGORY', fieldName: 'AV_Category__c', type: 'text'},
                            {label: 'SUBCATEGORY', fieldName: 'AV_Subcategory__c', type: 'text'},
                            {label: 'ADDITIONAL  INFO', fieldName: 'AV_Additional_Information__c', type: 'text'},
                            {label: 'STATUS', fieldName: 'AV_Status__c', type: 'text'},
                            {label: 'RELATED STUDY', fieldName: 'AV_Related_Studies__c', type: 'text'},
                            {label: 'AGE FROM CREATION', fieldName: 'AV_Age_from_creation_date__c', type: 'number'},
                            ]);
                    
                      },{
                                userId : userId,
                                relatedIdrp : relatedIdrp,
                                pageSize : pageSize,
                                pageNumber : pageNumber,
                                pageName : pageName
                                },true);
                            }
                            else {
                            helper.callServer(component,"c.getObservationsRecords",
                            function(response){
                                helper.hideSpinner(component);
                            //re-initialize
                            var completeList = [];
                            component.set('v.rowSection',false);
                            // component.set('v.showSection',false);
                            component.set("v.completeList",completeList);
                            component.set("v.rawData",completeList);  
                            component.set("v.totalRecords", 0);
                            component.set("v.startPage",0);
                            component.set("v.endPage",0);
                            var paginationList = [];
                            component.set('v.paginationList', paginationList);
                            //  component.set("v.SectionSize",0);
                                
                            if(response.length>0){
                                    component.set('v.rowSection',false);
                                    var pageSize = component.get("v.pageSize");
                                    var completeList = response; 
                                    component.set("v.totalRecords", completeList.length);
                                    component.set("v.rawData",completeList);  
    
                                    
                                    for(var i=0;i<completeList.length;i++){
                                        completeList[i].linkName = '/'+completeList[i].Id;
                                        
                                    }
                                    if(completeList.length <component.get("v.pageSize")){
                                        component.set("v.isLastPage", true);
                                    } else{
                                        var remSize = (component.get("v.SectionSize"))-((completeList.length)*component.get("v.pageNumber"));
                                        if(remSize<component.get("v.pageSize")&&remSize>0){
                                            component.set("v.isLastPage", false);
                                        }
                                        else if(remSize>component.get("v.pageSize")){
                                            component.set("v.isLastPage", false);
                                        }
                                        else{
                                        component.set("v.isLastPage", true);
                                        }
                                    }
                                    

                                
                                for(var i=0;i<completeList.length;i++){
                                    completeList[i].linkName = '/'+completeList[i].Id;
                                }
                                component.set("v.dataSize", completeList.length);
                            component.set('v.paginationList', completeList);
                            }
                                
                                component.set('v.columns', [
                                    {label: 'OBSERVATION ID', fieldName: 'linkName', type: 'url', typeAttributes: {label: { fieldName: 'Name' }, target: '_blank'}},
                                    {label: 'CATEGORY', fieldName: 'AV_Category__c', type: 'text'},
                                    {label: 'SUBCATEGORY', fieldName: 'AV_Subcategory__c', type: 'text'},
                                    {label: 'ADDITIONAL  INFO', fieldName: 'AV_Additional_Information__c', type: 'text'},
                                    {label: 'STATUS', fieldName: 'AV_Status__c', type: 'text'},
                                    {label: 'RELATED STUDY', fieldName: 'AV_Related_Studies__c', type: 'text'},
                                    {label: 'AGE FROM CREATION', fieldName: 'AV_Age_from_creation_date__c', type: 'number'},
                                    ]); 
                                    },{
                                    userId : userId,
                                    relatedIdrp : relatedIdrp,
                                    pageSize : pageSize,
                                    pageNumber : pageNumber,
                                    pageName : pageName
                                    },true);
                            }
                            
},



queriesBuildDatatable: function(component, event, helper) {


component.set('v.showSection',false);
var userId = $A.get("$SObjectType.CurrentUser.Id");
var pageName = component.get("v.PageName");


var relatedIdrp = '';
if(component.get("v.PageName")!==$A.get("$Label.c.AV_CDRP_Home")){
    relatedIdrp = component.get("v.recordId");
}
    var rowActions = helper.getQueryRowActions.bind(this, component); 


helper.callServer(component,"c.getTotalQueries", 
function(response){
    component.set("v.SectionSize",response);  
    if(component.get("v.SectionSize")>0){
    component.set('v.showSection',true); 
    }

},{userId : userId,
    relatedIdrp :relatedIdrp,
    pageName : pageName
    },true);
 
var pageSize = component.get("v.pageSize").toString();
var pageNumber = component.get("v.pageNumber").toString();
helper.showSpinner(component);
if(component.get("v.PageName")===$A.get("$Label.c.AV_CDRP_Home")){
helper.callServer(component,"c.getQueriesRecords",
                    function(response){
                        helper.hideSpinner(component);
                    //re-initialize
                    var completeList = [];
                    component.set('v.rowSection',false);
                    // component.set('v.showSection',false);
                    component.set("v.completeList",completeList);
                    component.set("v.rawData",completeList);  
                    component.set("v.totalRecords", 0);
                    component.set("v.startPage",0);
                    component.set("v.endPage",0);
                    var paginationList = [];
                    component.set('v.paginationList', paginationList);
                    //  component.set("v.SectionSize",0);
                        
                    if(response.length>0){
                            component.set('v.rowSection',false);
                            var pageSize = component.get("v.pageSize");
                            var completeList = response; 
                            component.set("v.totalRecords", completeList.length);
                            component.set("v.rawData",completeList);  

                            
                            for(var i=0;i<completeList.length;i++){
                                completeList[i].linkName = '/'+completeList[i].Id;
                                
                            }
                            if(completeList.length <component.get("v.pageSize")){
                                component.set("v.isLastPage", true);
                            } else{
                                var remSize = (component.get("v.SectionSize"))-((completeList.length)*component.get("v.pageNumber"));
                                if(remSize<component.get("v.pageSize")&&remSize>0){
                                    component.set("v.isLastPage", false);
                                }
                                else if(remSize>component.get("v.pageSize")){
                                    component.set("v.isLastPage", false);
                                }
                                else{
                                component.set("v.isLastPage", true);
                                }
                            }
                            component.set("v.dataSize", completeList.length);
                            component.set('v.paginationList', completeList);
                        }
                
                    
                        component.set('v.columns', [
                            {label: 'DISCREPANCY/QUERY ID', fieldName: 'linkName', type: 'url', typeAttributes: {label: { fieldName: 'name' }, target: '_blank'}},
                            {label: 'QUERY SOURCE', fieldName: 'querySource', type: 'text'},
                            {label: 'RELATED IDRP', fieldName: 'relatedIDRP', type: 'text'},
                            {label: 'COUNTRY', fieldName: 'country', type: 'text'},
                            {label: 'INVESTIGATOR NAME', fieldName: 'investigatorName', type: 'text'},
                            {label: 'SUBJECT NAME', fieldName: 'subjectName', type: 'text'},
                            {label: 'DATA FORM', fieldName: 'dataForm', type: 'text'},
                            {label: 'FIELD NAME', fieldName: 'fieldName', type: 'text'},
                            {label: 'QUERY TEXT', fieldName: 'queryText', type: 'text'},
                            {label: 'DISCREPANCY/QUERY STATUS', fieldName: 'status', type: 'text'},
                            {label: 'USER COMMENT', fieldName: 'userComment', type: 'text'},
                            {label: 'DAYS OPEN', fieldName: 'daysOpen', type: 'number'},
                            { type: 'action', typeAttributes: { rowActions: rowActions } }

                        ]);     
                            },{
                            userId : userId,
                            relatedIdrp : relatedIdrp,
                            pageSize : pageSize,
                            pageNumber : pageNumber,
                            pageName : pageName
                            },true);
                        }
                        else if(component.get("v.PageName")===$A.get("$Label.c.AV_CDRP_Record_Action")){
                        helper.callServer(component,"c.getQueriesRecords",
                        function(response){
                            helper.hideSpinner(component);
                        //re-initialize
                        var completeList = [];
                        component.set('v.rowSection',false);
                        // component.set('v.showSection',false);
                        component.set("v.completeList",completeList);
                        component.set("v.rawData",completeList);  
                        component.set("v.totalRecords", 0);
                        component.set("v.startPage",0);
                        component.set("v.endPage",0);
                        var paginationList = [];
                        component.set('v.paginationList', paginationList);
                        //  component.set("v.SectionSize",0);
                            
                        if(response.length>0){
                                component.set('v.rowSection',false);
                                var pageSize = component.get("v.pageSize");
                                var completeList = response; 
                                component.set("v.totalRecords", completeList.length);
                                component.set("v.rawData",completeList);  

                                
                                for(var i=0;i<completeList.length;i++){
                                    completeList[i].linkName = '/'+completeList[i].Id;
                                    
                                }
                                if(completeList.length <component.get("v.pageSize")){
                                    component.set("v.isLastPage", true);
                                } else{
                                    var remSize = (component.get("v.SectionSize"))-((completeList.length)*component.get("v.pageNumber"));
                                    if(remSize<component.get("v.pageSize")&&remSize>0){
                                        component.set("v.isLastPage", false);
                                    }
                                    else if(remSize>component.get("v.pageSize")){
                                        component.set("v.isLastPage", false);
                                    }
                                    else{
                                    component.set("v.isLastPage", true);
                                    }
                                }
                                component.set("v.dataSize", completeList.length);
                                component.set('v.paginationList', completeList);
                            }
                    
                        
                            component.set('v.columns', [
                                {label: 'DISCREPANCY/QUERY ID', fieldName: 'linkName', type: 'url', typeAttributes: {label: { fieldName: 'name' }, target: '_blank'}},
                                {label: 'QUERY SOURCE', fieldName: 'querySource', type: 'text'},
                                {label: 'COUNTRY', fieldName: 'country', type: 'text'},
                                {label: 'INVESTIGATOR NAME', fieldName: 'investigatorName', type: 'text'},
                                {label: 'SUBJECT NAME', fieldName: 'subjectName', type: 'text'},
                                {label: 'DATA FORM', fieldName: 'dataForm', type: 'text'},
                                {label: 'FIELD NAME', fieldName: 'fieldName', type: 'text'},
                                {label: 'QUERY TEXT', fieldName: 'queryText', type: 'text'},
                                {label: 'DISCREPANCY/QUERY STATUS', fieldName: 'status', type: 'text'},
                                {label: 'USER COMMENT', fieldName: 'userComment', type: 'text'},
                                {label: 'DAYS OPEN', fieldName: 'daysOpen', type: 'number'},
                                { type: 'action', typeAttributes: { rowActions: rowActions } }

                            ]);     
                                },{
                                userId : userId,
                                relatedIdrp : relatedIdrp,
                                pageSize : pageSize,
                                pageNumber : pageNumber,
                                pageName : pageName
                                },true);
                        }
                        else {
                        helper.callServer(component,"c.getQueriesRecords",
                    function(response){
                        helper.hideSpinner(component);
                    //re-initialize
                    var completeList = [];
                    component.set('v.rowSection',false);
                    // component.set('v.showSection',false);
                    component.set("v.completeList",completeList);
                    component.set("v.rawData",completeList);  
                    component.set("v.totalRecords", 0);
                    component.set("v.startPage",0);
                    component.set("v.endPage",0);
                    var paginationList = [];
                    component.set('v.paginationList', paginationList);
                    //  component.set("v.SectionSize",0);
                        
                    if(response.length>0){
                            component.set('v.rowSection',false);
                            var pageSize = component.get("v.pageSize");
                            var completeList = response; 
                            component.set("v.totalRecords", completeList.length);
                            component.set("v.rawData",completeList);  

                            
                            for(var i=0;i<completeList.length;i++){
                                completeList[i].linkName = '/'+completeList[i].Id;
                                
                            }
                            if(completeList.length <component.get("v.pageSize")){
                                component.set("v.isLastPage", true);
                            } else{
                                var remSize = (component.get("v.SectionSize"))-((completeList.length)*component.get("v.pageNumber"));
                                if(remSize<component.get("v.pageSize")&&remSize>0){
                                    component.set("v.isLastPage", false);
                                }
                                else if(remSize>component.get("v.pageSize")){
                                    component.set("v.isLastPage", false);
                                }
                                else{
                                component.set("v.isLastPage", true);
                                }
                            }
                            component.set("v.dataSize", completeList.length);
                            component.set('v.paginationList', completeList);
                        }
                
                    
                        component.set('v.columns', [
                            {label: 'DISCREPANCY/QUERY ID', fieldName: 'linkName', type: 'url', typeAttributes: {label: { fieldName: 'name' }, target: '_blank'}},
                            {label: 'QUERY SOURCE', fieldName: 'querySource', type: 'text'},
                            {label: 'COUNTRY', fieldName: 'country', type: 'text'},
                            {label: 'INVESTIGATOR NAME', fieldName: 'investigatorName', type: 'text'},
                            {label: 'SUBJECT NAME', fieldName: 'subjectName', type: 'text'},
                            {label: 'DATA FORM', fieldName: 'dataForm', type: 'text'},
                            {label: 'FIELD NAME', fieldName: 'fieldName', type: 'text'},
                            {label: 'QUERY TEXT', fieldName: 'queryText', type: 'text'},
                            {label: 'DISCREPANCY/QUERY STATUS', fieldName: 'status', type: 'text'},
                            {label: 'USER COMMENT', fieldName: 'userComment', type: 'text'},
                            {label: 'DAYS OPEN', fieldName: 'daysOpen', type: 'number'},
                            { type: 'action', typeAttributes: { rowActions: rowActions } }

                        ]);     
                            },{
                            userId : userId,
                            relatedIdrp : relatedIdrp,
                            pageSize : pageSize,
                            pageNumber : pageNumber,
                            pageName :pageName
                            },true);
                        }

                            },
    showSpinner: function (component, event, helper) {
                                var spinner = component.find("mySpinner");
                                $A.util.removeClass(spinner, "slds-hide");
                            },
                                
        hideSpinner: function (component, event, helper) {
                                var spinner = component.find("mySpinner");
                                $A.util.addClass(spinner, "slds-hide");
                            },

        handleNext : function(component, event, helper) { 
                                var pageNumber = component.get("v.pageNumber");
                                component.set("v.pageNumber", pageNumber+1);
                                if(component.get('v.SectionName')==='OPEN OBSERVATIONS'){
                                helper.observationsBuildDatatable(component, event, helper);
                                }else{
                                helper.queriesBuildDatatable(component, event, helper);
                                }
                            },
                                
        handlePrev : function(component, event, helper) {        
                                var pageNumber = component.get("v.pageNumber");
                                component.set("v.pageNumber", pageNumber-1);
                                   if(component.get('v.SectionName')==='OPEN OBSERVATIONS'){
                                    helper.observationsBuildDatatable(component, event, helper);
                                    }else{
                                    helper.queriesBuildDatatable(component, event, helper);
                                    }
                            },
    
    
    handleRowAction: function (component, event, helper) {
        var action = event.getParam('action');
        var row = event.getParam('row');
        if(component.get("v.PageName")===$A.get("$Label.c.AV_CDRP_Home")){
        switch (action.name) {
            case 'Edit':                
                var editRecordEvent = $A.get("e.force:editRecord");
                editRecordEvent.setParams({
                    "recordId": row['Id']
                });
                editRecordEvent.fire();                
                break;          
        }
        }
        else{
        switch (action.name) {
            case 'Edit':                  
                var editRecordEvent = $A.get("e.force:editRecord");
                editRecordEvent.setParams({
                    "recordId": row['Id']
                });
                editRecordEvent.fire();                
                break;       
                
            case 'follow':
            helper.followRecord(component, event, helper, row);
            break;
            
            case 'unfollow':
            helper.unFollowRecord(component, event, helper, row);
            break;    
        }
        }
    },
        handleSaveSuccess: function (component, event, helper) {
            $A.get("e.force:refreshView").fire();
        },
            
        
                getQueryRowActions: function (cmp, row, doneCallback) {
                    var actions = [];
                    actions = [
                    {
                        'label': 'Edit',
                        'name': 'Edit'
                    },
                    
                ];
                if(cmp.get("v.PageName")!==$A.get("$Label.c.AV_CDRP_Home")){
                if (row['isFollowed']) {
                    actions.push({
                        'label': 'Unfollow',
                        'iconName': 'utility:ban',
                        'name': 'unfollow'
                    });
                } else {
                    actions.push({
                        'label': 'Follow',
                        'iconName': 'utility:approval',
                        'name': 'follow'
                    });
                    
                }  
            }
                    
                    
                    // simulate a trip to the server
                    setTimeout($A.getCallback(function () {
                    doneCallback(actions);
                    }), 200);
                    },
                    
                    })