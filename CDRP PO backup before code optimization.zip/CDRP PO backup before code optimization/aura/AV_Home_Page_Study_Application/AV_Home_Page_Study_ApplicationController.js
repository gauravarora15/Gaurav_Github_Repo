({
	getStudyApplications : function(component, event, helper) {
		var actions = [
            { label: $A.get('$Label.c.AV_SPT_Edit'), name: 'Edit' }
        ]  
        component.set('v.columns', [ 		
            {label: $A.get('$Label.c.AV_SPT_SPIRIT_Number'), fieldName: 'linkName', type: 'url', 
             typeAttributes: {label: { fieldName: 'Name' }, target: '_self'}}, 			
            {label: $A.get('$Label.c.AV_SPT_Study_Title'), fieldName: 'AV_SPT_Study_Title__c', type: 'text'}, 
            {label: $A.get('$Label.c.AV_SPT_Application_Status'), fieldName: 'AV_SPT_Application_Status__c', type: 'String'}, 
            {label: $A.get('$Label.c.AV_SPT_Application_Type'), fieldName: 'AV_SPT_Application_Type__c', type: 'text'},            
            {type: 'action', typeAttributes: { rowActions: actions } } 
        ]); 
        helper.isExternalPortalUser(component);//get data from the helper 
	},
	handleRowAction: function (component, event, helper) {
        var action = event.getParam('action');
        var row = event.getParam('row');
        switch (action.name) {
            case 'Edit':
                if(component.get("v.isExternalSubmitter")){
                    var vfUrl = '/external/apex/AV_SPT_Study_Application_edit_Redirect?id='+row.Id;
                    var urlEvent = $A.get("e.force:navigateToURL");
                    urlEvent.setParams({
                        "url": vfUrl
                    });
                    urlEvent.fire();
                }else{
                    var editRecordEvent = $A.get("e.force:editRecord");
                    editRecordEvent.setParams({
                        "recordId": row.Id
                    });
                    editRecordEvent.fire();
                    //  $A.get('e.force:refreshView').fire(); 
                    
                }
                
        }
    },
    
     /* handleSelect: function (component, event, helper) {   
         component.set("v.isOpen", true); 
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
            componentDef: "c:AV_RecTypeSelcOnNew",
            componentAttributes:{
            isOpen : component.get("v.isOpen")
        }         
       });
    evt.fire();
    
    }, */
	onNext : function(component, event, helper) {        
        var pageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", pageNumber+1);
        helper.buildData(component, helper);
    },
    
    onPrev : function(component, event, helper) {        
        var pageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", pageNumber-1);
        helper.buildData(component, helper);
    },
    
    processMe : function(component, event, helper) {
        component.set("v.currentPageNumber", parseInt(event.target.name));
        helper.buildData(component, helper);
    }
})