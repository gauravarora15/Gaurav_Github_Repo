({
	onSearch : function(component, helper, filter) {
        var relatedIdrp = component.get("v.recordId");
         helper.callServer(component, "c.getCategoryMDRwithDataChecks",
                          function(response){
                               var result = response;
                               var arrayMapKeys = [];
                               for(var key in result){
                               arrayMapKeys.push({key: key, value: result[key]});
                               }
                              if(arrayMapKeys.length>0){
                                  component.set("v.mapChecks",arrayMapKeys);
                                  component.set("v.catFound",true);
                                  
                              }
                              else{
                                   component.set("v.catFound",false);
                              }  
                          },{
                              filter : filter,
                              relatedIdrp :relatedIdrp
                          }
                              
                          );
        
		
	},
    
    handleExpand : function(component, helper, filter) {
        component.set("v.activeSectionsFlag",true);
        var relatedIdrp = component.get("v.recordId");

        
        helper.callServer(component, "c.getAllDataCategoriesMDR",
                          function(response){ 
                              if(response.length>0){
                                  component.set("v.activeSections",response);
                                  
                              }},
                             {
                              relatedIdrp :relatedIdrp,
                                 filter :filter
                            }
                              
                          );
    },
                              
        
        
    
    
    handleCollapse : function(component, helper) {
        
                component.set("v.activeSectionsFlag",false);
                component.set("v.activeSections",null);


        
    }
    
})