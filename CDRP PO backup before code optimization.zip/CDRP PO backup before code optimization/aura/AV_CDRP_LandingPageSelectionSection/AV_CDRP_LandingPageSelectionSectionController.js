({ 
    
   doInit : function(component, event, helper) {  
       
       if(component.get('v.SectionName')==='OPEN TASKS'){
           component.set('v.SubSectionName','ASSIGNED TO ME'); 
           helper.taskBuildDatatable(component, event, helper);
       }
        
    },
    reInit : function(component,event,helper) {
      if(component.get("v.PageName") === 'Record')
      {
         if(component.get('v.SectionName')==='OPEN TASKS'){
           component.set('v.SubSectionName','ASSIGNED TO ME'); 
           helper.taskBuildDatatable(component, event, helper);
      	 }
         
      }
    },
    next: function (component, event, helper) {
        helper.next(component, event, helper);        
    },
    previous: function (component, event, helper) {
        helper.previous(component, event, helper);        
    },
    handleRowAction: function (component, event, helper) {
        helper.handleRowAction(component, event, helper);        
    },
    handleSaveSuccess: function (component, event, helper) {
        helper.handleSaveSuccess(component, event, helper);      }
    
})