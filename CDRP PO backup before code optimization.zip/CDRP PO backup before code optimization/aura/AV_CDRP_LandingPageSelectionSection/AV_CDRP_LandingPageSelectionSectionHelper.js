({

taskBuildDatatable: function(component, event, helper) {
    var rowActions = helper.getTaskRowActions.bind(this, component);
    var userId = $A.get("$SObjectType.CurrentUser.Id");
    var relatedIdrp = '';
    if(component.get("v.PageName")==="Record"){
        relatedIdrp = component.get("v.recordId");
    }
    helper.callServer(component,"c.getTaskRecords", 
                        function(response){                              
                            //re-initialize
                            var completeList = [];
                            component.set('v.rowSection',false);
                            component.set('v.showSection',false);
                            component.set("v.completeList",completeList);
                            component.set("v.rawData",completeList);  
                            component.set("v.totalRecords", 0);
                            component.set("v.startPage",0);
                            component.set("v.endPage",0);
                            var paginationList = [];
                            component.set('v.paginationList', paginationList);
                            component.set("v.SectionSize",0); 
                            
                            if(response.length>0){
                                component.set('v.rowSection',true);
                                component.set('v.showSection',true);
                                
                                var pageSize = component.get("v.pageSize");
                                var completeList = response; 
                                component.set("v.completeList",completeList);
                                component.set("v.rawData",completeList);  
                                component.set("v.totalRecords", completeList.length);
                                component.set("v.startPage",0);
                                component.set("v.endPage",pageSize);
                                var paginationList = [];
                                for(var i=0; i< pageSize; i++){
                                    if(completeList.length> i)
                                        paginationList.push(completeList[i]);    
                                }
                                for(var i=0;i<completeList.length;i++){
                                    completeList[i].linkName = '/'+completeList[i].Id;
                                    if(component.get("v.PageName")!=="Record"){
                                    if(completeList[i].AV_CDRP_Related_Study_Name__c!=null)
                                        completeList[i].AV_CDRP_Related_Study = completeList[i].AV_CDRP_Related_Study_Name__c;
                                    }
                                    else{
                                    if(completeList[i].AV_CDRP_Related_Study_Name__c!=null)
                                    completeList[i].cdrpTaskRelatedStudy = completeList[i].cdrpTaskRelatedStudy;
                                    }
                                    
                                }
                                component.set('v.paginationList', paginationList);
                                component.set("v.SectionSize",completeList.length);
                            }
                            if(component.get("v.PageName")!=="Record"){
                            component.set('v.columns', [
                                {label: 'TASK ID', fieldName: 'linkName', type: 'url', typeAttributes: {label: { fieldName: 'Name' }, target: '_blank'}},
                                {label: 'TASK CATEGORY', fieldName: 'AV_CDRP_Task_Category__c', type: 'text'},
                                {label: 'DESCRIPTION', fieldName: 'AV_CDRP_Task_Description__c', type: 'text'},
                                {label: 'PRIORITY', fieldName: 'AV_CDRP_Task_Priority__c', type: 'text'},
                                {label: 'DUE DATE', fieldName: 'AV_CDRP_Due_Date__c',  type: 'date-local'},
                                {label: 'RELATED STUDY', fieldName: 'AV_CDRP_Related_Study', type: 'text'},
                                {label: 'STATUS', fieldName: 'AV_CDRP_Status__c', type: 'text'},
                                { type: 'action', typeAttributes: { rowActions: rowActions } }
                            ]);
                        }
                        else{
                
                            component.set('v.columns', [
                                {label: 'TASK ID', fieldName: 'linkName', type: 'url', typeAttributes: {label: { fieldName: 'name' }, target: '_blank'}},
                                {label: 'TASK CATEGORY', fieldName: 'cdrpTaskCategory', type: 'text'},
                                {label: 'DESCRIPTION', fieldName: 'cdrpTaskDescription', type: 'text'},
                                {label: 'PRIORITY', fieldName: 'cdrpTaskPriority', type: 'text'},
                                {label: 'DUE DATE', fieldName: 'cdrpDueDate',  type: 'date-local'},
                                {label: 'RELATED IDRP', fieldName: 'cdrpTaskRelatedIdrp', type: 'text'},
                                {label: 'STATUS', fieldName: 'cdrpStatus', type: 'text'},
                                { type: 'action', typeAttributes: { rowActions: rowActions } }
                            ]);  
                        }
                        },{
                            userId : userId,
                            relatedIdrp : relatedIdrp
                        }) 
},


                                
    
    
    next: function (component, event, helper) {
        var sObjectList = component.get("v.completeList");
        var end = component.get("v.endPage");
        var start = component.get("v.startPage");
        var pageSize = component.get("v.pageSize");
        var paginationList = [];
        var counter = 0;
        for(var i=end; i<end+pageSize; i++){
            if(sObjectList.length > i){
                paginationList.push(sObjectList[i]);
            }
            counter ++ ;
        }
        start = start + counter;
        end = end + counter;
        component.set("v.startPage",start);
        component.set("v.endPage",end);
        component.set('v.paginationList', paginationList);
    },
        previous: function (component, event, helper) {
            var sObjectList = component.get("v.completeList");
            var end = component.get("v.endPage");
            var start = component.get("v.startPage");
            var pageSize = component.get("v.pageSize");
            var paginationList = [];
            var counter = 0;
            for(var i= start-pageSize; i < start ; i++){
                if(i > -1){
                    paginationList.push(sObjectList[i]);
                    counter ++;
                }else{
                    start++;
                }
            }
            start = start - counter;
            end = end - counter;
            component.set("v.startPage",start);
            component.set("v.endPage",end);
            component.set("v.paginationList", paginationList);
        },
            
            
            
            handleRowAction: function (component, event, helper) {
                var action = event.getParam('action');
                var row = event.getParam('row');
                if(component.get("v.PageName")!=="Record"){
                switch (action.name) {
                    case 'Edit':                
                        var editRecordEvent = $A.get("e.force:editRecord");
                        editRecordEvent.setParams({
                            "recordId": row['Id']
                        });
                        editRecordEvent.fire();                
                        break;          
                }
              }
              else{
                switch (action.name) {
                    case 'Edit':                  
                        var editRecordEvent = $A.get("e.force:editRecord");
                        editRecordEvent.setParams({
                            "recordId": row['Id']
                        });
                        editRecordEvent.fire();                
                        break;       
                      
                    case 'follow':
                    helper.followRecord(component, event, helper, row);
                    break;
                   
                    case 'unfollow':
                    helper.unFollowRecord(component, event, helper, row);
                    break;    
                }
              }
            },
                handleSaveSuccess: function (component, event, helper) {
                    $A.get("e.force:refreshView").fire();
                },
                    
                    
                    
                    getTaskRowActions: function (cmp, row, doneCallback) {
                        
                        var actions = [];
                        
                        if(cmp.get("v.PageName")!=="Record"){
                             actions = [
                                {
                                    'label': 'Edit',
                                    'name': 'Edit'
                                },
                                
                            ];
                        }
                        else{
                         actions = [
                            {
                                'label': 'Edit',
                                'name': 'Edit'
                            },
                            
                        ];
                        if (row['isFollowed']) {
                            actions.push({
                                'label': 'Unfollow',
                                'iconName': 'utility:ban',
                                'name': 'unfollow'
                            });
                        } else {
                            actions.push({
                                'label': 'Follow',
                                'iconName': 'utility:approval',
                                'name': 'follow'
                            });
                        }  
                    }   
                            
                            
                            
                            // simulate a trip to the server
                            setTimeout($A.getCallback(function () {
                            doneCallback(actions);
                            }), 200);
                     },

                
                        
                        })