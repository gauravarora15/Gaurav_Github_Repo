({
	doInit: function(component, event, helper) {
		var emptyLst = [];
		component.set('v.emailPillLst', emptyLst);
		//if($A.util.isEmpty(component.get("v.emailPillLst"))){
			var preSelectedEmailLst = component.get("v.selectedEmailLst");
			console.log('comp doinit called for email input omp: '+JSON.stringify(preSelectedEmailLst));
			for(var i=0; i<preSelectedEmailLst.length; i++){
				helper.pillGenerator(component, event, helper, preSelectedEmailLst[i]);
			}
		//}
    },
    handleChange : function(component, event, helper) {
    	component.find('emailInput').showHelpMessageIfInvalid();
    	//semi-colon 186 || comma 188 || enter = 13
        if(event.keyCode == 188 || event.keyCode == 186 || event.keyCode == 13){
        	var inputComp = component.find('emailInput');
        	var emailVal = component.get("v.emailInputVal");
        	if(event.keyCode == 188 || event.keyCode == 186){
        		emailVal = emailVal.substr(0, emailVal.length-1);
        	}
        	component.set("v.emailInputVal", emailVal);
        	component.find('emailInput').showHelpMessageIfInvalid();
        	var emailFieldValidity = inputComp.get("v.validity");
        	console.log('emailFieldValidity: '+emailFieldValidity.valid);
        	if(emailFieldValidity.valid && !$A.util.isEmpty(emailVal)){
            	helper.createEmailPill(component, event, helper);
            }
        }
    },
    handlePillRemoval : function(component, event, helper) {
        console.log('pill removed');
        var name = event.getParam("item").name;
        console.log(name + ' pill was removed!');
        // Remove the pill from view
        var items = component.get('v.emailPillLst');
        var item = event.getParam("index");
        items.splice(item, 1);
        component.set('v.emailPillLst', items);  
        var currentEmailPillsLst = component.get("v.selectedEmailLst");
        currentEmailPillsLst.splice(item, 1);
        component.set('v.selectedEmailLst', currentEmailPillsLst);
        console.log('currentEmailPillsLst: '+currentEmailPillsLst);
    }
})