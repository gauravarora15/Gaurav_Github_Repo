({
    doInit : function(component, event, helper) {
        var folderName = window.location.href;
        folderName = folderName.split('?folderName=').pop().split('&')[0].replace('%20',' ');
        component.set('v.folderName',folderName);
        var action  = component.get('c.fetchFiles');
        action.setParams({
            "folderName": folderName
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set('v.files',response.getReturnValue());
            }
        });
        
        $A.enqueueAction(action);
    }
})