({
    doInit : function(component, event, helper) {
       helper.doInitHelper(component, event, helper);
    },
    handleClick: function (component, event, helper) {
        helper.handleClickHelper(component, event, helper);
    }
    
})