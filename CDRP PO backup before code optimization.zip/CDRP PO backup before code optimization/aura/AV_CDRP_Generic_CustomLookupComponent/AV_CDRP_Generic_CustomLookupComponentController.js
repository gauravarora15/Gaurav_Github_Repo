({
  onfocus: function(component, event, helper) {
    helper.onfocus(component, helper);
  },
  keyPressController: function(component, event, helper) {
    helper.handleKeyPress(component, helper);
  },

  // function for clear the Record Selaction 
  clear: function(component, event, helper) {
    helper.handleClear(component);
  },

  // This function call when the end User Select any record from the result list.   
  handleComponentEvent: function(component, event, helper) {
    helper.handleComponentEvent(component, event);
  },

  // automatically call when the component is done waiting for a response to a server request.  
  hideSpinner: function(component, event, helper) {
    var spinner = component.find('spinner');
    var evt = spinner.get("e.toggle");
    evt.setParams({
      isVisible: false
    });
    evt.fire();
  },

  // automatically call when the component is waiting for a response to a server request.
  showSpinner: function(component, event, helper) {
    var spinner = component.find('spinner');
    var evt = spinner.get("e.toggle");
    evt.setParams({
      isVisible: true
    });
    evt.fire();
  },
    
    validateInput: function(component, event, helper){
        helper.validateInput(component, event, helper);
    },

    handlePreSelect: function(component, event, helper){
      helper.handlePreSelect(component, event, helper);
    },

    handleBlur : function(component, event, helper){
      helper.handleBlur(component, event, helper);
    }
    

})