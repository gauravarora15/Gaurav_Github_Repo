({
	openModelHelper : function(component, event, helper) {
		component.set("v.Spinner", true);
        var action = component.get("c.validateStatus");
        action.setParams({
            Id : component.get("v.recordId")
        });
        action.setCallback(this, function(response) {
            console.log('Status--'+response.getState());
        	if (response.getState() == "SUCCESS") {
                var errMsg = response.getReturnValue();
                console.log('errMsg--'+errMsg);
                if(errMsg != null && errMsg !=''){
                    component.set("v.isOpen",true);
                    component.set("v.errorMsg",errMsg);
                    component.set("v.Spinner", false);
                }else{
                    //setting timeout for spinner hide
                    setTimeout(function(){
    					component.set("v.Spinner", false);
    				}, 2000);
            	}
            }
        });
        $A.enqueueAction(action);
	},
    closeModelHelper : function(component, event, helper) {
    	component.set("v.isOpen", false);
        window.history.back();
    },
    handleSave : function(component, event, helper) {
        //navigate to the detail page on save
        component.set("v.isErrorOnSave", true); 
		component.find("edit").get("e.recordSave").fire();
	},
    handleSaveSuccess : function(component, event, helper) {
        //show toast message on success 
        component.set("v.isErrorOnSave", false);
    	var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "type": "success",
            "message": "The record has been Saved successfully."
        });
        toastEvent.fire();
        var rec  = component.get("v.recordId");
		var sObectEvent = $A.get("e.force:navigateToSObject");
    		sObectEvent .setParams({
    		"recordId": rec, 
    		"slideDevName": "detail"
        });
  		sObectEvent.fire();
       // $A.get('e.force:refreshView').fire();
        /* var href = window.location.split('\/')[0];
        window.location.href = href+'/external/detail/'+rec; */
    },
    handleError : function(component, event, helper) {
        //show toast message on error
    	var toastEvent = $A.get("e.force:showToast");
        	toastEvent.setParams({
            "title": "Error!",
           	"message": "There was an error while saving your record."
        });
        toastEvent.fire();
    },
    handleCancel : function(component, event, helper) {
        //redirect to the page from where it is triggered
       // window.history.back();
        var rec  = component.get("v.recordId");
		var sObectEvent = $A.get("e.force:navigateToSObject");
    		sObectEvent .setParams({
    		"recordId": rec, 
    		"slideDevName": "detail"
        });
  		sObectEvent.fire();
    },
    doneWaiting : function(component, event, helper) {
    	var error = component.get("v.isErrorOnSave");
        if(error){
            var toastEvent = $A.get("e.force:showToast");
        	toastEvent.setParams({
            "title": "Error!",
            "duration": "3000",
            "type": "error",
           	"message": "There was an error while saving your record."
        	});
        	toastEvent.fire();
            setTimeout(function(){
    			window.scrollTo({
  					top: 0,
  					left: 0,
  					behavior: 'smooth'
				});
    		}, 1000);
        	//window.scrollTo(0, 0);
        	component.set("v.isErrorOnSave",false);
        }
    }
})