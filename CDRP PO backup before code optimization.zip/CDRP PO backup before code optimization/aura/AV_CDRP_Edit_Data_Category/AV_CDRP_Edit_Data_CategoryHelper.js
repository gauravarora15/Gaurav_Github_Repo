({
    getDataCategoryOnLoad : function(component, event, helper){
        var action = component.get("c.getDataCategoryOnLoad");
        action.setParams({'recordId':component.get("v.recordId"),
                       'objectName': 'AV_CDRP_Expected_Data__c',
                       'lstFields':component.get("v.picklistAPIs")});
        action.setCallback(this,function(response){
            if (response.getState() == "SUCCESS") {
                var resp = response.getReturnValue();
                component.set("v.StudyId", resp.studyId);
                //alert('here' + component.get("v.StudyId"));
                component.set("v.idrprecordId", resp.drp.AV_CDRP_Data_Review_Plan__c);
                component.set("v.dcc.Expected_Data_Rule__c", resp.drp.Expected_Data_Rule__c);
                component.set("v.dcc.AV_CDRP_Data_Source__c", resp.drp.AV_CDRP_Data_Source__c);
                component.set("v.dcc.AV_CDRP_Data_Transfer_Frequency__c", resp.drp.AV_CDRP_Data_Transfer_Frequency__c);
                component.set("v.dcc.AV_CDRP_Critical_Data__c", resp.drp.AV_CDRP_Critical_Data__c);
                component.set("v.dcc.AV_CDRP_Critical_Data_Rationale__c", resp.drp.AV_CDRP_Critical_Data_Rationale__c);
				component.set("v.lastModifiedDate", resp.lastModifiedDate);
                if(component.get("v.dcc.AV_CDRP_Critical_Data__c") === 'Yes'){
                    component.set("v.criticalDataSelected",false);
                }                
               
                component.set("v.selectedStudyVisits", resp.stv);
                component.set("v.selectedDataTrajId",resp.drp.AV_CDRP_Data_Trajectory__r.Name);
                component.set("v.selectedDataCatId",resp.drp.AV_CDRP_Data_Category_MDR__r.Name);
                var dataCCopts =[];
                for(var i in resp.dct){
                    dataCCopts.push({
                                class: "optionClass",
                                label: resp.dct[i],
                                value: resp.dct[i]
                                
                            });
                }
                component.set("v.DataCCOptions", dataCCopts);
                
                var dataTraj='{"val":"'+resp.drp.AV_CDRP_Data_Trajectory__c+'","text":"'+resp.drp.AV_CDRP_Data_Trajectory__r.Name+'","sobjectType":"AV_CDRP_Data_Trajectory__c"}'; 
                var tempdataTraj =JSON.parse(dataTraj);
                component.set("v.selectedDataTraj",tempdataTraj);
                
                var dataCat='{"val":"'+resp.drp.AV_CDRP_Data_Category_MDR__c+'","text":"'+resp.drp.AV_CDRP_Data_Category_MDR__r.Name+'","objName":"AV_CDRP_Data_Category_MDR__c"}'; 
                var tempdataCat =JSON.parse(dataCat);
                component.set("v.selectedDataMDR",tempdataCat);
                
        var dataProviderFilterMap = {};
                dataProviderFilterMap['AV_Service_Type_Label__c']= $A.get("$Label.c.AV_CDRP_ServiceTypeFilters");
                dataProviderFilterMap['AV_Study_Number__c']=resp.drp.AV_CDRP_Data_Review_Plan__r.AV_CDRP_Protocol_Number__c;
                component.set("v.dataProviderFilter", dataProviderFilterMap);
                if (!($A.util.isEmpty(resp.dpValue) || $A.util.isUndefinedOrNull(resp.dpValue))) {
                component.set("v.selectedDataProvider.Id",resp.dpValue.Id);
                component.set("v.selectedDataProvider.AV_Vendor_Number__c",resp.dpValue.AV_Vendor_Number__c);
                component.set("v.selectedDataProvider.AV_Vendor_Number__r.Name",resp.dpValue.AV_Vendor_Number__r.Name);
                component.set("v.selectedDataProvider.AV_Service_Type_Label__c",resp.dpValue.AV_Service_Type_Label__c);
                component.find("relatedDataProvider").preselectValue();
                }
                var custs = [];
                for(var key in resp.stv){
                    custs.push({value:resp.stv[key], key:key});
                }
                component.set("v.sobJMDRVisitlist", custs);
                var abc = component.get("v.picklistAPIs");
                var pickListFlds = abc.split(',');
                var opts = [];
                var opts1= [];
                var opts2= [];
                var opts3=[];
                for( var index in pickListFlds){
                    var obj = resp.picklistVal[pickListFlds[index]];
                    var keys = Object.keys(resp.picklistVal[pickListFlds[index]]);
                    if(pickListFlds[index] == "AV_CDRP_Data_Source__c"){
                        for(var i in keys){
                            if(resp.picklistVal[pickListFlds[index]][keys[i]] == resp.drp.AV_CDRP_Data_Source__c){
                                opts.push({
                                    class: "optionClass",
                                    label: keys[i],
                                    value: resp.picklistVal[pickListFlds[index]][keys[i]],
                                    selected : true
                                });
                            }else{
                                opts.push({
                                    class: "optionClass",
                                    label: keys[i],
                                    value: resp.picklistVal[pickListFlds[index]][keys[i]]
                                });
                            }
                        }
                        component.set("v.DataSourcePicklstOptions", opts);
                    }
                    if(pickListFlds[index] == "AV_CDRP_Data_Transfer_Frequency__c"){
                        for(var i in keys){
                            if(resp.picklistVal[pickListFlds[index]][keys[i]] == resp.drp.AV_CDRP_Data_Transfer_Frequency__c){
                                opts1.push({
                                    class: "optionClass",
                                    label: keys[i],
                                    value: resp.picklistVal[pickListFlds[index]][keys[i]],
                                    selected : true
                                });
                            }else{
                                opts1.push({
                                    class: "optionClass",
                                    label: keys[i],
                                    value: resp.picklistVal[pickListFlds[index]][keys[i]]
                                }); 
                            }
                        }
                        component.set("v.DataFrequencyOptions", opts1);
                    }
                    if(pickListFlds[index] == "AV_CDRP_Critical_Data__c"){
                        for(var i in keys){
                            if(resp.picklistVal[pickListFlds[index]][keys[i]] == resp.drp.AV_CDRP_Critical_Data__c){
                                opts2.push({
                                    class: "optionClass",
                                    label: keys[i],
                                    value: resp.picklistVal[pickListFlds[index]][keys[i]],
                                    selected : true
                                });
                            }else{
                                opts2.push({
                                    class: "optionClass",
                                    label: keys[i],
                                    value: resp.picklistVal[pickListFlds[index]][keys[i]]
                                }); 
                            }
                        }
                        component.set("v.CriticalDataPicklstOptions", opts2);
                    }
                    if(pickListFlds[index] == "AV_CDRP_Critical_Data_Rationale__c"){
                        for(var i in keys){
                            if(resp.picklistVal[pickListFlds[index]][keys[i]] == resp.drp.AV_CDRP_Critical_Data_Rationale__c){
                                opts3.push({
                                    class: "optionClass",
                                    label: keys[i],
                                    value: resp.picklistVal[pickListFlds[index]][keys[i]],
                                    selected : true
                                });
                            }else{
                                opts3.push({
                                    class: "optionClass",
                                    label: keys[i],
                                    value: resp.picklistVal[pickListFlds[index]][keys[i]]
                                }); 
                            }
                        }
                        component.set("v.CriticalDataRationalePicklstOptions", opts3);
                    }   
                }
            }
        });
        $A.enqueueAction(action);
    },
    onSelectAll :  function(component, event, helper) {
        var abc = component.get("v.selectall");//event.getSource().get("v.checked");
        var opts = component.get("v.selectedStudyVisits");
        var def = component.get("v.sobJMDRVisitlist");
        var opts1 = [];
        
        if(abc){
            for(var key in opts){
                opts[key]=true;
                opts1.push({value:true, key:key});
            }
        }else{
            for(var key in opts){
                opts[key]=false;
                opts1.push({value:false, key:key});
            }
        }
        component.set("v.selectedStudyVisits", opts);
        component.set("v.sobJMDRVisitlist", opts1);
        component.set("v.selectedDataCategory", '');
    },
    Oncancel :function(component, event, helper){
         window.location.assign('/'+component.get("v.recordId"));
    },
    Onsave :function(component, event, helper){
		component.set("v.showError", false);
        let button = event.getSource();
        if(component.get("v.dcc.AV_CDRP_Critical_Data__c")!="None" && component.get("v.dcc.AV_CDRP_Data_Transfer_Frequency__c")!="None" && component.get("v.dcc.AV_CDRP_Data_Source__c")!="None" && component.get("v.selectedDataTraj")!=null && component.get("v.selectedDataTraj")!='' && component.get("v.selectedDataMDR")!=null && component.get("v.selectedDataMDR")!=''){
            if(component.get("v.dcc.AV_CDRP_Critical_Data__c")=='Yes' && component.get("v.dcc.AV_CDRP_Critical_Data_Rationale__c")=='None'){
                component.set("v.showError",true);
                component.set("v.messageType", 'error');
                component.set("v.errorMessage","Please enter a value in Critical Data Rationale"); 
            }else{
                button.set('v.disabled',true);
                var action = component.get("c.savedcc");
                action.setParams({"lastModifiedDate":component.get("v.lastModifiedDate"),
									"extData":component.get("v.recordId"),
									"DataPlan":component.get("v.idrprecordId"),  
									"picklist":JSON.stringify(component.get("v.dcc")),
									"dp":component.get("v.selectedDataProvider.Id"),
									"dcv" :component.get("v.selectedStudyVisits"),
									"datacategory":component.get("v.selectedDataMDR").val});
                action.setCallback(this,function(response){
                    if (response.getState() === "SUCCESS") {
                        var resp = response.getReturnValue();
                        if(!$A.util.isEmpty(resp.errorMessage) && !$A.util.isUndefinedOrNull(resp.errorMessage)){
                            component.set("v.showError",true);
                            component.set("v.messageType", 'error');
                            component.set("v.errorMessage",resp.errorMessage);
                            document.getElementsByClassName('slds-modal__content')[0].scrollTop=0;
                        }
                        else if(resp.lastModifiedDate != component.get("v.lastModifiedDate")){
							
							component.set("v.showError",true);
                            component.set("v.messageType", 'error');
                            component.set("v.errorMessage",$A.get('$Label.c.AV_CDRP_Record_Modified_Error'));
                            document.getElementsByClassName('slds-modal__content')[0].scrollTop=0;
                        }
                        else{
                           
                                window.location.assign('/'+resp.dataCategoryConfig.Id);
                    	}
                    }
                    else if (response.getState() ===  "ERROR") {
                        var errors = response.getError();                      
                        component.set("v.showError",true);
                        component.set("v.messageType", 'error');
                        component.set("v.errorMessage",errors[0].message);
                        button.set('v.disabled',false);
                    }
                });
                $A.enqueueAction(action);
            }
        }else{
            component.set("v.showError",true);
            component.set("v.messageType", 'error');
            component.set("v.errorMessage","* Mandatory fields cannot be blank"); 
        } 
         document.getElementsByClassName('slds-modal__content')[0].scrollTop=0;
    },
    onchange :function(component, event, helper){
        var abc = event.getSource().get("v.value");
        var def = event.getSource().getLocalId();
        var ghg = event.getSource().get("v.name");
        if(def=='Critical Data?'){
            component.set("v.dcc.AV_CDRP_Critical_Data__c", abc);
            if(abc === 'Yes')
                component.set("v.criticalDataSelected",false);
            else{
                component.set("v.criticalDataSelected",true);
                component.set("v.dcc.AV_CDRP_Critical_Data_Rationale__c",null);
            }
        } else if (def == 'Data Transfer Frequency') {
            component.set("v.dcc.AV_CDRP_Data_Transfer_Frequency__c", abc);
        }else if(def=='Data Source'){
            component.set("v.dcc.AV_CDRP_Data_Source__c", abc);
        }else if(def=='Critical Data Rationale'){
            component.set("v.dcc.AV_CDRP_Critical_Data_Rationale__c", abc);
        }else if(ghg=='Expected Data Rule'){
            component.set("v.dcc.Expected_Data_Rule__c", abc);
        }   
    },
    checkboxChange :function(component, event, helper){
        var abc = event.getSource().get("v.checked");
        var def = event.getSource().get("v.label");
        var opts =component.get("v.selectedStudyVisits");
        if(abc){
            opts[def] = true;
        }else{
            opts[def]= false;
        }
        component.set("v.selectall",false);
        component.set("v.selectedStudyVisits", opts);
        component.set("v.selectedDataCategory", '');
    },
    dataCCchange : function(component, event, helper){
        component.set("v.selectedItem",event.getParam("selectedItem"));
        var nameParam;
        if(component.get("v.selectedItem")!=null  && component.get("v.selectedItem").val!=null){
            nameParam=component.get("v.selectedItem").val;
        }
        component.set("v.nameP",nameParam);
        if(nameParam!=""  && nameParam!=null){
            var action = component.get("c.dataCC");
            action.setParams({'dcc':component.get("v.nameP")});
                action.setCallback(this,function(response){
                if (response.getState() === "SUCCESS") {
                    var resp = response.getReturnValue();  
                    var opts = component.get("v.selectedStudyVisits");    
                    var def = component.get("v.sobJMDRVisitlist");
                    var opts1 = [];      
                    for(var key in opts){
                        if(resp.includes(key)){
                            opts[key]=true;
                            opts1.push({value:true, key:key});
                        }else{
                           opts[key]=false;
                           opts1.push({value:false, key:key});  
                        }
                    }
                    component.set("v.selectall",false);
                    component.set("v.selectedStudyVisits", opts);
                    component.set("v.sobJMDRVisitlist", opts1);
                }
            });
            $A.enqueueAction(action);
        }
    },

    restrictPlanStatus: function (component, event, helper){
        var rec = component.get("v.recordId");
        var action = component.get("c.getPlanStatus"); 
        action.setParams({
            'recordId' : rec
        }); 
        action.setCallback(this,function(response){
            if (response.getState() == "SUCCESS") {
                var resp = response.getReturnValue().planMap;
                if(resp[$A.get("$Label.c.AV_CDRP_Plan_Owner")]){
                    helper.showToast('ERROR', 'ERROR', $A.get("$Label.c.AV_CDRP_Edit_Data_Category_Access_Error"));
                    this.navigateToRecord(component,response.getReturnValue().planId,"AV_CDRP_Data_Review_Plan__c");
                    $A.get('e.force:refreshView').fire();
                }
                else if(resp[$A.get("$Label.c.AV_CDRP_Plan_Status")]){
                    helper.showToast('ERROR', 'ERROR', $A.get("$Label.c.AV_CDRP_Data_Trajectory_Edit_Validation_Message"));
                    this.navigateToRecord(component,response.getReturnValue().planId,"AV_CDRP_Data_Review_Plan__c");
                    $A.get('e.force:refreshView').fire();
                }
				else{
                    helper.getDataCategoryOnLoad(component, event, helper);
                    component.set("v.showModal", true);
                }    
            }
        });
        $A.enqueueAction(action);
    },

    showToast: function (toastTitle, toastType, toastMessage) {
		var toastEvent = $A.get("e.force:showToast");
		toastEvent.setParams({
				"title": toastTitle,
				"type": toastType,
				"message": toastMessage
		});
		toastEvent.fire();
    },
	navigateToRecord: function (component, planId, sObject) {
        var pageReference = {    
            type: "standard__recordPage",
            attributes: {
                "recordId": planId,
                "objectApiName": sObject,
                "actionName": "view"
            }
        };
        component.set("v.pageReference", pageReference);
        var navService = component.find("navService");
        var pageReference = component.get("v.pageReference");
        navService.navigate(pageReference);
    }
})