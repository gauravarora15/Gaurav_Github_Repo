({
    fetchRLdetails : function(component, event, helper) {
        console.log('@@@@@fetch: '+component.get("v.recordLimit"));
        component.set("v.currentTZ", $A.get("$Locale.timezone"));
        var recordSize = component.get("v.recordLimit");
        var numRecSize = Number(component.get('v.recordLimit'));
        var isHistoryObj = false;
        if((component.get('v.childObjName')).indexOf('__') !== -1){
            if((component.get('v.childObjName')).indexOf('__History') !== -1){
                recordSize = ((numRecSize*2)+2).toString();
                console.log('rec size val: '+recordSize);
                console.log('rec size type: '+typeof recordSize);
                isHistoryObj = true;
            }
        }
        else{
            if((component.get('v.childObjName')).indexOf('History') !== -1){
                recordSize = ((numRecSize*2)+2).toString();
                console.log('rec size val: '+recordSize);
                console.log('rec size type: '+typeof recordSize);
                isHistoryObj = true;
            }
        }
        var action = component.get('c.fetchRelatedListDataWithoutCache'); 
        action.setParams({
            "parentObjAPI" : component.get('v.parentObjName'),
            "childObjAPI" : component.get('v.childObjName'),
            "parentId" : component.get('v.recordId'),
            "recordLimit" : recordSize
        });
        action.setCallback(this, function(a){
            var state = a.getState(); // get the response state
            if(state == 'SUCCESS') {
                console.log('@@@@@@: '+a.getReturnValue());
                var res = JSON.parse(a.getReturnValue());
                if(isHistoryObj){
                    if(res.RLrecDatalst.length > numRecSize){
                        var actualResLst = res.RLrecDatalst;
                        var tempRecLst = [];
                        for(var i=0; i<numRecSize; i++){
                            tempRecLst.push(actualResLst[i]);
                        }
                        component.set("v.recordsList", tempRecLst);
                        component.set("v.hasMoreRecs", true);
                    }
                    else{
                        component.set("v.recordsList", res.RLrecDatalst);
                    }
                }
                else{
                    component.set("v.recordsList", res.RLrecDatalst);
                    component.set("v.hasMoreRecs", res.hasMoreRecs);
                }
                component.set("v.lstBtnList", res.listBtnLst);
                console.log('Has more than 6 records: '+component.get("v.hasMoreRecs"));
                if(!$A.util.isEmpty(res.iconName)){
                    component.set("v.iconName", res.iconName);
                    component.set("v.iconTitle", res.iconTitle);
                }
                //$A.util.addClass(component.find("loadSpinner"), "slds-hide");
            }
        });
        $A.enqueueAction(action);
    },
    btnClick : function(component, event, helper) {
        console.log('button clicked: '+event.getSource().get("v.label"));
        var src = event.getSource().get("v.value");
        var srcOverrideType= src.substr(0, src.indexOf('_'));
        console.log('@@@@srcOverrideType: '+srcOverrideType);
        if(srcOverrideType == 'std'){
            var actionType = src.substr(src.indexOf('_')+1, src.length);
            console.log('std: '+actionType);
            if(actionType == 'Create'){
                var fieldAPIname = ''+component.get('v.parentObjName');
                var jsonObjStr = "{\""+component.get('v.parentObjName')+"\":\""+component.get('v.recordId')+"\"}";
                console.log('@@@jsonObj: '+JSON.parse(jsonObjStr));
                var createRecordEvent = $A.get("e.force:createRecord");                
                createRecordEvent.setParams({
                    "entityApiName": component.get("v.childObjName"),
                    "defaultFieldValues": JSON.parse(jsonObjStr)
                });
                createRecordEvent.fire();
            }            
        }
        if(srcOverrideType == 'url'){
            console.log('url override: '+src.substr(src.indexOf('_')+1, src.length));
            var urlStr = '';
            urlStr = ''+src.substr(src.indexOf('_')+1, src.length)+component.get("v.recordId");
            var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
                "url": urlStr
            });
            urlEvent.fire();
        }
        if(srcOverrideType == 'comp'){
            //code when component comes - not coding right now
            console.log('comp override: '+src.substr(src.indexOf('_')+1, src.length));
            var compName = '';
            compName = ''+src.substr(src.indexOf('_')+1, src.length);
            var evt = $A.get("e.force:navigateToComponent");
            evt.setParams({
                componentDef : compName,
                componentAttributes: {
                    "recordId" : component.get("v.recordId")
                }
            });
            evt.fire();
        }
    },
    handleSelect : function (cmp, event, helper) {
        console.log('button clicked: '+event.getParam("value"));
        var src = event.getParam("value");
        var srcOverrideType= src.substr(0, src.indexOf('_'));
        console.log('@@@@srcOverrideType: '+srcOverrideType);
        src = src.substr(src.indexOf('_')+1, src.length);
        if(srcOverrideType == 'std'){
            var actionType = src.substr(0, src.indexOf('_'));
            var recId = src.substr(src.indexOf('_')+1, src.length);
            console.log('std: '+actionType);
            if(actionType == 'Update'){
                var editRecordEvent = $A.get("e.force:editRecord");
                editRecordEvent.setParams({
                    "recordId": recId
                });
                editRecordEvent.fire();                
            }
            else if(actionType == 'Delete'){
                //call delete component - no standard available - use url
            }
            
        }
        if(srcOverrideType == 'url'){
            var recId = src.substr(0, src.indexOf('_'));
            var urlStr = src.substr(src.indexOf('_')+1, src.length);
            console.log('url override: '+src.substr(src.indexOf('_')+1, src.length));
            var urlStr = '';
            urlStr = ''+src.substr(src.indexOf('_')+1, src.length)+recId;
            console.log('new urlStr: '+urlStr);
            var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
                "url": urlStr
            });
            urlEvent.fire();
        }
        if(srcOverrideType == 'comp'){
            //code when component comes - not coding right now
            var recId = src.substr(0, src.indexOf('_'));
            var compName = src.substr(src.indexOf('_')+1, src.length);
            var evt = $A.get("e.force:navigateToComponent");
            evt.setParams({
                componentDef : compName,
                componentAttributes: {
                    "recordId" : recId
                }
            });
            evt.fire();
        }
    },
    showAll : function (component, event, helper) {
        var currentVal = component.get('v.showViewAll');
        if(component.get('v.hasMoreRecs') || currentVal == false){
            if(currentVal == false){
                component.set('v.hasMoreRecs', true);
                component.set('v.showViewAll', true);
                var tempLst = [];
                var recLst = component.get("v.recordsList");
                for(var i=0; i<Number(component.get('v.recordLimit')); i++){
                    tempLst.push(recLst[i]);
                }
                component.set("v.recordsList", tempLst);
            }
            else{
                component.set("v.showLoader", "true");
                //$A.util.removeClass(component.find("loadSpinner"), "slds-hide");
                component.set('v.showViewAll', false);
                var action = component.get('c.fetchRelatedListDataWithCache'); 
                console.log('action formed');
                action.setParams({
                    "parentObjAPI" : component.get('v.parentObjName'),
                    "childObjAPI" : component.get('v.childObjName'),
                    "parentId" : component.get('v.recordId'),
                    "recordLimit" : ''
                });
                console.log('Params set');
                action.setCallback(this, function(a){
                    var state = a.getState(); // get the response state
                    if(state == 'SUCCESS') {
                        console.log('@@@@@@: '+a.getReturnValue());
                        var res = JSON.parse(a.getReturnValue());
                        component.set("v.recordsList", res.RLrecDatalst);
                        component.set('v.hasMoreRecs', false);
                        //$A.util.removeClass(component.find("loadSpinner"), "slds-hide");
                        //$A.util.addClass(component.find("loadSpinner"), "slds-hide");
                    }
                    else{
                        console.log('Some error occurred with database fetch.');
                    }
                });
                $A.enqueueAction(action);
            }
        }
    },
    hideWaiting: function (component, event, helper) {
        component.set("v.showLoader", "false");
        console.log('I am done waiting...');
        //$A.util.removeClass(component.find("loadSpinner"), "slds-hide");
        //$A.util.addClass(component.find("loadSpinner"), "slds-hide");
    }
})