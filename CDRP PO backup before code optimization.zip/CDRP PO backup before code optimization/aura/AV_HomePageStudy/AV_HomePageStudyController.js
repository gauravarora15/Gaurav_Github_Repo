({
    getlist : function(component, event, helper) {
        component.set('v.columns', [
            {label: $A.get('$Label.c.AV_AssignIRB_ProtoNumLabel'), fieldName:'linkName', type: 'url',typeAttributes: {label: { fieldName: 'Name' },target:'_blank'} },
            {label: $A.get('$Label.c.AV_Study_c_Nickname'), fieldName: 'AV_Nickname__c', type: 'text'},
            {label: $A.get('$Label.c.AV_Study_c_Project'), fieldName: 'AV_Project__c', type: 'text'},
            {label: $A.get('$Label.c.AV_Managed_By'), fieldName: 'AV_Managed_By__c', type: 'text'},
            {label: $A.get('$Label.c.AV_Study_Type'), fieldName: 'AV_Study_Type__c', type: 'text'},
            {label: $A.get('$Label.c.AV_Study_Phase'), fieldName: 'AV_Study_Phase__c', type: 'text'},
            {label: $A.get('$Label.c.AV_Study_Status'), fieldName: 'AV_Study_Status__c', type: 'text'},
        ]);
            helper.getlist(component);//get data from the helper
            },
            
            onNext : function(component, event, helper) {        
            var pageNumber = component.get("v.currentPageNumber");
            component.set("v.currentPageNumber", pageNumber+1);
            helper.buildData(component, helper);
            },
            
            onPrev : function(component, event, helper) {        
            var pageNumber = component.get("v.currentPageNumber");
            component.set("v.currentPageNumber", pageNumber-1);
            helper.buildData(component, helper);
            },
            
            processMe : function(component, event, helper) {
            component.set("v.currentPageNumber", parseInt(event.target.name));
            helper.buildData(component, helper);
           
            }
            })