({
    doInitialAction: function (component, event, helper) {
        var crdCheck = component.get("v.crdCheck");
        component.set("v.checkData", crdCheck.checkAssigned);
        component.set("v.shortDescription", crdCheck.checkAssigned.AV_CDRP_Description__c.substring(0, 255));
        component.set("v.isPending", (crdCheck.checkAssigned.AV_CDRP_URL__c != null || crdCheck.checkAssigned.AV_CDRP_Edit_Check_Name__c != null));
        component.set("v.isDueDay", crdCheck.checkAssigned.AV_CDRP_Number_Of_Overdue_Check__c != 0 || crdCheck.checkAssigned.AV_CDRP_Number_Of_InReview_Check__c != 0 || crdCheck.checkAssigned.AV_CDRP_Number_Of_DataAccumulation_Check__c != 0);
    },
    handleSearchQuery: function (component, event, helper) {
        var idrpCheck = component.get("v.checkData");
        var study = component.get("v.checkData.AV_CDRP_Data_Review_Plan__c");
        var idrpname = component.get("v.checkData.AV_CDRP_Data_Review_Plan__r.Name");
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
            componentDef: "c:AV_CDRP_SearchQuery",
            componentAttributes: {
                studyIA: study,
                idrpCheckIA: idrpCheck,
                idrpnameIA: idrpname
            }
        });
        evt.fire();
    },
    handleNewTask: function (component, event, helper) {
        var idrpCheck = component.get("v.checkData");
        var fieldsToSet = {
            AV_CDRP_Related_IDRP_Check__c: {
                value: idrpCheck.Id
            }

        };
        var actionAPI = component.find("quickActionAPI");
        var args = {
            actionName: "AV_CDRP_Data_Review_Plan__c.AV_CDRP_New_Task",
            targetFields: fieldsToSet,
            submitOnSuccess: false
        };
        actionAPI.setActionFieldValues(args).then(function (result) {

        }).catch(function (e) {
            if (e.errors) {

            }
        });

    },

    createNewObservation: function (component, event, helper) {
        var idrpCheck = component.get("v.checkData");
        var recordId = idrpCheck.Id;
        var url = '/apex/AV_CreateEditObservationsPage?_lkid='+recordId;
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": url
        });
        urlEvent.fire();
    },

    createSearchObservation: function (component, event, helper) {
        var evt = $A.get("e.force:navigateToComponent");
        var drp = component.get("v.checkData.AV_CDRP_Data_Review_Plan__c");
        var studyName = component.get("v.checkData.AV_CDRP_Data_Review_Plan__r.AV_CDRP_Study_Name_Apex__c");
        var studyId = component.get("v.checkData.AV_CDRP_Data_Review_Plan__r.AV_CDRP_Protocol_Number__c");
        var IDRPCheckDPI = component.get("v.checkData");
        evt.setParams({
            componentDef: "c:AV_CDRP_ObservationSearch",
            componentAttributes: {
                recordId: drp,
                studyName: studyName,
                studyId: studyId,
                IDRPCheckDPI: IDRPCheckDPI
            }
        });
        evt.fire();
    },

    completeIDRPCheck: function (component, event, helper) {
        var crdCheck = component.get("v.crdCheck");
        component.set("v.isOpen", true);
        component.set("v.reviewCompletionRecord", {
            'AV_CDRP_Related_IDRP_Check__c': component.get("v.checkData.Id"),
            'Name': component.get("v.checkData.Name"),
            'AV_CDRP_Review_Completed_By__c': $A.get("$SObjectType.CurrentUser.Id")
        });
        component.set("v.frequency", component.get("v.crdCheck").frequency);
        component.set("v.checkWindow", component.get("v.crdCheck").checkWindow); 
        component.set("v.unreviewedCount", crdCheck.checkAssigned.AV_CDRP_Unreviewed_Counts_Analytics__c);
    },

    launchQueryPage: function (component, event, helper, reviewstatusIA) {
        var idrpCheck = component.get("v.checkData");
        if (idrpCheck.AV_CDRP_Method__c == $A.get("$Label.c.AV_CDRP_IDRP_Check_LSH_Edit_Check_Method") && !$A.util.isEmpty(idrpCheck.AV_CDRP_Edit_Check_Name__c) && !$A.util.isUndefinedOrNull(idrpCheck.AV_CDRP_Edit_Check_Name__c)) {
            var study = component.get("v.checkData.AV_CDRP_Data_Review_Plan__c");
            var idrpname = component.get("v.checkData.AV_CDRP_Data_Review_Plan__r.Name");
            var dcidIA = component.get("v.checkData.AV_CDRP_Data_Category_1__c");
            var dcnameIA = component.get("v.checkData.AV_CDRP_Data_Category_1__r.Name");
            var evt = $A.get("e.force:navigateToComponent");
            evt.setParams({
                componentDef: "c:AV_CDRP_SearchQuery",
                componentAttributes: {
                    studyIA: study,
                    idrpnameIA: idrpname,
                    idrpCheckIA: idrpCheck,
                    querySourceSelectedIA: 'LSH',
                    dcidIA: dcidIA,
                    dcnameIA: dcnameIA,
                    revstatusIA: reviewstatusIA
                }
            });
            evt.fire();
        } else if (idrpCheck.AV_CDRP_Method__c == $A.get("$Label.c.AV_CDRP_IDRP_Check_Data_Analytics_Tool_Method") && !$A.util.isEmpty(idrpCheck.AV_CDRP_URL__c) && !$A.util.isUndefinedOrNull(idrpCheck.AV_CDRP_URL__c)) {
            helper.navigationToPage(component, event, helper);
        }
    },
    navigationToPage: function (component, event, helper) {
        var URLToOpen = component.get("v.checkData.AV_CDRP_URL__c");
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": 'https://' + URLToOpen
        });
        urlEvent.fire();
    },
})