({
	getItemsToApprove : function(component, event, helper) {
        var actions = [
            { label: 'Reassign', name: 'Reassign' },
            { label: 'Approve/Reject', name: 'Approve/Reject' }
        ]
        component.set('v.columns', [
            {label: $A.get('$Label.c.AV_Type'), fieldName: 'objtype', type: 'string'},
            {label: $A.get('$Label.c.AV_RelatedTo'), fieldName: 'linkName', type: 'url',
            typeAttributes: {label: { fieldName: 'name' }, target: '_blank'} },
        	{label: $A.get('$Label.c.AV_Protocol_Number'), fieldName: 'protocolNumber', type: 'string'},
            {label: $A.get('$Label.c.AV_Study_Release_Type'), fieldName: 'sRType', type: 'string'},
            {label: $A.get('$Label.c.AV_Study_Release_Owner'), fieldName: 'studyReleaseOwner', type: 'string'},
            {label: $A.get('$Label.c.AV_Date_Submitted'), fieldName: 'DateSubmited', type: 'string'},
            {type: 'action', typeAttributes: { rowActions: actions}}            
        ]);
       helper.getItemsToApprove(component);//get data from the helper
            },

	handleRowAction: function (component, event, helper) {
        var action = event.getParam('action');
        var row = event.getParam('row');
        switch (action.name) {
                case 'Reassign':
                $A.get('e.force:navigateToURL').setParams({ 
       			"url": "/p/process/ProcessInstanceWorkitemWizardStageManager?id=" + row.approvalid
   				}).fire();
                break;
                
                case 'Approve/Reject':
            	var urlEvent = $A.get("e.force:navigateToURL");
            	urlEvent.setParams({
             	"url": "/p/process/ProcessInstanceWorkitemWizardStageManager?id=" + row.approvalid                     
            	});
            	urlEvent.fire();
                break;
        }
    },

	onNext : function(component, event, helper) {        
        var pageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", pageNumber+1);
        helper.buildData(component, helper);
    },
    
    onPrev : function(component, event, helper) {        
        var pageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", pageNumber-1);
        helper.buildData(component, helper);
    },
    
    processMe : function(component, event, helper) {
        component.set("v.currentPageNumber", parseInt(event.target.name));
        helper.buildData(component, helper);
    }    
})