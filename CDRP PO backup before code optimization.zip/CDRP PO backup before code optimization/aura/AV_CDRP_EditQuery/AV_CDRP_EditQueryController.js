({
	 doInit: function (component, event, helper) {
         helper.doInit(component,event,helper);
	}, 
    saveRecord : function(component, event, helper) {
         component.set("v.isErrorForSelectField",false);
        if(component.find("createShowHide").get("v.label") =='Save'){
            let button = event.getSource();
            button.set('v.disabled', true);
            helper.saveQuery(component, event, helper);
        }else if(component.find("createShowHide").get("v.label") =='Next'){
            component.set("v.isForwardEDC",true);
        }
		
	},
    getSelectedSPID :function(component, event, helper) {
        component.set("v.isErrorForSelectField",false);
        var selectedRows = event.getParam('selectedRows');
        var selectedrecord =[];
        // Display that fieldName of the selected rows
        component.set("v.selectedRowsSize",selectedRows.length);
        for (var i = 0; i < selectedRows.length; i++){
            selectedrecord.push(selectedRows[i]);
            component.set("v.selectedSPID",selectedrecord);
        }
        component.set("v.selectedSpidRecID",selectedrecord[0].recId);
    },
    goBackToPrevious : function (component, event, helper) {
        component.set("v.isErrorForSelectField",false);
        if(component.get("v.isForwardEDC") && component.get("v.isSelectDataPoints")){
            component.set("v.isSelectDataPoints",false);
            component.find("saveOrNext").set("v.label","Next");
            component.set("v.selectedRowsSize",0);
        }else if(component.get("v.isForwardEDC") &&  !component.get("v.isSelectDataPoints")){
            component.set("v.isForwardEDC",false);
            //component.set("v.isSelectDataPoints",false);
            component.set("v.selectedRowsSize",0);
            component.find("createShowHide").set("v.label","Next");
        }
    }, 
    showDataPointsorSave:function(component, event, helper) {
        component.set("v.displaySpinner",true);
        var selectedRows = component.get("v.selectedRowsSize");
        component.set("v.isErrorForSelectField",false);
        if(component.find("saveOrNext").get("v.label") == 'Next'){
            if(!$A.util.isEmpty(selectedRows) && !$A.util.isUndefinedOrNull(selectedRows) && selectedRows >= 1){
                helper.autoPopulateDataPoints(component, event, helper);
            }else{
                component.set("v.isErrorForSelectField",true);
                component.set('v.errorMessage','Please select a SPID before clicking Next.');
            	component.set("v.messageType",'error');
                document.getElementsByClassName('slds-modal__content')[0].scrollTop=0;
            }
        }else if(component.find("saveOrNext").get("v.label") == 'Submit'){
              component.set("v.isErrorForSelectField",false);
              helper.selectFieldRequiredForSave(component, event, helper);
        }
		 component.set("v.displaySpinner",false);
	},
    hideValidationmessage : function(component, event, helper) {
		 component.set("v.isErrorForSelectField",false);
	},
    changeButton : function(component, event, helper) {
		helper.changeButton(component, event, helper);
	},
    closeModal : function(component) {
       window.history.back();
    },
})