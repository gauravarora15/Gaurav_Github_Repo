({
    doInit: function (component, event, helper) {
        var action = component.get("c.getDataOnLoad");
        action.setParams({
            "queryId": component.get("v.recordId")
        });
        action.setCallback(this, function (response) {
            if (response.getState() == "SUCCESS") {
                var resp = response.getReturnValue();
                if (resp.queryRecordType == $A.get("$Label.c.AV_CDRP_EDC_Query_RecordType") || (resp.errorMessage != null && resp.errorMessage != '')) {
                    helper.showToast('', 'Error', 'You do not have access to create or edit this record.');
                    component.set("v.showModal", false);
                    window.history.go(-1);
                } else {
                    if (resp.queryRec.AV_CDRP_Query_Status__c == $A.get("$Label.c.AV_CDRP_Resolved") || resp.queryRec.AV_CDRP_Query_Status__c == $A.get("$Label.c.AV_Observation_status_value_Closed") || resp.queryRec.AV_CDRP_Query_Status__c == $A.get("$Label.c.AV_CDRP_Forward_to_EDC")) {
                        helper.showToast('', 'Error', 'No edits are allowed to a query in this status');
                        component.set("v.showModal", false);
                        window.history.go(-1);
                    } else {
                        component.set("v.QueryRecord", resp.queryRec);
                        component.set("v.queryWrapperRec", resp);
                        component.set("v.showModal", true);
                    }
                }
            }
        });
        $A.enqueueAction(action);
        component.set('v.columns', [{
                label: 'SPID',
                fieldName: 'SPID',
                type: 'text'
            },
            {
                label: 'DATASET LABEL',
                fieldName: 'dataSetLabel',
                type: 'text'
            },
            {
                label: 'FIELD NAME',
                fieldName: 'fieldName',
                type: 'Text'
            }
        ]);
    },
    changeButton: function (component, event, helper) {
        component.set("v.isErrorForSelectField", false);
        if (component.get("v.QueryRecord.AV_CDRP_Query_Status__c") == $A.get("$Label.c.AV_CDRP_Forward_to_EDC")) {
            component.find("createShowHide").set("v.label", "Next");
        } else {
            component.find("createShowHide").set("v.label", "Save");
        }
    },
    autoPopulateDataPoints: function (component, event, helper) {
        component.set("v.displaySpinner", true);
        component.set("v.isErrorForSelectField", false);
        var action = component.get("c.getSelectFieldFromRaveEDC");
        var selectedRec = component.get("v.selectedSPID");
        var spid = selectedRec[0].SPID;
        action.setParams({
            "SPID": component.get("v.selectedSPID")[0].SPID,
            "planSource": component.get("v.QueryRecord").AV_CDRP_Related_IDRP_Check__r.AV_CDRP_Data_Review_Plan__r.AV_CDRP_Study_Primary_Data_Source__c
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                if (response.getReturnValue().errorMessage == null || response.getReturnValue().errorMessage == '') {
                    component.set("v.dataPoints", response.getReturnValue().datasetPoints);
                    component.set("v.isSelectDataPoints", true);
                    component.find("saveOrNext").set("v.label", "Submit");
                } else {
                    component.set("v.isErrorForSelectField", true);
                    component.set('v.errorMessage', response.getReturnValue().errorMessage);
                    component.set("v.messageType", 'error');
                    document.getElementsByClassName('slds-modal__content')[0].scrollTop = 0;
                }
            } else {
                helper.showToast('', 'Error', response.errorString);
            }
        });
        $A.enqueueAction(action);
        component.set("v.displaySpinner", false);
    },
    selectFieldRequiredForSave: function (component, event, helper) {
        if (component.get("v.QueryRecord").AV_CDRP_Query_Status__c == $A.get("$Label.c.AV_CDRP_Forward_to_EDC") && ($A.util.isEmpty(component.get("v.selectedFieldValue")) || $A.util.isUndefined(component.get("v.selectedFieldValue")) || component.get("v.selectedFieldValue") == '--None--')) {
            component.set('v.errorMessage', 'Please select data point before clicking Submit.');
            component.set("v.messageType", 'error');
            component.set("v.isErrorForSelectField", true);
            document.getElementsByClassName('slds-modal__content')[0].scrollTop = 0;
        } else {
            helper.saveQuery(component, event, helper);
        }
    },
    // method to save the record in system
    saveQuery: function(component, event, helper) {
        component.set("v.displaySpinner",true);
        var queryRecord = component.get("v.QueryRecord");
        var action = component.get("c.updateQueryRec");
        action.setParams({
            "queryRecord": JSON.stringify(component.get("v.QueryRecord")),
            "recId": component.get("v.selectedSpidRecID"),
            "selectedFieldValue": component.get("v.selectedFieldValue")
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var response = response.getReturnValue();
                component.set("v.wrapperRec", response);
                if (!response.hasError) {
                    var navEvt = $A.get("e.force:navigateToSObject");
                    navEvt.setParams({
                        "recordId": response.returnRecordId,
                        "slideDevName": "detail"
                    });
                    navEvt.fire();
                    setTimeout(function () {
                        $A.get('e.force:refreshView').fire();
                    }, 1500);
                    helper.showToast('', 'Success', 'Query was saved successfully');

                } else {
                    helper.showToast('', 'Error', response.errorString);
                    let button = event.getSource();
                    button.set('v.disabled', false);
                }
            } else {
                helper.showToast('', 'Error', response.errorString);
                let button = event.getSource();
                button.set('v.disabled', false);
            }

        });
        $A.enqueueAction(action);
        component.set("v.displaySpinner",false);
    },
    showToast: function (toastTitle, toastType, toastMessage) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": toastTitle,
            "type": toastType,
            "message": toastMessage
        });
        toastEvent.fire();

    },
})