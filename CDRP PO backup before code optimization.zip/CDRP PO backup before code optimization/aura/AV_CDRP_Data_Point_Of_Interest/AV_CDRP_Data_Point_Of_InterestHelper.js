({
    fetchData : function(cmp, event, helper){
        cmp.set("v.data", []);
        var action = cmp.get("c.getDataPoints");
        action.setParams({
            'planId' : cmp.get("v.recordId")
        });
        action.setCallback(this,function(response){
            var resp = response.getReturnValue();
            var mapUniqueResponses = {};
            var ret = resp.idrpCheckMap;
            for (var key in ret){
                mapUniqueResponses[key] = ret[key];
            }
            if(resp.planRecord.AV_CDRP_Plan_Status__c == 'Approved'){
                cmp.set("v.truthy", true);
                cmp.set("v.planRecord", resp.planRecord);
                for(var i=0; i<resp.dpoiList.length; i++){
                    var data = {
                        Id: resp.dpoiList[i].dataPoint.Id,
                        study:  resp.dpoiList[i].dataPoint.AV_CDRP_Study_Name__c,
                        country: resp.dpoiList[i].dataPoint.AV_CDRP_Country__c,
                        investigatorName: resp.dpoiList[i].investigatorName,
                        subjects : resp.dpoiList[i].dataPoint.AV_CDRP_Subject_Name__c,
                        visit : resp.dpoiList[i].dataPoint.AV_CDRP_Visit__c,
                        dataForm: resp.dpoiList[i].dataPoint.AV_CDRP_Data_Form__c,
                        dataset : resp.dpoiList[i].dataPoint.AV_CDRP_DataSet_Label__c,
                        fieldName: resp.dpoiList[i].dataPoint.AV_CDRP_Field_Name__c,
                        fieldValue: resp.dpoiList[i].dataPoint.AV_CDRP_Field_Value__c,
                        spid : resp.dpoiList[i].dataPoint.AV_CDRP_SPID__c,
                        logLine : resp.dpoiList[i].dataPoint.AV_CDRP_Log_Line__c,
                        comments: resp.dpoiList[i].dataPoint.AV_CDRP_Comments__c,
                        idrpCheck : resp.dpoiList[i].dataPoint.AV_CDRP_IDRP_Check_Name__c,
                        userName: resp.dpoiList[i].userName,
                        studyID: resp.dpoiList[i].dataPoint.AV_CDRP_Study__c,
                        idrpCheckURL : '/' + resp.dpoiList[i].dataPoint.AV_CDRP_Related_IDRP_Check__c,
                        idrpCheckDPI : mapUniqueResponses[resp.dpoiList[i].dataPoint.AV_CDRP_Related_IDRP_Check__c],
                        investigatorId : resp.dpoiList[i].dataPoint.AV_CDRP_Investigator_Name__c,
                        investigatorIdNumber : resp.dpoiList[i].investigatorId
                    };
                    var currentData = cmp.get("v.data");
                    var newData = currentData.concat(data);
                    cmp.set("v.data", newData);
                }
            }
			cmp.set("v.disableReview", false);
            cmp.set("v.disableRefresh", false);
        });
        $A.enqueueAction(action); 
    },
    reviewData : function(component, event, helper){
        var action = component.get("c.reviewDataPoint");
        action.setParams({
            'selectedData' : JSON.stringify(component.get("v.selectedRows"))
        });
        action.setCallback(this,function(response){
            var resp = response.getReturnValue();
        });
        $A.enqueueAction(action);
    }
})