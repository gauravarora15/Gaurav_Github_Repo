({
  doInitHelper: function(component, event, helper) {
    var myPageRef = component.get("v.pageReference");
    var firstname = myPageRef.state.c__recordId;
		component.set("v.recordId", firstname);	
		var checkStatus = myPageRef.state.c__checkStatus;
        if(checkStatus==$A.get("$Label.c.AV_CDRP_Status_InApproval") || checkStatus==$A.get("$Label.c.AV_CDRP_Data_Check_Status_Completed") || checkStatus==$A.get("$Label.c.AV_CDRP_Data_Review_Plan_Status_Cancelled") || checkStatus==$A.get("$Label.c.AV_CDRP_Data_Check_Status_Superseded")) {
            helper.showToast('ERROR', 'ERROR', $A.get("$Label.c.AV_CDRP_Data_Trajectory_Edit_Validation_Message"));
            window.history.back();
        }
        else {
            component.set("v.showModal", true);
        }
	},
	showToast: function (toastTitle, toastType, toastMessage) {
		var toastEvent = $A.get("e.force:showToast");
		toastEvent.setParams({
				"title": toastTitle,
				"type": toastType,
				"message": toastMessage
		}); 
		toastEvent.fire();
},	
})