({
    //To update the count of selected options or display the single selected option
    doInit : function(component, event) {
        try{
            var optionsCount = component.get("v.options");
            var count = 0;
            var selectedSingleVal = '';
            var len=optionsCount.length;
            var selectedValuesArr = [];
            var selectPicklistIds = [];
            var selectionEvent = component.getEvent('picklistSelect');
            var label = component.get("v.multiselectLabel");
            for(var i=0;i< len;i++){
                if(optionsCount[i].isSelected === true){
                    count++;
                    
                    selectedSingleVal = optionsCount[i].Name;
                    selectedValuesArr.push(selectedSingleVal);
                    if(optionsCount[i].Id != undefined && optionsCount[i].Id != ''){
                        selectPicklistIds.push(optionsCount[i].Name);
                    }
                    
                }
            }
            if(count>1){
                component.set("v.optionsSelected",''+count+' Options Selected');
            }
            else if(count === 1){
                component.set("v.optionsSelected",selectedSingleVal);
            }
            else if(count === 0){
                component.set("v.optionsSelected",'');    
            }
            if (!$A.util.isEmpty(selectedValuesArr) && !$A.util.isUndefined(selectedValuesArr)) {
                component.set("v.selectedPickVals", selectedValuesArr);
            }
            // Restrict to fire component other than for Product Statement.
                selectionEvent.setParams({"optionIds" : selectPicklistIds,
                						"selectedItem" : component.get("v.selectedIdsInOrder")});
                // Fire event to parent component to provide selected templates.
                selectionEvent.fire();
           
            
        }
        catch(e){
            
        }
    },
    //To open/close the picklist dropdown
    toggleOpen : function(component, event) {
        try{
            //document.querySelector('.slds-combobox__input').focus();
            var device = $A.get("$Browser.isIPhone");
            if((event.currentTarget.dataset.attr === 'phone' && device === true) || (event.currentTarget.dataset.attr === 'notIphone' && device === false)){
                //If enter key is pressed or the select input is clicked
                if(event.keyCode === undefined || event.keyCode === 13){
                    var isOpenStatus = component.get("v.isOpen");
                    component.set("v.isOpen", !isOpenStatus);
                    this.doInit(component, event);
                }
                //If down arrow key is pressed
                if(event.keyCode === 40){
                    var focusedEle = document.activeElement;
                    var className = component.get('v.listItemClass');
                    var menuItems = document.querySelectorAll('.'+className);
                    menuItems[0].focus();
                    component.set("v.seloptionID",0);
                } 
            } 
        }
        catch(e){
            
        }
    },
    //To remove the pill or deselect an option
    handleRemoveOnly : function(component, event) {
        try{
            var options = component.get("v.options");
            var id = event.currentTarget.name;
            options[id].isSelected = false;
            //IF ORDER NEEDS TO BE MAINTAINED
            if(component.get("v.maintainOrder")){
            	var selectedIdsInOrder = component.get("v.selectedIdsInOrder");
		    	if(selectedIdsInOrder[options[id].Id] != undefined){
		    		delete selectedIdsInOrder[options[id].Id];
		    	}
		    	component.set("v.selectedIdsInOrder",selectedIdsInOrder);
		    	var selectionEvent = component.getEvent('templateSelection');
		    	selectionEvent.setParams({"selectedItem" : component.get("v.selectedIdsInOrder")});
	                // Fire event to parent component to provide selected templates.
	                selectionEvent.fire();
            }
                
            component.set("v.options", options);
        }
        catch(e){
            
        }
    },
    //To close the picklist on blur of the select input
    closePicklist : function(component, event,flag) {        
        try{
            setTimeout(function(){
            var activeEle;
            try{
                activeEle = document.activeElement.className;
                if((activeEle.indexOf('slds-listbox__item') === -1) && (activeEle.indexOf('slds-media__body') === -1) && (activeEle.indexOf('slds-truncate') === -1) && (activeEle.indexOf('listbox-wrapper') === -1)){
                    if(document.activeElement !== event.currentTarget)
                    component.set("v.isOpen", false);
                }
                //If browser is IE, and user clicks on scrollbar, pass focus to the input
                if(navigator.userAgent.match(/Trident/) !== null){
                    if(activeEle.indexOf('listbox-wrapper') > -1){
                        event.target.focus();
                    } 
                }
            } catch(e){
                var activeElement = document.body || null;
                activeEle = activeElement.className;
                if((activeEle.indexOf('slds-listbox__item') === -1) && (activeEle.indexOf('slds-media__body') === -1) && (activeEle.indexOf('slds-truncate') === -1) && (activeEle.indexOf('listbox-wrapper') === -1)){
                    if(activeElement !== event.currentTarget)
                    component.set("v.isOpen", false);
                }
                //If browser is IE, and user clicks on scrollbar, pass focus to the input
                if(navigator.userAgent.match(/Trident/) !== null){
                    if(activeEle.indexOf('listbox-wrapper') > -1){
                        event.target.focus();
                    }  
                }
            }
        },100);
        }
        catch(e){
            
        }
    } ,
    
    clearPicklistValues : function(component , event , helper){
        component.set("v.options" , []);
        component.set("v.selectedPickVals" , []);
        
    } ,
    handleSelectedValueHelper : function(component,event,helper){
    	var userSelection = event.getParam("selectedItemData");
    	var selectedIdsInOrder = component.get("v.selectedIdsInOrder");
    	if(userSelection.isSelected){
    		selectedIdsInOrder[userSelection.Id] = userSelection.Id;
    	}else if(selectedIdsInOrder[userSelection.Id] != undefined){
    		delete selectedIdsInOrder[userSelection.Id];
    	}
    	component.set("v.selectedIdsInOrder",selectedIdsInOrder);
    }
})