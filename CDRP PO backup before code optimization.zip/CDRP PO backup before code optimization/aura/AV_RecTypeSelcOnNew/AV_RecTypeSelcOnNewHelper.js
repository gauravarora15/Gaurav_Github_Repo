({
	fetchListOfRecordTypes: function(component, event, helper) {
      var action = component.get("c.fetchRecordTypeValues");        
        action.setParams({
            "objName": component.get("v.chdObjName")            
      });
	  action.setCallback(this, function(response) {
          
		  var state = response.getState();
          console.log('entred state'+ state);
          console.log('*****response****'+ response.getReturnValue());
         if (state === "SUCCESS") {
			 var result = response.getReturnValue();
			  //console.log('fetch recordtypes'+result);             
                component.set("v.stdRecType", result);
				}
        });
		  
         $A.enqueueAction(action);
   },
    createRecord: function(component, event, helper) { 
		component.set("v.isOpen", true);         
        var radios = document.getElementsByName('options');
        console.log('*****radios*****'+radios);
        var recordTypeLabel;
        for(var i=0; i<radios.length; i++) {
            if (radios[i].checked) {
                recordTypeLabel= radios[i].value;
                console.log(radios[i].value);
            }
        } 
      var action = component.get("c.getRecTypeId"); 
      action.setParams({
         "recordTypeLabel": recordTypeLabel,
          "objName" : 'AV_SPT_Study_Application__c'
      });
      action.setCallback(this, function(response) {
         var state = response.getState();
         console.log('entred state'+ state);
         if (state === "SUCCESS") {
             component.set("v.isOpen", false);
            var createRecordEvent = $A.get("e.force:createRecord");
            var RecTypeID  = response.getReturnValue();
            createRecordEvent.setParams({
               "entityApiName": 'AV_SPT_Study_Application__c',
               "recordTypeId": RecTypeID
            });
            createRecordEvent.fire();
             
         }  
      });
      $A.enqueueAction(action);
   }
})