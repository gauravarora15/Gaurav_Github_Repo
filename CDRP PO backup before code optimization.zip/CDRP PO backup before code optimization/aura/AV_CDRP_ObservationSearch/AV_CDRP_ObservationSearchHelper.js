({
    doInitHelper: function (component, event, helper) {
        if (component.get("v.studyName") == null) {

            var myPageRef = component.get("v.pageReference");
            if (myPageRef != null) {
                var firstname = myPageRef.state.c__recordId;
                var studyName = myPageRef.state.c__nameStudy;

                var studyId = myPageRef.state.c__studyId;
                var operationName = myPageRef.state.c__operationName;
                var taskId = myPageRef.state.c__taskId;
                component.set("v.studyName", studyName);
                component.set("v.studyId", studyId);
                component.set("v.operationName", operationName);
                component.set("v.taskId", taskId);
                component.set("v.recordId", firstname);
            }
        }
    }
})