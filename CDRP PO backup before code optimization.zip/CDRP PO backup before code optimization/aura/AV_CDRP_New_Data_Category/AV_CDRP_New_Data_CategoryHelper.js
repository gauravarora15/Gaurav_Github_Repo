({
    doSearch : function(component, event, helper) {
        //This component will show the object names which match the input given by the user
        
        var action = component.get("c.getDTDCVisits");
        action.setParams({"dtdc":component.get("v.dtdt")});
        action.setCallback(this,function(res){
            var resp = res.getReturnValue();
            component.set("v.sobJMDRVisitlist",resp);
            
        });
        $A.enqueueAction(action);
        
        
    },
    onSelectAll :  function(component, event, helper) {
        var abc = event.getSource().get("v.checked");
        var opts = component.get("v.selectedStudyVisits");
        
        var def = component.get("v.sobJMDRVisitlist");
        var opts1 = [];
        
        if(abc){
            for(var key in opts){
                opts[key]=true;
                opts1.push({value:true, key:key});
                //alert("333" +opts[key]);
            }
            
        }else{
            for(var key in opts){
                opts[key]=false;
                opts1.push({value:false, key:key});
                //alert("333" +opts[key]);
            }
        }
        
        
        component.set("v.selectedStudyVisits", opts);
        component.set("v.sobJMDRVisitlist", opts1);
        component.set("v.selectedDataCategory", '');
    },  
    getDataOnLoad : function(component, event, helper){
        //component.set("v.Spinner", true);
        console.log('checck Id' +component.get("v.checkId"));
        var action = component.get("c.getDataOnLoad");
        action.setParams({'recordId':component.get("v.checkId"),
                          'objectName': 'AV_CDRP_Expected_Data__c',
                          'lstFields':component.get("v.picklistAPIs")}); 
        action.setCallback(this,function(response){
            if (response.getState() == "SUCCESS") {
                //component.set("v.Spinner", false);
                var resp = response.getReturnValue();
					var status = $A.get("$Label.c.AV_Active");	
					var dataProviderFilterMap = {};
                dataProviderFilterMap['AV_Service_Type_Label__c']= $A.get("$Label.c.AV_CDRP_ServiceTypeFilters");
                dataProviderFilterMap['AV_Study_Number__r.Name']=resp.drp.AV_CDRP_Protocol_Number__r.Name;
                component.set("v.dataProviderFilter", dataProviderFilterMap);
					component.set("v.dataFilter",{'AV_CDRP_Data_Category_MDR__c.AV_CDRP_Data_Category_Status__c':status});
					component.set("v.dataTrajFilter",{'AV_CDRP_Data_Trajectory__c.AV_CDRP_Data_Review_Plan_Name__c':resp.drp.Name});
                component.set("v.selectedStudyVisits", resp.stv);
                
                var therapeuticAreaMapOptions = resp.therapeuticAreaMap;
                var optionsTherapeuticAreaMap = [];
                for(var i = 0;i<therapeuticAreaMapOptions.length;i++){
			 		var Option = {};
					Option.Name = therapeuticAreaMapOptions[i];
					Option.isSelected = false;
					Option.Id = therapeuticAreaMapOptions[i];
					optionsTherapeuticAreaMap.push(Option);
				} 
                component.set("v.therapeuticAreaLst", optionsTherapeuticAreaMap);
                var dataCCopts =[];
                for(var i in resp.dct){
                    dataCCopts.push({
                                class: "optionClass",
                                label: resp.dct[i],
                                value: resp.dct[i]
                                
                            });
                }
                component.set("v.DataCCOptions", dataCCopts);
                var custs = [];
              
                for(var key in resp.stv){
                    custs.push({value:resp.stv[key], key:key});
                }
                component.set("v.sobJMDRVisitlist", custs);
                var abc = component.get("v.picklistAPIs");
                var pickListFlds = abc.split(',');
                
                var opts = [];
                var opts1= [];
                var opts2= [];
                var opts3=[];
                
                for( var index in pickListFlds){
                    
                    var obj = resp.picklistVal[pickListFlds[index]];
                    var keys = Object.keys(resp.picklistVal[pickListFlds[index]]);
                    if(pickListFlds[index] == "AV_CDRP_Data_Source__c"){
                        
                        for(var i in keys){
                            
                            
                            
                            opts.push({
                                class: "optionClass",
                                label: keys[i],
                                value: resp.picklistVal[pickListFlds[index]][keys[i]]
                                
                            });
                            
                        }
                        
                        component.set("v.DataSourcePicklstOptions", opts);
                        component.set("v.dcc.AV_CDRP_Data_Source__c", opts[0].value);
                        
                    }
                    
                    
                    if(pickListFlds[index] == "AV_CDRP_Data_Transfer_Frequency__c"){
                        
                        for(var i in keys){
                            
                            opts1.push({
                                class: "optionClass",
                                label: keys[i],
                                value: resp.picklistVal[pickListFlds[index]][keys[i]]
                                
                            });
                            
                        }
                        
                        component.set("v.DataFrequencyOptions", opts1);
                        component.set("v.dcc.AV_CDRP_Data_Transfer_Frequency__c", opts1[0].value);
                        
                    }
                    
                    if(pickListFlds[index] == "AV_CDRP_Critical_Data__c"){
                        
                        for(var i in keys){
                            
                            opts2.push({
                                class: "optionClass",
                                label: keys[i],
                                value: resp.picklistVal[pickListFlds[index]][keys[i]]
                                
                            }); 
                            
                        }
                        
                        component.set("v.CriticalDataPicklstOptions", opts2);
                        component.set("v.dcc.AV_CDRP_Critical_Data__c", opts2[0].value);
                    }
                    
                    
                    if(pickListFlds[index] == "AV_CDRP_Critical_Data_Rationale__c"){
                        
                        for(var i in keys){
                            
                            opts3.push({
                                class: "optionClass",
                                label: keys[i],
                                value: resp.picklistVal[pickListFlds[index]][keys[i]]
                                
                            }); 
                            
                        }
                        
                        component.set("v.CriticalDataRationalePicklstOptions", opts3);
                        //console.log('### CriticalDataRationalePicklstOptions' +opts3[0].value);
                        component.set("v.dcc.AV_CDRP_Critical_Data_Rationale__c", opts3[0].value);
                    }
                    
                }
            }
        });
        
        $A.enqueueAction(action);
    }, 
    onchange :function(component, event, helper){
        var abc = event.getSource().get("v.value");
        var def = event.getSource().getLocalId();
        var ghg = event.getSource().get("v.name");
        if(def=='Critical Data?'){
            component.set("v.dcc.AV_CDRP_Critical_Data__c", abc);
            
            if(abc === 'Yes' || abc === 'None')
                component.set("v.criticalDataSelected",false);
            else{
                component.set("v.criticalDataSelected",true);
                component.set("v.dcc.AV_CDRP_Critical_Data_Rationale__c",'');
            }
        }else if(def=='Data Transfer Frequency'){
            component.set("v.dcc.AV_CDRP_Data_Transfer_Frequency__c", abc);
        }
            else if(def=='Data Source'){
                //console.log("data source" +def);
                component.set("v.dcc.AV_CDRP_Data_Source__c", abc);
            }else if(def=='Critical Data Rationale'){
                component.set("v.dcc.AV_CDRP_Critical_Data_Rationale__c", abc);
            }else if(ghg=='Expected Data Rule'){
                //console.log("expected data rule" +def);
                component.set("v.dcc.Expected_Data_Rule__c", abc);
            }
        
    },
    Oncancel :function(component, event, helper){
        //component.set("v.cancel", true);
       /* var navEvt = $A.get("e.force:navigateToSObject");
        var checkId = component.get("v.checkId");
        navEvt.setParams({
            "recordId": checkId,
            "slideDevName": "related"
        });
        navEvt.fire();
        $A.get('e.force:refreshView').fire();*/
        window.location.assign('/'+component.get("v.checkId"));
    },   
    
    dataCCchange : function(component, event, helper){
        
       component.set("v.selectedItem",event.getParam("selectedItem"));
        var nameParam;
        if(component.get("v.selectedItem")!=null  && component.get("v.selectedItem").val!=null){
            nameParam=component.get("v.selectedItem").val;
        }        
        component.set("v.nameP",nameParam);
     
        if(nameParam!=""  && nameParam!=null){
            var action = component.get("c.dataCC");
            action.setParams({'dcc':component.get("v.nameP")});
                action.setCallback(this,function(response){
                if (response.getState() === "SUCCESS") {
                    var resp = response.getReturnValue();  
                   
                    var opts = component.get("v.selectedStudyVisits");    
                    var def = component.get("v.sobJMDRVisitlist");
                    var opts1 = [];      
                    for(var key in opts){
                        if(resp.includes(key)){
                            opts[key]=true;
                            opts1.push({value:true, key:key});
                        }else{
                           opts[key]=false;
                           opts1.push({value:false, key:key});  
                        }
                    }
                    //component.set("v.selectall",false);
                    component.set("v.selectedStudyVisits", opts);
                    component.set("v.sobJMDRVisitlist", opts1);
                   
                }
            });
            $A.enqueueAction(action);
        }      
        
    },
    checkboxChange :function(component, event, helper){
        var abc = event.getSource().get("v.checked");
        var def = event.getSource().get("v.label");
        var opts =component.get("v.selectedStudyVisits");
       
        
        if(abc){
            opts[def] = true;
            
            
        }else{
            opts[def]= false;
            
        }
        
        component.set("v.selectedStudyVisits", opts);
        component.set("v.selectedDataCategory", '');
        
        
    },
    Onsave :function(component, event, helper){
		component.set("v.showError", false);
        let button = event.getSource();
        if(component.get("v.dcc.AV_CDRP_Critical_Data__c")!="None" && component.get("v.dcc.AV_CDRP_Data_Transfer_Frequency__c")!="None" && component.get("v.dcc.AV_CDRP_Data_Source__c")!="None" && ((component.get("v.selectedDataTraj.Id")!=null && component.get("v.selectedDataTraj.Id")!='' && component.get("v.selectedDataMDR.Id")!=null && component.get("v.selectedDataMDR.Id")!='')||(component.get("v.dataTrajNameId")!=null && component.get("v.dataTrajNameId")!='' && component.get("v.selectedDataMDR.Id")!=null && component.get("v.selectedDataMDR.Id")!=''))){
            if(component.get("v.dcc.AV_CDRP_Critical_Data__c")=='Yes' && component.get("v.dcc.AV_CDRP_Critical_Data_Rationale__c")=='None'){
                component.set("v.showError",true);
                component.set("v.errorMessage","Please enter a value in Critical Data Rationale"); 
                component.set("v.messageType", 'error');
            }else{
                button.set('v.disabled',true);
                var action = component.get("c.savedcc");
                //console.log("###" +component.get("v.dcc.AV_CDRP_Data_Source__c"));
                if(component.get("v.selectedDataTraj.Id")!=''){
                    action.setParams({"dt":component.get("v.selectedDataTraj.Id"),
                                      "dc":component.get("v.selectedDataMDR.Id"), 
                                      "dp":component.get("v.selectedDataProvider.Id"), 
                                      "picklist":JSON.stringify(component.get("v.dcc")),
                                      "dcv" :component.get("v.selectedStudyVisits")});
                }else if(component.get("v.dataTrajNameId")!=''){
                    
                    action.setParams({"dt":component.get("v.dataTrajNameId"),
                                      "dc":component.get("v.selectedDataMDR.Id"),  
                                      "dp":component.get("v.selectedDataProvider.Id"),
                                      "picklist":JSON.stringify(component.get("v.dcc")),
                                      "dcv" :component.get("v.selectedStudyVisits")});
                }
                action.setCallback(this,function(response){
                    if (response.getState() === "SUCCESS") {
                        var resp = response.getReturnValue();
                        if(!$A.util.isEmpty(resp.errorMessage)){
                            component.set("v.showError",true);
                            component.set("v.messageType", 'error');
                            component.set("v.errorMessage",resp.errorMessage);
                            button.set('v.disabled',false);
                            document.getElementsByClassName('slds-modal__content')[0].scrollTop=0;
                        }
                        else{
					/*	var pageReference = {    
                            type: "standard__recordPage",
                            attributes: {
                                "recordId": resp.dataCategoryConfig.Id,
                                "objectApiName": 'AV_CDRP_Expected_Data__c',
                                "actionName": "view"
                            }
                        };
                        component.set("v.pageReference", pageReference);
                        var navService = component.find("navService");
                        var pageReference = component.get("v.pageReference");
                        navService.navigate(pageReference);
						setTimeout(function(){$A.get('e.force:refreshView').fire();},1500);*/
                          
                          
                          	var urltodcc = '/' + resp.dataCategoryConfig.Id;
                            component.set("v.showError",true);
                            component.set("v.messageLink",true)
                            component.set("v.errorMessage",urltodcc);
                        	component.set("v.messageType", 'confirm');
                            setTimeout(function(){window.location.assign('/'+component.get("v.checkId"));},3000);
                            //window.location.assign('/'+component.get("v.checkId"));
						}
                    }
					else if (response.getState() ===  "ERROR") {
                        var errors = response.getError();                      
                        component.set("v.showError",true);
                        component.set("v.errorMessage",errors[0].message);
                        component.set("v.messageType", 'error');
                        button.set('v.disabled',false);
                    }
                });
                $A.enqueueAction(action);
            }
        }else{
            component.set("v.showError",true);
            component.set("v.errorMessage","* Mandatory fields cannot be blank"); 
            component.set("v.messageType", 'error');
        } 
            document.getElementsByClassName('slds-modal__content')[0].scrollTop=0;
       
    },
    showToastHelper : function(component, event, helper){
        
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            
            "message": "Mandatory fields missing"
        });
        toastEvent.fire();
    },
    
    /*getVisits : function(component, event, helper) {
        
        var action = component.get("c.getStudyVisits");//get MDR visits data from controller
        action.setParams({"drv":component.get("v.checkId")});
        
        action.setCallback(this,function(response){
            if (response.getState() == "SUCCESS") {
                
                var resp = response.getReturnValue();
                
                component.set("v.sobJMDRVisitlist",resp);
                var myMap = new Map();
                for(var i=0;i<resp.length;i++){
                    myMap.set(resp[i].Name,'false');
                }
                component.set("v.selectedStudyVisits", myMap);
                
            }
        });
        
        $A.enqueueAction(action);
        
        
    },
    
    
    fetchPicklistValues : function(component,event,helper){
        
        var action = component.get("c.fetchFieldsPicklistValueAPIName");
        action.setParams({
            'objectName': 'AV_CDRP_Expected_Data__c',
            'lstFields':'AV_CDRP_Critical_Data__c,AV_CDRP_Data_Transfer_Frequency__c,AV_CDRP_Data_Source__c,AV_CDRP_Critical_Data_Rationale__c'
        });
        action.setCallback(this, function(response) {
            if (response.getState() == "SUCCESS") {
                
                var result = response.getReturnValue();
                var abc = 'AV_CDRP_Critical_Data__c,AV_CDRP_Data_Transfer_Frequency__c,AV_CDRP_Data_Source__c,AV_CDRP_Critical_Data_Rationale__c';
                var pickListFlds = abc.split(',');
                
                var opts = [];
                var opts1= [];
                var opts2= [];
                var opts3=[];
                
                for( var index in pickListFlds){
                    
                    var obj = result[pickListFlds[index]];
                    var keys = Object.keys(result[pickListFlds[index]]);
                    if(pickListFlds[index] == "AV_CDRP_Data_Source__c"){
                        
                        for(var i in keys){
                            
                            
                            
                            opts.push({
                                class: "optionClass",
                                label: keys[i],
                                value: result[pickListFlds[index]][keys[i]]
                                
                            });
                            
                        }
                       
                        component.set("v.DataSourcePicklstOptions", opts);
                        component.set("v.dcc.AV_CDRP_Data_Source__c", opts[0].value);
                        
                    }
                
                    
                    if(pickListFlds[index] == "AV_CDRP_Data_Transfer_Frequency__c"){
                       
                        for(var i in keys){
                            
                            opts1.push({
                                class: "optionClass",
                                label: keys[i],
                                value: result[pickListFlds[index]][keys[i]]
                                
                            });
                            
                        }
                        
                        component.set("v.DataFrequencyOptions", opts1);
                        component.set("v.dcc.AV_CDRP_Data_Transfer_Frequency__c", opts1[0].value);
                      
                    }
                    
                    if(pickListFlds[index] == "AV_CDRP_Critical_Data__c"){
                         
                        for(var i in keys){
                            
                            opts2.push({
                                class: "optionClass",
                                label: keys[i],
                                value: result[pickListFlds[index]][keys[i]]
                                
                            }); 
                            
                        }
                        
                        component.set("v.CriticalDataPicklstOptions", opts2);
                        component.set("v.dcc.AV_CDRP_Critical_Data__c", opts2[0].value);
                    }
                    
                     
                    if(pickListFlds[index] == "AV_CDRP_Critical_Data_Rationale__c"){
                         
                        for(var i in keys){
                            
                            opts3.push({
                                class: "optionClass",
                                label: keys[i],
                                value: result[pickListFlds[index]][keys[i]]
                                
                            }); 
                            
                        }
                        
                        component.set("v.CriticalDataRationalePicklstOptions", opts3);
                        console.log('### CriticalDataRationalePicklstOptions' +opts3[0].value);
                        component.set("v.dcc.AV_CDRP_Critical_Data_Rationale__c", opts3[0].value);
                    }
                    
                }
            }
        });
        $A.enqueueAction(action);
        
    },*/
    OnNext :function(component, event, helper){
        component.set("v.showError",false);
        if(component.get("v.dcc.AV_CDRP_Critical_Data__c")!="None" && component.get("v.dcc.AV_CDRP_Data_Transfer_Frequency__c")!="None" && component.get("v.dcc.AV_CDRP_Data_Source__c")!="None" && ((component.get("v.selectedDataTraj.Id")!=null && component.get("v.selectedDataTraj.Id")!='' && component.get("v.selectedDataMDR.Id")!=null && component.get("v.selectedDataMDR.Id")!='')||(component.get("v.dataTrajNameId")!=null && component.get("v.dataTrajNameId")!='' && component.get("v.selectedDataMDR.Id")!=null && component.get("v.selectedDataMDR.Id")!=''))){
            if(component.get("v.dcc.AV_CDRP_Critical_Data__c")=='Yes' && component.get("v.dcc.AV_CDRP_Critical_Data_Rationale__c")=='None'){
                component.set("v.showError",true);
                component.set("v.errorMessage","Please enter a value in Critical Data Rationale"); 
                component.set("v.messageType", 'error');
            }else{
                var action = component.get("c.savedcc");
                if(component.get("v.selectedDataTraj.Id")!=''){
                    action.setParams({"dt":component.get("v.selectedDataTraj.Id"),
                                      "dc":component.get("v.selectedDataMDR.Id"),  
                                      "picklist":JSON.stringify(component.get("v.dcc")),
                                      "dcv" :component.get("v.selectedStudyVisits")});
                }else if(component.get("v.dataTrajNameId")!=''){
                    
                    action.setParams({"dt":component.get("v.dataTrajNameId"),
                                      "dc":component.get("v.selectedDataMDR.Id"),  
                                      "picklist":JSON.stringify(component.get("v.dcc")),
                                      "dcv" :component.get("v.selectedStudyVisits")});
                }
                
                action.setCallback(this,function(response){
                   //addded as fix to defec 1865
                    let button = event.getSource();    
                	button.set('v.disabled',true);
                    if (response.getState() === "SUCCESS") {
                        
                        var resp = response.getReturnValue();
                        //alert('error mssg -- '+resp.errorMessage);
                        if(!$A.util.isEmpty(resp.errorMessage)){
                           
                            component.set("v.showError",true);
                            component.set("v.messageType", 'error');
                            component.set("v.errorMessage",resp.errorMessage);
                            button.set('v.disabled',false);
                            document.getElementsByClassName('slds-modal__content')[0].scrollTop=0;
                        }
                        else{ 
                        //
                        var planId = component.get("v.checkId");
                        var trajId = component.get("v.dataTrajNameId");
                        var trajName = component.get("v.dataTrajName");
                        if(trajId!=null){
                            var pageReference = {    
                                type: "standard__component",
                                attributes: {
                                    "componentName": "c__AV_CDRP_New_Data_Category_Button",
                                },
                                "state": {
                                    "recordId": planId,
                                    "dataTrajName": trajName,
                                    "dataTrajNameId": trajId,
                                }
                            };
                        }else{
                            var pageReference = {   
                                type: "standard__component",
                                attributes: {
                                    "componentName": "c__AV_CDRP_New_Data_Category_Button",
                                },
                                "state": {
                                    "recordId":planId,
                                }
                            };
                        }
                            //component.set("v.pageReference", pageReference);
                            //var navService = component.find("navService");
                            //var pageReference = component.get("v.pageReference");
                            //navService.navigate(pageReference);
                            var urltodcc = '/' + resp.dataCategoryConfig.Id;
                            
                            component.set("v.showError",true);
                            component.set("v.messageLink",true)
                            component.set("v.errorMessage",urltodcc);
                        	component.set("v.messageType", 'confirm');
                            setTimeout(function(){window.location.reload();},3000);
                      }
                    }
                    else if (response.getState() ===  "ERROR") {
                        var errors = response.getError();                      
                        component.set("v.showError",true);
                        component.set("v.messageType", 'error');
                        component.set("v.errorMessage",errors[0].message);
                    }
                });
                $A.enqueueAction(action);
            }
        }else{
            component.set("v.showError",true);
            component.set("v.messageType", 'error');
            component.set("v.errorMessage","* Mandatory fields cannot be blank"); 
        } 
        document.getElementsByClassName('slds-modal__content')[0].scrollTop=0;
    },
    handleMultiSelect: function (component, event, helper) {
	if (event.getSource().get("v.multiselectLabel") == "Therapeutic Area Mapping") {
			var taMappings = event.getParam("optionIds");
			var selectedTAMappingIds;
			for (var i in taMappings) {
					if (i == 0) {
						selectedTAMappingIds = taMappings[i];
					} else {
							if (selectedTAMappingIds.indexOf(taMappings[i]) === -1) {
								selectedTAMappingIds = selectedTAMappingIds + ',' + taMappings[i];
							}
					}
			}
			
	}
       
        
        var status = $A.get("$Label.c.AV_Active");
        var fieldTA = "AV_CDRP_Data_Category_MDR__c.AV_CDRP_Therapeutic_Area_Mapping__c";
        component.set("v.dataFilter",{'AV_CDRP_Data_Category_MDR__c.AV_CDRP_Data_Category_Status__c':status,'AV_CDRP_Data_Category_MDR__c.AV_CDRP_Therapeutic_Area_Mapping__c':selectedTAMappingIds});
        component.set("v.multiPicklistString",fieldTA);
}
})