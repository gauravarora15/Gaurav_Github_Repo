({
    doInIt: function (component, event, helper) {
        //helper.getVisits(component, event, helper);
        //helper.fetchPicklistValues(component,event,helper);
        //helper.getLookupComponents(component, event, helper);
        helper.getDataOnLoad(component, event, helper);
    },
    onSelectAll: function (component, event, helper) {
        helper.onSelectAll(component, event, helper);
    },

    dataCCchange: function (component, event, helper) {
        helper.dataCCchange(component, event, helper);
    },
    cancel: function (component, event, helper) {
        //component.find("overlayLib1").notifyClose();        
        helper.Oncancel(component, event, helper);
    },
    save: function (component, event, helper) {
        helper.Onsave(component, event, helper);
    },
    next: function (component, event, helper) {
        helper.OnNext(component, event, helper);
    },

    onchange: function (component, event, helper) {
        helper.onchange(component, event, helper);
    },

    checkboxChange: function (component, event, helper) {
        helper.checkboxChange(component, event, helper);
    },
    doSearch: function (component, event, helper) {
        helper.doSearch(component, event, helper);
    },
    handleMultiSelect : function(component, event, helper){
		helper.handleMultiSelect(component, event, helper);
	}
})