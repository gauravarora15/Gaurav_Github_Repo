({
	doInit : function(component, event, helper) {
        var currentDomain = window.location.href;
        currentDomain = currentDomain.substring(0,currentDomain.indexOf('/'));
		var action  = component.get('c.fetchLinks');
        action.setParams({
            "usage": component.get("v.usage"),
            "domain":currentDomain
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set('v.links',response.getReturnValue());
            }
        });

        $A.enqueueAction(action);
	}
})