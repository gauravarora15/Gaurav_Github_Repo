({
	doInit : function(component, event, helper) {
		helper.doInitHelper(component, event, helper);
		component.set("v.Spinner",true);
	},
	userSelect : function(component, event, helper){
		helper.userSelect(component, event, helper);
	},
	handleMultiSelect : function(component, event, helper){
		helper.handleMultiSelect(component, event, helper);
	}, 
	handleSort : function(component, event, helper){
		helper.handleSort(component, event, helper);
	}, 
	handlePrevious : function(component, event, helper){
		helper.handlePrevious(component, event, helper);
	}, 
	handleNext : function(component, event, helper){
		helper.handleNext(component, event, helper);
	}, 
	
	handleRowsSelection: function(component, event, helper){
		helper.handleRowsSelection(component, event, helper);	
	}
})