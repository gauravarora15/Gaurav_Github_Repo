({
	getMonitoringActivity : function(component, event, helper) {
        var locale = $A.get("$Locale.langLocale");
        var format = _utilityLightning.getDtFormat(locale);       
		var action = component.get("c.getMonitoringActivities");//get data from server side controller
        action.setStorable();
        action.setCallback(this, function(response) {
            var state = response.getState();
             if (state === "SUCCESS") {
                 var records =response.getReturnValue();
                 records.forEach(function(record){
                 record.linkName = '/'+record.Id;
                       });
                 console.log(records);
                 for (var record of records)  
                 {                      
                     record.AV_Monitoring_Start_Date_Local_Format__c = $A.localizationService.formatDate(record.AV_Monitoring_Start_Date_Local_Format__c, format);
                     record.AV_Monitoring_End_Date_Local_Format__c = $A.localizationService.formatDate(record.AV_Monitoring_End_Date_Local_Format__c, format);
                 }                 
               	component.set("v.data", records);//set data in the page variable
                component.set("v.totalPages", Math.ceil(response.getReturnValue().length/component.get("v.pageSize")));
                component.set("v.allData", records);
                component.set("v.currentPageNumber",1);	
                 component.set("v.itemcount",records.length);
                this.buildData(component, helper);
                  }
                  });	
        var requestInitiatedTime = new Date().getTime();
        $A.enqueueAction(action);
	},
    /*
     * this function will build table data
     * based on current page selection
     * */
    buildData : function(component, helper) {
        var data = [];
        var pageNumber = component.get("v.currentPageNumber");
        var pageSize = component.get("v.pageSize");
        var allData = component.get("v.allData");
        var totalRec = component.get("v.itemcount");
        var x = (pageNumber-1)*pageSize;
        var recSrt= ((pageNumber - 1) * pageSize)+1 ;
        var recEnd = pageSize * pageNumber;
        //creating data-table data
        for(; x<(pageNumber)*pageSize; x++){
            if(allData[x]){
            	data.push(allData[x]);
            }
        }
        component.set("v.RecordStart", totalRec != 0 ? recSrt : 0);
        component.set("v.RecordEnd",totalRec >= recEnd ? recEnd : totalRec);
        component.set("v.data", data);
    }
})