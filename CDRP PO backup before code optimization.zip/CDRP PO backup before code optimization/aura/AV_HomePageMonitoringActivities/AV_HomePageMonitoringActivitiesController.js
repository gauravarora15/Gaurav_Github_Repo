({
	getMonitoringActivity : function(component, event, helper) {
		 var actions = [
            { label: $A.get('$Label.c.AV_SPT_Edit'), name: 'Edit' }
        ]
        component.set('v.columns', [ 		
            {label: $A.get('$Label.c.AV_Monitoring_Activity_Number_Label'), fieldName: 'linkName', type: 'url', 
            typeAttributes: {label: { fieldName: 'Name' }, target: '_blank'}},
            {label: $A.get('$Label.c.AV_Monitoring_Activity_Name_label'), fieldName: 'AV_Monitoring_ActivityName__c', type: 'text'},
        	{label: $A.get('$Label.c.AV_Monitoring_Start_Date_Local_Format'), fieldName: 'AV_Monitoring_Start_Date_Local_Format__c', type: 'text'},
            {label: $A.get('$Label.c.AV_Monitoring_End_Date_Local_Format'), fieldName: 'AV_Monitoring_End_Date_Local_Format__c', type: 'text'},
            {label: $A.get('$Label.c.AV_Monitoring_Activity_Status'), fieldName: 'AV_Monitoring_Activity_Status__c', type: 'string'},
            {type: 'action', typeAttributes: { rowActions: actions } } 
        ]);

        //helper.getMonitoringActivity(component, event, helper);
	},
           
        handleRowAction: function (component, event, helper) {
        var action = event.getParam('action');
        var row = event.getParam('row');
        switch (action.name) {
            case 'Edit':                  
                var editRecordEvent = $A.get("e.force:editRecord");
                editRecordEvent.setParams({
                    "recordId": row.Id
                });
                editRecordEvent.fire();
            break;
        }
    },
    
   handleSelect: function (component, event, helper) {
    var createRecordEvent = $A.get("e.force:createRecord");
        createRecordEvent.setParams({ 
            "entityApiName": "AV_Monitoring_Activity__c"
        });
        createRecordEvent.fire();
    },
     onNext : function(component, event, helper) {        
        var pageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", pageNumber+1);
        helper.buildData(component, helper);
    },
    
    onPrev : function(component, event, helper) {        
        var pageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", pageNumber-1);
        helper.buildData(component, helper);
    },
    
    processMe : function(component, event, helper) {
        component.set("v.currentPageNumber", parseInt(event.target.name));
        helper.buildData(component, helper);
    },
    onScriptLoad: function(component, event, helper) {
    console.log('script is loaded');
    helper.getMonitoringActivity(component, event, helper);
  },
})