({
	doInit : function(component, event, helper) {
		helper.doInitHelper(component, event, helper);
	},

	onSave : function(component, event, helper) {
		helper.onSave(component, event, helper);
	},
	reinit: function (component, event, helper) {
		$A.get('e.force:refreshView').fire();
	},
	closeModel:function (component, event, helper) {
		helper.onCancel(component, event, helper);
	},
	onSaveAndNew : function(component, event, helper) {
		helper.onSaveAndNew(component, event, helper);
	},
    handleCategoryChange : function(component, event, helper) {
		helper.handleCategoryChange(component, event, helper);
	}
})