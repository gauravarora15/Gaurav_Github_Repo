({
              getActionItems : function(component, event, helper) {
        var locale = $A.get("$Locale.langLocale");
        var format = _utilityLightning.getDtFormat(locale);
        var action = component.get("c.getActionItemRecords");//get data from server side controller
        action.setStorable();
        action.setCallback(this, function(response) {
            var state = response.getState();
             if (state === "SUCCESS") {
                 var records =response.getReturnValue();
                 records.forEach(function(record){
                     

                     record.linkName = '/'+record.Id;
                     //record.linkName1 = record.AV_Related_Observation__r.AV_Record_Type_Name__c;
                    // record.linkName2 = '/'+record.AV_Related_Observation__r.AV_Related_Study__c;
                    // record.linkName3 = '/'+record.AV_Related_Observation__r.AV_Related_PI_Primary_Facility__c;
                     //record.linkName4 = '/'+record.AV_Related_Observation__c;
                    console.log('record.linkName+'+record.linkName);
                     if(record.AV_Related_Observation__c != null)
                    {
                        record.linkName4= '/' + record.AV_Related_Observation__c; 
                        console.log('record.linkName+4'+record.AV_Related_Observation__c);
                    }
                    else{
                        record.linkName4='';
                    }
                     if(record.AV_Related_Observation__c != null && record.AV_Related_Observation__r != undefined && record.AV_Related_Studies__c != null)
                    {
                        record.linkName2= record.AV_Related_Studies__c; 
                        console.log('record.linkName+2'+record.AV_Related_Studies__c);
                    }
                    else{
                        record.linkName2='';
                    }
                  if(record.AV_Related_Observation__c != null && record.AV_Related_Observation__r != undefined && record.AV_Related_Observation__r.AV_Related_PI_Primary_Facility__c != null && record.AV_Related_PI_Primary_Facility_ET__c != null)
                    {
                        record.linkName3= '/' + record.AV_Related_Observation__r.AV_Related_PI_Primary_Facility__c; 
                       console.log('record.linkName+3'+record.AV_Related_Observation__r.AV_Related_PI_Primary_Facility__c);
                   
                    }
                    else if(record.AV_Related_Observation__c != null && record.AV_Related_Observation__r != undefined && record.AV_Related_Observation__r.AV_Related_PI_Primary_Facility_Risk__c != null && record.AV_Related_PI_Primary_Facility_ET__c != null)
                    {
                        record.linkName3= '/' + record.AV_Related_Observation__r.AV_Related_PI_Primary_Facility_Risk__c; 
                   
                    }
                    else{
                        record.linkName3='';
                    }
                     if(record.AV_Related_Observation__c != null && record.AV_Related_Observation__r != undefined && record.AV_Related_Observation__r.AV_Record_Type_Name__c != null)
                    {
                        record.linkName1= record.AV_Related_Observation__r.AV_Record_Type_Name__c;
                                console.log('record.linkName+1'+record.AV_Related_Observation__r.AV_Record_Type_Name__c);

                    }
                    else{
                        record.linkName1='';
                    }
                       });
                 for (var record of records)  
                {                      
                    record.AV_Due_Date__c = $A.localizationService.formatDate(record.AV_Due_Date__c, format);                     
                }
               component.set("v.data", records);//set data in the page variable
                component.set("v.totalPages", Math.ceil(response.getReturnValue().length/component.get("v.pageSize")));
                component.set("v.allData", records);
                component.set("v.currentPageNumber",1);       
                 component.set("v.itemcount",records.length);
                this.buildData(component, helper);
                  }
                  });       
        var requestInitiatedTime = new Date().getTime();
        $A.enqueueAction(action);
    },
    /*
     * this function will build table data
     * based on current page selection
     * */
    buildData : function(component, helper) {
        var data = [];
        var pageNumber = component.get("v.currentPageNumber");
        var pageSize = component.get("v.pageSize");
        var allData = component.get("v.allData");
        var totalRec = component.get("v.itemcount");
        var x = (pageNumber-1)*pageSize;
        var recSrt= ((pageNumber - 1) * pageSize)+1 ;
        var recEnd = pageSize * pageNumber;
        //creating data-table data
        for(; x<(pageNumber)*pageSize; x++){
            /*if(allData[x].AV_Related_Study_ET__c == null || allData[x].AV_Related_PI_Primary_Facility_ET__c == null              )
                     {
                         allData[x].AV_Related_Study_ET__c=' ';
                         allData[x].AV_Related_PI_Primary_Facility_ET__c =' ';                     
                     }*/
            if(allData[x]){
              data.push(allData[x]);
            }
        }
        component.set("v.RecordStart", totalRec != 0 ? recSrt : 0);
        component.set("v.RecordEnd",totalRec >= recEnd ? recEnd : totalRec);
        component.set("v.data", data);
    }
})