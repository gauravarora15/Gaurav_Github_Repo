({
	recordUpdatedHelper : function(component, event, helper) {
    	console.log('-----------'+event.getParams().changeType);
        if(event.getParams().changeType === "CHANGED"){
        	console.log('inside refresh 22');
            var sObectEvent = $A.get("e.force:navigateToSObject");
            	sObectEvent .setParams({
                	"recordId": component.get("v.recordId"),
                	"slideDevName": "detail"
                });
                sObectEvent.fire();
                console.log('inside refresh 22 exit');
        }
    }
})