({
	doInit : function(component, event, helper) {        
        helper.doInitialAction(component, event, helper);
    },
    dateSort:function(component, event, helper) {        
        helper.dateSort(component, event, helper);
    },
    dataAccumulationSort:function(component, event, helper) {        
        helper.dataAccumulationSort(component, event, helper);
    },
    // this function automatic call by aura:waiting event  
    showSpinner: function (component, event, helper) {
        // make Spinner attribute true for display loading spinner 
        component.set("v.Spinner", true);
    },

    // this function automatic call by aura:doneWaiting event 
    hideSpinner: function (component, event, helper) {
        // make Spinner attribute to false for hide loading spinner    
        component.set("v.Spinner", false);
    }    
})