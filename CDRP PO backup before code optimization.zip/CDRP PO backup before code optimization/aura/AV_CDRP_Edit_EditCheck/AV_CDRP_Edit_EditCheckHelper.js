({
	
	doInitHelper: function(component, event, helper) {
          
        var rec = component.get("v.recordId");
        
        helper.callServer(component,"c.getIdrpCheckStatus", 
                          function(response){  
                            var checkStatus = response; 
                           if(checkStatus==$A.get("$Label.c.AV_CDRP_Status_InApproval") || checkStatus==$A.get("$Label.c.AV_CDRP_Data_Check_Status_Completed") || checkStatus==$A.get("$Label.c.AV_CDRP_Data_Review_Plan_Status_Cancelled") || checkStatus==$A.get("$Label.c.AV_CDRP_Data_Check_Status_Superseded")) {
                               helper.showToast('ERROR', 'ERROR', $A.get("$Label.c.AV_CDRP_Data_Trajectory_Edit_Validation_Message"));
                               var navEvt = $A.get("e.force:navigateToSObject");
                                       navEvt.setParams({
                                           "recordId": rec,
                                           "slideDevName": "detail"
                                       });
                                       navEvt.fire();
                                       $A.get('e.force:refreshView').fire(); 
                           }
                           else if(checkStatus===$A.get("$Label.c.AV_CDRP_Business_Rule_Status_Inactive")) {
                             helper.showToast('ERROR', 'ERROR', $A.get("$Label.c.AV_CDRP_Check_Field_Inactive_Error"));
                             var navEvt = $A.get("e.force:navigateToSObject"); 
                                       navEvt.setParams({
                                           "recordId": rec,
                                           "slideDevName": "detail"
                                       });
                                       navEvt.fire();
                                       $A.get('e.force:refreshView').fire();
                         }
                           else {
                           component.set("v.showModal", true);
                          
                          
                          helper.callServer(component,"c.getEditCheckDetail", 
                          function(response){
                         component.set("v.checkId", response.AV_CDRP_Related_IDRP_Check__c);	
                         component.set("v.relatedDataCheck", response.AV_CDRP_Related_IDRP_Check__r.Name);	
                         component.set("v.purpose", response.AV_CDRP_Related_IDRP_Check__r.AV_CDRP_Purpose__c);	
                         component.set("v.checkName", response.Name);
                         component.set("v.EditCheckName", response.AV_CDRP_Edit_Check_Name__c);
                         component.set("v.editCheckRecordId",response.Id);
                         component.set("v.editCheckId",response.Name);

                         if(response.AV_CDRP_Parent_Library_Edit_Check__c!=null){
                         component.set("v.libCheckName", response.AV_CDRP_Parent_Library_Edit_Check__r.AV_CDRP_Edit_Check_Name__c);	
                         
                         component.set("v.relatedLibraryCheck", response.AV_CDRP_Parent_Library_Edit_Check__r.Name);	

                         }
                        
                      if (!($A.util.isEmpty(response.AV_CDRP_IDRP_Data_Category__c) || $A.util.isUndefinedOrNull(response.AV_CDRP_IDRP_Data_Category__c))) {
                        component.set("v.relatedDataCategory.Id",response.AV_CDRP_IDRP_Data_Category__c);
                        component.set("v.relatedDataCategory.Name",response.AV_CDRP_IDRP_Data_Category__r.Name);
                            component.find("relatedDataCategory").preselectValue();

                         }
                         component.set("v.dataCategoryFilter", {'AV_CDRP_IDRP_Data_Category__c.AV_CDRP_IDRP_Data_Category_Status__c':$A.get("$Label.c.AV_Active"),
                                                                  'AV_CDRP_IDRP_Data_Category__c.AV_CDRP_Related_IDRP__c':response.AV_CDRP_Related_IDRP_Check__r.AV_CDRP_Data_Review_Plan__c});
	

                          },{
                            recordId : rec
                          });
                          
                   
                     }
                          },{
                            recordId : rec
                          });
        
},
showToast: function (toastTitle, toastType, toastMessage) {
  var toastEvent = $A.get("e.force:showToast");
  toastEvent.setParams({
      "title": toastTitle,
      "type": toastType,
      "message": toastMessage
  });
  toastEvent.fire();
},
onSave: function(component,event,helper) {  
 
  component.set("v.isErrorForSelectField", false);
  component.set("v.showError", false);
  component.set("v.errorMessage", '');

  
    var purpose = component.get("v.purpose");
    var getInputkeyWord = component.get("v.relatedDataCategory").Id;
    var editCheckName = component.get("v.EditCheckName");
    if(typeof editCheckName != $A.get("$Label.c.AV_Undefined")){
      editCheckName=editCheckName.trimLeft();
    }
    if(editCheckName===null || editCheckName === "" || typeof editCheckName == $A.get("$Label.c.AV_Undefined") ){
      component.set("v.showError", true);
      let button = event.getSource();
      button.set('v.disabled', false);
    }
   else if ((getInputkeyWord == null || getInputkeyWord === "" || typeof getInputkeyWord == $A.get("$Label.c.AV_Undefined")) && purpose===$A.get("$Label.c.AV_CDRP_Missing_Data_Picklist")) {
      component.set("v.isErrorForSelectField", true);
      component.set("v.errorMessage", $A.get("$Label.c.AV_CDRP_Missing_Data_DataCategory_Blank_Error"));
      let button = event.getSource();
      button.set('v.disabled', false);
  }
  else {
      let button = event.getSource();
      button.set('v.disabled', true);
      helper.saverec(component, event, helper, editCheckName, $A.get("$Label.c.AV_CDRP_Save"));
      button.set('v.disabled',false);

  }
},

onSaveAndNew: function(component,event,helper) {  
 
  component.set("v.isErrorForSelectField", false);
  component.set("v.showError", false);
  component.set("v.errorMessage", '');

  
  var purpose = component.get("v.purpose");
  var getInputkeyWord = component.get("v.relatedDataCategory").Id;
  var editCheckName = component.get("v.EditCheckName");
  if(typeof editCheckName != $A.get("$Label.c.AV_Undefined")){
    editCheckName=editCheckName.trimLeft();
  }
  if(editCheckName===null || editCheckName === "" || typeof editCheckName == $A.get("$Label.c.AV_Undefined") ){
    component.set("v.showError", true);
    let button = event.getSource();
    button.set('v.disabled', false);
  }
 else if ((getInputkeyWord == null || getInputkeyWord === "" || typeof getInputkeyWord == $A.get("$Label.c.AV_Undefined")) && purpose===$A.get("$Label.c.AV_CDRP_Missing_Data_Picklist")) {
    component.set("v.isErrorForSelectField", true);
    component.set("v.errorMessage", $A.get("$Label.c.AV_CDRP_Missing_Data_DataCategory_Blank_Error"));
    let button = event.getSource();
    button.set('v.disabled', false);
}
  else {
      let button = event.getSource();
      button.set('v.disabled', true);
      var buttonclick =$A.get("$Label.c.AV_CDRP_SaveNew");
      helper.saverec(component, event, helper, editCheckName, buttonclick);
      button.set('v.disabled',false);

  }
},

// method to save the record in system
saverec: function(component, event, helper,editCheckName,buttonclick) {
  component.set("v.displaySpinner",true);
 // var queryWrapper = component.get("v.queryWrapperRec");
 if(component.get("v.editEditCheck")){

  var editCheckRecord = component.get("v.EditCheckRecord");
  var editCheckWrapperRec = component.get("v.editCheckWrapperRec");
  var getInputkeyWord = component.get("v.relatedDataCategory").Id;
  if(typeof getInputkeyWord == $A.get("$Label.c.AV_Undefined")){
    editCheckRecord.AV_CDRP_IDRP_Data_Category__c = '';
  }
  else{
  editCheckRecord.AV_CDRP_IDRP_Data_Category__c = component.get("v.relatedDataCategory").Id;
}
  editCheckRecord.AV_CDRP_Edit_Check_Name__c = editCheckName;
  editCheckRecord.AV_CDRP_Related_IDRP_Check__c = component.get("v.checkId");
  editCheckRecord.Id = component.get("v.editCheckRecordId");
  
  var action = component.get("c.updateEditCheckRec");
  action.setParams({
      "editCheckRecord": JSON.stringify(component.get("v.EditCheckRecord")) 
  });
  action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === "SUCCESS") {
          var response = response.getReturnValue();
          if(buttonclick===$A.get("$Label.c.AV_CDRP_Save")){
          component.set("v.wrapperRec",response);
          if(!response.hasError){
              if(component.get("v.updateFlag")){
                component.set("v.updateFlag",false);
                helper.showToast('','Success',$A.get("$Label.c.AV_CDRP_EditCheck_Update"));
              }
              else{
              helper.showToast('','Success',$A.get("$Label.c.AV_CDRP_EditCheck_Success"));
              }
              window.location.assign('/'+component.get("v.checkId"));

            }
            else{
              helper.showToast('ERROR','ERROR',response.errorString);
          }
          }
            else{
              if(!response.hasError){
              component.set("v.relatedDataCategory",null);
              component.set("v.EditCheckName","");
              var childCmp = component.find("relatedDataCategory");
              childCmp.invokeClose();
              if(component.get("v.updateFlag")){
                component.set("v.updateFlag",false);
                helper.showToast('','Success',$A.get("$Label.c.AV_CDRP_EditCheck_Update"));
              }
              else{
              helper.showToast('','Success',$A.get("$Label.c.AV_CDRP_EditCheck_Success"));
              }
              }
              else{
                helper.showToast('ERROR','ERROR',response.errorString);
            }
            }
          
            component.set("v.editEditCheck",false);
          

      }else if (response.getState() ===  "ERROR") {
        var errors = response.getError();                      
        component.set("v.showError",true);
        component.set("v.errorMessage",errors[0].message);
        component.set("v.messageType", 'error');
    }
      
  });
  $A.enqueueAction(action);
}
   else{
    var editCheckRecordNew = component.get("v.EditCheckRecordNew");
    var editCheckWrapperRec = component.get("v.editCheckWrapperRec");
    var getInputkeyWord = component.get("v.relatedDataCategory").Id;
    if(typeof getInputkeyWord == $A.get("$Label.c.AV_Undefined")){
        editCheckRecordNew.AV_CDRP_IDRP_Data_Category__c = '';
    }
    else{
        editCheckRecordNew.AV_CDRP_IDRP_Data_Category__c = component.get("v.relatedDataCategory").Id;
  }
  editCheckRecordNew.AV_CDRP_Edit_Check_Name__c = editCheckName;
  editCheckRecordNew.AV_CDRP_Related_IDRP_Check__c = component.get("v.checkId");
    var action = component.get("c.insertEditCheckRec");
    action.setParams({
        "editCheckRecord": JSON.stringify(component.get("v.EditCheckRecordNew")) 
    });
    action.setCallback(this, function(response) {
        var state = response.getState();
        if (state === "SUCCESS") {
            var response = response.getReturnValue();
            if(buttonclick==="save"){
            component.set("v.wrapperRec",response);
            if(!response.hasError){
                helper.showToast('','Success',$A.get("$Label.c.AV_CDRP_EditCheck_Success"));
                window.location.assign('/'+component.get("v.checkId"));

              }
              else{
                helper.showToast('ERROR','ERROR',response.errorString);
            }
            }
              else{
                if(!response.hasError){
                component.set("v.relatedDataCategory",null);
                component.set("v.EditCheckName","");
                var childCmp = component.find("relatedDataCategory");
                childCmp.invokeClose();
                helper.showToast('','Success',$A.get("$Label.c.AV_CDRP_EditCheck_Success"));
                }
                else{
                  helper.showToast('ERROR','ERROR',response.errorString);
              }
              }
            
              component.set("v.editEditCheck",false);
            
  
        }else if (response.getState() ===  "ERROR") {
          var errors = response.getError();                      
          component.set("v.showError",true);
          component.set("v.errorMessage",errors[0].message);
          component.set("v.messageType", 'error');
      }
        
    });
    $A.enqueueAction(action);
   }
 component.set("v.displaySpinner",false);
},

onCancel :function(component, event, helper){
  window.location.assign('/'+component.get("v.checkId"));

},   

})