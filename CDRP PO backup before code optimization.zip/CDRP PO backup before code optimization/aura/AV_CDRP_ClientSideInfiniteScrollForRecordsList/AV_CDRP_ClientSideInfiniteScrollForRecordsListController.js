({
  doInit: function(component, event, helper) {
    var userId = $A.get("$SObjectType.CurrentUser.Id");
    var pageRef = component.get("v.pageReference");
    var pageName = pageRef.state.c__pageName;
    var relatedIdrp = pageRef.state.c__relatedIdrp;
    var sectionName = pageRef.state.c__sectionName;
    var subSectionName = pageRef.state.c__subSectionName;
    var sectionSize = pageRef.state.c__sectionSize;
    component.set("v.pageName", pageName);
    component.set("v.relatedIdrp", relatedIdrp);
    component.set("v.sectionName", sectionName);
    component.set("v.subSectionName", subSectionName);
    component.set("v.sectionSize", sectionSize);
    component.set("v.totalNumberOfRows", sectionSize);

    if (
      sectionName === $A.get("$Label.c.AV_CDRP_Queries_Action_Header") ||
      sectionName ===
        $A.get("$Label.c.AV_CDRP_Queries_Action_Header").substring(0, 21)
    ) {
      helper.listOfAllQueries(component, event, helper);
    }

    if (sectionName === $A.get("$Label.c.AV_CDRP_Observation_Header")) {
      helper.listOfAllObservations(component, event, helper);
    }

    if (sectionName === $A.get("$Label.c.AV_Homepage_OpenTask_to_me")) {
      helper.listOfAllTasks(component, event, helper);
    }
  },

  loadMoreData: function(component, event, helper) {
    component.set("v.loadMoreStatus", $A.get("$Label.c.AV_CDRP_LoadingMessage"));
    if (
      component.get("v.data").length >= component.get("v.totalNumberOfRows") ||
      component.get("v.data").length >= 49000
    ) {
      component.set("v.enableInfiniteLoading", false);
      component.set("v.loadMoreStatus", $A.get("$Label.c.AV_CDRP_No_MoreData_Message"));
      event.getSource().set("v.isLoading", false);
    } else {
      event.getSource().set("v.isLoading", true);
    
       var sectionName = component.get("v.sectionName");
      if (
        sectionName === $A.get("$Label.c.AV_CDRP_Queries_Action_Header") ||
        sectionName ===
          $A.get("$Label.c.AV_CDRP_Queries_Action_Header").substring(0, 21)
      ) {
        helper.fetchQueryData(component, component.get("v.rowsToLoad")).then(
          $A.getCallback(function(data) {
            var currentData = component.get("v.data");
            var newData = currentData.concat(data);
            component.set("v.data", newData);
            event.getSource().set("v.isLoading", false);
            component.set(
              "v.loadMoreStatus",
              $A.get("$Label.c.AV_CDRP_Scroll_Message")
            );
          })
        );
      }

      if (sectionName === $A.get("$Label.c.AV_CDRP_Observation_Header")) {
        helper
          .fetchObservationData(component, component.get("v.rowsToLoad"))
          .then(
            $A.getCallback(function(data) {
              var currentData = component.get("v.data");
              var newData = currentData.concat(data);
              component.set("v.data", newData);
              event.getSource().set("v.isLoading", false);
              component.set(
                "v.loadMoreStatus",
                $A.get("$Label.c.AV_CDRP_Scroll_Message")
              );
            })
          );
      }

      if (sectionName === $A.get("$Label.c.AV_Homepage_OpenTask_to_me")) {
        helper.fetchTaskData(component, component.get("v.rowsToLoad")).then(
          $A.getCallback(function(data) {
            var currentData = component.get("v.data");
            var newData = currentData.concat(data);
            component.set("v.data", newData);
            event.getSource().set("v.isLoading", false);
            component.set(
              "v.loadMoreStatus",
              $A.get("$Label.c.AV_CDRP_Scroll_Message")
            );
          })
        );
      }
    }
  }
});