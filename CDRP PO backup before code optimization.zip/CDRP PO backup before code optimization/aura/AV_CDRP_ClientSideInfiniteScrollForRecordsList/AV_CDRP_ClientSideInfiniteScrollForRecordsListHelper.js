({
  listOfAllObservations: function(component, event, helper) {
    component.set("v.Spinner", true);

    var action = component.get("c.getObservationsRecords");
    var userId = $A.get("$SObjectType.CurrentUser.Id");
    var pageName = component.get("v.pageName");
    var relatedIdrp = "";
    if (component.get("v.pageName") !== $A.get("$Label.c.AV_CDRP_Home")) {
      relatedIdrp = component.get("v.relatedIdrp");
    }

    action.setParams({
      userId: userId,
      relatedIdrp: relatedIdrp,
      pageName: pageName,
      view: "listView"
    });
    action.setCallback(this, function(response) {
      component.set("v.completeList", response.getReturnValue());
      if (response.getReturnValue().length > 100) {
        var dataList = [];
        for (var i = 0; i < 100; i++) {
          response.getReturnValue()[i].linkName =
            "/" + response.getReturnValue()[i].Id;
          if (
            response.getReturnValue()[i].AV_Age_from_creation_date__c != null
          ) {
            response.getReturnValue()[
              i
            ].AV_Age_from_creation_date__c = response
              .getReturnValue()
              [i].AV_Age_from_creation_date__c.toString();
          }
          dataList.push(response.getReturnValue()[i]);
        }
        component.set("v.lastRecordNo", 100);
        component.set("v.data", dataList);

        component.set("v.columns", [
          {
            label: "OBSERVATION ID",
            fieldName: "linkName",
            type: "url",
            typeAttributes: { label: { fieldName: "Name" }, target: "_blank" }
          },
          { label: "CATEGORY", fieldName: "AV_Category__c", type: "text" },
          {
            label: "SUBCATEGORY",
            fieldName: "AV_Subcategory__c",
            type: "text"
          },
          {
            label: "ADDITIONAL  INFO",
            fieldName: "AV_Additional_Information__c",
            type: "text"
          },
          { label: "STATUS", fieldName: "AV_Status__c", type: "text" },
          {
            label: "RELATED STUDY",
            fieldName: "AV_Related_Studies__c",
            type: "text"
          },
          {
            label: "AGE FROM CREATION",
            fieldName: "AV_Age_from_creation_date__c",
            type: "text"
          }
        ]);
        component.set("v.Spinner", false);
      }
    });
    $A.enqueueAction(action);
  },

  listOfAllQueries: function(component, event, helper) {
    component.set("v.Spinner", true);

    var userId = $A.get("$SObjectType.CurrentUser.Id");
    var pageName = component.get("v.pageName");
    var relatedIdrp = "";
    if (component.get("v.pageName") !== $A.get("$Label.c.AV_CDRP_Home")) {
      relatedIdrp = component.get("v.relatedIdrp");
    }
    if (component.get("v.pageName") === $A.get("$Label.c.AV_CDRP_Home")) {
          var act = component.get("c.getAllQueriesRecordHomePage");
          act.setParams({
          recordTypeId: component.get("v.pageReference").state.c__recordTypeId,
      });
      act.setCallback(this, function(response) {
        var state = response.getState();
        if (state === "SUCCESS") {
          component.set("v.completeList", response.getReturnValue());
          
          if (response.getReturnValue().length > 100) {
            var dataList = [];
            for (var i = 0; i < 100; i++) {
              response.getReturnValue()[i].linkName =
                "/" + response.getReturnValue()[i].Id;
              if (response.getReturnValue()[i].daysOpen != null) {
                response.getReturnValue()[i].daysOpen = response
                  .getReturnValue()
                  [i].daysOpen.toString();
              }
              dataList.push(response.getReturnValue()[i]);
            }
            component.set("v.lastRecordNo", 100);
            component.set("v.data", dataList);
  
            if (component.get("v.pageName") === $A.get("$Label.c.AV_CDRP_Home")) {
              component.set("v.columns", [
                {
                  label: "DISCREPANCY/QUERY ID",
                  fieldName: "linkName",
                  type: "url",
                  typeAttributes: {
                    label: { fieldName: "name" },
                    target: "_blank"
                  }
                },
                { label: "QUERY SOURCE", fieldName: "querySource", type: "text" },
                { label: "RELATED IDRP", fieldName: "relatedIDRP", type: "text" },
                { label: "COUNTRY", fieldName: "country", type: "text" },
                {
                  label: "INVESTIGATOR NAME",
                  fieldName: "investigatorName",
                  type: "text"
                },
                { label: "SUBJECT NAME", fieldName: "subjectName", type: "text" },
                { label: "DATA FORM", fieldName: "dataForm", type: "text" },
                { label: "FIELD NAME", fieldName: "fieldName", type: "text" },
                { label: "QUERY TEXT", fieldName: "queryText", type: "text" },
                {
                  label: "DISCREPANCY/QUERY STATUS",
                  fieldName: "status",
                  type: "text"
                },
                { label: "USER COMMENT", fieldName: "userComment", type: "text" },
                { label: "DAYS OPEN", fieldName: "daysOpen", type: "text" },
              ]);
              component.set("v.Spinner", false);
            } else {
              component.set("v.columns", [
                {
                  label: "DISCREPANCY/QUERY ID",
                  fieldName: "linkName",
                  type: "url",
                  typeAttributes: {
                    label: { fieldName: "name" },
                    target: "_blank"
                  }
                },
                { label: "QUERY SOURCE", fieldName: "querySource", type: "text" },
                { label: "COUNTRY", fieldName: "country", type: "text" },
                {
                  label: "INVESTIGATOR NAME",
                  fieldName: "investigatorName",
                  type: "text"
                },
                { label: "SUBJECT NAME", fieldName: "subjectName", type: "text" },
                { label: "DATA FORM", fieldName: "dataForm", type: "text" },
                { label: "FIELD NAME", fieldName: "fieldName", type: "text" },
                { label: "QUERY TEXT", fieldName: "queryText", type: "text" },
                {
                  label: "DISCREPANCY/QUERY STATUS",
                  fieldName: "status",
                  type: "text"
                },
                { label: "USER COMMENT", fieldName: "userComment", type: "text" },
                { label: "DAYS OPEN", fieldName: "daysOpen", type: "text" },
              ]);
              component.set("v.Spinner", false);
            }
          }
        } else if (state === "INCOMPLETE") {
          component.set("v.Spinner", false);
          helper.showToast(
            "ERROR",
            "ERROR",
            $A.get("$Label.c.AV_CDRP_ErrorMessage")
          );
        } else {
          component.set("v.Spinner", false);
          helper.showToast(
            "ERROR",
            "ERROR",
            $A.get("$Label.c.AV_CDRP_ErrorMessage")
          );
        }
      });
      $A.enqueueAction(act);
        
 } else {
          var act = component.get("c.getAllQueriesRecordPlanPage");
          act.setParams({
          recordTypeId: component.get("v.pageReference").state.c__recordTypeId,
          pageName: pageName,
          relatedIdrp: relatedIdrp
      });
      act.setCallback(this, function(response) {
        var state = response.getState();
        if (state === "SUCCESS") {
          component.set("v.completeList", response.getReturnValue());
         
          if (response.getReturnValue().length > 100) {
            var dataList = [];
            for (var i = 0; i < 100; i++) {
              response.getReturnValue()[i].linkName =
                "/" + response.getReturnValue()[i].Id;
              if (response.getReturnValue()[i].daysOpen != null) {
                response.getReturnValue()[i].daysOpen = response
                  .getReturnValue()
                  [i].daysOpen.toString();
              }
              dataList.push(response.getReturnValue()[i]);
            }
            component.set("v.lastRecordNo", 100);
            component.set("v.data", dataList);
  
            if (component.get("v.pageName") === $A.get("$Label.c.AV_CDRP_Home")) {
              component.set("v.columns", [
                {
                  label: "DISCREPANCY/QUERY ID",
                  fieldName: "linkName",
                  type: "url",
                  typeAttributes: {
                    label: { fieldName: "name" },
                    target: "_blank"
                  }
                },
                { label: "QUERY SOURCE", fieldName: "querySource", type: "text" },
                { label: "RELATED IDRP", fieldName: "relatedIDRP", type: "text" },
                { label: "COUNTRY", fieldName: "country", type: "text" },
                {
                  label: "INVESTIGATOR NAME",
                  fieldName: "investigatorName",
                  type: "text"
                },
                { label: "SUBJECT NAME", fieldName: "subjectName", type: "text" },
                { label: "DATA FORM", fieldName: "dataForm", type: "text" },
                { label: "FIELD NAME", fieldName: "fieldName", type: "text" },
                { label: "QUERY TEXT", fieldName: "queryText", type: "text" },
                {
                  label: "DISCREPANCY/QUERY STATUS",
                  fieldName: "status",
                  type: "text"
                },
                { label: "USER COMMENT", fieldName: "userComment", type: "text" },
                { label: "DAYS OPEN", fieldName: "daysOpen", type: "text" },
              ]);
              component.set("v.Spinner", false);
            } else {
              component.set("v.columns", [
                {
                  label: "DISCREPANCY/QUERY ID",
                  fieldName: "linkName",
                  type: "url",
                  typeAttributes: {
                    label: { fieldName: "name" },
                    target: "_blank"
                  }
                },
                { label: "QUERY SOURCE", fieldName: "querySource", type: "text" },
                { label: "COUNTRY", fieldName: "country", type: "text" },
                {
                  label: "INVESTIGATOR NAME",
                  fieldName: "investigatorName",
                  type: "text"
                },
                { label: "SUBJECT NAME", fieldName: "subjectName", type: "text" },
                { label: "DATA FORM", fieldName: "dataForm", type: "text" },
                { label: "FIELD NAME", fieldName: "fieldName", type: "text" },
                { label: "QUERY TEXT", fieldName: "queryText", type: "text" },
                {
                  label: "DISCREPANCY/QUERY STATUS",
                  fieldName: "status",
                  type: "text"
                },
                { label: "USER COMMENT", fieldName: "userComment", type: "text" },
                { label: "DAYS OPEN", fieldName: "daysOpen", type: "text" },
              ]);
              component.set("v.Spinner", false);
            }
          }
        } else if (state === "INCOMPLETE") {
          component.set("v.Spinner", false);
          helper.showToast(
            "ERROR",
            "ERROR",
            $A.get("$Label.c.AV_CDRP_ErrorMessage")
          );
        } else {
          component.set("v.Spinner", false);
          helper.showToast(
            "ERROR",
            "ERROR",
            $A.get("$Label.c.AV_CDRP_ErrorMessage")
          );
        }
      });
      $A.enqueueAction(act);
        }
        
  },
  listOfAllTasks: function(component, event, helper) {
    component.set("v.Spinner", true);

    var userId = $A.get("$SObjectType.CurrentUser.Id");
    var pageName = component.get("v.pageName");
    var existList = component.get("v.existList");
    var relatedIdrp = "";
    if (component.get("v.pageName") !== $A.get("$Label.c.AV_CDRP_Home")) {
      relatedIdrp = component.get("v.relatedIdrp");
    }
    var action = component.get("c.getAllTaskRecords");
    action.setParams({
      userId: userId,
      relatedIdrp: relatedIdrp
    });
    action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === "SUCCESS") {
        component.set("v.completeList", response.getReturnValue());

        if (response.getReturnValue().length > 100) {
          var dataList = [];
          for (var i = 0; i < 100; i++) {
            response.getReturnValue()[i].linkName =
              "/" + response.getReturnValue()[i].Id;
            if (
              component.get("v.pageName") === $A.get("$Label.c.AV_CDRP_Home")
            ) {
              if (
                response.getReturnValue()[i].AV_CDRP_Related_Study_Name__c !=
                null
              )
                response.getReturnValue()[
                  i
                ].AV_CDRP_Related_Study = response.getReturnValue()[
                  i
                ].AV_CDRP_Related_Study_Name__c;
            } else {
              if (
                response.getReturnValue()[i].AV_CDRP_Related_Study_Name__c !=
                null
              )
                response.getReturnValue()[
                  i
                ].cdrpTaskRelatedStudy = response.getReturnValue()[
                  i
                ].cdrpTaskRelatedStudy;
            }
            dataList.push(response.getReturnValue()[i]);
          }
          component.set("v.lastRecordNo", 100);
          component.set("v.data", dataList);

          if (component.get("v.pageName") === $A.get("$Label.c.AV_CDRP_Home")) {
            component.set("v.columns", [
              {
                label: "TASK ID",
                fieldName: "linkName",
                type: "url",
                typeAttributes: {
                  label: { fieldName: "name" },
                  target: "_blank"
                }
              },
              {
                label: "TASK CATEGORY",
                fieldName: "cdrpTaskCategory",
                type: "text"
              },
              {
                label: "DESCRIPTION",
                fieldName: "cdrpTaskDescription",
                type: "text"
              },
              {
                label: "PRIORITY",
                fieldName: "cdrpTaskPriority",
                type: "text"
              },
              {
                label: "DUE DATE",
                fieldName: "cdrpDueDate",
                type: "date-local"
              },
              {
                label: "RELATED STUDY",
                fieldName: "cdrpTaskRelatedStudy",
                type: "text"
              },
              { label: "STATUS", fieldName: "cdrpStatus", type: "text" },
            ]);
          } else {
            component.set("v.columns", [
              {
                label: "TASK ID",
                fieldName: "linkName",
                type: "url",
                typeAttributes: {
                  label: { fieldName: "name" },
                  target: "_blank"
                }
              },
              {
                label: "TASK CATEGORY",
                fieldName: "cdrpTaskCategory",
                type: "text"
              },
              {
                label: "DESCRIPTION",
                fieldName: "cdrpTaskDescription",
                type: "text"
              },
              {
                label: "PRIORITY",
                fieldName: "cdrpTaskPriority",
                type: "text"
              },
              {
                label: "DUE DATE",
                fieldName: "cdrpDueDate",
                type: "date-local"
              },
              {
                label: "RELATED IDRP",
                fieldName: "cdrpTaskRelatedIdrp",
                type: "text"
              },
              { label: "STATUS", fieldName: "cdrpStatus", type: "text" },
            ]);
          }
          component.set("v.Spinner", false);
        }
      } else if (state === "INCOMPLETE") {
        component.set("v.Spinner", false);
        helper.showToast(
          "ERROR",
          "ERROR",
          $A.get("$Label.c.AV_CDRP_ErrorMessage")
        );
      } else {
        component.set("v.Spinner", false);
        helper.showToast(
          "ERROR",
          "ERROR",
          $A.get("$Label.c.AV_CDRP_ErrorMessage")
        );
      }
    });
    $A.enqueueAction(action);
  },

  fetchObservationData: function(component, rows) {
    return new Promise(
      $A.getCallback(function(resolve, reject) {
        var resultData = component.get("v.completeList");
        if (resultData.length > 0) {
          var startPoint = component.get("v.lastRecordNo");
          var nextRecordsSize = component.get("v.lastRecordNo") + 100;
          component.set("v.lastRecordNo", nextRecordsSize);

          var dataList = [];
          for (var i = startPoint; i < nextRecordsSize; i++) {
            if (resultData[i] != null) {
              resultData[i].linkName = "/" + resultData[i].Id;
              if (resultData[i].AV_Age_from_creation_date__c != null) {
                resultData[i].AV_Age_from_creation_date__c = resultData[
                  i
                ].AV_Age_from_creation_date__c.toString();
              }

              dataList.push(resultData[i]);
            } else {
              break;
            }
          }

          resolve(dataList);
        }
      })
    );
  },

  fetchQueryData: function(component, rows) {
    return new Promise(
      $A.getCallback(function(resolve, reject) {
        var resultData = component.get("v.completeList");
        if (resultData.length > 0) {
          var startPoint = component.get("v.lastRecordNo");
          var nextRecordsSize = component.get("v.lastRecordNo") + 100;
          component.set("v.lastRecordNo", nextRecordsSize);

          var dataList = [];
          for (var i = startPoint; i < nextRecordsSize; i++) {
            if (resultData[i] != null) {
              resultData[i].linkName = "/" + resultData[i].Id;
              if (resultData[i].daysOpen != null) {
                resultData[i].daysOpen = resultData[i].daysOpen.toString();
              }

              dataList.push(resultData[i]);
            } else {
              break;
            }
          }

          resolve(dataList);
        }
      })
    );
  },

  fetchTaskData: function(component, rows) {
    return new Promise(
      $A.getCallback(function(resolve, reject) {
        var resultData = component.get("v.completeList");
        if (resultData.length > 0) {
          var startPoint = component.get("v.lastRecordNo");
          var nextRecordsSize = component.get("v.lastRecordNo") + 100;
          component.set("v.lastRecordNo", nextRecordsSize);

          var dataList = [];
          for (var i = startPoint; i < nextRecordsSize; i++) {
            if (resultData[i] != null) {
              resultData[i].linkName = "/" + resultData[i].Id;
              if (
                component.get("v.pageName") === $A.get("$Label.c.AV_CDRP_Home")
              ) {
                if (resultData[i].AV_CDRP_Related_Study_Name__c != null)
                  resultData[i].AV_CDRP_Related_Study =
                    resultData[i].AV_CDRP_Related_Study_Name__c;
              } else {
                if (resultData[i].AV_CDRP_Related_Study_Name__c != null)
                  resultData[i].cdrpTaskRelatedStudy =
                    resultData[i].cdrpTaskRelatedStudy;
              }

              dataList.push(resultData[i]);
            } else {
              break;
            }
          }

          resolve(dataList);
        }
      })
    );
  }
});