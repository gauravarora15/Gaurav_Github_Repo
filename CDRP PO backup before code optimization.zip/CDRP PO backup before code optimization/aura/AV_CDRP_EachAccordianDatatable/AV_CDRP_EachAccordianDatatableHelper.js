({
    getExpectedData : function(component) {
        
         if(component.get("v.data")!=undefined){
            component.set("v.recordPresent", true); 
            var completeList = component.get("v.data");
             for(var i=0;i<completeList.length;i++){
                 completeList[i].linkName = '/'+completeList[i].Id;
                 completeList[i].dataCategoryName = completeList[i].AV_CDRP_Data_Category_MDR__r.Name+'-'+completeList[i].AV_CDRP_Data_Trajectory__r.Name+'-'+completeList[i].Name;


                 if(completeList[i].AV_CDRP_Data_Category_MDR__r!=null){
                    completeList[i].Data_Category__c = completeList[i].AV_CDRP_Data_Category_MDR__r.Name;
                 } 
             }  
            
            component.set('v.columns', [
                {label: 'DATA CATEGORY NAME', fieldName: 'linkName', type: 'url',sortable:true, typeAttributes: {label: { fieldName: 'dataCategoryName' }, target: '_blank'}},
                {label: 'DATA CATEGORY', fieldName: 'Data_Category__c', type: 'text',sortable:true},
                {label: 'DATA SOURCE', fieldName: 'AV_CDRP_Data_Source__c', type: 'text',sortable:true},
                {label: 'Visit', fieldName: 'AV_CDRP_Applicable_Visits__c', type: 'text'},
                {label: 'DATA TRANSFER FREQUENCY', fieldName: 'AV_CDRP_Data_Transfer_Frequency__c', type: 'text',sortable:true},
                {label: 'CRITICAL DATA?', fieldName: 'AV_CDRP_Critical_Data__c', type: 'text',sortable:true},
                {label: 'Critical Data Rationale', fieldName: 'AV_CDRP_Critical_Data_Rationale__c', type: 'text',sortable:true},

                
            ]);
                }else{
                component.set('v.loadMoreStatus', 'No more data to load');
                
                }
                
                
        },
      
         getDataCheck : function(component) {     
           if(component.get("v.data")!=undefined){
            component.set("v.recordPresent", true); 
            var completeList = component.get("v.data");
             for(var i=0;i<completeList.length;i++){
                 completeList[i].linkName = '/'+completeList[i].Id;
                 if(completeList[i].AV_CDRP_Owner__r!=null){
                    completeList[i].OwnerName__c = completeList[i].AV_CDRP_Owner__r.Name;
                 } 
             }  
                component.set('v.columns', [
            {label: 'CHECK ID', fieldName: 'linkName', type: 'url',sortable:true, typeAttributes: {label: { fieldName: 'Name' }, target: '_blank'}},
            {label: 'PURPOSE', fieldName: 'AV_CDRP_Purpose__c', type: 'text',sortable:true},
            {label: 'METHOD', fieldName: 'AV_CDRP_Method__c', type: 'text',sortable:true},
            {label: 'DESCRIPTION', fieldName: 'AV_CDRP_Description__c', type: 'text'},
            {label: 'VISITS', fieldName: 'AV_CDRP_Applicable_Visits__c', type: 'text'},
            {label: 'ROLE', fieldName: 'AV_CDRP_Study_Role__c', type: 'text',sortable:true},
            {label: 'OWNER', fieldName: 'OwnerName__c', type: 'text',sortable:true},
            {label: 'FREQUENCY', fieldName: 'AV_CDRP_Frequency__c', type: 'text',sortable:true},
            {label: 'QUERY TEXT', fieldName: 'AV_CDRP_Query_Text__c', type: 'text'},
            {label: 'URL', fieldName: 'AV_CDRP_URL__c', type: 'text',sortable:true},
            {label: 'REVIEW COMMENT STATUS', fieldName: 'AV_CDRP_Review_Comment_Status__c', type: 'text',sortable:true}

        ]);
            }else{
               component.set('v.loadMoreStatus', 'No more data to load');

            }
    },
             
               
     sortData: function (cmp, fieldName, sortDirection) {
                var data = cmp.get("v.data");
                var reverse = sortDirection !== 'asc';
                //sorts the rows based on the column header that's clicked
                data.sort(this.sortBy(fieldName, reverse))
                cmp.set("v.data", data);
                },
               
     sortBy: function (field, reverse, primer) {
                var key = primer ?
                function(x) {return primer(x[field])} :
            function(x) {return x[field]};
        //checks if the two rows should switch places
        reverse = !reverse ? 1 : -1;
        return function (a, b) {
            return a = key(a), b = key(b), reverse * ((a > b) - (b > a));
        }
    },
    
    
    
})