({
	doInit : function(component, event, helper) {
        
        helper.onSearch(component, helper,"All");
		
	},
    
    onChange : function(component, event, helper) {
         var filter = component.find('select').get('v.value');

        helper.onSearch(component, helper, filter);
		
	},
    
    
    // this function automatic call by aura:waiting event  
    showSpinner: function(component, event, helper) {
       // make Spinner attribute true for display loading spinner 
       
        component.set("v.Spinner", true); 
   },
    
 // this function automatic call by aura:doneWaiting event 
    hideSpinner : function(component,event,helper){
     // make Spinner attribute to false for hide loading spinner    
       component.set("v.Spinner", false);
    },
    
    handleExpand: function(component, event, helper){
        helper.handleExpand(component, helper);
    },
    
    handleCollapse: function(component, event, helper){
      helper.handleCollapse(component, helper);  
    }
  
  
     
})