({
    doInit : function(component,event,helper) {
   
        if(component.get("v.querySourceSelectedIA") != null && component.get("v.querySourceSelectedIA") !='')
        {
        	component.find("querySource").set("v.value", 'LSH');
        	component.set("v.querySource", 'LSH');
			component.set("v.querySourceSelected",'LSH');
            if(component.get("v.dcidIA")!=null && component.get("v.dcnameIA")!=null)
        {
            var dcid = component.get("v.dcidIA");
            var dcname = component.get("v.dcnameIA");
             var defaultDC = {Id:dcid,Name:dcname};
            component.set("v.selectedDCRecords",defaultDC);
        }
        if(component.get("v.revstatusIA")!=null)
        {	var rsIA = component.get("v.revstatusIA");
            component.find("reviewStatus").set("v.value", rsIA);
        }
            
              var rowActions = helper.getTaskRowActions.bind(this, component);
            component.set('v.myColumns', [
                {label: 'Discrepency/Query ID', fieldName: 'queryId',  initialWidth: 100, type: 'url', 
                 cellAttributes: {class: {fieldName: 'ClassName'}},
                 typeAttributes: {label: { fieldName: 'Name' }, target: '_blank'},sortable:true}, 
                {label: 'Related IDRP', fieldName: 'relatedIDRP', initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                {label: 'Country', fieldName: 'country', initialWidth: 100,type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                {label: 'Investigator Name', fieldName: 'investigatorName',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                {label: 'Subject', fieldName: 'subject', initialWidth: 100,type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                {label: 'Visit', fieldName: 'visit',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                {label: 'Data Form', fieldName: 'dataForm', initialWidth: 100,type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                {label: 'Field Name', fieldName: 'dataFieldName',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                {label: 'Query Text', fieldName: 'queryText',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                {label: 'Discrepency/Query Status', fieldName: 'status',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                 {label: 'Related IDRP Check', fieldName: 'idrpCheck',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                {label: 'Days Open', fieldName: 'daysOpen',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}}, 
                {label: 'User Comments', fieldName: 'comment',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}}, 
                {label: 'Review Status', fieldName: 'reviewStatus',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
               
                { type: 'action', typeAttributes: { rowActions: rowActions } } 
                
            ]);
        }
		 if(component.get("v.pageReference")!=null && component.get("v.flag2")==='true'){
			component.set("v.flag2",'false');
       
        var myPageRef = component.get("v.pageReference");
		var firstname = myPageRef.state.c__recId;
        
		var studyName = myPageRef.state.c__nameStudy;
        var planId = myPageRef.state.c__planId;
        var plan = myPageRef.state.c__plan;
        
		var studyId = myPageRef.state.c__studyId;
		var operationName = myPageRef.state.c__operationName;
        
		var taskId = myPageRef.state.c__taskId;
         
		component.set("v.recordId", firstname);
		component.set("v.studyName", studyName);
        component.set("v.planId", planId);
        component.set("v.plan", plan);
		component.set("v.studyId", studyId);
		component.set("v.operationName", operationName);
		component.set("v.taskId", taskId);
        
        component.set("v.totalRecords", 0);
        component.set("v.pageNumber", 0);
        component.set("v.endPage", 0);
        component.set("v.startPage", 0);
        var IDRP = {Id:component.get("v.planId"),Name:component.get("v.plan")};
        
        if(operationName == $A.get("$Label.c.AV_CDRP_Add_Query_Action")){
            component.set("v.selectedIDRPRecords",IDRP);
        }
		 }
		 
        if(component.get("v.flag1")==='true')
           
        { 
            component.set("v.flag1", 'false');
        if(component.get("v.studyDPI")!=null){
            var abc = component.get("v.studyDPI");
           component.set("v.selectedIDRPRecords", abc);
            
        }
         if(component.get("v.studyIA")!=null){
            //var studyIA = component.get("v.studyIA");
			var idrpnameIA = component.get("v.idrpnameIA");
            var defaultIDRP = {Id:component.get("v.studyIA"),Name:idrpnameIA};
			  component.set("v.selectedIDRPRecords",defaultIDRP);
			  
            //component.set("v.selectedIDRPRecords", studyIA);
            
        }
        
         if(component.get("v.subjectDPI")!=null){
            var hij = component.get("v.subjectDPI");
            component.set("v.subject", hij);
            
        }
        
        if(component.get("v.idrpCheckDPI")!=null){
            var def = component.get("v.idrpCheckDPI");
            component.set("v.selectedCheckRecords", def);
            
        }
        if(component.get("v.idrpCheckIA")!=null){
            var ghi = component.get("v.idrpCheckIA");
            component.set("v.selectedCheckRecords", ghi);
            
        }
		}
        var idrp = component.get("v.selectedIDRPRecords");
          var myMap;
                for(var i=0;i<idrp.length;i++){
                    if(myMap!=null){
                    myMap = myMap + ',' + idrp[i].Id ;
                  
                    } else{
                        myMap = idrp[i].Id ; 
                    }
                }
        
        component.set("v.searchDCRecords", {'AV_CDRP_IDRP_Data_Category__c.AV_CDRP_Related_IDRP__c':myMap});
         component.set("v.searchRoleRecords", {'AV_CDRP_Plan_Role__c.AV_CDRP_Data_Review_Plan__c':myMap});
        
        
        var action = component.get("c.getDataOnLoad"); 
        var qstatus=[];
         var qstatusL=[];
          var countryE=[];
         var countryEX=[];
         var countryL=[];
          var countryLM=[];
           var siteNameL=[];
          var siteNameM=[];
         var siteNameE=[];
          var siteNameX=[];
         var mGroup=[];
         var mGroupX=[];
        
        action.setParams({
            "drp" : component.get("v.selectedIDRPRecords")
        });
        action.setCallback(this,function(response){
        
            var resp = response.getReturnValue();
               
            if (response.getState() == "SUCCESS") { 
              
              
                
                
                
                for(var i=0; i<resp.queryStatusValEDC.length; i++)
                {
                    var Option = {};
                    Option.Name = resp.queryStatusValEDC[i];
                    Option.isSelected = false;
                    Option.Id = resp.queryStatusValEDC[i];
                    qstatus.push(Option);
                }
                
                component.set("v.queryStatusListEDC",qstatus);
                 
                for(var i=0; i<resp.countryEDC.length; i++)
                {
                    var Option = {};
                    Option.Name = resp.countryEDC[i];
                    Option.isSelected = false;
                    Option.Id = resp.countryEDC[i];
                    countryE.push(Option);
                }
                
                component.set("v.countryEDCSet",countryE);
                 for(var i=0; i<resp.countryX.length; i++)
                {
                    var Option = {};
                    Option.Name = resp.countryX[i];
                    Option.isSelected = false;
                    Option.Id = resp.countryX[i];
                    countryEX.push(Option);
                }
                
                component.set("v.countryXSet",countryEX);
                for(var i=0; i<resp.countryLSH.length; i++)
                {
                    var Option = {};
                    Option.Name = resp.countryLSH[i];
                    Option.isSelected = false;
                    Option.Id = resp.countryLSH[i];
                    countryL.push(Option);
                }
                
                component.set("v.countryLSHSet",countryL);
                for(var i=0; i<resp.countryM.length; i++)
                {
                    var Option = {};
                    Option.Name = resp.countryM[i];
                    Option.isSelected = false;
                    Option.Id = resp.countryM[i];
                    countryLM.push(Option);
                }
                
                component.set("v.countryMSet",countryLM);
                for(var i=0; i<resp.investigatorNameEDC.length; i++)
                {
                    var Option = {};
                    Option.Name = resp.investigatorNameEDC[i];
                    Option.isSelected = false;
                    Option.Id = resp.investigatorNameEDC[i];
                    siteNameE.push(Option);
                }
                
                component.set("v.investigatorNameEDCSet",siteNameE);
                 for(var i=0; i<resp.investigatorNameX.length; i++)
                {
                    var Option = {};
                    Option.Name = resp.investigatorNameX[i];
                    Option.isSelected = false;
                    Option.Id = resp.investigatorNameX[i];
                    siteNameX.push(Option);
                }
                
                component.set("v.investigatorNameXSet",siteNameX);
                 for(var i=0; i<resp.investigatorNameLSH.length; i++)
                {
                    var Option = {};
                    Option.Name = resp.investigatorNameLSH[i];
                    Option.isSelected = false;
                    Option.Id = resp.investigatorNameLSH[i];
                    siteNameL.push(Option);
                }
                
                component.set("v.investigatorNameLSHSet",siteNameL);
                for(var i=0; i<resp.investigatorNameM.length; i++)
                {
                    var Option = {};
                    Option.Name = resp.investigatorNameM[i];
                    Option.isSelected = false;
                    Option.Id = resp.investigatorNameM[i];
                    siteNameM.push(Option);
                }
                
                component.set("v.investigatorNameMSet",siteNameM);
                  for(var i=0; i<resp.markingGroup.length; i++)
                {
                    var Option = {};
                    Option.Name = resp.markingGroup[i];
                    Option.isSelected = false;
                    Option.Id = resp.markingGroup[i];
                    mGroup.push(Option);
                }
                
                component.set("v.markingGroupSet",mGroup);
                for(var i=0; i<resp.markingGroupX.length; i++)
                {
                    var Option = {};
                    Option.Name = resp.markingGroupX[i];
                    Option.isSelected = false;
                    Option.Id = resp.markingGroupX[i];
                    mGroupX.push(Option);
                }
                
                component.set("v.markingGroupXSet",mGroupX);
                for(var i=0; i<resp.queryStatusValLSH.length; i++)
                {
                    var Option = {};
                    Option.Name = resp.queryStatusValLSH[i];
                    
                    if(component.get("v.dcidIA")!=null && resp.queryStatusValLSH[i]==='Unreviewed' && !component.get("v.notSelectStatus")){
                       Option.isSelected =true;
                    }
                    else{
                    	Option.isSelected = false;
                    }                    
                    Option.Id = resp.queryStatusValLSH[i];
                    qstatusL.push(Option);
                }
                
                component.set("v.queryStatusListLSH",qstatusL);
                  var myMapSV;
                
                for(var i=0;i<resp.studyIds.length;i++){
                    if(myMapSV!=null){
                    
                    myMapSV = myMapSV + ',' + resp.studyIds[i] ;
                      
                    } else{
                       
                        myMapSV = resp.studyIds[i]; 
                        
                    }
                }
                 component.set("v.searchSVRecords", {'AV_CDRP_Study_Visit__c.AV_CDRP_Study__c' :myMapSV});
            
             
         component.set("v.querySourceSelectedIA",'');
            }
              
        });
        $A.enqueueAction(action);
          
    },
    // Event Method to handle the Multiseelect Picklist values
    handleMultiSelect: function (component, event, helper) {
      
        
            var qStatus = event.getParam("optionIds");
            var selectedCatIds;
            for (var i in qStatus) {
                if (i == 0) {
                    selectedCatIds = qStatus[i];
                } else {
                    if (selectedCatIds.indexOf(qStatus[i]) === -1) {
                        selectedCatIds = selectedCatIds + ',' + qStatus[i];
                    }
                }
            }
        if (event.getSource().get("v.multiselectLabel") == "Discrepancy/Query Status") {
            component.set("v.searchParameters.AV_CDRP_Query_Status__c", selectedCatIds);  
           
        }else if(event.getSource().get("v.multiselectLabel") == "Country"){
            component.set("v.searchParameters.AV_CDRP_Country__c", selectedCatIds);  
           
        } else if(event.getSource().get("v.multiselectLabel") == "Site Name"){
                  component.set("v.searchParameters.AV_CDRP_Site_Name__c", selectedCatIds);
        } else if(event.getSource().get("v.multiselectLabel") == "Investigator Name"){
                   component.set("v.InvestigatorNames", selectedCatIds);
        }
         else if(event.getSource().get("v.multiselectLabel") == "Marking Group"){
               component.set("v.searchParameters.AV_CDRP_Marking_Group_Name__c", selectedCatIds);  
        }
    },
	 handleLookupSelect: function (component, event, helper) {
       helper.doInit(component, event, helper);
    },
    //Clear lookup
	clearLookup : function (component, event, helper) {   
        var appEvent = $A.get("e.c:AV_CDRP_GenericLookupClearEvent"); 
        // set the Selected sObject Record to the event attribute.  
        //appEvent.setParams({"action" : "clear" }); 
        appEvent.setParams({ "action" : "clear" });
 
        // fire the event  
        appEvent.fire(); 
    },

    getListOfIds : function(component, event, helper,compareList){
        var currentDCList=[];
        if(compareList!=null && compareList.length>0){
            for(var i=0; i<compareList.length; i++){
               
                currentDCList.push(compareList[i].Id);
            }
        component.set("v.comparisonList",currentDCList);
        }
    },
    
    
    
    clearAll : function(component,event,helper) {
         //Clearing functionality for fields which are not prepopulated from any route::
         if( component.get("v.querySourceSelected") == "LSH" || component.get("v.querySourceSelected") == "Manual")
        { 
                       
            component.find("visitlsh").set("v.value",'');      
            component.find("dataformlsh").set("v.value",'');           
            component.find("datafieldlsh").set("v.value",'');  
            component.find("fromdatelsh").set("v.value",'');
            component.find("todatelsh").set("v.value",'');
            component.set("v.selectedCheckRecords",[]);
            if(component.get("v.querySourceSelected") == "LSH")
            {
                 component.set("v.countryLSHSet",'');
                 component.set("v.investigatorNameLSHSet",'');
            }
            else
            {//if component.get("v.querySourceSelected") == "Manual"
                component.set("v.countryMSet",'');             
            	component.set("v.investigatorNameMSet",''); 
            }
            
         }
        else if (component.get("v.querySourceSelected") == "Rave" || component.get("v.querySourceSelected") == "RaveX")
        {
           
            component.find("dataformedc").set("v.value",''); //EDC
            component.find("datafieldedc").set("v.value",''); //EDC
            component.find("createdby").set("v.value",'');
            component.find("fromdateedc").set("v.value",'');
            component.find("todateedc").set("v.value",'');
            component.find("createdby").set("v.value",'');                       
            component.set("v.selectedVisitRecords",[]);                        
            component.set("v.queryStatusListEDC",[]);
            if(component.get("v.querySourceSelected") == "Rave")
            {
                component.find("markingGroup").set("v.value",'');
                component.find("countryedc").set("v.value",'');
                component.find("investigatorNameEDC").set("v.value",'');
            }
            else 
            {//if(component.get("v.querySourceSelected") == "RaveX")
              component.find("countryX").set("v.value",'');
              component.find("investigatorNameX").set("v.value",'');
              component.find("markingGroupX").set("v.value",'');  
            }
        }
       //  Clearing Source for All routes 
       
            component.find("querySource").set("v.value","Select One");
            component.set("v.querySourceSelected","Select One");
            component.set("v.querySource","Select One");
       
        
        //INACTION Larger Route
              
        if(component.get("v.dcidIA")!=null && component.get("v.dcnameIA")!=null)
        {
            

                
                //Query Status
                  component.find("qstatuslsh").set("v.value",'');
                    component.set("v.notSelectStatus","true");
                
               
                 //Review Status
                component.find("reviewStatus").set("v.value","None");
                
                //Role
                component.set("v.selectedRoleRecords",[]);
                           
                //IDRP Check
                component.set("v.selectedCheckRecords",[]);
               //Data Category     
                component.set("v.selectedDCRecords",[]);
             
            
        }
        //CLEAR SUBJECT FOR ALL ROUTES
       component.find("subjectID").set("v.value",'');
 
        component.set("v.displayTable", false);
        component.set("v.errorDisplay",false);
        //DPI prepopulated attributes
        if(component.get("v.subjectDPI")!=null)
        {
        	component.set("v.queryStatusListLSH",[]);
            component.set("v.reviewStatus",'None');
                
            //DPI : IDRP Check
            component.set("v.selectedCheckRecords",[]);
            //Data Category
            component.set("v.selectedDCRecords",[]);
            //Role
            component.set("v.selectedRoleRecords",[]);
        }
        //helper.clearLookup(component,event,helper);
       // helper.doInit(component,event,helper);
       if(component.get("v.studyIA")!=null){
            //var studyIA = component.get("v.studyIA");
			var idrpnameIA = component.get("v.idrpnameIA");
            var defaultIDRP = {Id:component.get("v.studyIA"),Name:idrpnameIA};
			  component.set("v.selectedIDRPRecords",defaultIDRP);
			  
            //component.set("v.selectedIDRPRecords", studyIA);
            
        }
         if(component.get("v.studyDPI")!=null){
            var abc = component.get("v.studyDPI");
            console.log('abc::'+abc);
           component.set("v.selectedIDRPRecords", abc);
            
        }
        
    },

    handleSearch : function(component,event,helper) {
        
        let button = event.getSource();
		button.set('v.disabled',true);
        component.set('v.lstQueryPagination',[]);
        component.set('v.lstQuery',[]);
        component.set("v.totalRecords", 0);
        component.set("v.selectedQueryList", []);
      
        component.set("v.messageText",'');
        component.set("v.errorDisplay", false);
       // var querySource = component.find("v.querySource");
        var querySource = component.find("querySource").get("v.value");    
        if(querySource === 'Select One')
        {  
            component.set("v.messageType", 'error');
            component.set("v.messageText", $A.get("$Label.c.AV_CDRP_Select_Query_Source_Error_Message"));        
            component.set("v.errorDisplay", true);
            button.set('v.disabled',false);
        }else{
            //var querySource = component.find("querySource").get("v.value");
           
          
            component.set("v.searchParameters.AV_CDRP_Subject_Name__c",component.find("subjectID").get("v.value"));
         
            if(querySource === 'Rave' || querySource === 'RaveX')
            { 
               
                component.set("v.searchParameters.AV_CDRP_Data_Form__c",component.find("dataformedc").get("v.value"));                
                component.set("v.searchParameters.AV_CDRP_Data_Field_Name__c",component.find("datafieldedc").get("v.value"));
               
               component.set("v.searchParameters.AV_CDRP_Created_By__c",component.find("createdby").get("v.value"));
                
                
            
                 var fromdate = '';
				if(component.find("fromdateedc").get("v.value")!=null){
                fromdate = component.find("fromdateedc").get("v.value"); 
				}				
                var todate = '';
				if( component.find("todateedc").get("v.value")!=null){
                todate = component.find("todateedc").get("v.value");  
				}				           
            }
            else if( querySource === 'LSH' || querySource === 'Manual')
            {                
                     
                component.set("v.searchParameters.AV_CDRP_Visit__c",component.find("visitlsh").get("v.value"));                
                 component.set("v.searchParameters.AV_CDRP_Data_Form__c",component.find("dataformlsh").get("v.value"));                
                component.set("v.searchParameters.AV_CDRP_Data_Field_Name__c",component.find("datafieldlsh").get("v.value"));
                
                //review status
                var reviewStatus = component.find("reviewStatus").get("v.value");  
                component.set("v.searchParameters.AV_CDRP_Review_Status__c", reviewStatus);
                //from date 
                var fromdate = '';
                if(component.find("fromdatelsh").get("v.value")!=null){
                fromdate = component.find("fromdatelsh").get("v.value");  
				}				
                //to date
                var todate ='';
				if(component.find("todatelsh").get("v.value")!=null){
                todate= component.find("todatelsh").get("v.value");
				}
            }
            
           
            var selectedFilters = JSON.stringify(component.get("v.searchParameters"));
             var taskId = '';
            if(component.get("v.operationName") == $A.get("$Label.c.AV_CDRP_Add_Query_Action")){
                taskId = component.get("v.taskId");}
            //alert("selectedFilers" +selectedFilters);
            //alert("source" +querySource);
            //alert("selectedIDRP" +JSON.stringify(component.get("v.selectedIDRPRecords")));
            var action = component.get("c.searchQueries");
           
            action.setParams({
                "searchFilters": selectedFilters,
                "fromDate"     : fromdate,
                "toDate"	   : todate,
                "idrp"		   : component.get("v.selectedIDRPRecords"),
                "dataC"		   : component.get("v.selectedCheckRecords"),
                "dc"		   : component.get("v.selectedDCRecords"),
                "role"         : component.get("v.selectedRoleRecords"),
                "visit"        : component.get("v.selectedVisitRecords"),
                "source"   : querySource,
                "taskId"	:	taskId,
                "investigatorNames"  :  component.get("v.InvestigatorNames")
                
            });
            action.setCallback(this,function(response){
               // let button = event.getSource();
			    button.set('v.disabled',false);
               
                if (response.getState() == "SUCCESS") { 
                    
                    var resp = response.getReturnValue();
                    var operationName = component.get("v.operationName");
                    if(operationName == $A.get("$Label.c.AV_CDRP_Add_Query_Action")){
                        component.set("v.hideCheckbox", false);

                    }else{
                        component.set("v.hideCheckbox", true);
                    }
                    if(resp[0].errorMssg !="")
                    {
                       //alert('errormessage @@@@@ '+ resp[0].errorMssg + resp[0]);
                          component.set("v.displayTable", false);
                        component.set("v.messageText", resp[0].errorMssg);
                        component.set("v.messageType", 'error');
                        component.set("v.errorDisplay",true);
                    }
                    else{
                        component.set("v.displayTable", true);
                   var pageSize = component.get("v.pageSize");
                 
                    component.set("v.startPage", 0);
                    component.set("v.endPage", pageSize);
                    component.set("v.pageNumber", 1);
                 
                    
                    component.set("v.totalRecords", resp.length);
                    for(var i=0; i<resp.length; i++){
                      
                        var data={
                            queryId: '/' + resp[i].QueryName.Id,
                            Name: resp[i].QueryID,
                           // study : resp[i].Study,
                            relatedIDRP : resp[i].RelatedIDRP,
                            instanceName : resp[i].InstanceName,
                            markingGroup : resp[i].MarkingGroup,
                            resolvedDate : resp[i].ResolvedDate,
                            country: resp[i].Country,
                            site : resp[i].SiteName,
                            investigatorName : resp[i].InvestigatorName,
                            visit : resp[i].Visit,
                            subject :resp[i].Subject,
                            queryText : resp[i].Querytext,
                            status : resp[i].QueryStatus,
                            dataCategory : resp[i].DataCategory,
                            daysOpen : resp[i].DaysOpen,
                            createdBy : resp[i].CreatedBy , 
                            updatedDate: resp[i].UpdatedDate , 
                            comment : resp[i].UserComments , 
                            reviewStatus : resp[i].ReviewStatus,
                            dataForm :resp[i].DataForm , 
                            dataField : resp[i].DataField , 
                            dataFieldName : resp[i].DataFieldName,
                            createdDate : resp[i].CreatedDate , 
                            answeredDate: resp[i].AnsweredDate , 
                            answerText : resp[i].AnswerText,
                            Id : resp[i].recordId,
                            Studyvisit : resp[i].Studyvisit,
                            idrpCheck :resp[i].RelatedIDRPCheck,
                            isSelected : resp[i].isSelected,
                            isFollowed : resp[i].isFollowed
                        };
                       
                        
                       /* if(querySource == 'LSH'){
                            data={   
                                
                                createdBy : resp[i].CreatedBy , 
                                updatedDate: resp[i].UpdatedDate , 
                                comment : resp[i].UserComments , 
                                reviewStatus : resp[i].ReviewStatus
                                
                            };
                         
                        }else if(querySource == 'EDC'){
                            data={
                                    dataForm :resp[i].DataForm , 
                                    dataField : resp[i].DataField , 
                                    createdDate : resp[i].CreatedDate , 
                                    answeredDate: resp[i].AnsweredDate , 
                                    answerText : resp[i].AnswerText                                
                                };                            
                        }*/
                        var currentData = component.get("v.lstQuery");
                            var newData = currentData.concat(data);
                         
                            component.set("v.lstQuery", newData); 
                          
                        
                    }
                    var completeList =  component.get("v.lstQuery");
                       
                        var objList = [];
                    for (var j = 0; j < completeList.length; j++) {
                        var obj = {};
                        obj = completeList[j];
                       
                        if (completeList[j].isSelected && operationName == $A.get("$Label.c.AV_CDRP_Add_Query_Action")) {
                            obj.ClassName = "table-rowColor";
                           
                        } else {
                            obj.ClassName = "";
                        }
                        objList.push(obj);
                    }
                    
                    var paginationList = [];
                    for (var i =0; i < pageSize; i++) {
                        if (objList.length>i)
                            paginationList.push(objList[i]);
                    }
                    component.set('v.lstQueryPagination', paginationList);
                     component.set('v.rawData', paginationList);

                    
                    
                }
            }  
                
            });
            $A.enqueueAction(action);
            
        }
    },
    handleQuerySourceChange : function(component,event,helper) {
        var querySource = event.getSource().get("v.value");
        component.set("v.querySourceSelected",querySource);
       
            component.set("v.displayTable", false);
            
        
        component.set("v.errorDisplay", false); 
        var rowActions = helper.getTaskRowActions.bind(this, component);
            
       
        //var source = component.find("querySource").get("v.value");
       
        component.set("v.querySource",querySource);
        if(querySource=='LSH' || querySource == 'Manual'){
            component.set('v.myColumns', [
                {label: 'Discrepency/Query ID', fieldName: 'queryId',  initialWidth: 100, type: 'url', 
                 cellAttributes: {class: {fieldName: 'ClassName'}},
                 typeAttributes: {label: { fieldName: 'Name' }, target: '_blank'},sortable:true}, 
                {label: 'Related IDRP', fieldName: 'relatedIDRP', initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                {label: 'Country', fieldName: 'country', initialWidth: 100,type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                {label: 'Investigator Name', fieldName: 'investigatorName',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                {label: 'Subject', fieldName: 'subject', initialWidth: 100,type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                {label: 'Visit', fieldName: 'visit',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                {label: 'Data Form', fieldName: 'dataForm', initialWidth: 100,type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                {label: 'Field Name', fieldName: 'dataFieldName',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                {label: 'Query Text', fieldName: 'queryText',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                {label: 'Discrepency/Query Status', fieldName: 'status',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                 {label: 'Related IDRP Check', fieldName: 'idrpCheck',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                {label: 'Days Open', fieldName: 'daysOpen',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}}, 
                {label: 'User Comments', fieldName: 'comment',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}}, 
                {label: 'Review Status', fieldName: 'reviewStatus',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
               
                { type: 'action', typeAttributes: { rowActions: rowActions } } 
                
            ]);}else if(querySource == 'Rave' || querySource == 'RaveX' ){
                component.set('v.myColumns', [
                    {label: 'Discrepancy/Query ID', fieldName: 'queryId', initialWidth: 100, type: 'url',sortable:true,
                     cellAttributes: {class: {fieldName: 'ClassName'}},
                 	typeAttributes: {label: { fieldName: 'Name' }, target: '_blank'}}, 
                    {label: 'Related IDRP', fieldName: 'relatedIDRP', initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                    {label: 'Country', fieldName: 'country', initialWidth: 100,type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                    {label: 'Site Name', fieldName: 'site',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                     {label: 'Subject', fieldName: 'subject', initialWidth: 100,type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                    {label: 'Study Visit', fieldName: 'Studyvisit',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                    {label: 'Instance Name', fieldName: 'instanceName', initialWidth: 100,type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                    {label: 'Data Form', fieldName: 'dataForm', initialWidth: 100,type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                    {label: 'Field Name', fieldName: 'dataFieldName',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                    {label: 'Query Text', fieldName: 'queryText',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                    {label: 'Discrepancy/Query Status', fieldName: 'status',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                    {label: 'Marking Group', fieldName: 'markingGroup', initialWidth: 100,type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                    {label: 'Days Open', fieldName: 'daysOpen',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}}, 
                    {label: 'Created By', fieldName: 'createdBy', initialWidth: 100,type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                    {label: 'Created Date', fieldName: 'createdDate', initialWidth: 100,type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}}, 
                    {label: 'Answered Date', fieldName: 'answeredDate', initialWidth: 100,type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}}, 
                    {label: 'Resolved Date', fieldName: 'resolvedDate', initialWidth: 100,type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                    {label: 'Answer text', fieldName: 'answerText',initialWidth: 100, type: 'text',sortable:true,cellAttributes: {class: {fieldName: 'ClassName'}}},
                    { type: 'action', typeAttributes: { rowActions: rowActions } }
                    
                    
                    
                ]);}
        // Once User changes option from 'Select One', error message should disappear
    },
    //Method for sorting the each columnn
    handleSort: function (component, event, helper) {
        component.set('v.Spinner', true);
        // We use the setTimeout method here to simulate the async
        // process of the sorting data, so that user will see the
        // spinner loading when the data is being sorted.
        setTimeout(function () {
            var fieldName = event.getParam('fieldName');
            var sortDirection = event.getParam('sortDirection');
            component.set("v.sortedBy", fieldName);
            component.set("v.sortedDirection", sortDirection);
            helper.sortData(component, helper, fieldName, sortDirection);
            component.set('v.Spinner', false);
        }, 0);
    },
    sortData: function (component, helper, fieldName, sortDirection) {
        var data = component.get("v.lstQueryPagination");
        var reverse = sortDirection !== 'asc';
        
        data = Object.assign([],
                             data.sort(this.sortBy(fieldName, reverse ? -1 : 1))
                            );
        component.set("v.lstQueryPagination", data);
    },
    sortBy: function (field, reverse, primer) {
        var key = primer ?
            function (x) {
                return primer(x[field])
            } :
        function (x) {
            return x[field]
        };
        return function (a, b) {
            var A = key(a);
            var B = key(b);
            return reverse * ((A > B) - (B > A));
        };
    },
    
    //Handle the Previous Button Pagination
    handlePrevious: function (component, event, helper) {
        component.set("v.messageText", '');
component.set("v.messageType", '');
         component.set("v.errorDisplay", false);
        component.set("v.Spinner", true);
        var sObjectList = component.get("v.lstQuery");
        var end = component.get("v.endPage");
        var start = component.get("v.startPage");
        var pageSize = component.get("v.pageSize");
        var previousPageNumber = component.get("v.pageNumber") - 1;
        component.set("v.pageNumber", previousPageNumber);
        var paginationList = [];
        var counter = 0;
        for (var i = start - pageSize; i < start; i++) {
            if (i > -1) {
                paginationList.push(sObjectList[i]);
                counter++;
            } else {
                start++;
            }
        }
        start = start - counter;
        end = end - counter;
        component.set("v.startPage", start);
        component.set("v.endPage", end);
        component.set("v.lstQueryPagination", []);
        component.set("v.lstQueryPagination", paginationList);
        component.set("v.rawData",paginationList);
        component.set("v.Spinner", false);
        document.getElementsByClassName('slds-modal__content slds-p--around-medium')[0].scrollTop=0;
    },
    
    // Handle the Next button Pagination
    handleNext: function (component, event, helper) {
         component.set("v.messageText",'');
          component.set("v.messageType", '');
         component.set("v.errorDisplay", false);
        component.set("v.Spinner", true);
        var sObjectList = component.get("v.lstQuery");
        var end = component.get("v.endPage");
        var start = component.get("v.startPage");
        console.log('$$$$$$$ START PAGE: ' + start);
        console.log('$$$$$$$ END PAGE: ' + end);
        var pageSize = component.get("v.pageSize");
        var pageNumber = end / pageSize;
        var nextPageNumber = component.get("v.pageNumber") + 1;
        component.set("v.pageNumber", nextPageNumber);
        console.log('$$$$$$$ PAGE NUMBER: ' + pageNumber);
        var paginationList = [];
        var counter = 0;
        for (var i = end; i < end + pageSize; i++) {
            if (sObjectList.length > i) {
                paginationList.push(sObjectList[i]);
            }
            counter++;
        }
        start = start + counter;
        end = end + counter;
        component.set("v.startPage", start);
        component.set("v.endPage", end);
        component.set("v.lstQueryPagination", []);
        component.set('v.lstQueryPagination', paginationList);
        component.set("v.rawData",paginationList);
        component.set("v.Spinner", false);
        document.getElementsByClassName('slds-modal__content slds-p--around-medium')[0].scrollTop=0;
    },
     followRecord: function (cmp,event, helper, row) {
        var rows = cmp.get('v.rawData');
        var rowIndex = rows.indexOf(row);
        //var recordId = component.get("v.recordId");
        var action=cmp.get("c.setFollowRecord");
        action.setParams({
            "recordId" : rows[rowIndex]['Id'],
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS")
            {
                rows[rowIndex]['isFollowed'] = true;
              

            }
            else if(state === "ERROR")
            {
            
            }
        });
        $A.enqueueAction(action);
    },
    unFollowRecord: function (cmp,event, helper, row) {
        var rows = cmp.get('v.rawData');
        var rowIndex = rows.indexOf(row);
        //var recordId = component.get("v.recordId");
        var action=cmp.get("c.setUnFollowRecord");
        action.setParams({
            "recordId" : rows[rowIndex]['Id'],
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS")
            {
                rows[rowIndex]['isFollowed'] = false;
               
            }
            else if(state === "ERROR")
            {
               
            }
        });
        $A.enqueueAction(action);
    },
    
     handleRowAction : function(component, event, helper){
          component.set("v.messageText",'');
          component.set("v.messageType", '');
         component.set("v.errorDisplay", false);
        var action = event.getParam('action');
                var row = event.getParam('row');
              
                switch (action.name) {
                      
                      
                    case 'follow':
                    helper.followRecord(component, event, helper, row);
                    component.set("v.messageType", 'confirm');
            component.set("v.messageText", $A.get("$Label.c.AV_CDRP_FollowSuccess"));        
            component.set("v.errorDisplay", true);
               document.getElementsByClassName('slds-modal__content slds-p--around-medium')[0].scrollTop=0;           
                    break;
                   
                    case 'unfollow':
                    helper.unFollowRecord(component, event, helper, row);
                         component.set("v.messageType", 'confirm');
            component.set("v.messageText", $A.get("$Label.c.AV_CDRP_UnFollowSuccess"));        
            component.set("v.errorDisplay", true);
                          document.getElementsByClassName('slds-modal__content slds-p--around-medium')[0].scrollTop=0;
                    break;    
                }
              
     },
                
                    
                    
                    
                    getTaskRowActions: function (component, row, doneCallback) {
                        
                        var actions = [];
                        
                        
                        if (row['isFollowed']) {
                            actions.push({
                                'label': 'Unfollow',
                               // 'iconName': 'utility:ban',
                                'name': 'unfollow'
                            });
                        } else {
                            actions.push({
                                'label': 'Follow',
                               // 'iconName': 'utility:approval',
                                'name': 'follow'
                            });
                        }
                            // simulate a trip to the server
                            setTimeout($A.getCallback(function () {
                            doneCallback(actions);
                            }), 200);
                  
},
    userSelect: function (component, event, helper) {
        var key = event.getSource().getLocalId();
        if (key === 'addCon' || key === 'addExit') {
            helper.handleAddCon(component, event, helper, key);
        } 
    },
    handleRowsSelection: function (component, event, helper) {
	var selectedRows = event.getParam('selectedRows');
       
	component.set("v.selectedQueryList", selectedRows);
},

    handleAddCon: function (component, event, helper, key) {
        
        component.set("v.messageText", '');
        component.set("v.Spinner", true);
        var taskId = '';
        if(!$A.util.isEmpty(component.get("v.taskId")) || !$A.util.isUndefinedOrNull(component.get("v.taskId"))){
           taskId = component.get("v.taskId"); 
        }

        var action = component.get("c.queryCreation");
        action.setParams({
            "response": JSON.stringify(component.get("v.selectedQueryList")),
            "source" :component.get("v.querySource"),
            "taskId" : component.get("v.taskId")
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            
            if (state === "SUCCESS") {
                var resp = response.getReturnValue();
               // alert(resp);
                if ($A.util.isEmpty(resp) || $A.util.isUndefinedOrNull(resp)) {
                        if (key === 'addCon') {
                        var selectedQueries = component.get("v.selectedQueryList");

                        if (component.get("v.selectedQueryList").length !=0){
                            var queryList = [];
                            for (var i = 0; i < selectedQueries.length; i++) {
                                queryList.push(selectedQueries[i].Id);
                            }
                            var totalList = component.get("v.lstQueryPagination");

                            for (var i = 0; i < totalList.length; i++) {
                                if (queryList.indexOf(totalList[i].Id) !== -1) {
                                    totalList[i].ClassName = "table-rowColor";
                                }

                        }

                            component.set("v.lstQueryPagination", totalList);
                             component.set("v.errorDisplay",true);
                            component.set("v.messageText", $A.get("$Label.c.AV_CDRP_Associated_Risk_Success_Message"));
                            component.set("v.messageType", 'confirm');
                        }else{
                            component.set("v.messageText", '');
                            component.set("v.messageType", '');
							component.set("v.errorDisplay",false);

                        }
                        

                    } else if (key === 'addExit') {
                        if (component.get("v.selectedQueryList").length !=0){
                            helper.showToast('SUCCESS', 'SUCCESS', $A.get("$Label.c.AV_CDRP_Associated_Risk_Success_Message"));
                        }else{
                            component.set("v.messageText", '');
                            component.set("v.messageType", '');
                        }
                       // window.history.back();
                       window.location.assign('/'+component.get("v.taskId"));
                    }

                   
                    


                } else {
                    if (key === 'addCon' || key === 'addExit') {
                        component.set("v.errorDisplay",true);
                        component.set("v.messageText", resp);
                        component.set("v.messageType", 'error');
                    }
                }
            } else if (state === "ERROR") {
                helper.showToast('ERROR', 'ERROR', $A.get("$Label.c.AV_CDRP_ErrorMessage"));
            }
            component.set("v.Spinner", false);
        });
        $A.enqueueAction(action);

    },
    showToast: function (toastTitle, toastType, toastMessage) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": toastTitle,
            "type": toastType,
            "message": toastMessage
        });
        toastEvent.fire();
    }
                          
     
        
    
})