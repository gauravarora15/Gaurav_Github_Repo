({
  taskBuildDatatable: function(component, event, helper) {
    component.set("v.Spinner", true);
    var userId = $A.get("$SObjectType.CurrentUser.Id");
    var relatedIdrp = "";
    if (component.get("v.PageName") !== $A.get("$Label.c.AV_CDRP_Home")) {
      relatedIdrp = component.get("v.recordId");
    }
    var pageName = component.get("v.PageName");
    //re-initialize
    var completeList = [];
    component.set("v.rowSection", false);
    component.set("v.showSection", false);
    component.set("v.completeList", completeList);
    component.set("v.rawData", completeList);
    component.set("v.totalRecords", 0);
    component.set("v.startPage", 0);
    component.set("v.endPage", 0);
    var paginationList = [];
    component.set("v.paginationList", paginationList);
    component.set("v.SectionSize", 0);

    helper.callServer(
      component,
      "c.getTotalTaskCount",
      function(response) {
        component.set("v.SectionSize", response);
        var rowActions = helper.getTaskRowActions.bind(this, component);
        if (component.get("v.SectionSize") > 0) {
          component.set("v.showSection", true);
          var action = component.get("c.getTaskRecords");
          action.setParams({
            userId: userId,
            relatedIdrp: relatedIdrp
          });
          action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
              var response = response.getReturnValue();
              if (response.length > 0) {
                component.set("v.rowSection", true);
                var pageSize = component.get("v.pageSize");
                var completeList = response;
                component.set("v.completeList", completeList);
                component.set("v.rawData", completeList);
                component.set("v.totalRecords", completeList.length);
                component.set("v.startPage", 0);
                component.set("v.endPage", pageSize);
                var paginationList = [];
                for (var i = 0; i < pageSize; i++) {
                  if (completeList.length > i)
                    paginationList.push(completeList[i]);
                }
                for (var i = 0; i < completeList.length; i++) {
                  completeList[i].linkName = "/" + completeList[i].Id;
                  if (
                    component.get("v.PageName") ===
                    $A.get("$Label.c.AV_CDRP_Home")
                  ) {
                    if (completeList[i].AV_CDRP_Related_Study_Name__c != null)
                      completeList[i].AV_CDRP_Related_Study =
                        completeList[i].AV_CDRP_Related_Study_Name__c;
                  } else {
                    if (completeList[i].AV_CDRP_Related_Study_Name__c != null)
                      completeList[i].cdrpTaskRelatedStudy =
                        completeList[i].cdrpTaskRelatedStudy;
                  }
                }
                component.set("v.paginationList", paginationList);

                //for navigation
                var sectionSize = component.get("v.SectionSize");
                if (sectionSize > 100) {
                  var pageName = component.get("v.PageName");
                  var relatedIdrp = component.get("v.recordId");
                  var sectionName = component.get("v.SectionName");
                  var subSectionName = component.get("v.SubSectionName");
                  var completeList = component.get("v.completeList")[0];

                  var pageReference = {
                    type: "standard__component",
                    attributes: {
                      componentName:
                        "c__AV_CDRP_ClientSideInfiniteScrollForRecordsList"
                    },
                    state: {
                      c__pageName: pageName,
                      c__relatedIdrp: relatedIdrp,
                      c__sectionSize: sectionSize,
                      c__sectionName: sectionName,
                      c__subSectionName: subSectionName,
                    }
                  };
                  component.set("v.pageReference", pageReference);
                }
              }

              if (
                component.get("v.PageName") === $A.get("$Label.c.AV_CDRP_Home")
              ) {
                component.set("v.columns", [
                  {
                    label: "TASK ID",
                    fieldName: "linkName",
                    type: "url",
                    typeAttributes: {
                      label: { fieldName: "name" },
                      target: "_blank"
                    }
                  },
                  {
                    label: "TASK CATEGORY",
                    fieldName: "cdrpTaskCategory",
                    type: "text"
                  },
                  {
                    label: "DESCRIPTION",
                    fieldName: "cdrpTaskDescription",
                    type: "text"
                  },
                  {
                    label: "PRIORITY",
                    fieldName: "cdrpTaskPriority",
                    type: "text"
                  },
                  {
                    label: "DUE DATE",
                    fieldName: "cdrpDueDate",
                    type: "date-local"
                  },
                  {
                    label: "RELATED STUDY",
                    fieldName: "cdrpTaskRelatedStudy",
                    type: "text"
                  },
                  { label: "STATUS", fieldName: "cdrpStatus", type: "text" },
                  { type: "action", typeAttributes: { rowActions: rowActions } }
                ]);
              } else {
                component.set("v.columns", [
                  {
                    label: "TASK ID",
                    fieldName: "linkName",
                    type: "url",
                    typeAttributes: {
                      label: { fieldName: "name" },
                      target: "_blank"
                    }
                  },
                  {
                    label: "TASK CATEGORY",
                    fieldName: "cdrpTaskCategory",
                    type: "text"
                  },
                  {
                    label: "DESCRIPTION",
                    fieldName: "cdrpTaskDescription",
                    type: "text"
                  },
                  {
                    label: "PRIORITY",
                    fieldName: "cdrpTaskPriority",
                    type: "text"
                  },
                  {
                    label: "DUE DATE",
                    fieldName: "cdrpDueDate",
                    type: "date-local"
                  },
                  {
                    label: "RELATED IDRP",
                    fieldName: "cdrpTaskRelatedIdrp",
                    type: "text"
                  },
                  { label: "STATUS", fieldName: "cdrpStatus", type: "text" },
                  { type: "action", typeAttributes: { rowActions: rowActions } }
                ]);
              }
              component.set("v.Spinner", false);
            } else if (state === "INCOMPLETE") {
              component.set("v.Spinner", false);
              helper.showToast(
                "ERROR",
                "ERROR",
                $A.get("$Label.c.AV_CDRP_ErrorMessage")
              );
            } else {
              component.set("v.Spinner", false);
              helper.showToast(
                "ERROR",
                "ERROR",
                $A.get("$Label.c.AV_CDRP_ErrorMessage")
              );
            }
          });
          $A.enqueueAction(action);
        } else {
          component.set("v.Spinner", false);
        }
      },
      { userId: userId, relatedIdrp: relatedIdrp, pageName: pageName },
      false
    );
  },

  queriesBuildDatatable: function(component, event, helper) {
    component.set("v.Spinner", true);
    var userId = $A.get("$SObjectType.CurrentUser.Id");
    var pageName = component.get("v.PageName");

    var relatedIdrp = "";
    if (component.get("v.PageName") !== $A.get("$Label.c.AV_CDRP_Home")) {
      relatedIdrp = component.get("v.recordId");
    }

    //re-initialize
    var completeList = [];
    component.set("v.rowSection", false);
    component.set("v.showSection", false);
    component.set("v.completeList", completeList);
    component.set("v.rawData", completeList);
    component.set("v.totalRecords", 0);
    component.set("v.startPage", 0);
    component.set("v.endPage", 0);
    var paginationList = [];
    component.set("v.paginationList", paginationList);
    component.set("v.SectionSize", 0);

    helper.callServer(
      component,
      "c.getTotalNoQueryRecord",
      function(response) {
        component.set("v.SectionSize", response);
        var rowActions = helper.getTaskRowActions.bind(this, component);
        if (component.get("v.SectionSize") > 0) {
          component.set("v.showSection", true);
          var action = component.get("c.getQueriesRecords");
          action.setParams({
            userId: userId,
            relatedIdrp: relatedIdrp,
            pageName: pageName
          });
          action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
              var response = response.getReturnValue();
              if (response.length > 0) {
                component.set("v.rowSection", false);
                component.set("v.showSection", true);
                var pageSize = component.get("v.pageSize");
                var completeList = response;
                component.set("v.completeList", completeList);
                component.set("v.rawData", completeList);
                component.set("v.totalRecords", completeList.length);
                component.set("v.startPage", 0);
                component.set("v.endPage", pageSize);
                var paginationList = [];
                for (var i = 0; i < pageSize; i++) {
                  if (completeList.length > i)
                    paginationList.push(completeList[i]);
                }
                for (var i = 0; i < completeList.length; i++) {
                  completeList[i].linkName = "/" + completeList[i].Id;
                  if (component.get("v.PageName") !== "Record") {
                    if (completeList[i].CDRP_Site__r != null)
                      completeList[i].CDRP_Site =
                        completeList[i].CDRP_Site__r.Name;
                    if (completeList[i].CDRP_Data_Check_Visit__r != null)
                      completeList[i].CDRP_Visit =
                        completeList[i].CDRP_Data_Check_Visit__r.Name;

                    if (typeof completeList[i].Days_Open__c !== "undefined") {
                      completeList[i].Open_Days = completeList[i].Days_Open__c;
                    }
                  }
                }
                component.set("v.paginationList", paginationList);

                var sectionSize = component.get("v.SectionSize");
                if (sectionSize > 100) {
                  var pageName = component.get("v.PageName");
                  var relatedIdrp = component.get("v.recordId");
                  var sectionName = component.get("v.SectionName");
                  var subSectionName = component.get("v.SubSectionName");
                  var completeList = component.get("v.completeList")[0];
                  var recordTypeId = completeList.queryRecordTypeId;

                  var pageReference = {
                    type: "standard__component",
                    attributes: {
                      componentName:
                        "c__AV_CDRP_ClientSideInfiniteScrollForRecordsList"
                    },
                    state: {
                         c__pageName: pageName,
                         c__relatedIdrp: relatedIdrp,
                         c__sectionSize: sectionSize,
                         c__sectionName: sectionName,
                         c__subSectionName: subSectionName,
                         c__recordTypeId: recordTypeId,
                         c__LSHQueryStatus: completeList.LSHQueryStatus
                    }
                  };
                  component.set("v.pageReference", pageReference);
                }
              }
              if (
                component.get("v.PageName") === $A.get("$Label.c.AV_CDRP_Home")
              ) {
                component.set("v.columns", [
                  {
                    label: "DISCREPANCY/QUERY ID",
                    fieldName: "linkName",
                    type: "url",
                    typeAttributes: {
                      label: { fieldName: "name" },
                      target: "_blank"
                    }
                  },
                  {
                    label: "QUERY SOURCE",
                    fieldName: "querySource",
                    type: "text"
                  },
                  {
                    label: "RELATED IDRP",
                    fieldName: "relatedIDRP",
                    type: "text"
                  },
                  { label: "COUNTRY", fieldName: "country", type: "text" },
                  {
                    label: "INVESTIGATOR NAME",
                    fieldName: "investigatorName",
                    type: "text"
                  },
                  {
                    label: "SUBJECT NAME",
                    fieldName: "subjectName",
                    type: "text"
                  },
                  { label: "DATA FORM", fieldName: "dataForm", type: "text" },
                  { label: "FIELD NAME", fieldName: "fieldName", type: "text" },
                  { label: "QUERY TEXT", fieldName: "queryText", type: "text" },
                  {
                    label: "DISCREPANCY/QUERY STATUS",
                    fieldName: "status",
                    type: "text"
                  },
                  {
                    label: "USER COMMENT",
                    fieldName: "userComment",
                    type: "text"
                  },
                  { label: "DAYS OPEN", fieldName: "daysOpen", type: "number" },
                  { type: "action", typeAttributes: { rowActions: rowActions } }
                ]);
                component.set("v.Spinner", false);
              } else {
                component.set("v.columns", [
                  {
                    label: "DISCREPANCY/QUERY ID",
                    fieldName: "linkName",
                    type: "url",
                    typeAttributes: {
                      label: { fieldName: "name" },
                      target: "_blank"
                    }
                  },
                  {
                    label: "QUERY SOURCE",
                    fieldName: "querySource",
                    type: "text"
                  },
                  { label: "COUNTRY", fieldName: "country", type: "text" },
                  {
                    label: "INVESTIGATOR NAME",
                    fieldName: "investigatorName",
                    type: "text"
                  },
                  {
                    label: "SUBJECT NAME",
                    fieldName: "subjectName",
                    type: "text"
                  },
                  { label: "DATA FORM", fieldName: "dataForm", type: "text" },
                  { label: "FIELD NAME", fieldName: "fieldName", type: "text" },
                  { label: "QUERY TEXT", fieldName: "queryText", type: "text" },
                  {
                    label: "DISCREPANCY/QUERY STATUS",
                    fieldName: "status",
                    type: "text"
                  },
                  {
                    label: "USER COMMENT",
                    fieldName: "userComment",
                    type: "text"
                  },
                  { label: "DAYS OPEN", fieldName: "daysOpen", type: "number" },
                  { type: "action", typeAttributes: { rowActions: rowActions } }
                ]);
                component.set("v.Spinner", false);
              }
            } else if (state === "INCOMPLETE") {
              component.set("v.Spinner", false);
              helper.showToast(
                "ERROR",
                "ERROR",
                $A.get("$Label.c.AV_CDRP_ErrorMessage")
              );
            } else {
              component.set("v.Spinner", false);
              helper.showToast(
                "ERROR",
                "ERROR",
                $A.get("$Label.c.AV_CDRP_ErrorMessage")
              );
            }
          });
          $A.enqueueAction(action);
        } else {
          component.set("v.Spinner", false);
        }
      },
      { userId: userId, relatedIdrp: relatedIdrp, pageName: pageName },
      false
    );
  },

  observationsBuildDatatable: function(component, event, helper) {
    component.set("v.Spinner", true);
    var userId = $A.get("$SObjectType.CurrentUser.Id");
    var relatedIdrp = "";
    if (component.get("v.PageName") !== $A.get("$Label.c.AV_CDRP_Home")) {
      relatedIdrp = component.get("v.recordId");
    }
    var pageName = component.get("v.PageName");
    //re-initialize
    var completeList = [];
    component.set("v.rowSection", false);
    component.set("v.showSection", false);
    component.set("v.completeList", completeList);
    component.set("v.rawData", completeList);
    component.set("v.totalRecords", 0);
    component.set("v.startPage", 0);
    component.set("v.endPage", 0);
    var paginationList = [];
    component.set("v.paginationList", paginationList);
    component.set("v.SectionSize", 0);

    helper.callServer(
      component,
      "c.getTotalObservations",
      function(response) {
        component.set("v.SectionSize", response);
        var rowActions = helper.getTaskRowActions.bind(this, component);
        if (component.get("v.SectionSize") > 0) {
          component.set("v.showSection", true);
          var action = component.get("c.getObservationsRecords");
          action.setParams({
            userId: userId,
            relatedIdrp: relatedIdrp,
            pageName: pageName,
            view: ""
          });
          action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
              var response = response.getReturnValue();
              if (response.length > 0) {
                component.set("v.rowSection", false);
                component.set("v.showSection", true);
                var pageSize = component.get("v.pageSize");
                var completeList = response;
                component.set("v.completeList", completeList);
                component.set("v.totalRecords", completeList.length);
                component.set("v.startPage", 0);
                component.set("v.endPage", pageSize);
                var paginationList = [];
                for (var i = 0; i < pageSize; i++) {
                  if (completeList.length > i)
                    paginationList.push(completeList[i]);
                }
                for (var i = 0; i < completeList.length; i++) {
                  completeList[i].linkName = "/" + completeList[i].Id;
                }
                component.set("v.paginationList", paginationList);

                var sectionSize = component.get("v.SectionSize");
                if (sectionSize > 100) {
                  var pageName = component.get("v.PageName");
                  var relatedIdrp = component.get("v.recordId");
                  var sectionName = component.get("v.SectionName");
                  var subSectionName = component.get("v.SubSectionName");

                  var pageReference = {
                    type: "standard__component",
                    attributes: {
                      componentName:
                        "c__AV_CDRP_ClientSideInfiniteScrollForRecordsList"
                    },
                    state: {
                      c__pageName: pageName,
                      c__relatedIdrp: relatedIdrp,
                      c__sectionSize: sectionSize,
                      c__sectionName: sectionName,
                      c__subSectionName: subSectionName,
                    }
                  };
                  component.set("v.pageReference", pageReference);
                }
              }
              component.set("v.columns", [
                {
                  label: "OBSERVATION ID",
                  fieldName: "linkName",
                  type: "url",
                  typeAttributes: {
                    label: { fieldName: "Name" },
                    target: "_blank"
                  }
                },
                {
                  label: "CATEGORY",
                  fieldName: "AV_Category__c",
                  type: "text"
                },
                {
                  label: "SUBCATEGORY",
                  fieldName: "AV_Subcategory__c",
                  type: "text"
                },
                {
                  label: "ADDITIONAL  INFO",
                  fieldName: "AV_Additional_Information__c",
                  type: "text"
                },
                { label: "STATUS", fieldName: "AV_Status__c", type: "text" },
                {
                  label: "RELATED STUDY",
                  fieldName: "AV_Related_Studies__c",
                  type: "text"
                },
                {
                  label: "AGE FROM CREATION",
                  fieldName: "AV_Age_from_creation_date__c",
                  type: "number"
                }
              ]);
              component.set("v.Spinner", false);
            } else if (state === "INCOMPLETE") {
              component.set("v.Spinner", false);
              helper.showToast(
                "ERROR",
                "ERROR",
                $A.get("$Label.c.AV_CDRP_ErrorMessage")
              );
            } else {
              component.set("v.Spinner", false);
              helper.showToast(
                "ERROR",
                "ERROR",
                $A.get("$Label.c.AV_CDRP_ErrorMessage")
              );
            }
          });
          $A.enqueueAction(action);
        } else {
          component.set("v.Spinner", false);
        }
      },
      { userId: userId, relatedIdrp: relatedIdrp, pageName: pageName },
      false
    );
  },

  next: function(component, event, helper) {
    var sObjectList = component.get("v.completeList");
    var end = component.get("v.endPage");
    var start = component.get("v.startPage");
    var pageSize = component.get("v.pageSize");
    var paginationList = [];
    var counter = 0;
    for (var i = end; i < end + pageSize; i++) {
      if (sObjectList.length > i) {
        paginationList.push(sObjectList[i]);
      }
      counter++;
    }
    start = start + counter;
    end = end + counter;
    component.set("v.startPage", start);
    component.set("v.endPage", end);
    component.set("v.paginationList", paginationList);
  },
  previous: function(component, event, helper) {
    var sObjectList = component.get("v.completeList");
    var end = component.get("v.endPage");
    var start = component.get("v.startPage");
    var pageSize = component.get("v.pageSize");
    var paginationList = [];
    var counter = 0;
    for (var i = start - pageSize; i < start; i++) {
      if (i > -1) {
        paginationList.push(sObjectList[i]);
        counter++;
      } else {
        start++;
      }
    }
    start = start - counter;
    end = end - counter;
    component.set("v.startPage", start);
    component.set("v.endPage", end);
    component.set("v.paginationList", paginationList);
  },

  handleRowAction: function(component, event, helper) {
    var action = event.getParam("action");
    var row = event.getParam("row");
    /**  if(component.get("v.PageName")!=="Record"){
                switch (action.name) {
                    case 'Edit':                
                        var editRecordEvent = $A.get("e.force:editRecord");
                        editRecordEvent.setParams({
                            "recordId": row['Id']
                        });
                        editRecordEvent.fire();                
                        break;          
                }
                }
                else{*/
    switch (action.name) {
      case "Edit":
        var editRecordEvent = $A.get("e.force:editRecord");
        editRecordEvent.setParams({
          recordId: row["Id"]
        });
        editRecordEvent.fire();
        break;

      case "follow":
        helper.followRecord(component, event, helper, row);
        break;

      case "unfollow":
        helper.unFollowRecord(component, event, helper, row);
        break;
    }
    //  }
  },
  handleSaveSuccess: function(component, event, helper) {
    $A.get("e.force:refreshView").fire();
  },
  showToast: function(toastTitle, toastType, toastMessage) {
    var toastEvent = $A.get("e.force:showToast");
    toastEvent.setParams({
      title: toastTitle,
      type: toastType,
      message: toastMessage
    });
    toastEvent.fire();
  },

  getTaskRowActions: function(cmp, row, doneCallback) {
    var actions = [];

    /**  if(cmp.get("v.PageName")!=="Record"){
                                actions = [
                                {
                                    'label': 'Edit',
                                    'name': 'Edit'
                                },
                                
                            ];
                        }
                        else{**/
    actions = [
      {
        label: "Edit",
        name: "Edit"
      }
    ];
    if (row["isFollowed"]) {
      actions.push({
        label: "Unfollow",
        name: "unfollow"
      });
    } else {
      actions.push({
        label: "Follow",
        name: "follow"
      });
    }
    // }

    // simulate a trip to the server
    setTimeout(
      $A.getCallback(function() {
        doneCallback(actions);
      }),
      200
    );
  },

  handleClick: function(component, event, helper){
    if (
      component.get("v.SectionName") ===
      $A.get("$Label.c.AV_CDRP_Queries_Action_Header") ||  component.get("v.SectionName") ===
      $A.get("$Label.c.AV_CDRP_Queries_Action_Header").substring(0, 21)
    ) {

     if(component.get("v.PageName") !== $A.get("$Label.c.AV_CDRP_Home")){
      var completeList = component.get("v.completeList")[0];
      var action = component.get("c.setRolesInCache");
           action.setParams({
            roles: JSON.stringify(completeList.studyRoles),  
           });
           action.setCallback(this, function(response) {
             var state = response.getState();
             if (state === "SUCCESS") {
               if(response.getReturnValue()){
                const navService = component.find("navService");
                const pageReference = component.get("v.pageReference");
                const handleUrl = url => {
                 window.open(url);
                };
              const handleError = error => {
              };
              navService.generateUrl(pageReference).then(handleUrl, handleError);

               }else{
                helper.showToast(
                  "ERROR",
                  "ERROR",
                  $A.get("$Label.c.AV_CDRP_ErrorMessage")
                );
               }
             }
        });
           $A.enqueueAction(action);
     }

    else{
      var completeList = component.get("v.completeList")[0];
      var action = component.get("c.setChecksInCache");
           action.setParams({
            checks: JSON.stringify(completeList.checks),  
           });
           action.setCallback(this, function(response) {
             var state = response.getState();
             if (state === "SUCCESS") {
               if(response.getReturnValue()){
                const navService = component.find("navService");
                const pageReference = component.get("v.pageReference");
                const handleUrl = url => {
                 window.open(url);
                };
              const handleError = error => {
              };
              navService.generateUrl(pageReference).then(handleUrl, handleError);

               }else{
                helper.showToast(
                  "ERROR",
                  "ERROR",
                  $A.get("$Label.c.AV_CDRP_ErrorMessage")
                );
               }
             }
        });
           $A.enqueueAction(action);
    }
  }
    else{
    const navService = component.find("navService");
    const pageReference = component.get("v.pageReference");
    const handleUrl = url => {
      window.open(url);
    };
    const handleError = error => {
    };
    navService.generateUrl(pageReference).then(handleUrl, handleError);
  }
}

});