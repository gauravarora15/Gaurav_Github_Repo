({
	doInitHelper: function (component, event, helper) {
		var rec = component.get("v.recordId");
		var action = component.get("c.updateStatus");
		action.setParams({
			'recordId': rec
		});
		action.setCallback(this, function (response) {
			if (response.getState() == "SUCCESS") {
				component.set("v.displaySpinner", false);
				var resp = response.getReturnValue();
				if (resp == $A.get("$Label.c.AV_CDRP_Data_Review_Plan_Status_Approved")) {
					/*var navEvt = $A.get("e.force:navigateToSObject");
           			var planId = component.get("v.recordId");
            		navEvt.setParams({
                		"recordId": planId,
                		"slideDevName": "related"
            		});
            		navEvt.fire();	 
					//window.location.reload();*/
					window.location.assign('/'+component.get("v.recordId"));
					helper.showToast('Success', 'Success', $A.get("$Label.c.AV_CDRP_Complete_IDRP_Success_Message"));
				}
				else if (resp == $A.get("$Label.c.AV_CDRP_Data_Check_Status_Completed")) {
					component.set("v.displaySpinner", false);
            		var navEvt = $A.get("e.force:navigateToSObject");
           			var planId = component.get("v.recordId");
            		navEvt.setParams({
                		"recordId": planId,
                		"slideDevName": "related"
            		});
            		navEvt.fire();
					$A.get('e.force:refreshView').fire();
                    //window.location.assign('/'+component.get("v.recordId"));
					helper.showToast('Error', 'Error', $A.get("$Label.c.AV_CDRP_Complete_IDRP_Existing_Message"));
				}
				else  {
					component.set("v.displaySpinner", false);	
            		var navEvt = $A.get("e.force:navigateToSObject");
           			var planId = component.get("v.recordId");
            		navEvt.setParams({
                		"recordId": planId,
                		"slideDevName": "related"
            		});
            		navEvt.fire();
					$A.get('e.force:refreshView').fire();
					helper.showToast('Error', 'Error',resp);
				}
			}
		});
		$A.enqueueAction(action);
	},
	showToast: function (toastTitle, toastType, toastMessage) {
		var toastEvent = $A.get("e.force:showToast");
		toastEvent.setParams({
			"title": toastTitle,
			"type": toastType,
			"message": toastMessage
		});
		toastEvent.fire();
	}
})