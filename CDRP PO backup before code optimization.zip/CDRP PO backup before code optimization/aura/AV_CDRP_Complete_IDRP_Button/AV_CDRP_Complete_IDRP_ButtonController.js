({
	doInit : function(component, event, helper) {
        
       
		//console.log('INSIDE THE DO INIT CONTROLLER');
		helper.doInitHelper(component, event, helper);
	}
	
    
})