({
    doInit : function(component, event, helper) {
        var recordIdList = component.get("v.selectedCases");
        var workspaceAPI = component.find("workspace");
        component.set("v.showMessage", true);
        if(recordIdList.length > 0){
            var action = component.get("c.updateCaseOwner");
            action.setParams({
                "recordIdList": recordIdList
            });
            action.setCallback(this,function(response){
                var state = response.getState();
                if (state === "SUCCESS"){
                    component.set("v.displaySpinner", false);
                    component.set("v.showMessage", true);
                    var result = response.getReturnValue();
                    var arrayMapKeys = [];
                    for(var key in result){
                        arrayMapKeys.push({key: key, value: result[key]});
                    }
                    component.set("v.errorMessagesMap", arrayMapKeys);
                    
                    if(arrayMapKeys.length == 0){
                    	var myEvent = $A.get("e.c:AG_TakeMassOwnershipEvent");
	                    myEvent.setParams({
	                        successString:'success'
	                    });
	                    
	                    myEvent.fire();
                    }
                }
            });
            $A.enqueueAction(action);
        }else{
        	alert('select some cases');
        }
    }
})