({    
    closeFocusedTab : function(component, event, helper) {
        
            var myEvent = $A.get("e.c:AG_TakeMassOwnershipEvent");
            myEvent.setParams({
                successString:'close'
            });
            
            myEvent.fire();
    },
    
    continueOwnershipChange : function(component, event, helper){
        component.set('v.popup',false);
        helper.doInit(component, event, helper);
    }
})