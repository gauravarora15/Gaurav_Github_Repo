({
    handleInit : function(component, event, helper) {
        component.set("v.displaySpinner" , true);
        component.set("v.handleRefreshView" , true);
        var lookupFilterMap = {};
        lookupFilterMap['AG_Status__c'] = 'Active';
        component.set("v.lookupFilterMap",lookupFilterMap);
        var action = component.get("c.handleInit");
        action.setParams({
            "recordId" : component.get("v.recordId")
        });
        action.setCallback(this,function(response){
            var state = response.getState();

            if(state === "SUCCESS"){  
                component.set("v.caseProductWrapper",response.getReturnValue());
                if(!component.get("v.caseProductWrapper.isError")){
                    if(component.get("v.caseProductWrapper.isEdit")){
                        
                        component.set("v.showBody",true);

                        component.set("v.stopChange",true);

                        /* product update code has to be before lotbatch message code */
                        var lotBatchValMsg = component.get("v.caseProductWrapper.caseProductRecord.AG_Lot_Batch_Response_Msg_DONOTONVIEW__c");
                        component.set("v.selectedProductLookUpRecord.Id",component.get("v.caseProductWrapper.caseProductRecord.AG_Product__c"));
                        component.set("v.selectedProductLookUpRecord.Name",component.get("v.caseProductWrapper.caseProductRecord.AG_Product__r.Name"));
                        var setProduct = component.find("product");
                        setProduct.preselectValue();

                        /*setting filter for dosage form on edit*/
                        var lookupFilterMapForDosageForm = {};
                        lookupFilterMapForDosageForm["AG_Product__c"] = component.get("v.caseProductWrapper.caseProductRecord.AG_Product__c");
                        component.set("v.lookupFilterMapForDosageForm",lookupFilterMapForDosageForm);
                        
                        
                        if(!$A.util.isUndefinedOrNull(lotBatchValMsg) && !$A.util.isEmpty(lotBatchValMsg)){
                            component.set("v.responseStringLotBatch",lotBatchValMsg);
                            if(lotBatchValMsg == $A.get("$Label.c.AG_LB_Match_Product_Package")){
                                component.set("v.messageSev","confirm");
                            } else if(lotBatchValMsg == $A.get("$Label.c.AG_LB_Does_Not_Exists_ODS")){
                                component.set("v.messageSev","error");
                            } else{
                                component.set("v.messageSev","warning");
                            }
                            component.set("v.showResponseStringLotMessage",true);
                        }
                        
                        
                        if(!$A.util.isUndefinedOrNull(component.get("v.caseProductWrapper.caseProductRecord.AG_Dosage_Form__c")) && !$A.util.isEmpty(component.get("v.caseProductWrapper.caseProductRecord.AG_Dosage_Form__c"))){
                            
                            var selectedRelatedDosageForm = {};
                            //itit of selectedRelatedDosageForm
                            component.set("v.selectedRelatedDosageForm",selectedRelatedDosageForm);
                            component.set("v.selectedRelatedDosageForm.AG_Dosage_Form__c",component.get("v.caseProductWrapper.caseProductRecord.AG_Dosage_Form__c"));
                            
                            component.set("v.selectedRelatedDosageForm.AG_Dosage_Form__r.Name",component.get("v.caseProductWrapper.caseProductRecord.AG_Dosage_Form__r.Name"));
                            var setDosageForm = component.find("dosageForm");
                            setDosageForm.preselectValue();
                            /*
                            if(!component.get("v.caseProductWrapper.caseProductRecord.AG_Override__c")){
                                component.set("v.disabled",true);
                            }
                            */
                        }
                        component.set("v.caseProductWrapper.customCaseNumber",component.get("v.caseProductWrapper.caseProductRecord.AG_Case__r.AG_Custom_Case_Number__c"));
                        component.set("v.stopChange",false);
                        if(!$A.util.isEmpty(component.get("v.caseProductWrapper.caseProductRecord.AG_Reason_For_Missing_Lot_No__c")) && !$A.util.isUndefinedOrNull(component.get("v.caseProductWrapper.caseProductRecord.AG_Reason_For_Missing_Lot_No__c"))){
                            component.set("v.lotBatchUnKnownValue",true);
                            component.set("v.showResponseStringLotMessage",false);
             			    component.set("v.responseStringLotBatch","");
                        }
                    }
                } else{
                    //perform the error handling mechanism
                    if(component.get("v.caseProductWrapper.errorString")==$A.get("$Label.c.AG_Cannot_Edit_Case_Product")){
                        helper.showToast('Error',component.get("v.caseProductWrapper.errorString"),'error');
                        helper.handleCancel(component,event, helper);
                    }
                    else{
                        component.set("v.errormessage",component.get("v.caseProductWrapper.errorString"));
                        component.set("v.hasErrors",true);
                        component.set("v.showBody",false);
                    }
                }
                
            } else if(state === "INCOMPLETE"){
                helper.showToast('Error',$A.get("$Label.c.AG_errorMessage"),'error');
            } else if(state === "ERROR"){
                helper.showToast('Error',$A.get("$Label.c.AG_errorMessage"),'error');
            }
            component.set("v.displaySpinner",false);
        });
        $A.enqueueAction(action);
       
    }, 
    validateLotNumberInODS : function(component, event, helper) {
        var caseProductWrapper= component.get("v.caseProductWrapper");
        component.set("v.displaySpinner" , true);
        var productMatched = false;
        var action = component.get("c.getLotBatch");
        action.setParams({
            "lotNumber" : component.get("v.caseProductWrapper.caseProductRecord.AG_Lot_Batch_Number_NotOnView__c")
        });

        var getDosageForm = component.get("c.returnDosageFormDetails");

        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){  
                component.set("v.lotBatchWrapper",response.getReturnValue());
                var responsevalue = response.getReturnValue();
                if( !$A.util.isUndefinedOrNull(responsevalue.status) && responsevalue.status == "Success"){
                     //lot batch details found
                    if($A.util.isUndefinedOrNull(responsevalue.errors) || $A.util.isEmpty(responsevalue.errors)){
                        //package type matched
                        if(!$A.util.isUndefinedOrNull(responsevalue.lotBatchInfo.MFG_STAGE_CODE) && !$A.util.isEmpty(responsevalue.lotBatchInfo.MFG_STAGE_CODE) && responsevalue.lotBatchInfo.MFG_STAGE_CODE == $A.get("$Label.c.AG_Lot_Batch_FDP_Label")){
                          if(((!$A.util.isUndefinedOrNull(responsevalue.lotBatchInfo.TRADE_NAME) && !$A.util.isEmpty(responsevalue.lotBatchInfo.TRADE_NAME) )
                                 && (((component.get("v.selectedProductLookUpRecord.Name").trim()).toUpperCase() == ((responsevalue.lotBatchInfo.TRADE_NAME).trim()).toUpperCase()))) || (!$A.util.isUndefinedOrNull(responsevalue.lotBatchInfo.GENERIC_NAME) && !$A.util.isEmpty(responsevalue.lotBatchInfo.GENERIC_NAME) && ((component.get("v.selectedProductLookUpRecord.Name").trim()).toUpperCase() == ((responsevalue.lotBatchInfo.GENERIC_NAME).trim()).toUpperCase()))){
                                    //lot batch details found, package type details are matched,product details are matched
                                    component.set("v.responseStringLotBatch", $A.get("$Label.c.AG_LB_Match_Product_Package"));
                                    component.set("v.messageSev","confirm");
                                    productMatched = true;
                                    caseProductWrapper.validated = $A.get("$Label.c.AG_Yes_Lot_Batch_exists_and_matched_with_product_error");
                                } else{
                                    //lot batch details found, package type details are matched, product details are not matched
                                    component.set("v.responseStringLotBatch", $A.get("$Label.c.AG_LB_No_Match_Pro_ODS"));
                                    component.set("v.messageSev","warning");
                                    caseProductWrapper.validated = $A.get("$Label.c.AG_Yes_Lot_Batch_exists_and_does_not_matched_with_product_error");
                                }
                        } else{ //package type not matched
                            if(((!$A.util.isUndefinedOrNull(responsevalue.lotBatchInfo.TRADE_NAME) && !$A.util.isEmpty(responsevalue.lotBatchInfo.TRADE_NAME) )
                                 && (((component.get("v.selectedProductLookUpRecord.Name").trim()).toUpperCase() == ((responsevalue.lotBatchInfo.TRADE_NAME).trim()).toUpperCase()))) || (!$A.util.isUndefinedOrNull(responsevalue.lotBatchInfo.GENERIC_NAME) && !$A.util.isEmpty(responsevalue.lotBatchInfo.GENERIC_NAME) && ((component.get("v.selectedProductLookUpRecord.Name").trim()).toUpperCase() == ((responsevalue.lotBatchInfo.GENERIC_NAME).trim()).toUpperCase()))){
                                //lot batch details found, package type not matched,product details are matched
                                    component.set("v.responseStringLotBatch", $A.get("$Label.c.AG_LB_Match_Product_Not_Package"));
                                    component.set("v.messageSev","warning");
                                    productMatched = true;
                                    caseProductWrapper.validated = $A.get("$Label.c.AG_Yes_Lot_Batch_exists_and_matched_with_product_error");
                                } else{
                                    //lot batch details found, package type not matched, product details are not matched 
                                    component.set("v.responseStringLotBatch", $A.get("$Label.c.AG_LB_No_Match_Pro_Pack"));
                                    component.set("v.messageSev","warning");
                                    caseProductWrapper.validated = $A.get("$Label.c.AG_Yes_Lot_Batch_exists_and_does_not_matched_with_product_error");
                            }
                        }

                       
                    //lot batch number not found
                    } else{
                        component.set("v.responseStringLotBatch", $A.get("$Label.c.AG_LB_Does_Not_Exists_ODS"));
                        component.set("v.messageSev","error");
                        caseProductWrapper.validated = $A.get("$Label.c.AG_No_Lot_Batch_Number_does_not_exist");
                    }
                    if(!$A.util.isUndefinedOrNull(component.get("v.responseStringLotBatch")) && !$A.util.isEmpty(component.get("v.responseStringLotBatch"))){
                        component.set("v.showResponseStringLotMessage",true);
                    }
                    
                }else if($A.util.isUndefinedOrNull(responsevalue.status) || responsevalue.status != "Success"){
                     component.set("v.hasErrors",true);
                    component.set("v.errormessage",$A.get("$Label.c.AG_ODS_Connection_Failed"));
                }   
            }else if(state === "ERROR"){
                    helper.showToast('Error',$A.get("$Label.c.AG_errorMessage"),'error');
            }
            component.set("v.displaySpinner" , false);
                
        });
        $A.enqueueAction(action);
        
    },

    handleFormValidation: function(component, event, helper){
        var hasError = false;
        var productId = component.get("v.selectedProductLookUpRecord.Id");
        var justificationForMissingLotBatch = component.get("v.caseProductWrapper.caseProductRecord.AG_Justification_For_Missing_Lot_Number__c");
        if($A.util.isUndefinedOrNull(productId) || $A.util.isEmpty(productId)){
            var product = component.find("product");
            product.validateInput();
            hasError = true;
        }
        if(!component.find("justification").get("v.validity").valid){
            component.find("justification").showHelpMessageIfInvalid();
            hasError = true;
        }
        if(!hasError){
            helper.handleSave(component, event, helper);
        }
    },

    handleSave : function(component, event, helper){
        component.set("v.displaySpinner",true);
        component.set("v.hasErrors",false);
        var focusedTabId;
        component.set("v.errormessage","");
        var action = component.get("c.saveCaseProductRec");
        var wrapper = component.get("v.caseProductWrapper");
        wrapper.lotBatchWrapper = component.get("v.lotBatchWrapper");
        action.setParams({
            "wrapString" : JSON.stringify(component.get("v.caseProductWrapper"))
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var resp = response.getReturnValue();
                if(!$A.util.isUndefinedOrNull(resp) && !$A.util.isEmpty(resp)){
                    if(component.get("v.caseProductWrapper.caseProductRecord.AG_Case__c").indexOf(resp)> -1){
                        //no error message returned
                        if(component.get("v.caseProductWrapper").isEdit){
                            helper.showToast('Success',$A.get("$Label.c.AG_Case_Product_Create_Success"),'success');
                            
                            var workspaceAPI = component.find("workspace");
                            workspaceAPI.getFocusedTabInfo().then(function(response) {
                                focusedTabId = response.tabId;
                            });
                            
                            workspaceAPI.getEnclosingTabId().then(function(enclosingTabId) {
                                
                                workspaceAPI.openSubtab({
                                    parentTabId: enclosingTabId,
                                    pageReference: {
                                        "type": "standard__recordPage",
                                        "attributes": {
                                            "recordId":component.get("v.recordId"),
                                            "actionName":"view"
                                            
                                        },
                                        "state": {
                                            
                                        }
                                    }
                                }).then(function(subtabId) {
                                    workspaceAPI.closeTab({tabId: focusedTabId});
                                    workspaceAPI.focusTab({tabId : subtabId});
                                    workspaceAPI.refreshTab({
                                        tabId: subtabId,
                                        includeAllSubtabs: true
                                    });
                                }).catch(function(error) {
                                    console.log("error");
                                });
                            });
                           
                            component.set("v.displaySpinner",false);
                        }
                        else{
                            helper.showToast('Success',$A.get("$Label.c.AG_case_Product_Edit_Success"),'success');
                            /*component.set("v.displaySpinner",false);
                            var navEvt = $A.get("e.force:navigateToSObject");
                            navEvt.setParams({
                                "recordId": resp,
                                "slideDevName": "detail",
                                "isredirect":true
                            });
                            navEvt.fire();
                            $A.get('e.force:refreshView').fire();
							*/
							helper.closeFocusedTabAndOpenNewTab(component , event , helper, resp);
                        }
                        
                        
                    } else{
                        //error message returned
                        component.set("v.hasErrors",true);
                        component.set("v.errormessage",resp);
                    }
                } else{
                    helper.showToast('Error',$A.get("$Label.c.AG_errorMessage"),'error');
                }
                
            } else{
                helper.showToast('Error',$A.get("$Label.c.AG_errorMessage"),'error');
            }
            component.set("v.displaySpinner",false);
        });
        $A.enqueueAction(action);
    },     
    handleCancel:function(component,event, helper){
        var workspaceAPI = component.find("workspace");
        workspaceAPI.getFocusedTabInfo().then(function(response) {
            var focusedTabId = response.tabId;
            workspaceAPI.closeTab({tabId: focusedTabId});
            workspaceAPI.openTab({
                recordId: component.get("v.recordId"),
                focus: true
            });
        })
        .catch(function(error) {
            console.log(error);
        });
    },

    showToast: function(title,message,type){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message,
            "type": type
       });
        toastEvent.fire();
    },
	lotNumberWithReasonforMissingLotNumber : function(component, event, helper){
      
        if(!$A.util.isEmpty(component.get("v.caseProductWrapper.caseProductRecord.AG_Reason_For_Missing_Lot_No__c")) && !$A.util.isUndefinedOrNull(component.get("v.caseProductWrapper.caseProductRecord.AG_Reason_For_Missing_Lot_No__c"))){
            component.set("v.showResponseStringLotMessage",false);
            component.set("v.responseStringLotBatch","");
            component.set("v.caseProductWrapper.caseProductRecord.AG_Lot_Batch_Number_NotOnView__c","UNKNOWN");
        }else{
             component.set("v.showResponseStringLotMessage",false);
             component.set("v.responseStringLotBatch","");
             component.set("v.caseProductWrapper.caseProductRecord.AG_Lot_Batch_Number_NotOnView__c","");
        }
    },
    closeFocusedTabAndOpenNewTab : function(component, event, helper, recordId) {
        var workspaceAPI = component.find("workspace");
            
            workspaceAPI.openTab({
                url: '#/sObject/'+recordId+'/view',
                focus: true
            })
        $A.get('e.force:refreshView').fire();
       
    }

})