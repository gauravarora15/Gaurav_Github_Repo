({
    doInit : function(component,event, helper ) {
        helper.handleInit(component, event, helper);
    },
    
    validateLotNumber : function(component,event, helper ) {

        var productId = component.get("v.selectedProductLookUpRecord.Id");
        var lotBatchSelection = component.get("v.caseProductWrapper.caseProductRecord.AG_Lot_Batch_Number_NotOnView__c");
        if(!$A.util.isUndefinedOrNull(productId) && !$A.util.isEmpty(productId) && !$A.util.isUndefinedOrNull(lotBatchSelection) && !$A.util.isEmpty(lotBatchSelection)){
            component.set("v.hasErrors",false);
            component.set("v.errormessage",'');
            helper.validateLotNumberInODS(component, event, helper);
        } else{
            //Error Message
            component.set("v.hasErrors",true);
            component.set("v.errormessage",$A.get("$Label.c.AG_LB_Prod_Required"));
        }
    },
    trimSpacePadding : function(component, event, helper){
        var valueField = event.getSource().get("v.value");
        
        if(!$A.util.isEmpty(valueField) && !$A.util.isUndefinedOrNull(valueField)){
            
                component.set("v.caseProductWrapper.caseProductRecord.AG_Justification_For_Missing_Lot_Number__c",valueField.trim());
        }
    },
    checkLotBatch : function(component, event, helper){
        
            component.set("v.responseStringLotBatch","");
            component.set("v.showResponseStringLotMessage",false);
        
    },

    handleSave: function(component,event, helper ) {
          var validForm = component.find('missinglot').reduce(function (validSoFar, inputCmp) {
                inputCmp.showHelpMessageIfInvalid();
                return validSoFar && inputCmp.get('v.validity').valid;
                }, true); 
            if(validForm){ 

                helper.saveCaseProduct(component, event, helper);
            } 
             
   },

    handleCancel:function(component,event, helper ) {
        helper.handleCancel(component, event, helper);
    },

    showBody:function(component, event, helper){
        if(component.get("v.showBody")){
            component.set("v.showBody",false);
            component.find("createShowHide").set("v.label","New")

        } else{
            component.set("v.showBody",true);
            component.find("createShowHide").set("v.label","Hide");
        }
    },

    handleProductChange : function(component, event, helper){
    	
    	if(component.get("v.handleRefreshView")){
    		component.set("v.caseProductWrapper.caseProductRecord.AG_Product__c",component.get("v.selectedProductLookUpRecord.Id"));
    		component.set("v.responseStringLotBatch","");
    		component.set("v.showResponseStringLotMessage",false);
    	}
        

        if(!component.get("v.stopChange")){
            component.find("dosageForm").invokeClose();
            component.set("v.selectedRelatedDosageForm.AG_Dosage_Form__c",'');
            component.set("v.selectedRelatedDosageForm.AG_Dosage_Form__r.Name",'');

            var lookupFilterMapForDosageForm = {};
            if(!$A.util.isEmpty(component.get("v.selectedProductLookUpRecord.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedProductLookUpRecord.Id"))){
                lookupFilterMapForDosageForm["AG_Product__c"] = component.get("v.selectedProductLookUpRecord.Id");
                component.set("v.lookupFilterMapForDosageForm",lookupFilterMapForDosageForm);
            }
        }
        
    },

    handleDosageFormChange : function(component, event, helper){
        if(!component.get("v.stopChange")){
            component.set("v.caseProductWrapper.caseProductRecord.AG_Dosage_Form__c",component.get("v.selectedRelatedDosageForm.AG_Dosage_Form__c"));
        }
    },

    handleResponseStringLotBatch : function(component, event, helper){
        component.set("v.caseProductWrapper.caseProductRecord.AG_Lot_Batch_Response_Msg_DONOTONVIEW__c",component.get("v.responseStringLotBatch"));
    },

    handleFormValidation : function(component, event, helper){
        helper.handleFormValidation(component, event, helper);
    },
    handleSpace : function(component, event, helper){
        var fieldVale = event.getSource().get("v.value");
        var fieldLabel = event.getSource().get("v.label");
        if(!$A.util.isEmpty(fieldVale) && !$A.util.isUndefinedOrNull(fieldVale)){
            if(fieldLabel == $A.get("$Label.c.AG_Lot_Batch_Number")){
            	component.set("v.caseProductWrapper.caseProductRecord.AG_Lot_Batch_Number_NotOnView__c",fieldVale.trim());
        	}
        	else if(fieldLabel == $A.get("$Label.c.AG_Justification_For_Missing_Lot_Number_Label")){
            	component.set("v.caseProductWrapper.caseProductRecord.AG_Justification_For_Missing_Lot_Number__c",fieldVale.trim());
        	}
        }
    },
    handleLotNumberValue : function(component, event, helper){
        helper.lotNumberWithReasonforMissingLotNumber(component, event, helper);
    },
    refreshViewHandler : function(component,event, helper ) {
    	
    	component.find("product").invokeClose();
        helper.handleInit(component, event, helper);
        component.set("v.showBody",false);
        component.find("createShowHide").set("v.label","New");
    }

})