({
	//COMMON HELPER METHOD INVOKED FROM ALL BUTTONS 
	handleClickHelper : function(component,event,helper) {
		component.set("v.Spinner" , true);
		component.set("v.errorMessage","");
		var buttonId = event.getSource().getLocalId();
        if(buttonId == 'cancelButton' && $A.util.isEmpty(component.get("v.documentId"))){
        	$A.get("e.force:closeQuickAction").fire();	    
        }else if(buttonId == 'cancelButton' && !$A.util.isEmpty(component.get("v.documentId"))){
              helper.deleteConetentDocumentHelper(component,event,helper);
        }else if(buttonId == 'saveButton'){
        	helper.validateFields(component,event,helper);
        }
	},
	//HELPER METHOD THAT RUNS ON PAGE LOAD
	doInitHelper : function(component,event,helper) {
		var action = component.get("c.sourceDocDetails");
        action.setParams({"caseId" : component.get("v.recordId")});
        action.setCallback(this,function(response){
            
            //get the response state
            var state = response.getState();
            
            if(state === "SUCCESS"){

                var response = response.getReturnValue();
                
                if($A.util.isEmpty(response.errorMessage)){
                	component.set("v.caseNumber",response.caseNumber);
                }else{
                	$A.get("e.force:closeQuickAction").fire();
                	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , response.errorMessage,$A.get("$Label.c.AG_Error"));
                }
                component.set("v.Spinner" , false);
            } else if(state === "ERROR"){
            	component.set("v.errorMessage",$A.get("$Label.c.AG_errorMessage"));
            	component.set("v.Spinner" , false);
            }else if(state === "INCOMPLETE"){
                component.set("v.errorMessage",$A.get("$Label.c.AG_errorMessage"));
            	component.set("v.Spinner" , false);
            }
            
        });
        $A.enqueueAction(action);
	},
    //SHOW TOAST MESSAGE TO USER
    showToast : function(component, event, helper,title , message , type) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message,
            "type" : type
        });
        toastEvent.fire();
    },
    //VALIDATES ALL REQUIRED FIELDS
    validateFields : function(component,event,helper){
    	var inputCmp = component.find("name");
    	inputCmp.setCustomValidity("");
    	var validity = inputCmp.get("v.validity");
    	
    	if(!validity.valid){
    		component.set("v.Spinner" , false);
    		inputCmp.reportValidity();
    		return;
    	}else if($A.util.isEmpty(component.get("v.documentId"))){
    		component.set("v.errorMessage",$A.get("$Label.c.AG_Error_File_Upload"));
    		component.set("v.Spinner" , false);
    	}else if($A.util.isEmpty(component.get("v.sourceDocument").AG_Name__c.trim())){
    		inputCmp.setCustomValidity($A.get("$Label.c.AG_Complete_Field"));
    		inputCmp.reportValidity();
    		component.set("v.Spinner" , false);
    		return;
    	}else{
    		helper.createSourceAttachmentHelper(component,event,helper);
    	}
    },
    //METHOD TO CREATE NEW SOURCE ATTACHMENT AND RELATE DOCUMENT TO THE RECORD
    createSourceAttachmentHelper : function(component,event,helper) {
    	component.set("v.sourceDocument.AG_Case_Number__c",component.get("v.recordId"));
		var action = component.get("c.createSourceDocument");
        action.setParams({"attachmentInstance" : component.get("v.sourceDocument"),
        				"documentId":component.get("v.documentId")});
        action.setCallback(this,function(response){
            
            //get the response state
            var state = response.getState();
            
            if(state === "SUCCESS"){

                var response = response.getReturnValue();
                
                if($A.util.isEmpty(response.errorMessage)){
                	$A.get("e.force:closeQuickAction").fire();	
                	helper.showToast(component, event, helper,$A.get("$Label.c.AG_Sucess_Toast_Type") , $A.get("$Label.c.AG_Create_Record_Successfully"),$A.get("$Label.c.AG_Sucess_Toast_Type"));
                	$A.get('e.force:refreshView').fire();
                	helper.navigateToSourceAttachment(component,event,helper,response.attachmentId);
                }else{
                	component.set("v.errorMessage",response.errorMessage);
                }
                component.set("v.Spinner" , false);
            } else if(state === "ERROR"){
            	 helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            	 component.set("v.Spinner" , false);
            }else if(state === "INCOMPLETE"){
                 helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                 component.set("v.Spinner" , false);
            }
        });
        $A.enqueueAction(action);
	},
	//METHOD TO NAVIGATE USER TO SOURCE ATTACHMENT RECORD
	navigateToSourceAttachment : function(component , event , helper,recordId){
            
            var pageReference = {
                type: 'standard__recordPage',
                attributes: {
                    recordId: recordId,
                    actionName : 'view',
                    objectApiName : 'AG_Attachment__c'
                },
                state: {
                    
                }
            };
            
            component.set("v.pageReference", pageReference);
            var navService = component.find("navService");
            var pageReference = component.get("v.pageReference");
            navService.navigate(pageReference);
    },
    //METHOD TO DELETE CONTENT DOCUMENT RECORD ON CANCEL
	deleteConetentDocumentHelper : function(component,event,helper) {
		var action = component.get("c.deleteContentDocument");
        action.setParams({"documentId" : component.get("v.documentId")});
        action.setCallback(this,function(response){
            
            //get the response state
            var state = response.getState();
            
            if(state === "SUCCESS"){

                var response = response.getReturnValue();
                
                if($A.util.isEmpty(response.errorMessage)){
                	$A.get("e.force:closeQuickAction").fire();
                }else{
                	component.set("v.errorMessage",response.errorMessage);
                }
                component.set("v.Spinner" , false);
            } else if(state === "ERROR"){
            	component.set("v.errorMessage",$A.get("$Label.c.AG_errorMessage"));
            	component.set("v.Spinner" , false);
            }else if(state === "INCOMPLETE"){
                component.set("v.errorMessage",$A.get("$Label.c.AG_errorMessage"));
                component.set("v.Spinner" , false);
            }
        });
        $A.enqueueAction(action);
	},
})