({
	doInit : function(component, event, helper) {
		helper.doInitHelper(component,event,helper);
	},
    handleFilesChange : function(component, event, helper) {
		component.set("v.errorMessage","");
        var uploadedFiles = event.getParam("files");
        component.set("v.documentId",uploadedFiles[0].documentId);
	},
    handleClick : function(component, event, helper) {
        helper.handleClickHelper(component,event,helper);
    }
})