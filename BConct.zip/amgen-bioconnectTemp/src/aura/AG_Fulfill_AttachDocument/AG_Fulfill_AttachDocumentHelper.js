({
    createResponse : function(component , event , helper) {
        var action = component.get("c.createResponseForDocuments");
        var documentId = event.getParam("files")[0].documentId;
        action.setParams({"parentId" : component.get("v.requestId"), 
                          "documentId" : documentId });
        action.setCallback(this,function(response){
            var state = response.getState();
            
            if(state === "SUCCESS"){
                var responseId = response.getReturnValue();
                if(!$A.util.isEmpty(responseId) && !$A.util.isUndefined(responseId)){
                    //component.set("v.responseId" , responseId);
                    helper.showToast(component, event, helper,$A.get("$Label.c.AG_DocumentUploaded") , $A.get("$Label.c.AG_DocumentUploadSuccess") ,$A.get("$Label.c.AG_Sucess_Toast_Type"));
        			helper.navigateToComponents(component , event , helper , 1);
                }else{
                    helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                    helper.navigateToComponents(component , event , helper , 1);
                }  
            } else if(state === "ERROR"){
                	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                	helper.navigateToComponents(component , event , helper , 1);
            }
        });
        $A.enqueueAction(action);
    },
    showToast : function(component, event, helper,title , message , type) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message,
            "type" : type
        });
        toastEvent.fire();
    },
    uploadedFile : function(component , event , helper){
    	
        helper.createResponse(component , event , helper);
    },
    navigateToComponents  :function(component , event , helper,componentNo){
        var compEvent = component.getEvent("navigateComponent");
        compEvent.setParams({"componentNo" : componentNo });
		compEvent.fire();
    }
})