({
    handleUploadFinished  : function(component , event , helper){
        helper.uploadedFile(component , event , helper);
    }
})