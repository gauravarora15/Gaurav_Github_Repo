({
    afterRender : function(component, helper) {
        
        
        
        this.superAfterRender();
        var pageReference = component.get("v.pageReference");
        var pageRefRecordId = pageReference.state.c__recordId;
        var workspaceAPI = component.find("workspace");
        var auditTrailRecId;
        var alreadyexistingTabId;
        var existingTabId ;
        
        var ifTabIsPresent = [];
        
        var workspaceAPI = component.find("workspace");
        workspaceAPI.getAllTabInfo().then(function(response) {
            var duplicateCheck = 0;
            var checkIfFirstLoad = false;
            
            response.forEach(function(element) {
                
                var focusedTabId = element.tabId;
                
                var previousId;
                if(element.customTitle == undefined && pageRefRecordId == element.recordId){
                    auditTrailRecId = element.recordId;
                }
                if(element.customTitle != undefined ){
                    alreadyexistingTabId = element.pageReference.state.c__recordId;
                }
                
                if(element.customTitle == undefined || (element.customTitle !=undefined && pageRefRecordId != element.pageReference.state.c__recordId)){
                  
                    if(pageRefRecordId == element.pageReference.state.c__recordId && duplicateCheck != 1){
                        if(undefined != element.pageReference.attributes.componentName && 
                       element.pageReference.attributes.componentName ==  $A.get("$Label.c.AG_Audit_Trail_Component")){
                        
                        workspaceAPI.setTabLabel({
                            tabId: element.tabId,
                            label: $A.get("$Label.c.AG_Audit_Trail_Tab"),
                            focus: true
                        });
                    }
                    }
                    else if(pageRefRecordId == element.pageReference.state.c__recordId && duplicateCheck == 1){
                        workspaceAPI.closeTab({tabId: existingTabId});
                        workspaceAPI.focusTab({tabId : focusedTabId});
                        workspaceAPI.setTabLabel({
                        tabId: element.tabId,
                        label: $A.get("$Label.c.AG_Audit_Trail_Tab")
                       }); 
                    }
                }
                /* if already tab is created*/
                else if(element.customTitle !=undefined && pageRefRecordId == element.pageReference.state.c__recordId){
                    /*get tab Id of existing tab*/
                    existingTabId = focusedTabId; 
                    /*check the duplicate var*/
                    duplicateCheck = duplicateCheck + 1;
                }
                else{
                    workspaceAPI.closeTab({tabId: focusedTabId});
                }
                
                
            });
        })
        .catch(function(error) {
            //alert(error);
        });
        
    }
})