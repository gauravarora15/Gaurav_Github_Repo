({
    doInitHelper: function(component,event,helper){
		var pageReference = component.get("v.pageReference");
        component.set("v.recordId", pageReference.state.c__recordId);
        component.set("v.displaySpinner", true);
        component.find("errorToastPlaceholder").set("v.body", []);
        var action = component.get("c.historyItems");
        action.setParams({
            "recordId": component.get("v.recordId"),
            "recordName" : component.get("v.Name") 
        });
        action.setCallback(this,function(response){
            component.set("v.displaySpinner", false);
            var state = response.getState();
            if(state === "SUCCESS"){
                var res = response.getReturnValue();
                if(!$A.util.isEmpty(res) && !$A.util.isUndefined(res)){
                    var allRecords = response.getReturnValue().historyWrapperList;
                    var rowsPerPage= $A.get("$Label.c.AG_Audit_Trail_Rows_Per_Page");  
                    component.set("v.serializedrecs",allRecords.length);
                    component.set("v.historyList",response.getReturnValue());   
                    component.set("v.userName",response.getReturnValue().userName);
                    component.set("v.currentTime",response.getReturnValue().generatedTime);
                    component.set("v.maxPage", Math.ceil((allRecords.length)/rowsPerPage));  
                    helper.renderTable(component);
                } else{
                    this.showErrorToast(component, $A.get("$Label.c.AG_AuditTableError"));
                }
            } else if(state === "INCOMPLETE"){
                this.showErrorToast(component, $A.get("$Label.c.AG_AuditTableError"));
            } else if(state === "ERROR"){
                // Prepare a toast UI message
                this.showErrorToast(component, $A.get("$Label.c.AG_AuditTableError"));
            }
            
        });
        $A.enqueueAction(action);  
    },
    
    //logic to render the data table
    renderTable: function(component) {
        var records = component.get("v.historyList"),
            recordList = records.historyWrapperList,
            rowsPerPage = $A.get("$Label.c.AG_Audit_Trail_Rows_Per_Page"),
            pageNumber = component.get("v.pageNumber"),
            maxPage=component.get("v.maxPage"),
            pageRecords = recordList.slice((pageNumber-1)*rowsPerPage, pageNumber*rowsPerPage);
			var currentHistoryListIds=[];
        if(pageNumber == 1){
            component.set("v.hideFirst",true);
            component.set("v.hidePrev",true);
        }
        else{
            component.set("v.hideFirst",false);
            component.set("v.hidePrev",false);
        }
        if(pageNumber==maxPage){
            component.set("v.hideLast",true);
            component.set("v.hideNext",true);
        }
        else{
            component.set("v.hideLast",false);
            component.set("v.hideNext",false);
        }
        component.set("v.currentList", pageRecords);
		for(var i=0;i<pageRecords.length;i++){
            currentHistoryListIds.push(pageRecords[i].historyRecId);
        }
        var HighestPageNumber = pageNumber*$A.get("$Label.c.AG_Audit_Trail_Rows_Per_Page");
            if(HighestPageNumber>recordList.length){
                HighestPageNumber = recordList.length;
            }
        var pegeNumberHeader = (pageNumber*$A.get("$Label.c.AG_Audit_Trail_Rows_Per_Page"))-($A.get("$Label.c.AG_Audit_Trail_Rows_Per_Page")-1);
        pegeNumberHeader = pegeNumberHeader+ ' to ' + HighestPageNumber + ' of '+ recordList.length+' Audit History Records';
        component.set("v.numberOfRecordsHeader",pegeNumberHeader);
        var action = component.get("c.createCacheForAuditTrail");
        action.setParams({
            "auditHistoryIds": JSON.stringify(currentHistoryListIds) 
        });
        action.setCallback(this,function(response){
            
            var state = response.getState();
            if(state === "SUCCESS"){
                var res = response.getReturnValue();
                if(!$A.util.isEmpty(res) && !$A.util.isUndefined(res)){
                   //alert('res'+res);
                } else{
                    helper.showErrorToast(component, $A.get("$Label.c.AG_AuditTableError"));
                }
            } else if(state === "INCOMPLETE"){
                helper.showErrorToast(component, $A.get("$Label.c.AG_AuditTableError"));
            } else if(state === "ERROR"){
                // Prepare a toast UI message
                helper.showErrorToast(component, $A.get("$Label.c.AG_AuditTableError"));
            }
            
        });
        $A.enqueueAction(action); 
    },

    showErrorToast: function(component, errorMsg) {
        $A.createComponent(
            "c:AG_ToastNotificationComponent", {
                "errorMsg": errorMsg
            },
            function(errorToast) {
                if (component.isValid()) {
                    var targetCmp = component.find("errorToastPlaceholder");
                    var body = targetCmp.get("v.body");
                    body.push(errorToast);
                    targetCmp.set("v.body", body);
                }
                component.set("v.displaySpinner", false);
            }
        );
    },
    fetchHistoryForRecord : function(component , event , helper , recordId){
    	
    	var action = component.get("c.historyItems");
        action.setParams({
            "recordId": recordId 
        });
        action.setCallback(this,function(response){
            
            var state = response.getState();
            if(state === "SUCCESS"){
                var res = response.getReturnValue();
                if(!$A.util.isEmpty(res) && !$A.util.isUndefined(res)){
                    var allRecords = response.getReturnValue().historyWrapperList;
                    var rowsPerPage=$A.get("$Label.c.AG_Audit_Trail_Rows_Per_Page");   
                    component.set("v.historyList",response.getReturnValue());   
                    component.set("v.maxPage", Math.ceil((allRecords.length)/rowsPerPage));  
                    helper.renderTable(component , event , helper , allRecords);
                } else{
                    helper.showErrorToast(component, $A.get("$Label.c.AG_AuditTableError"));
                }
            } else if(state === "INCOMPLETE"){
                helper.showErrorToast(component, $A.get("$Label.c.AG_AuditTableError"));
            } else if(state === "ERROR"){
                // Prepare a toast UI message
                helper.showErrorToast(component, $A.get("$Label.c.AG_AuditTableError"));
            }
            
        });
        $A.enqueueAction(action); 
    },
    navigateCancel : function(component , event , helper){
    	  var workspaceAPI = component.find("workspace");
        workspaceAPI.getFocusedTabInfo().then(function(response) {
            var focusedTabId = response.tabId;
            workspaceAPI.closeTab({tabId: focusedTabId});
        })
        .catch(function(error) {
            
        });
    },
     
    //field Ascending Helper
    fieldAscendingHelper : function(component,event,helper){
    	  //get the list of records that needs to be sorted
        var audits = component.get("v.currentList");
        //first time the arrow will be upArrow and the order is asc(default) 
        //or if the arrow is downarrow and the order you want to sort is Asc then show the uparrow and sort the data to ascending order
        if((component.get("v.fieldUpArrow") && component.get("v.fieldAscorDesc")===$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label")) ||(!component.get("v.fieldUpArrow") && component.get("v.fieldAscorDesc")===$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"))) {
            component.set("v.fieldUpArrow",true);
        }else{
            component.set("v.fieldUpArrow",false);
        }
        //pass the list of records that needs to be sorted to helper method along with the field that needs to be sorted and the order in which we need to sort
        audits.sort(helper.compareValues(component,helper,$A.get("$Label.c.AG_Audit_Trail_fieldLabel_Label"), component.get("v.fieldAscorDesc")));
         if(component.get("v.fieldAscorDesc")===$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label")){
             component.set("v.fieldAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Descending_order_Label"));
        }else{
            component.set("v.fieldAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"));
        }
        //set the sorted results back to the list
        component.set("v.currentList",audits);
        //when we click on filedLabel to sort this time other fields may be sorted by decending order previously so we need to make their symbols to upArrow and order to ascending
        component.set("v.userUpArrow",true);
        component.set("v.dateUpArrow",true);
        component.set("v.userAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"));
        component.set("v.dateAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"));
        //Hightlight the Field tag and de highlight the other Date and User tags
        component.set("v.highlightField",true);
        component.set("v.highlightDate",false);
        component.set("v.highlightUser",false);
	},
     //user Ascending Helper
    userAscendingHelper : function(component,event,helper){
        //get the list of records that needs to be sorted
        var audits = component.get("v.currentList");
        if((component.get("v.userUpArrow") && component.get("v.userAscorDesc")===$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label")) ||(!component.get("v.userUpArrow") && component.get("v.userAscorDesc")===$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"))) {
            component.set("v.userUpArrow",true);
        }else{
            component.set("v.userUpArrow",false);
        }
        audits.sort(helper.compareValues(component,helper,$A.get("$Label.c.AG_Audit_Trail_userName_Label"), component.get("v.userAscorDesc")));
         if(component.get("v.userAscorDesc")===$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label")){
             component.set("v.userAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Descending_order_Label"));
        }else{
            component.set("v.userAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"));
        }
        //when we click on UserName to sort this time other fields may be sorted by decending order previously so we need to make their symbols to upArrow and order to ascending
        component.set("v.currentList",audits);
		component.set("v.fieldUpArrow",true);
        component.set("v.dateUpArrow",true);  
        component.set("v.fieldAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"));
        component.set("v.dateAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"));
         //Hightlight the Field tag and de highlight the other Date and User tags
         component.set("v.highlightUser",true);
         component.set("v.highlightDate",false);
         component.set("v.highlightField",false);
    },
     //date Ascending Helper
    dateAscendingHelper : function(component,event,helper){
         //get the list of records that needs to be sorted
        var audits = component.get("v.currentList");
        component.set("v.displaySpinner", true);
        if((component.get("v.dateUpArrow") && component.get("v.dateAscorDesc")===$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label")) ||(!component.get("v.dateUpArrow") && component.get("v.dateAscorDesc")===$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"))) {
            component.set("v.dateUpArrow",true);
        }else{
            component.set("v.dateUpArrow",false);
        }
        audits.sort(helper.compareValues(component,helper,$A.get("$Label.c.AG_Audit_Trail_createdDate_Label"), component.get("v.dateAscorDesc")));
         if(component.get("v.dateAscorDesc")===$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label")){
             component.set("v.dateAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Descending_order_Label"));
        }else{
            component.set("v.dateAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"));
        }
        component.set("v.currentList",audits);
        //when you click on Date to sort this time other fields may be sorted by decending order previously so we need to make their symbols to upArrow and order to ascending
		component.set("v.fieldUpArrow",true);
        component.set("v.userUpArrow",true);  
        component.set("v.fieldAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"));
        component.set("v.userAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"));
        component.set("v.displaySpinner", false);
        //Hightlight the Field tag and de highlight the other Date and User tags
        component.set("v.highlightDate",true);
        component.set("v.highlightUser",false);
        component.set("v.highlightField",false);
    },
     // function for dynamic sorting
    compareValues:function(component, helper,key, order) {
      return function(a, b) {
       const varA = (typeof a[key] === $A.get("$Label.c.AG_Audit_Trail_string_Label")) ? 
          a[key].toUpperCase() : a[key];
        const varB = (typeof b[key] === $A.get("$Label.c.AG_Audit_Trail_string_Label")) ? 
          b[key].toUpperCase() : b[key];
        let comparison = 0;
        if (varA > varB) {
          comparison = 1;
        } else if (varA < varB) {
          comparison = -1;
        }
        return (
          (order == $A.get("$Label.c.AG_Audit_Trail_Descending_order_Label")) ? (comparison * -1) : comparison
        );
      };
	}
    
})
