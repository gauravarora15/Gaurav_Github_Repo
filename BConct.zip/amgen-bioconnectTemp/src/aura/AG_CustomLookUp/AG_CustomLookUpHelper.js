({
  onfocus: function(component, helper) {
    var isShowRecentItems = component.get("v.showRecentItems");
    var searchIcon = component.find("searchIcon");
    $A.util.addClass(searchIcon, 'slds-hide');
    $A.util.removeClass(searchIcon, 'slds-show');
    if (isShowRecentItems) {
      var forOpen = component.find("searchRes");
      $A.util.addClass(forOpen, 'slds-is-open');
      $A.util.removeClass(forOpen, 'slds-is-close');
      // Get Default 5 Records order by createdDate DESC  
      var getInputkeyWord = '';
      helper.searchHelper(component, event, getInputkeyWord);
    }
  },
  handleKeyPress: function(component, helper) {
    var searchIcon = component.find("searchIcon");
    $A.util.addClass(searchIcon, 'slds-hide');
    $A.util.removeClass(searchIcon, 'slds-show');
    // get the search Input keyword   
    var getInputkeyWord = component.get("v.SearchKeyWord");
    // check if getInputKeyWord size id more then 0 then open the lookup result List and 
    // call the helper 
    // else close the lookup result List part.   
    if (getInputkeyWord.length > 0) {
      var forOpen = component.find("searchRes");
      $A.util.addClass(forOpen, 'slds-is-open');
      $A.util.removeClass(forOpen, 'slds-is-close');
      helper.searchHelper(component, event, getInputkeyWord);
    } else {
      component.set("v.listOfSearchRecords", null);
      var forclose = component.find("searchRes");
      $A.util.addClass(forclose, 'slds-is-close');
      $A.util.removeClass(forclose, 'slds-is-open');
    }

  },
  // function for clear the Record Selaction 
  handleClear: function(component) {
    var pillTarget = component.find("lookup-pill");
    var lookUpTarget = component.find("lookupField");

    $A.util.addClass(pillTarget, 'slds-hide');
    $A.util.removeClass(pillTarget, 'slds-show');

    $A.util.addClass(lookUpTarget, 'slds-show');
    $A.util.removeClass(lookUpTarget, 'slds-hide');

    var forclose = component.find("searchRes");
    $A.util.addClass(forclose, 'slds-is-close');
    $A.util.removeClass(forclose, 'slds-is-open');

    component.set("v.SearchKeyWord", null);
    component.set("v.listOfSearchRecords", null);
    component.set("v.selectedRecord", {});

  },

  // This function call when the end User Select any record from the result list.   
  handleComponentEvent: function(component, event) {
    // get the selected Account record from the COMPONETN event

    
    var selectedRecordFromEvent = event.getParam("recordByEvent");
    component.set("v.selectedRecord",selectedRecordFromEvent);
    

    var forclose = component.find("lookup-pill");
    $A.util.addClass(forclose, 'slds-show');
    $A.util.removeClass(forclose, 'slds-hide');

    var forclose = component.find("searchRes");
    $A.util.addClass(forclose, 'slds-is-close');
    $A.util.removeClass(forclose, 'slds-is-open');

    var lookUpTarget = component.find("lookupField");
    $A.util.addClass(lookUpTarget, 'slds-hide');
    $A.util.removeClass(lookUpTarget, 'slds-show');
      
    var searchIcon = component.find("searchIcon");
    $A.util.addClass(searchIcon, 'slds-hide');
    $A.util.removeClass(searchIcon, 'slds-show');

  },

  handlePreSelect : function(component, event){

    var forclose = component.find("lookup-pill");
    $A.util.addClass(forclose, 'slds-show');
    $A.util.removeClass(forclose, 'slds-hide');

    var forclose = component.find("searchRes");
    $A.util.addClass(forclose, 'slds-is-close');
    $A.util.removeClass(forclose, 'slds-is-open');

    var lookUpTarget = component.find("lookupField");
    $A.util.addClass(lookUpTarget, 'slds-hide');
    $A.util.removeClass(lookUpTarget, 'slds-show');

    
  },
  
  searchHelper: function(component, event, getInputkeyWord) {
    // call the apex class method 
    var action = component.get("c.fetchLookUpValues");
    // set param to method  
    action.setParams({
      'searchKeyWord': getInputkeyWord,
      'ObjectName': component.get("v.objectAPIName"),
      'lookupFilters': component.get("v.lookupFilters"),
      'searchResultsCnt': component.get("v.searchResultsCnt"),
      'isJunctionObjectSearch': component.get("v.isJunctionObjectSearch")
    });
    // set a callBack    

    action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === "SUCCESS") {
        var storeResponse = response.getReturnValue();
        // if storeResponse size is equal 0 ,display No Result Found... message on screen.                }
        if (storeResponse.length == 0) {
          component.set("v.Message", 'No Result Found...');
        } else {
          component.set("v.Message", '');
        }
        // set searchResult list with return value from server.
        component.set("v.listOfSearchRecords", storeResponse);
      }

    });
    // enqueue the Action  
    $A.enqueueAction(action);

  },
    
    validateInput: function(component, event, helper){
        var inputField = component.find("searchRes");
        if(component.get("v.isRequired")){
            if($A.util.isEmpty(component.get("v.selectedRecord.Id")) || $A.util.isUndefinedOrNull(component.get("v.selectedRecord.Id"))){
                $A.util.removeClass(inputField,'slds-has-error');
                $A.util.addClass(inputField,'slds-has-error');
                component.set("v.isFieldEmpty",true);
            } else{
                $A.util.removeClass(inputField,'slds-has-error');
                component.set("v.isFieldEmpty",false);
            }
        }
    }
})