({
	validateSRSubcase : function(component,event,helper){
	
		component.set("v.Spinner" , true);
		var srCaseIds = component.get("v.srCaseIds");
		srCaseIds.push(component.get("v.recordId"));
		component.set("v.srCaseIds",srCaseIds);
		var action = component.get("c.validateSRSubCaseRouteToSafety");
        action.setParams({"srCaseIdSet" : component.get("v.srCaseIds")});
        action.setCallback(this,function(response){
            
            //get the response state 
            var state = response.getState();
            if(state === "SUCCESS"){
                var responseWrapper = response.getReturnValue();
                if(!$A.util.isEmpty(responseWrapper) && !$A.util.isUndefined(responseWrapper)){
                	if(!$A.util.isEmpty(responseWrapper.buttonClickErrors) && !$A.util.isUndefined(responseWrapper.buttonClickErrors)){
                		helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , responseWrapper.buttonClickErrors ,$A.get("$Label.c.AG_Error"));
                		return;
                	}
                	if(!$A.util.isEmpty(responseWrapper.srCaseMap) && !$A.util.isUndefined(responseWrapper.srCaseMap) && $A.util.isEmpty(responseWrapper.systemError)){
                		var key = component.get("v.recordId");
                		if(undefined != responseWrapper.srCaseMap[key] && responseWrapper.srCaseMap[key].readyToPick){
                			helper.showToast(component, event, helper,$A.get("$Label.c.AG_Sucess_Toast_Type") , $A.get("$Label.c.AG_Argus_Initiate_SR_Subcase"),$A.get("$Label.c.AG_Sucess_Toast_Type")); 
                		}else if(undefined != responseWrapper.srCaseMap[key] && !responseWrapper.srCaseMap[key].readyToPick){
                			component.set("v.errorList" , responseWrapper.srCaseMap[key].errorMessageList);
                		}
                	}else{
                		helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                	}
                }else{
                	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                }
            } else if(state === "ERROR"){
            	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }else if(state === "INCOMPLETE"){
                helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }
            component.set("v.Spinner" , false);
        });
        $A.enqueueAction(action);
	},
	userSelectHelper : function(component,event,helper){
		// Close the action panel
        var dismissActionPanel = $A.get("e.force:closeQuickAction");
        dismissActionPanel.fire();
		$A.get('e.force:refreshView').fire();
	},
	/*Toast event to show message to user.*/
    showToast : function(component, event, helper,title , message , type) {
    	
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message,
            "type" : type,
            "duration" : 6000
        });
        toastEvent.fire();
        helper.userSelectHelper(component,event,helper);
    }
})