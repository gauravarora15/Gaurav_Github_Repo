({
	doInit : function(component, event, helper) {
		helper.validateSRSubcase(component,event,helper);
	},
	userSelect : function(component,event,helper){
		helper.userSelectHelper(component,event,helper);
	}
})