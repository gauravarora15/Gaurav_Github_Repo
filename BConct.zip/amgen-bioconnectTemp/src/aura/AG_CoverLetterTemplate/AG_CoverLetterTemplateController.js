({
    doInit : function(component,event,helper) {
        helper.handleInit(component, event, helper);
    },

    handleSelectedTempTypeChange: function(component, event, helper){
        helper.handleSelectedTempTypeChange(component, event, helper);
    },
    
    
    handleFormValidation: function(component, event, helper){
        helper.handleFormValidation(component, event, helper);
    },
    handleSelectedUser : function(component, event, helper){
        helper.handleSelectedUser(component, event, helper);
    },
    handleBlur: function(component, event, helper){
        var templateName = component.get("v.templateRecord").AG_Template_Name__c;
      if(($A.util.isEmpty(templateName.trim()) || $A.util.isUndefined(templateName.trim()))
        && (!$A.util.isEmpty(component.get("v.templateRecord").AG_Template_Name__c))){
       component.set("v.showNameError",true);  
        }
       
    },
    handleTemplateSelection: function(component, event, helper) {
        helper.handleTemplateSelectionHelper(component,event,helper);
    },
     populateCountry: function(component, event, helper) {
        helper.populateCountry(component,event,helper);
    },
    handleSearchMergeField: function(component, event, helper){
        helper.handleSearchMergeField(component, event, helper);
    },
    
    handleCancel : function(component , event , helper){
        helper.handleCancel(component , event , helper);
    },

    doNothing : function(component, event, helper){
        console.log('donnneeee');
    },
     copyMergeField : function(component, event, helper){
    helper.handleCopy(component, event, helper);
    } 
})