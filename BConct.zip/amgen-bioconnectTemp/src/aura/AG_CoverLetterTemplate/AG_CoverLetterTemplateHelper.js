({
handleInit: function(component, event, helper) {
    component.set("v.displaySpinner", true);
    var pageReference = component.get("v.pageReference");
    if(!$A.util.isUndefinedOrNull(pageReference.state.c__isClone) && !$A.util.isEmpty(pageReference.state.c__isClone)){
        component.set("v.isClone", pageReference.state.c__isClone);
    }
    if (component.get("v.isClone")) {
        component.set("v.recordId", pageReference.state.c__recordId);
    }
    var action = component.get("c.getTemplateList");
    if(!$A.util.isEmpty(component.get("v.recordId")) && !$A.util.isUndefinedOrNull(component.get("v.recordId"))){
        component.set("v.isEdit",true); 
    } else{
        component.set("v.isEdit",false);
        /*Adding Name to the New Tab*/
		document.title = "New Template"; 
        var workspaceAPI = component.find("workspace");
        workspaceAPI.getFocusedTabInfo().then(function(response) {
            var focusedTabId = response.tabId;
            workspaceAPI.setTabLabel({
                tabId: focusedTabId,
                label: "New Template"
            });
        })
        .catch(function(error) {
            console.log(error);
        });
    }
    action.setParams({
        "isEdit" : component.get("v.isEdit"),
        "recordId" : component.get("v.recordId")
    });
    action.setCallback(this,function(response){
        
        var state = response.getState();
        component.set("v.displaySpinner",false);
        if(state === "SUCCESS"){     
            component.set("v.wrapperList",response.getReturnValue());
			// set the attribute to true if profile is system admin
			component.set("v.isSystemAdmin",component.get("v.wrapperList.isSysAdmin"));
            //set the metadatalist
            component.set("v.lstMetadata",component.get("v.wrapperList.lstMergeFieldMetaData"));
            // set the Country values in the multi picklist
            var optionSelect = response.getReturnValue().lstCountry;
            var options = [];
            for(var i = 0;i<optionSelect.length;i++){
                
                var option = {};
                option.Name = optionSelect[i];
                option.isSelected = false;
                option.Id = optionSelect[i];
                options.push(option);
            } 
            component.set("v.options",options);
            
            if($A.util.isEmpty(component.get("v.wrapperList.errorMessage")) ||
               $A.util.isUndefined(component.get("v.wrapperList.errorMessage"))){
                //server call is success without any exception
                var mapRecordType = [];
                var rtIDVsDeveloperName = component.get("v.wrapperList.mapIDVsRTDeveloperName");
                var serverRT = component.get("v.wrapperList.mapRecordTypes");
                var OpeningTemplateId = '';
                //creating recordType Map to generate Template Type Picklist
                for(var eachkey in serverRT){
                    mapRecordType.push({
                        value: serverRT[eachkey],
                        key: eachkey
                    });
                    
                    if(rtIDVsDeveloperName[serverRT[eachkey]] == 'AG_Opening'){
                        OpeningTemplateId = serverRT[eachkey];
                    }
                }
                component.set("v.recordTypeMap",mapRecordType);
                var mapProduct = [];
                
                var serverProduct = component.get("v.wrapperList.mapProduct");
                
                //to generate Product List
                for(var eachkey in serverProduct){
                    mapProduct.push({
                        value: serverProduct[eachkey],
                        key: eachkey
                    });
                    
                }
                
                component.set("v.productMap",mapProduct);
                
                //for using Data Table will remove if we dont need
                component.set('v.mycolumns', [{
                    label: 'Object Name',
                    fieldName: 'AG_Object_Label__c',
                    type: 'text',
                    cellAttributes: {
                        class: 'slds-no-row-hover'
                    }
                },
                                              {
                                                  label: 'Field Name',
                                                  fieldName: 'AG_Field_Label__c',
                                                  type: 'text',
                                                  cellAttributes: {
                                                      class: 'slds-no-row-hover'
                                                  }
                                              },
                                              {
                                                  label: 'Merge Field',
                                                  fieldName: 'AG_Merge_Field_Val__c',
                                                  type: 'text',
                                                  cellAttributes: {
                                                      class: 'slds-no-row-hover'
                                                  }
                                              }
                                             ]);
                var array;
                var editOptions = [];
                if (component.get("v.isEdit")) {
                    component.set("v.templateRecord", component.get("v.wrapperList.templateRecord"));
                    //set The UserLookup
                    component.set("v.selectedTemplateRT", component.get("v.templateRecord.RecordType.DeveloperName"));
                    component.set("v.selectedUserLookUpRecord.Id", component.get("v.wrapperList.templateRecord.AG_User_Name__c"));
                    component.set("v.selectedUserLookUpRecord.Name", component.get("v.wrapperList.templateRecord.AG_User_Name__r.Name"));
                    
                    if (!$A.util.isEmpty(component.get("v.templateRecord.AG_Product__c")) &&
                        !$A.util.isUndefined(component.get("v.templateRecord.AG_Product__c"))) {
                        component.set("v.selectedProduct", component.get("v.templateRecord.AG_Product__r.Name"));
                    }
                    
                      
                        
                    
                    if (component.get("v.isClone")) {
                        component.set('v.templateRecord.AG_Status__c',$A.get("$Label.c.AG_Draft") );
                    }
                    else
                    {
                        component.set("v.selectedStatus",component.get("v.templateRecord.AG_Status__c"));
                        if(component.get("v.selectedStatus") == 'Archived' || component.get("v.selectedStatus") == 'Removed'){
                            component.find("statusField").set("v.disabled",true);
                        }
                    }
                    if(!$A.util.isEmpty(component.get("v.templateRecord.AG_Country__c")) &&
                       !$A.util.isUndefined(component.get("v.templateRecord.AG_Country__c"))){
                        var countryString = component.get("v.templateRecord.AG_Country__c");
                        array = countryString.split(";");
                        // component.set("v.selectedPickVals",array);
                        var allCountry=response.getReturnValue().lstCountry;
                        for(var i = 0;i<allCountry.length;i++){
                            
                            var option = {};
                            option.Name = allCountry[i];
                            if(array.includes(allCountry[i])){
                               option.isSelected = true; 
                            }
                            else{
                                option.isSelected = false;
                            }
                            
                            option.Id = allCountry[i];
                            editOptions.push(option);
                        }
                        component.set("v.options",editOptions);
                    }
                } else {
                    component.set('v.selectedTemplateRT', 'AG_Opening'); //setting the first value as selected 
                    component.set('v.templateRecord.RecordTypeId', OpeningTemplateId);
                    component.set('v.templateRecord.AG_Status__c', $A.get("$Label.c.AG_Draft"));
                }
            } else {
                helper.showToastNotification(component, event, helper, $A.get("$Label.c.AG_errorMessage"), 'error');
            }
        } else if (state === "INCOMPLETE") {
            helper.showToastNotification(component, event, helper, $A.get("$Label.c.AG_errorMessage"), 'error');
            
        } else {
            helper.showToastNotification(component, event, helper, $A.get("$Label.c.AG_errorMessage"), 'error');
        }
    });
    $A.enqueueAction(action);
    
    
    
},

/*set value in User Name field for Signature Template*/
handleSelectedUser: function(component, event, helper) {
    component.set("v.templateRecord.AG_User_Name__c", component.get("v.selectedUserLookUpRecord.Id"));
},

/*This method is called when a Template selection is made/modfied*/
handleTemplateSelectionHelper: function(component, event, helper) {
    
    var template = event.getSource().get("v.value");
    
    var serverRTIdVsDN = component.get("v.wrapperList.mapIDVsRTDeveloperName");
    for (var temp in serverRTIdVsDN) {
        if (template == temp) {
            component.set("v.selectedTemplateRT", serverRTIdVsDN[temp]);
            break;
        }
    }
    
},     


/* method to populate the country field */
populateCountry : function(component, event, helper) {
    
    var templateData = event.getParam("templateIds"); 
    var countryText='';
    for(var i = 0;i<templateData.length;i++)
    {
        if(countryText == '')
        {
            countryText = templateData[i];
        }
    else{
        countryText = countryText+ ';'+templateData[i];}
    
    }
    component.set("v.templateRecord.AG_Country__c",countryText);
    
}, 
/* to hide certain fields if Template Type is Agent Note Template*/
handleSelectedTempTypeChange: function(component, event, helper) {
    
    if (component.get("v.selectedTemplateRT") == 'AG_Agent_Note_Template') {
        component.set("v.hideFieldForAgent", true);
    } else {
        component.set("v.hideFieldForAgent", false);
    }
    if (component.get("v.selectedTemplateRT") == 'AG_MI_Fulfillment_Cover_Letter_Footer') {
        component.set("v.hideFieldForFooter", true);
    } else {
        component.set("v.hideFieldForFooter", false);
    }
    if (component.get("v.selectedTemplateRT") == 'AG_Product_Statement') {
        component.set("v.showProduct", true);
    } else {
        component.set("v.showProduct", false);
    }
    if (component.get("v.selectedTemplateRT") == 'AG_Email_body') {
        component.set("v.showForEmailBody", true);
    } else {
        component.set("v.showForEmailBody", false);
    }
    if (component.get("v.selectedTemplateRT") == 'AG_MI_Fulfillment_Signature') {
        component.set("v.hideFieldForSignature", true);
        if(!$A.util.isEmpty(component.get("v.templateRecord.AG_User_Name__c")))
        {
            component.find("Usernamecheck").preselectValue();
        }
    }
     else {
        component.set("v.hideFieldForSignature", false);
    }if (component.get("v.selectedTemplateRT") == 'AG_MI_Fulfillment_Cover_Letter_Footer') {
        component.set("v.isFooterTemplate", true);
    } else {
        component.set("v.isFooterTemplate", false);
    }
    
    
},

/* to search merge field*/
handleSearchMergeField: function(component, event, helper){
    var searchString = component.find("searchMerge").get("v.value");
    if(searchString.length > 2){
        component.find("searchMerge").set("v.isLoading",true);
        var action = component.get("c.searchMergeField");
        action.setParams({
            "seachString" : searchString
        });
        action.setCallback(this,function(response){
            component.find("searchMerge").set("v.isLoading",false);
            var state = response.getState();
            if (state === "SUCCESS") {
                if (!$A.util.isEmpty(response.getReturnValue()) && !$A.util.isUndefined(response.getReturnValue())) {
                    component.set("v.lstMetadata", response.getReturnValue());
                } else {
                    console.log('error in search string');
                }
            } else {
                console.log('error in search');
            }
        });
        $A.enqueueAction(action);
    }
	else{
        component.set("v.lstMetadata",component.get("v.wrapperList.lstMergeFieldMetaData"));
    }
},

handleFormValidation: function(component, event, helper) {
    //component.set("v.displaySpinner",true);
    var hasError = false;
    component.set("v.showStatusError", false);
    $A.util.removeClass(component.find("statusField"), 'slds-has-error');
    component.find('tempName').setCustomValidity("");
    component.find('tempName').reportValidity();
    
    //finding field level errors
    
    /*fetching all field using common aura id and using reduce function to show error on them was not working
     *since we are dealing with only two fields, i could easily deal with them individually
     */
    
    if ($A.util.isEmpty(component.find('tempName').get("v.value").trim()) || $A.util.isEmpty(component.find('tempName').get("v.value"))) {
        component.find('tempName').setCustomValidity("Complete this field.");
        component.find('tempName').reportValidity();
        hasError = true;
    }
    
    /*************** Product Error when required************/
    
    if ((component.get("v.selectedTemplateRT") == 'AG_Product_Statement')) {
        if ($A.util.isEmpty(component.get("v.templateRecord.AG_Product__c")) || $A.util.isUndefined(component.get("v.templateRecord.AG_Product__c"))) {
            component.set("v.showProductError", true);
            $A.util.addClass(component.find("prodId"), 'slds-has-error');
            hasError = true;
        }
    } else {
        component.set("v.showProductError", false);
        /*set product as null if it was set*/
        component.set("v.templateRecord.AG_Product__c", '');
    }
    
    
    /************Dynamic field error**************/
    if (component.get("v.selectedTemplateRT") == 'AG_Water_Mark') {
        var dynamicWater = '';
        dynamicWater = component.get("v.templateRecord.AG_Dynamic_WaterMark__c");
        var dynamicWater1 = ''
       /* if ($A.util.isEmpty(component.get("v.templateRecord.AG_Dynamic_WaterMark__c")) || $A.util.isUndefined(component.get("v.templateRecord.AG_Dynamic_WaterMark__c"))) {
            component.set("v.showDynamicError", true);
            hasError = true;
        }*/
/*****************/
 if($A.util.isEmpty(component.get("v.templateRecord.AG_Dynamic_WaterMark__c")) || $A.util.isUndefined(component.get("v.templateRecord.AG_Dynamic_WaterMark__c"))){
                component.set("v.showDynamicError",true);
                hasError = true;
            }else{
                
                dynamicWater1 = dynamicWater.replace('<p>','').replace('</p>','').trim(); 
                
                if($A.util.isEmpty(dynamicWater1))
                {
                    component.set("v.showDynamicError",true);
                    hasError = true;
                }else{
                    component.set("v.showDynamicError",false);
                }   
            }

/*********************/

    } else {
        component.set("v.showDynamicError", false);
        /*if watermark value was set, make it null*/
        component.set("v.templateRecord.AG_Dynamic_WaterMark__c", '');
        
    }
    
    /************Validation for MI Fulfillment Signature ****************/
    
    if (component.get("v.selectedTemplateRT") == 'AG_MI_Fulfillment_Signature') {
        if ($A.util.isEmpty(component.get("v.templateRecord.AG_User_Name__c")) || $A.util.isUndefinedOrNull(component.get("v.templateRecord.AG_User_Name__c"))) {
            hasError = true;
            component.set("v.showUserError", true);
        } else {
            component.set("v.showUserError", false);
        }
    } else {
        /*set User Error as null. Set User value as null*/
        component.set("v.templateRecord.AG_User_Name__c", '');
    }
 /*********************** Cover Letter Field error ****************************/
   if(component.get("v.selectedTemplateRT") == 'AG_MI_Fulfillment_Cover_Letter_Footer'){
            var footer1 = '';
            var footer = '';
            footer = component.get("v.templateRecord.AG_Footer_on_cover_letter_1st_page__c");
            
            if($A.util.isEmpty(component.get("v.templateRecord.AG_Footer_on_cover_letter_1st_page__c")) || $A.util.isUndefined(component.get("v.templateRecord.AG_Footer_on_cover_letter_1st_page__c"))){
                component.set("v.showCoverLetterError",true);
                hasError = true;
            }else{
                
                footer1 = footer.replace('<p>','').replace('</p>','').trim(); 
                
                if($A.util.isEmpty(footer1))
                {
                    component.set("v.showCoverLetterError",true);
                    hasError = true;
                }else{
                    component.set("v.showCoverLetterError",false);
                }   
            }
        }
        
    /*************erro closure ****************/
    
    if (component.get("v.isEdit") && !component.get("v.isClone") && !component.get("v.isSystemAdmin")) {
        if (component.get("v.selectedStatus") != component.get("v.templateRecord.AG_Status__c")) {
            if (component.get("v.selectedStatus") == 'Draft' && component.get("v.templateRecord.AG_Status__c") == 'Archived') {
                component.set("v.showStatusError", true);
                $A.util.addClass(component.find("statusField"), 'slds-has-error');
                hasError = true;
            } else if (component.get("v.selectedStatus") == 'Active' &&
                       (component.get("v.templateRecord.AG_Status__c") == 'Draft' || component.get("v.templateRecord.AG_Status__c") == 'Removed')) {
                component.set("v.showStatusError", true);
                $A.util.addClass(component.find("statusField"), 'slds-has-error');
                hasError = true;
                
            } else {
                component.set("v.showStatusError", false);
            }
        }
    }
    
    
    if (!hasError) {
        helper.handleSave(component, event, helper);
    }
},

// method to save the record in system
handleSave: function(component, event, helper) {
	component.set("v.displaySpinner", true);
    component.set("v.showNameError", false);
    var action = component.get("c.saveTemplate");
    action.setParams({
        "templateRecord": JSON.stringify(component.get("v.templateRecord")),
        "recordId": component.get("v.recordId"),
        "isClone": component.get("v.isClone")
    });
    action.setCallback(this, function(response) {
        var state = response.getState();
        if (state === "SUCCESS") {
            var returnVal = response.getReturnValue();
            if(returnVal.hasError){
                if(returnVal.hasMergeFieldError){
                    component.set("v.validMergeFields", true);
                    component.set("v.errorOnMergeFields", true); 
                    component.set("v.incorrectMergeFields",returnVal.errorString);      
                }else{
                    helper.showToastNotification(component, event, helper, returnVal.errorString, 'error');
                }    
            }
            else{
                if (component.get("v.isEdit")) {
                    helper.showToastNotification(component, event, helper, $A.get("$Label.c.AG_Template_Edit_Success"), 'success');
                } else{
                    helper.showToastNotification(component, event, helper, $A.get("$Label.c.AG_Template_Create_Success"), 'success');
                }
      
                var workspaceAPI = component.find("workspace");
        workspaceAPI.getFocusedTabInfo().then(function(response) {
            var focusedTabId = response.tabId;
            
            //Opening New Tab
            workspaceAPI.openTab({
                pageReference: {
                "type": "standard__recordPage",
                "attributes": {
                    "recordId":returnVal.returnRecordId,
                    "actionName":"view"
                },
                "state": {}
            },
            }).then(function(response) {
                workspaceAPI.closeTab({tabId: focusedTabId});
                workspaceAPI.focusTab({tabId : response});
				workspaceAPI.refreshTab({
                      tabId: response,
                      includeAllSubtabs: true
             });
            })
            .catch(function(error) {
                console.log(error);
            });

            //Closing old one
            
        })
        .catch(function(error) {
            console.log(error);
        });


                }
            } else {
                helper.showToastNotification(component, event, helper, $A.get("$Label.c.AG_errorMessage"), 'error');
            }
			component.set("v.displaySpinner", false);
        });
        $A.enqueueAction(action);
    },

// method to show the toast message
showToastNotification: function(component, event, helper, message, type){
    var toastEvent = $A.get("e.force:showToast");
    toastEvent.setParams({
        message: message,
        type: type,
    });
    toastEvent.fire();
},

/****************method to copy paste the data from Merge Field Set************/
handleCopy: function(component, event, helper) {
    var mergeField = event.currentTarget.dataset.index;
    var recordType = component.get("v.selectedTemplateRT");
    var description = '';
    //CHECK FOR RECORD TYPE AND ACCORDINGLY COPY DESCRIPTION
        if (recordType ==  $A.get("$Label.c.AG_Watermark_Statement_Template_RT")) {
            if(!$A.util.isUndefinedOrNull(component.get("v.templateRecord.AG_Dynamic_WaterMark__c")))
            {
                var dynamic = component.get("v.templateRecord.AG_Dynamic_WaterMark__c");
                var modified = dynamic.substring(0, dynamic.length - 4);
                description = dynamic +' '+mergeField;
            }
            else
            {
                description = mergeField;
            }
        component.set("v.templateRecord.AG_Dynamic_WaterMark__c", description);
       } 
        else if (recordType == $A.get("$Label.c.AG_MI_Fulfillment_Cover_Letter_Footer_DeveloperName")) {
            var buttonId = event.currentTarget.id;
            if(buttonId == 'footer1')
            {
                if(!$A.util.isUndefinedOrNull(component.get("v.templateRecord.AG_Footer_on_cover_letter_1st_page__c")))
                {
                    var footerDescription = component.get("v.templateRecord.AG_Footer_on_cover_letter_1st_page__c");
                    var modified = footerDescription.substring(0, footerDescription.length - 4);
                    description = footerDescription +' '+mergeField;
                }
                else{
                    description = mergeField;
                }
            component.set("v.templateRecord.AG_Footer_on_cover_letter_1st_page__c", description);
        }
        else if(buttonId == 'footer2')
        {
             if(!$A.util.isUndefinedOrNull(component.get("v.templateRecord.AG_Footeronsubsequent_pages_of_the_cover__c")))
            {
                var footerDescription = component.get("v.templateRecord.AG_Footeronsubsequent_pages_of_the_cover__c");
                var modified = footerDescription.substring(0, footerDescription.length - 4);
                description = footerDescription +' '+mergeField;
            }
            else{
                description = mergeField;
            }
            component.set("v.templateRecord.AG_Footeronsubsequent_pages_of_the_cover__c", description);
        }       
    }
    else{
            if(!$A.util.isUndefinedOrNull(component.get("v.templateRecord.AG_Description__c")))
            {
                var currentVal = component.get("v.templateRecord.AG_Description__c");
                var modified = currentVal.substring(0, currentVal.length - 4);
                description = currentVal +' '+mergeField;
            }
            else
            {
                description = mergeField;
            } 
            component.set("v.templateRecord.AG_Description__c", description);
       }
},
/* method to handle the cancel action*/
handleCancel:function(component){
    var workspaceAPI = component.find("workspace");
    if(component.get("v.isEdit")){
        workspaceAPI.getFocusedTabInfo().then(function(response) {
            var focusedTabId = response.tabId;
            workspaceAPI.closeTab({tabId: focusedTabId});
            workspaceAPI.openTab({
                recordId: component.get('v.recordId'),
                focus: true
            });
        })
        .catch(function(error) {
            console.log(error);
        });
    } else{
        workspaceAPI.getFocusedTabInfo().then(function(response) {
            var focusedTabId = response.tabId;
            workspaceAPI.closeTab({tabId: focusedTabId});
        })
        .catch(function(error) {
            console.log(error);
        });
    }
}

})