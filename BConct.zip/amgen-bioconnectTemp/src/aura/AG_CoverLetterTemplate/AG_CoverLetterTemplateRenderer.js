({
    afterRender : function(component, helper) {
        this.superAfterRender();
        var workspaceAPI = component.find("workspace");
        workspaceAPI.getAllTabInfo().then(function(response) {
        	response.forEach(function(element) {
        		  if(undefined != element.pageReference.attributes.componentName && 
				  element.pageReference.attributes.componentName == $A.get("$Label.c.AG_CoverLetterTemplate")){
					  workspaceAPI.setTabLabel({
		                tabId: element.tabId,
		                label: $A.get("$Label.c.AG_New_Template")
					  });

				workspaceAPI.setTabIcon({
            	tabId: element.tabId,
           		icon: "custom:custom56", //set icon you want to set
           		iconAlt: $A.get("$Label.c.AG_New_Template") //set label tooltip you want to set
        		});
                            
				  }
			});
        }).catch(function(error) {
            console.log(error);
        });
    }
})