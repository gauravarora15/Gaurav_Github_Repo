({
	doInit : function(component, event, helper) {
		helper.getData(component,event,helper);
	},
    handleMenuSelect : function(component , event , helper){
    	helper.CreateResponses(component , event , helper);    
    },
    userSelect : function(component, event, helper) {
		helper.userSelectHelper(component , event , helper);	
	},
	handleResponseDelete : function(component , event , helper){
		helper.handleResponseHelper(component , event , helper);
	},
	handleResponseUpdate : function(component , event , helper){
		helper.handleRespUpdateHelper(component , event , helper);
	}
	
	
})