({
    getData : function(component,event,helper) {
        
        document.title = $A.get("$Label.c.AG_Fulfilment");
        component.set("v.Spinner" , true);
        component.set("v.disableNext",false);
        var action = component.get("c.getSubCaseDetails");
        action.setParams({"CaseId" : component.get("v.CaseId"),
        				 "fudId": component.get("v.fulfillmentUserDataId")
        				});
        action.setCallback(this,function(a){
            
            //get the response state
            var state = a.getState();
            
            if(state === "SUCCESS"){
                var custs = [];
                var response = a.getReturnValue();
                component.set("v.masterCaseWrapper" , response);
                component.set("v.requestsSelection" , response.userSelectedData.mapRequestIdVsSelected);
                component.set("v.documentsReordered" , response.userSelectedData.ResponseIds);
				component.set("v.fulfillmentUserDataId", response.userDataId);
                if(response.allowFulfillment == false){
                	component.set("v.ErrorMessage" , $A.get("$Label.c.AG_AccessFulfillmentErrorMessage"));
                	component.set("v.Spinner" , false);
                	return;
                }
                if(response.masterCase.Status == $A.get("$Label.c.AG_Case_Status_Void")){
                	component.set("v.ErrorMessage" , $A.get("$Label.c.AG_Error_Void_Status"));
                	component.set("v.Spinner" , false);
                	return;
                }
                
                if(response.responseCount == 0){
                	component.set("v.disableNext",true);
                	component.set("v.ErrorMessageOnNextButton",$A.get("$Label.c.AG_ErrorMessage_NoResponse"));//
                }
                if($A.util.isEmpty(response.exceptionMessage)){
	                var conts = response.mapScaseReqWrap;
	                if(Object.keys(conts).length != 0){
	                    for ( var key in conts ) {
	                        custs.push({key:key,value:conts[key]});
	                    }
	                    component.set("v.reponses", custs);
	                }else{
	                	component.set("v.disableNext",true);
	                	component.set("v.ErrorMessageOnNextButton",$A.get("$Label.c.AG_ErrorMessage_NoRequest"));
	                }
                }else{
                	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                }
                component.set("v.Spinner" , false);
            } else if(state === "ERROR"){
            	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }else if(state === "INCOMPLETE"){
                	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }
            component.set("v.Spinner" , false);
        });
        $A.enqueueAction(action);
    },
    CreateResponses : function(component , event , helper){
        
        component.set("v.Spinner" , true);
        var selectedMenuItemValue = event.getParam("value");
        var parameters = selectedMenuItemValue.split(",");
        if(parameters.length === 2){
            
            var requestId = parameters[0];
            var requestType = parameters[1];
            if(requestType === 'AttachDocument'){
                helper.attachDocument(component,event , helper , requestId);
            }else if(requestType === 'AttachResponseForRequest' || requestType === 'AttachResponseForMasterCase'){
                helper.searchDocument(component,event,helper,requestId,requestType);
            }else if(requestType === 'AttachResponseFromEpic' || requestType === 'AttachResponseFromEpicForMasterCase'){
                helper.searchEpicDocument(component, event, helper, requestId, requestType);
            }
        }    
    },
    attachDocument : function(component , event , helper , parentId){
		var modalBody;
        $A.createComponent("c:AG_Fulfill_AttachDocument", {"requestId" : parentId , "masterCaseId" : component.get("v.CaseId")},
           function(content, status) {
               if (status === "SUCCESS") {
                   modalBody = content;
                   component.find('overlayLib').showCustomModal({
                       header: $A.get("$Label.c.AG_UploadDocument"),
                       body: modalBody, 
                       showCloseButton: true,
                       cssClass: "mymodal",
                       closeCallback: function() {
                       		helper.getData(component , event , helper);   
                       }
                   })
               }                               
           }); 
        component.set("v.Spinner" , false);             
    },
    searchDocument : function(component , event , helper,parentId,requestType){
    	var forMasterCase;
    	if(requestType == 'AttachResponseForRequest'){
    		forMasterCase = false;
    	}else{
    		forMasterCase = true;
    	}
    	var modalBody;
        $A.createComponent("c:AG_FulFill_AttachResponseToRequest", {"parentId" : parentId , "forMasterCase" : forMasterCase},
           function(content, status) {
               if (status === "SUCCESS") {
                   modalBody = content;
                   component.find('overlayLib').showCustomModal({
                       header: $A.get("$Label.c.AG_Attach_Response_Volt"),
                       body: modalBody, 
                       showCloseButton: true,
                       cssClass: "slds-modal_large",
                       closeCallback: function() {
                    	   helper.getData(component  ,event , helper);
                       }
                   })
               }                               
           }); 
        component.set("v.Spinner" , false);     	    
    },

    searchEpicDocument:function(component, event, helper, parentId, requestType){
        var forMasterCase;
        if(requestType == 'AttachResponseFromEpic'){
            forMasterCase = false;
        }else{
            forMasterCase = true;
        }
        var modalBody;
        $A.createComponent("c:AG_Fulfill_AttachEpicResponseToRequest", {"parentId" : parentId , "forMasterCase" : forMasterCase},
           function(content, status) {
               if (status === "SUCCESS") {
                   modalBody = content;
                   component.find('overlayLib').showCustomModal({
                       header: $A.get("$Label.c.AG_AttachResponseFromEpic"),
                       body: modalBody, 
                       showCloseButton: true,
                       cssClass: "slds-modal_large",
                       closeCallback: function() {
                           helper.getData(component  ,event , helper);
                       }
                   })
               }                               
           }); 
        component.set("v.Spinner" , false);     

    },
    userSelectHelper : function(component , event , helper){
    	
    	component.set("v.Spinner", true);
        var key = event.getSource().getLocalId();
        
        if(key === 'next'){
            helper.navigateToComponents(component,event , helper,2 , key);
        }else if(key === 'close'){
            helper.navigateToComponents(component,event , helper,0 , key);
        }else if(key === 'cancel'){
            helper.navigateToComponents(component,event , helper,0 , key);
        }
    },
    navigateToComponents  : function(component , event , helper,componentNo , key){
        var compEvent = component.getEvent("navigateComponent");
        if(key === 'cancel'){
        	compEvent.setParams({"componentNo" : componentNo });
        	compEvent.fire();
        }else{
        	var saveData = false;
	        if(componentNo == 2){
	        	saveData = true;
	        }
	        compEvent.setParams({"componentNo" : componentNo ,
	        					"masterCaseWrapper" : JSON.stringify(component.get("v.masterCaseWrapper")),
	        					"selectedRequests" : component.get("v.requestsSelection"),
	        					"documentsReordered" : component.get("v.documentsReordered"),
	        					"saveAndClose" : !saveData ,
	        					"saveData" : saveData ,
	        					"fulfillmentPackageId":component.get("v.fulfillmentPackageId"),
	        					"fulfillmentUserData":component.get("v.fulfillmentUserDataId")}); 
			compEvent.fire();
        }
        
    },
    handleResponseHelper : function(component , event , helper){
    	 
    	 component.set("v.Spinner", true);
    	 var respID = event.target.id;
    	 var action = component.get("c.deleteResponses");
         
         action.setParams({"responseId" : respID});
        
         action.setCallback(this,function(response){
            
            //get the response state
            var state = response.getState();
            //check if result is successfull
            if(state === "SUCCESS"){
            	var isDeleted = response.getReturnValue();
            	if(isDeleted){
            		helper.showToast(component, event, helper,$A.get("$Label.c.AG_Sucess_Toast_Type") , $A.get("$Label.c.AG_ResponseRemoveMessage"),$A.get("$Label.c.AG_Sucess_Toast_Type"));
            		helper.getData(component , event , helper);
            	}else{
            		helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            		helper.getData(component , event , helper);
            	}
            	
            } else if(state === "ERROR"){
            	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                component.set("v.Spinner", false);
            }else if(state === "INCOMPLETE"){
                	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }
         });
        
        $A.enqueueAction(action);
    },
    showToast : function(component, event, helper,title , message , type) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message,
            "type" : type
        });
        toastEvent.fire();
    },
    handleRespUpdateHelper : function(component, event, helper){
    	
    	component.set("v.Spinner", true);
    	var res = event.getSource().get("v.value");
    	var act = component.get("c.updateResponses");
        act.setParams({"responseInstance" : JSON.stringify(res)});
        act.setCallback(this,function(a){
            
            //get the response state
            var state = a.getState();
            
            if(state === "SUCCESS"){
                var custs = [];
                var response = a.getReturnValue();
                
                if(!$A.util.isEmpty(response)){
	                if(response){
	                	helper.getData(component , event , helper);
	                }else{
	                	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
	                	component.set("v.Spinner" , false);
	                }
                }else{
                	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                	component.set("v.Spinner" , false);
                }
                
            } else if(state === "ERROR"){
            	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            	component.set("v.Spinner" , false);
            }else if(state === "INCOMPLETE"){
                	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                	component.set("v.Spinner" , false);
            }
            
        });
        $A.enqueueAction(act);
    },
   /* previewModeHelper : function(component ,event,helper){
    	
    	var document = event.target.id;
    	var parameters = document.split(",");
        if(parameters.length === 2){
        	var docId = parameters[0];
            var docSize = parameters[1];
            if(parseInt(docSize) >$A.get("$Label.c.AG_File_Size")){
            	helper.openPromptComponent(component , event , helper);
            }else{
            	helper.fetchVoltData(component,event,helper,docId);
            }
        }else{
        	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            component.set("v.Spinner" , false);
        }
    },*/
    openPromptComponent : function(component,event,helper){
    	var modalBody;
        $A.createComponent("c:AG_Reusable_Prompt_Component", {"message" : $A.get("$Label.c.AG_File_Size_Limit") , 
        					"confirm":component.getReference('v.confirm') , "isPrompt":false},
           function(content, status) {
               if (status === "SUCCESS") {
                   modalBody = content;
                   component.find('overlayLib').showCustomModal({
                       header: $A.get("$Label.c.AG_Label_Warning"),
                       body: modalBody, 
                       showCloseButton: false,
                       cssClass: "mymodal",
                       closeCallback: function() {
                    	   component.set("v.Spinner" , false);
                       }
                   })
               }                               
           });
    },
    fetchVoltData : function(component,event,helper,documentId){
    	component.set("v.Spinner" , true);
        var action = component.get("c.getPdfContent");
        action.setParams({ docId : documentId});
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            
            if (state === "SUCCESS") {
                var pdfData = response.getReturnValue();
                var modalBody;
		        $A.createComponent("c:AG_PDFViewer", {"pdfData" : pdfData},
		           function(content, status) {
		               if (status === "SUCCESS") {
		                   modalBody = content;
		                   component.find('overlayLib').showCustomModal({
		                       header: 'Document',
		                       body: modalBody, 
		                       showCloseButton: true,
		                       cssClass: "slds-modal_large",
		                       closeCallback: function() {
		                    	   helper.getData(component  ,event , helper);
		                       }
		                   })
		               }                               
		           }); 
            }
            component.set("v.Spinner" , false);
        });
        $A.enqueueAction(action);
    }
    
})