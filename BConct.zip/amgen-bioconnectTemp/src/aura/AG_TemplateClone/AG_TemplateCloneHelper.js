({
doInit: function(component, event, helper){
var recordId = component.get("v.recordId");
component.set("v.displaySpinner",true);

var action = component.get("c.validate");
 action.setParams({
    "recId" : recordId
});
action.setCallback(this,function(response){
    //get the response state
    var state = response.getState();
    //check if result is successfull
    if(state === "SUCCESS"){
        var returnMasterCase = response.getReturnValue();

        //If user have create permission navigate to Create Edit component
        if(returnMasterCase)
        {
            component.set("v.displaySpinner",false);
            var pageReference = {
            type: 'standard__component',
            attributes: {
                componentName: 'c__AG_CoverLetterTemplate',

            },
             state: {
                "c__recordId":recordId,
                "c__isClone":'true'
            }
            };
        component.set("v.pageReference", pageReference);
         var navService = component.find("navService");
         var pageReference = component.get("v.pageReference");
         navService.navigate(pageReference); 

        }
        //If user don't have create permission through error message
        else   
        {
            component.set("v.displaySpinner",false);
            helper.showErrorPrompt(component, event, helper, $A.get("$Label.c.AG_Template_Clone_Restrict"))
        }           

    }
    else if(state === "INCOMPLETE"){
        // Show toast on error case
        helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_Template_Clone_Error"));
        
    }
    else if(state === "ERROR"){
        // Show toast on error case
        helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_Template_Clone_Error"));
        
    }
    

});
component.set("v.displaySpinner",false);
$A.enqueueAction(action);

},

showErrorPrompt: function(component, event, helper, errorMessage){
    helper.showToast( "error","Error",errorMessage);
    var dismissActionPanel = $A.get("e.force:closeQuickAction");
    dismissActionPanel.fire();
},
   
showToast: function(toastTitle, toastType, toastMessage){
var toastEvent = $A.get("e.force:showToast");
toastEvent.setParams({
    "title": toastTitle,
    "type": toastType,
    "message": toastMessage
});
toastEvent.fire();
}


})