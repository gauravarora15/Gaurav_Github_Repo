({
    doInit : function(component, event, helper) {
        var recordId = component.get("v.recordId");
        component.set("v.displaySpinner" , true);
        var action = component.get("c.checkResendStatus");        
        action.setParams({"fullFillPackgeId" : recordId});
        action.setCallback(this,function(response){
            
            var state = response.getState();
            
            if(state === "SUCCESS") {
                component.set("v.displaySpinner" , false);
                if(!$A.util.isEmpty(response.getReturnValue().returnMessage) && !$A.util.isUndefined(response.getReturnValue().returnMessage)){
                    helper.openPromptComponent(component,event,helper, response.getReturnValue().returnMessage);
                }else{
                    if(response.getReturnValue().status==$A.get("$Label.c.AG_Cancelled_Status_Label")){
                   helper.openPromptComponent(component,event,helper, $A.get("$Label.c.AG_CancelledStatusValidation"));
                }
                else {
                    if(response.getReturnValue().returnValue) {
                        helper.navigateToFullfillment(component, event, helper);
                    }
                    else {
                        helper.openPromptComponent(component,event,helper, $A.get("$Label.c.AG_Resend_Validation"));
                    }
                }
                }
                
            }
            else if (state === "INCOMPLETE") {
                component.set("v.displaySpinner" , false);
                helper.openPromptComponent(component, event, helper,$A.get("$Label.c.AG_Resend_Service_Unavailable"));
            }
            else if (state === "ERROR") {
                component.set("v.displaySpinner" , false);
                helper.openPromptComponent(component, event, helper,$A.get("$Label.c.AG_Resend_Service_Unavailable"));
            }
        });
        $A.enqueueAction(action); 
    }
})