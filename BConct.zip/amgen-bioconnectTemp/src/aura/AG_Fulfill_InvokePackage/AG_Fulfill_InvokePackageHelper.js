({
	navigateToFullfillment : function(component, event, helper) {
        var recordId = component.get("v.recordId");
        var defaultScreen = component.get("v.defaultScreen");
        var pageReference = {
            type: 'standard__component',
            attributes: {
                componentName: 'c__AG_FulfillmentContainer',

            },
            state: {
                "c__packageId": recordId,
                 "c__defaultScreen" : defaultScreen,
                 "c__navigateToCase" : false

            }
        };
        component.set("v.pageReference", pageReference);
        var navService = component.find("navService");
        var pageReference = component.get("v.pageReference");
        //event.preventDefault();
        navService.navigate(pageReference); 
    },
    //SHOW PROMPT TO INFORM THAT NEW VERSION CANNOT BE CREATED BASED ON CURRENT STATUS.
    openPromptComponent : function(component,event,helper, message){
        
        var modalBody;
        $A.createComponent("c:AG_Reusable_Prompt_Component", {"message" : message ,"isPrompt":false},
           function(content, status) {
               if (status === "SUCCESS") {
                   modalBody = content;
                   component.find('overlayLib').showCustomModal({
                       header: $A.get("$Label.c.AG_Error"),
                       body: modalBody, 
                       showCloseButton: false,
                       cssClass: "mymodal",
                       closeCallback: function() {
                           helper.userPromptHelper(component,event,helper);
                       }
                   })
               }                               
           });
    },
    //NAVIGATE BASED ON USER SELECTION
    userPromptHelper : function(component , event , helper){ 
    	//NAVIGATE TO FULFILLMENT PACKAGE
    	if(!$A.util.isEmpty(component.find("overlayLib")) && !$A.util.isUndefinedOrNull(component.find("overlayLib"))){
    		component.find("overlayLib").notifyClose();
    		$A.get("e.force:closeQuickAction").fire();
    	}
    }
})