({
    //Select or unselect the option
	toggleselection : function(component, event, helper) {
		helper.toggleSelection(component, event);
	}
})