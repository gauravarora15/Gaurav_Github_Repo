({
    loadWizard : function(component , event , helper) {
    	
        var pageReference = component.get("v.pageReference");
        component.set("v.caseId", pageReference.state.c__caseId);
        component.set("v.packageId", pageReference.state.c__packageId);
        component.set("v.defaultScreen", pageReference.state.c__defaultScreen);
        component.set("v.userDataId", pageReference.state.c__userDataId);
        component.set("v.navigateToCase",pageReference.state.c__navigateToCase);
        var defaultScreen =component.get("v.defaultScreen");
        helper.createComponent(component , event , helper , defaultScreen); 
      	
    },
    createComponent : function(component , event , helper,componentNo){
        if(componentNo == 0){
        	if(component.get("v.navigateToCase")){
        		helper.navigateToMasterCase(component , event , helper);
        	}else{
        		helper.navigateToPackage(component , event , helper);
        	}
        }
        else if(componentNo == 1){
        	var packageId = '';
        	if(!$A.util.isUndefined(component.get("v.packageId"))){
        		packageId = component.get("v.packageId");
        	}else if(!$A.util.isUndefined(event.getParam("fulfillmentPackageId"))){
        		packageId = event.getParam("fulfillmentPackageId");
        	}
        	var requestsSelection = event.getParam("selectedRequests");
        	var documentsReordered = event.getParam("documentsReordered");
        	var userDataId = '';
        	if(!$A.util.isUndefined(component.get("v.userDataId"))){
        		userDataId = component.get("v.userDataId");
        	}else if(!$A.util.isUndefined(event.getParam("fulfillmentUserData"))){
        		userDataId = event.getParam("fulfillmentUserData");
        	}
        	if($A.util.isUndefined(requestsSelection)){
        		requestsSelection = {};
        	}
        	if($A.util.isUndefined(documentsReordered)){
        		documentsReordered = [];
        	}
        	if($A.util.isUndefined(packageId)){
        		packageId = "";
        	}
        	if($A.util.isUndefined(userDataId)){
        		userDataId = "";
        	}
        	
            $A.createComponent(
                "c:AG_Fulfill_AddResponse",
                {
                    "CaseId" : component.get("v.caseId"),
                    "requestsSelection" : requestsSelection,
                	"documentsReordered" : documentsReordered,
                	"fulfillmentPackageId" : packageId,
                	"fulfillmentUserDataId" : userDataId
                },
                function(newChild){
                    if (component.isValid()) {
                        var parent = component.find("renderComp");
                        var body = parent.get("v.body");
                        body = newChild;
                        parent.set("v.body", body);
                    }
                }
            );
            
        }else if(componentNo == 2){
        	var requestsSelection = event.getParam("selectedRequests");
        	var documentsReordered = event.getParam("documentsReordered");
        	var packageId = event.getParam("fulfillmentPackageId");
        	//var userDataId = component.get("v.userDataId");
        	var userDataId = '';
        	if(!$A.util.isUndefined(component.get("v.userDataId"))){
        		userDataId = component.get("v.userDataId");
        	}else if(!$A.util.isUndefined(event.getParam("fulfillmentUserData"))){
        		userDataId = event.getParam("fulfillmentUserData");
        	}
        	if($A.util.isUndefined(packageId)){
        		packageId = "";
        	}
        	
        	
            $A.createComponent(
                "c:AG_Fulfill_SelectRequest",
                {
                	"CaseId" : component.get("v.caseId"),
                	"selectedRequestState" : requestsSelection,
                	"documentsReordered" : documentsReordered,
                	"fulfillmentUserDataId":userDataId,
                	"fulfillmentPackageId":packageId
                },
                function(newChild){
                    if (component.isValid()) {
                        var parent = component.find("renderComp");
                        var body = parent.get("v.body");
                        body = newChild;
                        parent.set("v.body", body);
                    }
                }
            );
        }else if(componentNo == 3){
        	var masterCaseWrapper = event.getParam("masterCaseWrapper");
        	var requestsSelection = event.getParam("selectedRequests");
        	var documentsReordered = event.getParam("documentsReordered");
        	var packageId = event.getParam("fulfillmentPackageId");
        	var userDataId = event.getParam("fulfillmentUserData");
        	if($A.util.isUndefined(packageId)){
        		packageId = "";
        	}
        	if($A.util.isUndefined(userDataId)){
        		userDataId = "";
        	}
            $A.createComponent(
                "c:AG_Fulfill_ReorderDocuments",
                {
                	"masterCaseWrapper" : JSON.parse(masterCaseWrapper),
                	"requestsSelection" : requestsSelection,
                	"values" : documentsReordered,
                	"fulfillmentUserDataId":userDataId,
                	"fulfillmentPackageId":packageId
                },
                function(newChild){
                    if (component.isValid()) {
                        var parent = component.find("renderComp");
                        var body = parent.get("v.body");
                        body = newChild;
                        parent.set("v.body", body);
                    }
                }
            );
        }else if(componentNo == 4){
            var masterCaseWrapper = event.getParam("masterCaseWrapper");
            var requestsSelection = event.getParam("selectedRequests");
            var documentsReordered = event.getParam("documentsReordered");
            var fulfillmentPackageId = event.getParam("fulfillmentPackageId");
            var userDataId = event.getParam("fulfillmentUserData");
            if($A.util.isUndefined(userDataId)){
        		userDataId = "";
        	}
            $A.createComponent(
                "c:AG_ComposeDocument",
                {
                    "masterCaseWrapper" : JSON.parse(masterCaseWrapper),
                	"selectedRequestState" : requestsSelection,
                	"documentsReordered" : documentsReordered,
                	"fulfillmentPackageId" : fulfillmentPackageId,
                	"fulfillmentUserDataId":userDataId
                },
                function(newChild){
                    if (component.isValid()) {
                        var parent = component.find("renderComp");
                        var body = parent.get("v.body");
                        body = newChild;
                        parent.set("v.body", body);
                    }
                }
            );
        }else if(componentNo == 5){
            var masterCaseWrapper = event.getParam("masterCaseWrapper");
            var requestsSelection = event.getParam("selectedRequests");
            var documentsReordered = event.getParam("documentsReordered");
            var fulfillmentPackageId = event.getParam("fulfillmentPackageId");
            var fulfillmentUserDataId = event.getParam("fulfillmentUserData");
            if($A.util.isEmpty(fulfillmentUserDataId) || $A.util.isUndefined(fulfillmentUserDataId)){
            	fulfillmentUserDataId = '';
            }
            if($A.util.isEmpty(masterCaseWrapper) || $A.util.isUndefined(masterCaseWrapper)){
                masterCaseWrapper = '{}';
            }
            if($A.util.isEmpty(fulfillmentPackageId) || $A.util.isUndefined(fulfillmentPackageId)){
                fulfillmentPackageId = component.get("v.packageId");
            }
            $A.createComponent(
                "c:AG_Fulfill_SelectMethods",
                {
                    "masterCaseWrapper" : JSON.parse(masterCaseWrapper),
                	"selectedRequestState" : requestsSelection,
                	"documentsReordered" : documentsReordered,
                	"fulfillmentPackageId" : fulfillmentPackageId,
                	"fulfillmentUserDataId" : fulfillmentUserDataId
                },
                function(newChild){
                    if (component.isValid()) {
                        var parent = component.find("renderComp");
                        var body = parent.get("v.body");
                        body = newChild;
                        parent.set("v.body", body);
                    }
                }
            );
        }else if(componentNo == 6){
             var fulfillmentPackageId = event.getParam("fulfillmentPackageId");
			 var userSelections = event.getParam("methodSelection");
             $A.createComponent(
                "c:AG_Fulfill_FulfillmentMethodContainer",
                {
                    "fulfillmentPackageId" : fulfillmentPackageId,
                    "selectedMethodList" : JSON.parse(userSelections) 
                },
                function(newChild){
                    if (component.isValid()) {
                        var parent = component.find("renderComp");
                        var body = parent.get("v.body");
                        body = newChild;
                        parent.set("v.body", body);
                    }
                }
            );
        }
    },
    fetchComponentData : function(component , event , helper){
        var compNo = event.getParam("componentNo");
        helper.createComponent(component , event , helper , compNo);
    },
    closeFocusedTab : function(component, event, helper) {
        var workspaceAPI = component.find("workspace");
        workspaceAPI.getFocusedTabInfo().then(function(response) {
            var focusedTabId = response.tabId;
            workspaceAPI.closeTab({tabId: focusedTabId});
        })
        .catch(function(error) {
            
        });
    },
    saveUserState : function(component , event , helper , requestsSelection , documentsReordered , saveAndClose){
    	var action = component.get("c.saveUserData");
        action.setParams({"documentsReordered" : documentsReordered , "requestsSelection" : requestsSelection , "masterCaseId" : component.get("v.caseId"),"fudId":component.get("v.userDataId")});
        action.setCallback(this,function(response){
            
            //get the response state
            var state = response.getState();
            if(state === "SUCCESS"){
                var fudId = response.getReturnValue();
                if($A.util.isEmpty(fudId) || $A.util.isUndefinedOrNull(fudId)){
                	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                }else{
                	component.set("v.userDataId",fudId);
                }
            }else if(state === "ERROR"){
            	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }
            if(saveAndClose){
                helper.showToast(component, event, helper,$A.get("$Label.c.AG_Sucess_Toast_Type") , $A.get("$Label.c.AG_Fulfillment_Data_Saved_Success_Message"),$A.get("$Label.c.AG_Sucess_Toast_Type")); 
                if(component.get("v.navigateToCase")){
                	helper.navigateToMasterCase(component , event , helper);
	        	}else{
	        		helper.navigateToPackage(component , event , helper);
	        	}
            }else{
            	helper.fetchComponentData(component , event , helper);
            }
        });
        $A.enqueueAction(action);
    },
    showToast : function(component, event, helper,title , message , type) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message,
            "type" : type
        });
        toastEvent.fire();
    },
    navigateToMasterCase : function(component , event , helper){
    	var recordId = component.get("v.caseId");
            var pageReference = {
                type: 'standard__recordPage',
                attributes: {
                    recordId: recordId,
                    actionName : 'view',
                    objectApiName : 'Case'
                },
                state: {
                    
                }
            };
            helper.closeFocusedTab(component , event , helper);
            component.set("v.pageReference", pageReference);
            var navService = component.find("navService");
            var pageReference = component.get("v.pageReference");
            navService.navigate(pageReference);
    },
    saveUserDataHelper : function(component , event , helper){
    	
    	var requestsSelection = event.getParam("selectedRequests");
        var documentsReordered = event.getParam("documentsReordered");
        var saveAndClose = event.getParam("saveAndClose");
        var saveData = event.getParam("saveData");
		if(!$A.util.isUndefined(event.getParam("fulfillmentUserData"))){
        		var userDataId = event.getParam("fulfillmentUserData");
        		component.set("v.userDataId",userDataId);
        }
        if(saveAndClose){
        	helper.saveUserState(component,event,helper,requestsSelection,documentsReordered , saveAndClose);
        }else if(saveData){
    		helper.saveUserState(component,event,helper,requestsSelection,documentsReordered , saveAndClose);
    	}else{
            helper.fetchComponentData(component , event , helper);
        }
        
    },
    navigateToPackage : function(component , event , helper){
        var recordId = component.get("v.packageId");
            var pageReference = {
                type: 'standard__recordPage',
                attributes: {
                    recordId: recordId,
                    actionName : 'view',
                    objectApiName : 'AG_Fulfillment_Package__c'
                },
                state: {
                    
                }
            };
            helper.closeFocusedTab(component , event , helper);
            component.set("v.pageReference", pageReference);
            var navService = component.find("navService");
            var pageReference = component.get("v.pageReference");
            navService.navigate(pageReference);
    }
})