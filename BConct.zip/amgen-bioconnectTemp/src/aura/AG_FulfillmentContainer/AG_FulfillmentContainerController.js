({
	doInit : function(component, event, helper) {
		helper.loadWizard(component , event , helper);	
	},
    loadComponents : function(component , event , helper){
        helper.saveUserDataHelper(component , event , helper);
    }
})