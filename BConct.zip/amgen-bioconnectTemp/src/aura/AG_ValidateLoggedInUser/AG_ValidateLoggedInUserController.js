({
	doInit : function(component, event, helper) {
		helper.validateUser(component , event , helper);
	},
	save : function(component , event , helper){
		helper.saveData(component , event , helper);
	},
	cancel : function(component , event , helper){
		helper.navigateBack(component , event , helper, '');
	},
    handleSaveSuccess : function(component , event , helper){
        helper.successMessage(component , event , helper);
    }
	
})