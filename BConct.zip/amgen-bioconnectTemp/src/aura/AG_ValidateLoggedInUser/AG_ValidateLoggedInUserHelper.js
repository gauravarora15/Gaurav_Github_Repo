({
    validateUser : function(component , event , helper) {
        
        var workspaceAPI = component.find("workspace");
        workspaceAPI.getFocusedTabInfo().then(function(response) {
        	component.set("v.parentTab" , response.parentTabId);
        });
        var action = component.get("c.validate");
        var recordId = component.get("v.recordId");
        action.setParams({
            "recId": recordId  
        });
        action.setCallback(this,function(response){
            
            var state = response.getState();
            if(state === "SUCCESS"){
                var res = response.getReturnValue();
                if(!$A.util.isEmpty(res) && !$A.util.isUndefined(res)){
                    if(res == true){
                        component.set("v.validUser", true); //id retrieved earlier
                    }else{
                        helper.showToast(component , event , helper , component.get("v.sObjectName") +' '+ $A.get("$Label.c.AG_errormessageForNonOwners")+' '+ component.get("v.sObjectName")  , $A.get("$Label.c.AG_Error_Toast_Type") ,  $A.get("$Label.c.AG_Error_Toast_Type") , $A.get("$Label.c.AG_PermissionError"));
                    }
                    
                }else{
                    helper.showToast(component,event , helper , $A.get("$Label.c.AG_errorMessage") , $A.get("$Label.c.AG_Error_Toast_Type") , $A.get("$Label.c.AG_errorMessage") , $A.get("$Label.c.AG_PermissionError")); 
                }
            } else if(state === "INCOMPLETE"){
                helper.showToast(component,event , helper , $A.get("$Label.c.AG_errorMessage") , $A.get("$Label.c.AG_Error_Toast_Type") , $A.get("$Label.c.AG_errorMessage") , $A.get("$Label.c.AG_PermissionError"));
            } else if(state === "ERROR"){
                helper.showToast(component,event , helper , $A.get("$Label.c.AG_errorMessage") , $A.get("$Label.c.AG_Error_Toast_Type") , $A.get("$Label.c.AG_errorMessage") , $A.get("$Label.c.AG_PermissionError"));
            }
            
        });
        $A.enqueueAction(action); 
    },
    navigateBack : function(component , event , helper, type){
        var recordId = component.get("v.recordId");
        var workspaceAPI = component.find("workspace");
        workspaceAPI.getFocusedTabInfo().then(function(response) {
        	
            var focusedTabId = response.tabId;
            workspaceAPI.closeTab({tabId: focusedTabId});
            var tabId = component.get("v.parentTab");
            workspaceAPI.openSubtab({
                    parentTabId: tabId ,
                    recordId: recordId,
                    focus: true
            });
            
             
        })
        .catch(function(error) {
            console.log('err::'+error);
        });

        workspaceAPI.refreshTab({
                tabId: component.get("v.parentTab"),
                includeAllSubtabs: true
            }).catch(function(error){
                console.log("error here" + error);
            });


        /*
        if(type != $A.get("$Label.c.AG_Error_Toast_Type") && type != ''){
        	//window.location.reload(true);
        	 //$A.get('e.force:refreshView').fire();
        }
        */
        
        
    },
    showToast : function(component , event , helper , message , type ,title ,messageTemplate ){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title : title,
            message: message ,
            messageTemplate: messageTemplate,
            duration:' 3000',
            key: 'info_alt',
            type: type,
            mode: 'dismissible'
        });
        toastEvent.fire();
        helper.navigateBack(component , event , helper, type);
    },
    saveData : function(component , event , helper){
        component.find("edit").get("e.recordSave").fire();
    },
    successMessage : function(component , event , helper){
        helper.showToast(component , event , helper , $A.get("$Label.c.AG_RecordSaved") , $A.get("$Label.c.AG_Sucess_Toast_Type") ,  $A.get("$Label.c.AG_Sucess_Toast_Type") , $A.get("$Label.c.AG_Sucess_Toast_Type"));   
    } 
})