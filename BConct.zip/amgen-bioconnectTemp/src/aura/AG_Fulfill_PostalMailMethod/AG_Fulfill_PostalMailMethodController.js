({
	doInit : function(component, event, helper) {
        helper.doInit(component, event, helper);
	},
    userSelect : function(component, event, helper) {
		helper.userSelectHelper(component , event , helper);	
	},
	viewSuccessScreen: function(component, event, helper){
		helper.viewSuccessScreen(component, event, helper);
	}
})