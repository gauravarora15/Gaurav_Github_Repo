({
	//Method on loading of component
	doInit : function(component, event, helper) {
		component.set("v.displaySpinner" , true); 
        var fulfillmentPackageId = component.get("v.fulfillmentPackageId");
        var action = component.get("c.getConfirmDocuments");
        action.setParams({ 
        	"packageId" : fulfillmentPackageId
        });
        action.setCallback(this, function(response){
            var state = response.getState();
                if(state === 'SUCCESS'){
                    var responseVar = response.getReturnValue();
                     if(!$A.util.isEmpty(responseVar) && !$A.util.isUndefinedOrNull(responseVar)){
                    
                    component.set("v.confirmDoc",responseVar.fulfillDocuments);
                    component.set("v.masterCaseNumber", responseVar.masterCase);
                    component.set("v.caseId" , responseVar.masterCaseId);
                    component.set("v.responseDocId", responseVar.mergeResponseId);
                    component.set("v.mergeRespSize", responseVar.mergeRespSize);
                    component.set("v.returnNotified", responseVar.isNotified);
                    component.set("v.returnCCed", responseVar.isCCed);
                    component.set("v.isPrintComplete",false);
                    
                    if(!$A.util.isEmpty(responseVar.errorMessage) && !$A.util.isUndefinedOrNull(responseVar.errorMessage)){
                        helper.openPromptComponent(component,event,helper, responseVar.errorMessage);
                        component.set("v.disableComplete", true);
                    }
                    
                }
                }else if(state === "INCOMPLETE"){
                    helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
                   
                } else if(state === "ERROR"){
                    helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
                   
                }
            component.set("v.displaySpinner" , false); 
            });
            
            $A.enqueueAction(action);
    },

    //Method for navigation
    userSelectHelper : function(component, event, helper) {
        var key = event.getSource().getLocalId();
        if(key === 'close'){
            helper.navigateToMasterCase(component,event , helper);
        }if(key === 'nextMethod') {
            helper.navigateToMethodContainer(component , event , helper);
        }if(key === 'cancel'){
            helper.navigateToMasterCase(component,event , helper);
        }if(key === 'skip'){
            helper.navigateToMethodContainerOnSkip(component,event , helper);
        }
            
    },

    //Navigate to the Next selected method
    navigateToMethodContainer : function(component , event , helper){
        var methodSelection = component.get("v.selectedMethodList");
        var fulfillmentPackageId = component.get("v.fulfillmentPackageId");
        var compEvent = component.getEvent("containerMethodEvent");
        var returnNotified = component.get("v.returnNotified");
         var returnCCed = component.get("v.returnCCed");
        compEvent.setParams({"fulfillmentPackageId" : fulfillmentPackageId,methodSelection : methodSelection, isNotified:returnNotified, isCC:returnCCed});
        compEvent.fire();
    },
    
    //Navigate to next selected method when skip is clicked
    navigateToMethodContainerOnSkip : function(component , event , helper){
        var methodSelection = component.get("v.selectedMethodList");
        if(methodSelection.postalMail){
            methodSelection.postalMail = false;
            
        }else if(methodSelection.PostalMailFacilitator){
            methodSelection.PostalMailFacilitator = false;
        }
        
        var fulfillmentPackageId = component.get("v.fulfillmentPackageId");
        var compEvent = component.getEvent("containerMethodEvent");
        compEvent.setParams({"fulfillmentPackageId" : fulfillmentPackageId,methodSelection : methodSelection, isNotified:false, isCC:false});
        compEvent.fire();
    },

    //Method of navigating for the Master Case
    navigateToMasterCase : function(component , event , helper){
        var recordId = component.get("v.caseId");
            var pageReference = {
                type: 'standard__recordPage',
                attributes: {
                    recordId: recordId,
                    actionName : 'view',
                    objectApiName : 'Case'
                },
                state: {
                    
                }
            };
            helper.closeFocusedTab(component , event , helper);
            component.set("v.pageReference", pageReference);
            var navService = component.find("navService");
            var pageReference = component.get("v.pageReference");
            navService.navigate(pageReference);
    },

    //Method for closing the focussed tab

    closeFocusedTab : function(component, event, helper) {
        var workspaceAPI = component.find("workspace");
        workspaceAPI.getFocusedTabInfo().then(function(response) {
            var focusedTabId = response.tabId;
            workspaceAPI.closeTab({tabId: focusedTabId});
        })
        .catch(function(error) {
            
        });
    },

    //Method of the Print Complete
    viewSuccessScreen : function(component, event, helper){
        var successScreen = event.getParam("successMessage");
        helper.showFulfilledRequests(component, event, helper,successScreen);
    },

    //Method for the Fulfilled Requests
    showFulfilledRequests: function(component, event, helper, successScreen){
        component.set("v.displaySpinner" , true); 
        var methodSelection = component.get("v.selectedMethodList");
        var selectedValue = '';
        if(methodSelection.postalMail){
            selectedValue = $A.get("$Label.c.AG_Postal_Mail");
           }else if(methodSelection.PostalMailFacilitator){
            selectedValue = $A.get("$Label.c.AG_Postal_Mail_To_Facilitator");
           
        }
        var fulfillmentPackageId = component.get("v.fulfillmentPackageId");
        var fulFillResponseDoc = component.get("v.confirmDoc");
        var action = component.get("c.savePostalMethod");
        action.setParams({
            "packageId" : fulfillmentPackageId,
            "responseDoc" : JSON.stringify(fulFillResponseDoc),
            "selectedValue" : selectedValue
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var responseVar = response.getReturnValue();
               
                if(!$A.util.isEmpty(responseVar) && !$A.util.isUndefinedOrNull(responseVar)){
                    if(!$A.util.isEmpty(responseVar.errorMessage) && !$A.util.isUndefinedOrNull(responseVar.errorMessage)){
                     helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
                     component.set("v.disablePrintComplete",true);  
                     component.set("v.disableSkip",true); 
                    
                    }else{
                          
                        component.set('v.responseEmailcolumns', [{
                        label: $A.get("$Label.c.AG_Fulfillment_Request_Heading"),
                        fieldName: 'requestName',
                        type: 'text'
                    },
                    {
                        label: $A.get("$Label.c.AG_Fulfillment_Subcase_Heading"),
                        fieldName: 'subCase',
                        type: 'text'
                    },
                    {
                        label: $A.get("$Label.c.AG_Fulfillment_Request_Status_Heading"),
                        fieldName: 'requestStatus',
                        type: 'text'
                    }
                    ]);
                    component.set("v.responseEmaildata", responseVar.reponseWrapperList);
                     
                     component.set("v.isPrintComplete", successScreen);    
                }
               }      
                
            }else if(state === "INCOMPLETE"){
                    helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
                    
                } else if(state === "ERROR"){
                    helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
                    
                }
              component.set("v.displaySpinner" , false);
        });
      
        $A.enqueueAction(action);
        
        var notified = component.get("v.returnNotified");
        var cc = component.get("v.returnCCed");
        if(methodSelection.postalMail){
             methodSelection.postalMail = false;
            component.set("v.disableButton",false);
            if(!notified && !cc && !methodSelection.PostalMailFacilitator){
                 component.set("v.disableButton",true); 
            }
        }else if(methodSelection.PostalMailFacilitator){
                 methodSelection.PostalMailFacilitator = false;
                component.set("v.disableButton",false);  
               if(!notified && !cc){
                 component.set("v.disableButton",true); 
            }
            }
        
        
    },

     //Mwthos to create toast
    showToast: function(toastTitle, toastType, toastMessage){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": toastTitle,
            "type": toastType,
            "message": toastMessage
        });
        toastEvent.fire();
    },
	
	
    //SHOW PROMPT TO INFORM THAT NEW VERSION CANNOT BE CREATED BASED ON CURRENT STATUS.
    openPromptComponent : function(component,event,helper, message){
        component.set("v.confirm",false);
        var modalBody;
        $A.createComponent("c:AG_Reusable_Prompt_Component", {"message" : message , 
                            "confirm":component.getReference('v.confirm') , "isPrompt":true, "negative":$A.get("$Label.c.AG_No")},
           function(content, status) {
               if (status === "SUCCESS") {
                   modalBody = content;
                   component.find('overlayLib').showCustomModal({
                       header: $A.get("$Label.c.AG_Label_Warning"),
                       body: modalBody, 
                       showCloseButton: false,
                       cssClass: "mymodal",
                       closeCallback: function() {
                           helper.userPromptHelper(component,event,helper);
                       }
                   })
               }                               
           });
    },

     //VALIDATE USER INPUT TO CREATE FP OR CANCEL.
    userPromptHelper : function(component , event , helper){ 
        if(component.get("v.confirm")){
            helper.navigateToMethodContainerOnSkip(component,event , helper);
        }else{
            component.set("v.displaySpinner" , false);
        }
    }


})
