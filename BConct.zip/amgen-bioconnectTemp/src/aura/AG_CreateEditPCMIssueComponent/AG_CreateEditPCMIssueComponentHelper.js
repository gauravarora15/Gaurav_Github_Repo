({
	doInitHelper : function(component, event, helper) {
        var action = component.get("c.doInitHelper");
        var pageReference = component.get("v.pageReference");
        if($A.util.isEmpty(component.get("v.recordId")) || $A.util.isUndefinedOrNull(component.get("v.recordId"))){
  			component.set("v.currentRecordId",pageReference.state.c__currentRecordId);
            component.set("v.currentObjectName",pageReference.state.c__currentObjectName);
        } else{
            component.set("v.currentRecordId",component.get("v.recordId"));
            component.set("v.currentObjectName",component.get("v.sObjectName"));
        }
        action.setParams({
            "sObjectName" : component.get("v.currentObjectName"),
            "recordId" : component.get("v.currentRecordId")
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var returnValue = response.getReturnValue();
                component.set("v.pcmIssueWrapper",returnValue);
                if(component.get("v.pcmIssueWrapper.hasError")){
                    helper.showErrorPrompt(component, event, helper, component.get("v.pcmIssueWrapper.errorMessage"));
                } else{
                    //set all the fields for LDS
                    helper.setFieldsForLDS(component, event, helper);

                    //CREATE
                    
                    if(component.get("v.pcmIssueWrapper.isCreate")){
                        component.set("v.record",component.get("v.pcmIssueWrapper.pcmIssueRecord"));
                        component.set("v.displayContent",true);
                        component.set("v.runLDSCreate",true);

                        component.set("v.disableStatus",true);

                        helper.setLookupFilters(component, event, helper);
                        
                        
                        component.find("recordCreater").getNewRecord(
                            "AG_PCM_Issue__c", // sObject type (objectApiName)
                            null,      // recordTypeId
                            false,     // skip cache?
                            $A.getCallback(function() {
                                var rec = component.get("v.record");
                                component.set("v.pcmIssueRecord.AG_PCM_Record__c",component.get("v.currentRecordId"));
                                var error = component.get("v.ldsError");
                                if(error || (rec === null)) {
                                    console.log("Error initializing record template: " + error);
                                    return;
                                }
                            })
                        );

                        
                        
                    } else{
                        //component.set("v.mode","EDIT");
                        //alert('code in edit');
                        component.set("v.runLDS",true);
                    }
                    
                }
                
            } else{
                helper.showErrorPrompt(component, event, helper, $A.get("$Label.c.AG_errorMessage")); 
            }
        });
        $A.enqueueAction(action);
	},
    
    setFieldsForLDS : function(component, event, helper){
        var recordFields = component.get("v.pcmIssueWrapper.queryField");
        var array = [];
        var fields = [];
        array = recordFields.split(",");
        for(var i = 0; i < array.length; i++)
        {
            fields.push(array[i]);
        }
        component.set("v.fieldSet",fields);
    },

    setLookupFilters : function(component, event, helper){
        var lookupFilterMapForProduct = {};
        if(component.get('v.pcmIssueWrapper.isCreate')){
            lookupFilterMapForProduct['AG_Case__c'] = component.get('v.pcmIssueWrapper.pcmCase.ParentId');
        } else{
            lookupFilterMapForProduct['AG_Case__c'] = component.get('v.pcmIssueRecord.AG_Parent_Case_Id__c');
        }
        lookupFilterMapForProduct['AG_Product__r.AG_Status__c'] = 'Active';
        component.set("v.lookupFilterMapForProduct",lookupFilterMapForProduct);
        
        var commonStatusFilterCheck = {};
        commonStatusFilterCheck['AG_Status__c'] = 'Active';
        component.set("v.commonStatusFilterCheck",commonStatusFilterCheck);
    },

   
    handleCaseProductChange : function(component, event, helper){
        
        component.find("dosageForm").invokeClose();
        component.set("v.selectedRelatedDosageForm.Id",'');
        component.set("v.selectedRelatedDosageForm.Name",'');

        var lookupFilterMapForReportedCode = {};
        var lookupFilterMapForDosageForm = {};
        if(!$A.util.isEmpty(component.get("v.selectedCaseProductLookUpRecord")) && !$A.util.isUndefinedOrNull(component.get("v.selectedCaseProductLookUpRecord")) && !$A.util.isEmpty(component.get("v.selectedCaseProductLookUpRecord.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedCaseProductLookUpRecord.Id"))){
            lookupFilterMapForDosageForm['AG_Product__c'] = component.get('v.selectedCaseProductLookUpRecord.AG_Product__c');
            component.set('v.lookupFilterMapForDosageForm',lookupFilterMapForDosageForm);
            //set the changed value in PCM Issue Record
            component.set("v.pcmIssueRecord.AG_Product__c",component.get('v.selectedCaseProductLookUpRecord.AG_Product__c'));
            component.set("v.pcmIssueRecord.AG_Case_Product_Id__c",component.get('v.selectedCaseProductLookUpRecord.Id'));
            if(component.get('v.pcmIssueRecord.AG_Product__c') != component.get("v.productOldValue") && !component.get("v.pcmIssueWrapper.isCreate")){
            	helper.showToast(component, event, helper,$A.get("$Label.c.AG_Label_Warning"), $A.get("$Label.c.AG_PCM_Issue_Product_change_lot_Batch_Revalidate"),$A.get("$Label.c.AG_Label_Warning")); 
            }
        } else{
          
            component.set("v.selectedCaseProductLookUpRecord.Id",'');
            component.set("v.selectedCaseProductLookUpRecord.Name",'');
            component.set("v.pcmIssueRecord.AG_Product__c",'');
        }

        component.find("itemType").invokeClose();
        component.set("v.selectedRelatedItemTypeDosage.Id",'');
        component.set("v.selectedRelatedItemTypeDosage.Name",'');
        

        component.find("asReportedCode").invokeClose();
        component.set("v.selectedAsAReportedCode.Id",'');
        component.set("v.selectedAsAReportedCode.Name",'');
        

        component.find("asInvestigatedCode").invokeClose();
        component.set("v.selectedInvestigatedCode.Id",'');
        component.set("v.selectedInvestigatedCode.Name",'');

        
        
        

        
    },

    handleRelatedDosageFormChange : function(component, event, helper){

        /*When Dosage form is changed, make Item Type, As a Reported COde and As Investigated code as Null*/

        
        component.find("itemType").invokeClose();
        component.set("v.selectedRelatedItemTypeDosage.Id",'');
        component.set("v.selectedRelatedItemTypeDosage.Name",'');

        var lookupFilterMapForItemType={};

        if(!$A.util.isEmpty(component.get("v.selectedRelatedDosageForm")) && !$A.util.isUndefinedOrNull(component.get("v.selectedRelatedDosageForm")) && !$A.util.isEmpty(component.get("v.selectedRelatedDosageForm.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedRelatedDosageForm.Id"))){
            lookupFilterMapForItemType['AG_Dosage_Form__c'] = component.get("v.selectedRelatedDosageForm.AG_Dosage_Form__c");
            component.set('v.lookupFilterMapForItemType',lookupFilterMapForItemType);
            //set the changed value in PCM Issue Record
            component.set("v.pcmIssueRecord.AG_Dosage_Form__c",component.get('v.selectedRelatedDosageForm.AG_Dosage_Form__c'));
        } else{
            component.set("v.selectedRelatedDosageForm.Id",'');
            component.set("v.selectedRelatedDosageForm.Name",'');
            //set the changed value in PCM Issue Record
            component.set("v.pcmIssueRecord.AG_Dosage_Form__c",'');
        }

        component.find("asReportedCode").invokeClose();
        component.set("v.selectedAsAReportedCode.Id",'');
        component.set("v.selectedAsAReportedCode.Name",'');
        

        component.find("asInvestigatedCode").invokeClose();
        component.set("v.selectedInvestigatedCode.Id",'');
        component.set("v.selectedInvestigatedCode.Name",''); 

    },

    handleRelatedItemTypeChange : function(component, event, helper){
        /*When Item Type is changed, make As reported code and Investigated code null*/
        component.find("asReportedCode").invokeClose();
        component.set("v.selectedAsAReportedCode.Id",'');
        component.set("v.selectedAsAReportedCode.Name",'');
        var lookupFilterMapForReportedCode = {};
        var lookupFilterMapForInvestigatedCode ={};
        
        if(!$A.util.isEmpty(component.get("v.selectedRelatedItemTypeDosage")) && !$A.util.isUndefinedOrNull(component.get("v.selectedRelatedItemTypeDosage")) && !$A.util.isEmpty(component.get("v.selectedRelatedItemTypeDosage.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedRelatedItemTypeDosage.Id"))){
            lookupFilterMapForReportedCode['AG_Item_Type__c'] = component.get("v.selectedRelatedItemTypeDosage.AG_Item_Type_Name__c");
            lookupFilterMapForReportedCode['AG_Issue_Code__r.AG_As_Reported_Code__c'] = 'true';
            lookupFilterMapForInvestigatedCode['AG_Item_Type__c'] = component.get("v.selectedRelatedItemTypeDosage.AG_Item_Type_Name__c");
            lookupFilterMapForInvestigatedCode['AG_Issue_Code__r.AG_As_Investigated_Code__c'] = 'true';
            component.set('v.lookupFilterMapForReportedCode',lookupFilterMapForReportedCode);
            component.set("v.lookupFilterMapForInvestigatedCode",lookupFilterMapForInvestigatedCode);
            //set the changed value in PCM Issue Record
            component.set("v.pcmIssueRecord.AG_Item_Type__c",component.get('v.selectedRelatedItemTypeDosage.AG_Item_Type_Name__c'));
        } else{
            component.set("v.selectedRelatedItemTypeDosage.Id",'');
            component.set("v.selectedRelatedItemTypeDosage.Name",'');
            //set the changed value in PCM Issue Record
            component.set("v.pcmIssueRecord.AG_Item_Type__c",'');
        }
        component.find("asInvestigatedCode").invokeClose();
        component.set("v.selectedInvestigatedCode.Id",'');
        component.set("v.selectedInvestigatedCode.Name",'');

    },

    handleReportedCodeChange : function(component, event, helper){
        /*When Reported Code is changed*/
        if(!$A.util.isEmpty(component.get("v.selectedRelatedAsAReportedCode")) && !$A.util.isUndefinedOrNull(component.get("v.selectedRelatedAsAReportedCode")) && !$A.util.isEmpty(component.get("v.selectedRelatedAsAReportedCode.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedRelatedAsAReportedCode.Id"))){
            //set the changed value in PCM Issue Record
            component.set("v.pcmIssueRecord.AG_As_reported_Code__c",component.get('v.selectedRelatedAsAReportedCode.AG_Issue_Code__c'));
        } else{
            component.set("v.pcmIssueRecord.AG_As_reported_Code__c",'');
        }

    },

    handleInvestigatedCodeChange : function(component, event, helper){
        /*When Investigated Code is changed*/
        if(!$A.util.isEmpty(component.get("v.selectedRelatedInvestigatedCode")) && !$A.util.isUndefinedOrNull(component.get("v.selectedRelatedInvestigatedCode")) && !$A.util.isEmpty(component.get("v.selectedRelatedInvestigatedCode.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedRelatedInvestigatedCode.Id"))){
            //set the changed value in PCM Issue Record
            component.set("v.pcmIssueRecord.AG_As_Investigated_Code__c",component.get('v.selectedRelatedInvestigatedCode.AG_Issue_Code__c'));
        } else{
            component.set("v.pcmIssueRecord.AG_As_Investigated_Code__c",'');
        }        
    },

    handleCategoryChange : function(component, event, helper){
        var lookupFilterMapForselectedCode = {};
        if(!$A.util.isEmpty(component.get("v.selectedCategory")) && !$A.util.isUndefinedOrNull(component.get("v.selectedCategory")) && !$A.util.isEmpty(component.get("v.selectedCategory.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedCategory.Id"))){
            //set the changed value in PCM Issue Record
            component.set("v.pcmIssueRecord.AG_Category__c",component.get('v.selectedCategory.Id'));
            lookupFilterMapForselectedCode['AG_Status__c'] = 'Active';
            lookupFilterMapForselectedCode['AG_Quality_Defect_Category__c'] = component.get('v.selectedCategory.Id');
            component.set("v.lookupFilterMapForselectedCode",lookupFilterMapForselectedCode);
        } else{
            component.set("v.pcmIssueRecord.AG_Category__c",'');
        }
        
        component.find("code").invokeClose();
        var code = {};
        code['sobjectType'] = 'AG_Quality_Defect_Code__c';
        code['Id'] = '';
        code['Name'] = '';
        component.set("v.selectedCode",code);
        /*
        component.set("v.selectedCode.Id",'');
        component.set("v.selectedCode.Name",'');
        */

        
        component.find("subCode").invokeClose();
        var subCode = {};
        subCode['sobjectType'] = 'AG_Quality_Defect_Sub_Code__c';
        subCode['Id'] = '';
        subCode['Name'] = '';
        component.set("v.selectedSubCode",subCode);
        

        /*
        component.set("v.selectedSubCode.Id",'');
        component.set("v.selectedSubCode.Name",'');
        */

    },

    handleCodeChange : function(component, event, helper){
        var lookupFilterMapForselectedSubCode = {};

        if(!$A.util.isEmpty(component.get("v.selectedCode")) && !$A.util.isUndefinedOrNull(component.get("v.selectedCode")) && !$A.util.isEmpty(component.get("v.selectedCode.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedCode.Id"))){
            //set the changed value in PCM Issue Record
            component.set("v.pcmIssueRecord.AG_Code__c",component.get('v.selectedCode.Id'));
            lookupFilterMapForselectedSubCode['AG_Status__c'] = 'Active';
            lookupFilterMapForselectedSubCode['AG_Quality_Defect_Code__c'] = component.get('v.selectedCode.Id');
            component.set("v.lookupFilterMapForselectedSubCode",lookupFilterMapForselectedSubCode);
        } else{
            component.set("v.selectedCode.Id",'');
            component.set("v.selectedCode.Name",'');
            component.set("v.pcmIssueRecord.AG_Code__c",'');
        }

        component.find("subCode").invokeClose();
        component.set("v.selectedSubCode.Id",'');
        component.set("v.selectedSubCode.Name",'');
        
    },

    handleSubCodeChange : function(component, event, helper){
        if(!$A.util.isEmpty(component.get("v.selectedSubCode")) && !$A.util.isUndefinedOrNull(component.get("v.selectedSubCode")) && !$A.util.isEmpty(component.get("v.selectedSubCode.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedSubCode.Id"))){
            //set the changed value in PCM Issue Record
            component.set("v.pcmIssueRecord.AG_Sub_Code__c",component.get('v.selectedSubCode.Id'));
           
        } else{
            component.set("v.pcmIssueRecord.AG_Sub_Code__c",'');
        }
    },

    handlePCMIssueClosureCodeChange : function(component, event, helper){
        
        if(!$A.util.isEmpty(component.get("v.selectedPCMIssueClosureCode")) && !$A.util.isUndefinedOrNull(component.get("v.selectedPCMIssueClosureCode")) && !$A.util.isEmpty(component.get("v.selectedPCMIssueClosureCode.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedPCMIssueClosureCode.Id"))){
            //set the changed value in PCM Issue Record
            component.set("v.pcmIssueRecord.AG_Issue_Closure_Code__c",component.get('v.selectedPCMIssueClosureCode.Id'));
            
        } else{
            component.set("v.pcmIssueRecord.AG_Issue_Closure_Code__c",'');
        }
    },

     handleMedicalChange : function(component, event, helper){
        if(!$A.util.isEmpty(component.get("v.selectedPCMMedicalDevice")) && !$A.util.isUndefinedOrNull(component.get("v.selectedPCMMedicalDevice")) && !$A.util.isEmpty(component.get("v.selectedPCMMedicalDevice.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedPCMMedicalDevice.Id"))){
            //set the changed value in PCM Issue Record
            component.set("v.pcmIssueRecord.AG_PCM_Medical_Device__c",component.get('v.selectedPCMMedicalDevice.Id'));
        } else{
            component.set("v.pcmIssueRecord.AG_PCM_Medical_Device__c",'');
        }
    },

    handleInvestigationPlanChange : function(component, event, helper){
        if(!$A.util.isEmpty(component.get("v.selectedInvestigationPlan")) && !$A.util.isUndefinedOrNull(component.get("v.selectedInvestigationPlan")) && !$A.util.isEmpty(component.get("v.selectedInvestigationPlan.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedInvestigationPlan.Id"))){
            //set the changed value in PCM Issue Record
            component.set("v.pcmIssueRecord.AG_Select_Plan__c",component.get('v.selectedInvestigationPlan.Id'));
        } else{
            component.set("v.pcmIssueRecord.AG_Select_Plan__c",'');
        }
    },

    handleRecordFetchAtEdit : function(component, event, helper){
        //fetched record on Edit from LDS
        component.set("v.displaySpinner",true);
        var eventParams = event.getParams();
        if(eventParams.changeType === "ERROR") {
            helper.showErrorPrompt(component, event, helper, component.get("v.recordError"));
            component.set("v.displaySpinner",false);
        } else{
            
            
            var pcmIssue = component.get("v.pcmIssueRecord");
            if(pcmIssue.AG_PCM_Record__r.Status == $A.get("$Label.c.AG_Completed")){
                component.set("v.displaySpinner",false);
                helper.showErrorPrompt(component, event, helper, 'PCM Issue cannot be updated for pcm sub case with completed status');
            } else if(pcmIssue.AG_PCM_Record__r.Status == 'Void'){
                component.set("v.displaySpinner",false);
                helper.showErrorPrompt(component, event, helper, 'PCM Issue cannot be updated for pcm sub case with void status');
            } else if(pcmIssue.AG_PCM_Record__r.Status == $A.get("$Label.c.AG_Ready_for_Closure_Status")){
                component.set("v.displaySpinner",false);
                helper.showErrorPrompt(component, event, helper, $A.get("$Label.c.AG_PCM_Issue_Edit_Error_Read_For_Clo"));
            } else if(pcmIssue.AG_Status__c == 'Closed'){
                component.set("v.displaySpinner",false);
                helper.showErrorPrompt(component, event, helper, 'PCM Issue in Closed status cannot be edited');
            } else if(pcmIssue.AG_Status__c == 'Void'){
                component.set("v.displaySpinner",false);
                helper.showErrorPrompt(component, event, helper, 'PCM Issue in Void status cannot be edited')
            } else{
                component.set("v.displayContent",true);
                helper.setLookupFilters(component, event, helper);
                if(pcmIssue.AG_Status__c == 'Void'){
                    component.set("v.disableStatus",true);
                }
                helper.handleEditValidationsOnDataLoad(component, event, helper, pcmIssue);
            }
            
        }
        component.set("v.stopChange",false);
        component.set("v.displaySpinner",false);
        
    },

    handleEditValidationsOnDataLoad : function(component, event, helper, pcmIssue){
        component.set("v.stopChange",true);
        var caseProduct = {};
        
        component.set("v.selectedCaseProductLookUpRecord.Id",pcmIssue.AG_Product__c); // stuffing dummy value to avoid mandatory check voilation
        component.set("v.productOldValue",pcmIssue.AG_Product__c);
        component.set("v.selectedCaseProductLookUpRecord.AG_Product__c",pcmIssue.AG_Product__c);
        component.set("v.selectedCaseProductLookUpRecord.AG_Product__r.Name",pcmIssue.AG_Product__r.Name);
        component.find("product").preselectValue();
        /*setting the lookup filter for Dosage Form Based on Product populated*/
        var lookupFilterMapForDosageForm = {}
        lookupFilterMapForDosageForm['AG_Product__c'] = component.get('v.selectedCaseProductLookUpRecord.AG_Product__c');
        component.set('v.lookupFilterMapForDosageForm',lookupFilterMapForDosageForm);
        
        if(!$A.util.isUndefinedOrNull(pcmIssue.AG_Dosage_Form__c) && !$A.util.isEmpty(pcmIssue.AG_Dosage_Form__c)){
            component.set("v.selectedRelatedDosageForm.Id",pcmIssue.AG_Dosage_Form__c); // stuffing dummy value to avoid mandatory check voilation
            component.set("v.selectedRelatedDosageForm.AG_Dosage_Form__c",pcmIssue.AG_Dosage_Form__c);
            component.set("v.selectedRelatedDosageForm.AG_Dosage_Form__r.Name",pcmIssue.AG_Dosage_Form__r.Name);
            component.find("dosageForm").preselectValue();
            /*setting the lookup filter for Item Type based on Dosage Form Selected*/
            var lookupFilterMapForItemType = {};
            lookupFilterMapForItemType['AG_Dosage_Form__c'] = component.get("v.selectedRelatedDosageForm.AG_Dosage_Form__c");
            component.set('v.lookupFilterMapForItemType',lookupFilterMapForItemType);
        }
        


        if(!$A.util.isUndefinedOrNull(pcmIssue.AG_Item_Type__c) && !$A.util.isEmpty(pcmIssue.AG_Item_Type__c)){
            component.set("v.selectedRelatedItemTypeDosage.AG_Item_Type_Name__c",pcmIssue.AG_Item_Type__c);
            component.set("v.selectedRelatedItemTypeDosage.AG_Item_Type_Name__r.Name",pcmIssue.AG_Item_Type__r.Name);
            component.find("itemType").preselectValue();

            var lookupFilterMapForReportedCode = {};
            lookupFilterMapForReportedCode['AG_Item_Type__c'] = component.get("v.selectedRelatedItemTypeDosage.AG_Item_Type_Name__c");
            lookupFilterMapForReportedCode['AG_Issue_Code__r.AG_As_Reported_Code__c'] = 'true';
            component.set("v.lookupFilterMapForReportedCode",lookupFilterMapForReportedCode);

            var lookupFilterMapForInvestigatedCode = {};
            lookupFilterMapForInvestigatedCode['AG_Item_Type__c'] = component.get("v.selectedRelatedItemTypeDosage.AG_Item_Type_Name__c");
            lookupFilterMapForInvestigatedCode['AG_Issue_Code__r.AG_As_Investigated_Code__c'] = 'true';
            component.set("v.lookupFilterMapForInvestigatedCode",lookupFilterMapForInvestigatedCode);
        }

        if(!$A.util.isUndefinedOrNull(pcmIssue.AG_As_reported_Code__c) && !$A.util.isEmpty(pcmIssue.AG_As_reported_Code__c)){
            component.set("v.selectedRelatedAsAReportedCode.AG_Issue_Code__c",pcmIssue.AG_As_reported_Code__c);
            component.set("v.selectedRelatedAsAReportedCode.AG_Issue_Code__r.Name",pcmIssue.AG_As_reported_Code__r.Name);
            component.find("asReportedCode").preselectValue();
        }

        if(!$A.util.isUndefinedOrNull(pcmIssue.AG_As_Investigated_Code__c) && !$A.util.isEmpty(pcmIssue.AG_As_Investigated_Code__c)){
            component.set("v.selectedRelatedInvestigatedCode.AG_Issue_Code__c",pcmIssue.AG_As_Investigated_Code__c);
            component.set("v.selectedRelatedInvestigatedCode.AG_Issue_Code__r.Name",pcmIssue.AG_As_Investigated_Code__r.Name);
            component.find("asInvestigatedCode").preselectValue();
        }

        if(!$A.util.isUndefinedOrNull(pcmIssue.AG_PCM_Medical_Device__c) && !$A.util.isEmpty(pcmIssue.AG_PCM_Medical_Device__c)){
            component.set("v.selectedPCMMedicalDevice.Id",pcmIssue.AG_PCM_Medical_Device__c);
            component.set("v.selectedPCMMedicalDevice.Name",pcmIssue.AG_PCM_Medical_Device__r.Name);
            component.find("medicalDevice").preselectValue();
        }

        if(!component.get("v.pcmIssueWrapper.showOnlyInformation")){
            /*these fields will not be visible for people who dont have access to the section*/
            if(!$A.util.isUndefinedOrNull(pcmIssue.AG_Select_Plan__c) && !$A.util.isEmpty(pcmIssue.AG_Select_Plan__c)){
                var InvestigationPlan = {};
                var InvestigationPlan = {'Id':'','Name':''};
                InvestigationPlan.Id = pcmIssue.AG_Select_Plan__c;
                InvestigationPlan.Name = pcmIssue.AG_Select_Plan__r.Name;
                component.set("v.selectedInvestigationPlan",InvestigationPlan);
                component.find("selectPlan").preselectValue();
            }

            if(!$A.util.isUndefinedOrNull(pcmIssue.AG_Issue_Closure_Code__c) && !$A.util.isEmpty(pcmIssue.AG_Issue_Closure_Code__c)){
                var PCMIssueClosureCode = {};
                var PCMIssueClosureCode = {'Id':'','Name':''};
                PCMIssueClosureCode.Id = pcmIssue.AG_Issue_Closure_Code__c;
                PCMIssueClosureCode.Name = pcmIssue.AG_Issue_Closure_Code__r.Name;
                component.set("v.selectedPCMIssueClosureCode",PCMIssueClosureCode);
                component.find("issueClosureCode").preselectValue();
            }

            if(!$A.util.isUndefinedOrNull(pcmIssue.AG_Category__c) && !$A.util.isEmpty(pcmIssue.AG_Category__c)){
                var category = {};
                var category = {'Id':'','Name':'','AG_PCM_Quality_Defect_Category_Name__c':''};
                category.Id = pcmIssue.AG_Category__c;
                category.Name = pcmIssue.AG_Category__r.Name;
                category.AG_PCM_Quality_Defect_Category_Name__c = pcmIssue.AG_Category__r.AG_PCM_Quality_Defect_Category_Name__c
                component.set("v.selectedCategory",category);
                component.find("category").preselectValue();

                var lookupFilterMapForselectedCode = {};
                lookupFilterMapForselectedCode['AG_Status__c'] = 'Active';
                lookupFilterMapForselectedCode['AG_Quality_Defect_Category__c'] = component.get('v.selectedCategory.Id');
                component.set("v.lookupFilterMapForselectedCode",lookupFilterMapForselectedCode);
            }

            if(!$A.util.isUndefinedOrNull(pcmIssue.AG_Code__c) && !$A.util.isEmpty(pcmIssue.AG_Code__c)){
                var code = {};
                var code = {'Id':'','Name':'','AG_Quality_Defect_Code__c':''};
                code.Id = pcmIssue.AG_Code__c;
                code.Name = pcmIssue.AG_Code__r.Name;
                code.AG_PCM_Quality_Defect_Code_Name__c = pcmIssue.AG_Code__r.AG_PCM_Quality_Defect_Code_Name__c;
                component.set("v.selectedCode",code);
                component.find("code").preselectValue();

                var lookupFilterMapForselectedSubCode = {};
                lookupFilterMapForselectedSubCode['AG_Status__c'] = 'Active';
                lookupFilterMapForselectedSubCode['AG_Quality_Defect_Code__c'] = component.get('v.selectedCode.Id');
                component.set("v.lookupFilterMapForselectedSubCode",lookupFilterMapForselectedSubCode);
            }

            if(!$A.util.isUndefinedOrNull(pcmIssue.AG_Sub_Code__c) && !$A.util.isEmpty(pcmIssue.AG_Sub_Code__c)){
                
                var SubCode = {};
                var SubCode = {'Id':'','Name':'','AG_PCM_Quality_Defect_Sub_Code_Name__c':''};
                SubCode.Id = pcmIssue.AG_Sub_Code__c;
                SubCode.Name = pcmIssue.AG_Sub_Code__r.Name;
                SubCode.AG_PCM_Quality_Defect_Sub_Code_Name__c = pcmIssue.AG_Sub_Code__r.AG_PCM_Quality_Defect_Sub_Code_Name__c;
                component.set("v.selectedSubCode",SubCode);
                component.find("subCode").preselectValue();
            }
        }

        
        
                
    },

    handleStatusChange : function(component, event, helper){
        var value =  event.getSource().get("v.value");
        if(value != 'Void'){
            component.set("v.pcmIssueRecord.AG_Void_Reason__c",'');
            component.set("v.pcmIssueRecord.AG_Void_Justification__c",'');
        }
    },


    handleSaveValidations : function(component, event, helper){

        var errorMessage = '';
        var formValid = component.find('field').reduce(function (validSoFar, inputCmp) {
            // Displays error messages for invalid fields
            inputCmp.showHelpMessageIfInvalid();
            
            if(inputCmp.get('v.label') == component.get("v.pcmIssueWrapper.mapFieldAPIVsLabel.ag_reported_expiration_date_year__c") && isNaN(inputCmp.get('v.value'))){
            	inputCmp.setCustomValidity($A.get("AG_Error_UnvalidNumbers"));
            	inputCmp.reportValidity();
            }else if(inputCmp.get('v.label') == component.get("v.pcmIssueWrapper.mapFieldAPIVsLabel.ag_reported_expiration_date_year__c") && !isNaN(inputCmp.get('v.value'))){
            	inputCmp.setCustomValidity('');
            }
            return validSoFar && inputCmp.get('v.validity').valid;
        }, true);
         
		 if(!component.get("v.pcmIssueWrapper.isCreate")){
            if(component.get("v.pcmIssueWrapper.showOnlyInformation") && component.get("v.pcmIssueRecord").AG_Status__c == $A.get("$Label.c.AG_PCM_Issue_Closed_Status")){
                formValid = false;
                errorMessage = $A.get("$Label.c.AG_PCM_Issue_Close_Error");
            }
        }
        if($A.util.isEmpty(component.get("v.pcmIssueRecord.AG_Product__c")) || $A.util.isUndefinedOrNull(component.get("v.pcmIssueRecord.AG_Product__c"))){
            component.set("v.selectedCaseProductLookUpRecord.Id",'');
            formValid = false;
            errorMessage = $A.get("$Label.c.AG_Form_Validations");
        }
    
        if(!component.get("v.pcmIssueWrapper.showOnlyInformation")){
            if(!$A.util.isEmpty(component.get("v.pcmIssueRecord.AG_Other_How_Was_Quality_Defect_Identifi__c")) && !$A.util.isUndefinedOrNull(component.get("v.pcmIssueRecord.AG_Other_How_Was_Quality_Defect_Identifi__c")) && component.get("v.pcmIssueRecord.AG_How_Was_Quality_Defect_Identified__c") != 'Other'){
                formValid = false;
                if($A.util.isEmpty(errorMessage) || $A.util.isUndefinedOrNull(errorMessage)){
                    errorMessage = $A.get("$Label.c.AG_How_Was_Quality_Error");
                } else{
                    errorMessage = errorMessage + '<br/>' + $A.get("$Label.c.AG_How_Was_Quality_Error");
                }
            }
            if(!$A.util.isEmpty(component.get("v.pcmIssueRecord.AG_Identified_Date__c")) && !$A.util.isUndefinedOrNull(component.get("v.pcmIssueRecord.AG_Identified_Date__c"))){
                var FieldValue = component.get("v.pcmIssueRecord.AG_Identified_Date__c");
                if(FieldValue.split('-')[0].length != 4){
                    formValid = false;
                    if($A.util.isEmpty(errorMessage) || $A.util.isUndefinedOrNull(errorMessage)){
                        errorMessage = 'Field: '+component.get("v.pcmIssueWrapper.mapFieldAPIVsLabel.ag_identified_date__c") + ' has invalid value';
                    } else{
                        errorMessage = errorMessage + '<br/>' +'Field: '+component.get("v.pcmIssueWrapper.mapFieldAPIVsLabel.ag_identified_date__c") + ' has invalid value';
                    }

                }
            }

        }


        if(formValid){
            helper.handleSave(component, event, helper);
        } else{
            if($A.util.isEmpty(errorMessage) || $A.util.isUndefinedOrNull(errorMessage)){
                component.set("v.errorMessage",$A.get("$Label.c.AG_Form_Validations"));
            } else{
                component.set("v.errorMessage",errorMessage);   
            }
            
            component.set("v.showError",true);
        }
        

    },

    handleSave : function(component, event, helper){
        component.set("v.showError",false);
        var hasError = false;
        component.set("v.displaySpinner",true);
        var action = component.get("c.upsertPCMIssue");
        action.setParams({
            "pcmIssueRecord" : component.get("v.pcmIssueRecord")
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === 'SUCCESS'){
                var returnValue = [];
                returnValue = response.getReturnValue();
                if(returnValue.isSuccess){
                    //helper.navigateToRecord(component, event, helper, returnValue.recordId);

                    if(component.get("v.pcmIssueWrapper.isCreate")){
                        console.log('closeFocusedTabAndOpenNewTab--> '+returnValue.recordId);
                        helper.closeFocusedTabAndOpenNewTab(component, event, helper, returnValue.recordId);
                        helper.showToast(component, event, helper,$A.get("$Label.c.AG_Sucess_Toast_Type"), 'PCM Issue is created.',$A.get("$Label.c.AG_Sucess_Toast_Type"));
                    } else{
                        //Salesforce support code change
                        component.find("workspace").getFocusedTabInfo().then(function (response) {
                            helper.navigateToRecord(component, event, helper, returnValue.recordId, response.parentTabId); 
                        });
                       
                        helper.showToast(component, event, helper,$A.get("$Label.c.AG_Sucess_Toast_Type"), 'PCM Issue is updated.',$A.get("$Label.c.AG_Sucess_Toast_Type"));
                    }
                    
                } else{
                    component.set("v.errorMessage",returnValue.errorMessage);
                    component.set("v.showError",true);
                }
                
                
            } else{
                component.set("v.errorMessage",$A.get("$Label.c.AG_errorMessage"))
                component.set("v.showError",true);
            }
            component.set("v.displaySpinner",false);
        });

        $A.enqueueAction(action);
    },

    showToast : function(component, event, helper,title , message , type) {
        
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message,
            "type" : type
        });
        toastEvent.fire();
     
    },

    navigateToRecord : function(component , event , helper, recordId, parentTabId){
        var subTabId;
        /*var pageReference = {
            type: 'standard__recordPage',
            attributes: {
                recordId: recordId,
                actionName : "view",
                objectApiName : component.get("v.currentObjectName")
            },
            state: {
                
            }
        };
        */
        helper.closeFocusedTab(component , event , helper);
        //component.set("v.pageReference", pageReference);
        /*var navService = component.find("navService");
        var pageReference = component.get("v.pageReference");*/
        event.preventDefault();
        /*
        navService.navigate(pageReference);*/
		var workspaceAPI = component.find("workspace");
        workspaceAPI.openSubtab({
            parentTabId: parentTabId,
            pageReference: {
                "type": 'standard__recordPage',
                "attributes": {
                    "recordId": recordId,
                    "actionName" : "view",
                    "objectApiName" : component.get("v.currentObjectName")
                },
                "state": {
                    
                }
            },
            focus: true
        }).then(function(response){
            subTabId = response
            workspaceAPI.focusTab({tabId : subTabId});
        }).catch(function(error){
            console.log("this error: " + error);
        });

       
  
      //Salesforce support code change  
    
    
	workspaceAPI.refreshTab({
                tabId: parentTabId,
                includeAllSubtabs: true
            }).catch(function(error){
                console.log("error here123" + error);
            });  
        

    
        
        /*
     component.find("workspace").getFocusedTabInfo().then(function (response) {
           $A.get('e.force:refreshView').fire();
			            
            //component.find('subProcRecord').reloadRecord();
            //Salesforce support code change
            var focusedTabId = response.parentTabId;         
            workspaceAPI.refreshTab({
                tabId: focusedTabId,
                includeAllSubtabs: true
            });
        // $A.get('e.force:refreshView').fire();
          
        }).catch(function (error) {
            console.log('Error is : ' + error);
            location.reload();

        });

        */
        
   
                
    },

    closeFocusedTab : function(component, event, helper) {
        var workspaceAPI = component.find("workspace");
        workspaceAPI.getFocusedTabInfo().then(function(response) {

            var focusedTabId = response.tabId;
            workspaceAPI.closeTab({tabId: focusedTabId});
        })
        .catch(function(error) {
            
        });
    },

    showErrorPrompt: function(component, event, helper, errorMessage){
        component.find("notifLib").showNotice({
            "variant": "error",
            "header": "Error",
            "message": errorMessage,
            closeCallback: function() {
                helper.navigateToRecord(component, event, helper, component.get("v.currentRecordId"));
            }
        });
    },

    closeFocusedTabAndOpenNewTab : function(component, event, helper, recordId) {
        var workspaceAPI = component.find("workspace");
            workspaceAPI.getFocusedTabInfo().then(function(response) {
            var focusedTabId = response.tabId;
            console.log('focusedTabId--> '+focusedTabId);

            //Opening New Tab
            workspaceAPI.openTab({
                url: '#/sObject/'+recordId+'/view'
            }).then(function(response) {
                workspaceAPI.focusTab({tabId : response});
            })
            .catch(function(error) {
                console.log(error);
            });

            //Closing old one
            workspaceAPI.closeTab({tabId: focusedTabId});
        })
        .catch(function(error) {
            console.log(error);
        });
    }
})