({
	doInit : function(component, event, helper) {
		helper.doInitHelper(component, event, helper);
	},
    recordUpdated : function(component, event, helper){
        helper.handleRecordFetchAtEdit(component, event, helper);
    },
    trimSpacePadding : function(component, event, helper){
        var valueField = event.getSource().get("v.value");
        var labelField = event.getSource().get("v.label");
        if(!$A.util.isEmpty(valueField) && !$A.util.isUndefinedOrNull(valueField)){
            if(labelField == component.get("v.pcmIssueWrapper.mapFieldAPIVsLabel.ag_other_how_was_quality_defect_identifi__c")){
                component.set("v.pcmIssueRecord.AG_Other_How_Was_Quality_Defect_Identifi__c",valueField.trim());
            } else if(labelField == component.get("v.pcmIssueWrapper.mapFieldAPIVsLabel.ag_void_justification__c")){
                component.set("v.pcmIssueRecord.AG_Void_Justification__c",valueField.trim());
            }
        }
    },
    handleStatusChange : function(component, event, helper){
        helper.handleStatusChange(component, event, helper);
    },
    handleCaseProductChange : function(component, event, helper){
        if(!component.get("v.stopChange")){
            helper.handleCaseProductChange(component, event, helper);
        }
    },
    handleRelatedDosageFormChange : function(component, event, helper){
        if(!component.get("v.stopChange")){
            helper.handleRelatedDosageFormChange(component, event, helper);
        }
        //helper.handleRelatedDosageFormChange(component, event, helper);
    },
    handleRelatedItemTypeChange : function(component, event, helper){
        if(!component.get("v.stopChange")){
            helper.handleRelatedItemTypeChange(component, event, helper);
        }
        //helper.handleRelatedItemTypeChange(component, event, helper);
    },
    handleReportedCodeChange : function(component, event, helper){
        if(!component.get("v.stopChange")){
            helper.handleReportedCodeChange(component, event, helper);
        }
        //helper.handleReportedCodeChange(component, event, helper);
    },
    handleInvestigatedCodeChange : function(component, event, helper){
        if(!component.get("v.stopChange")){
            helper.handleInvestigatedCodeChange(component, event, helper);
        }
        //helper.handleInvestigatedCodeChange(component, event, helper);
    },
    handleCategoryChange : function(component, event, helper){
        if(!component.get("v.stopChange")){
            helper.handleCategoryChange(component, event, helper);
        }
        //helper.handleCategoryChange(component, event, helper);
    },
    handleCodeChange : function(component, event, helper){
        if(!component.get("v.stopChange")){
            helper.handleCodeChange(component, event, helper);
        }
        //helper.handleCodeChange(component, event, helper);
    },
    handleSubCodeChange : function(component, event, helper){
        helper.handleSubCodeChange(component, event, helper);
    },
    handlePCMIssueClosureCodeChange : function(component, event, helper){
        helper.handlePCMIssueClosureCodeChange(component, event, helper);
    },
    handleMedicalChange : function(component, event, helper){
        helper.handleMedicalChange(component, event, helper);
    },
    handleInvestigationPlanChange : function(component, event, helper){
        helper.handleInvestigationPlanChange(component, event, helper);
    },
    handleSaveValidations : function(component, event, helper){
        helper.handleSaveValidations(component, event, helper);
    },
    handleCancel : function(component, event, helper){
        helper.navigateToRecord(component, event, helper, component.get("v.currentRecordId"));
    }
})