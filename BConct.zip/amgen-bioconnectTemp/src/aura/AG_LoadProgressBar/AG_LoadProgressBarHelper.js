({
	startLoaderHelper : function(component,event,helper) {
        
        component._interval = setInterval($A.getCallback(function () {
            var progress = component.get("v.progress");
            component.set("v.progress", progress === 100 ? 100 : progress + 1);
            if(component.get("v.isSuccess")){
                component.find("overlayLib").notifyClose();
                component.set('v.progress', 100);
                clearInterval(component._interval);
                
            }else if(component.get('v.progress') == 100 && !component.get("v.isSuccess")){
                component.find("overlayLib").notifyClose();
                component.set("v.isProgressing", false);
                clearInterval(component._interval);
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_MergeResponse_Timeout"));
            }
        }), 1800);
	},
	//Mwthos to create toast
    showToast: function(toastTitle, toastType, toastMessage){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": toastTitle,
            "type": toastType,
            "message": toastMessage
        });
        toastEvent.fire();
    }
})