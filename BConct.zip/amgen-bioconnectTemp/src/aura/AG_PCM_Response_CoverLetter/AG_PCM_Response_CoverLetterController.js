({
	doInit : function(component, event, helper) {
        helper.doInit(component, event, helper);
	},
     handleTemplateSelect : function(component, event, helper){
        helper.handleTemplateSelect(component , event , helper);
    },
  
     save : function(component, event, helper){
        helper.save(component , event , helper);
    },
    handleCancel : function(component, event, helper){
        helper.handleCancel(component , event , helper);
    }
})