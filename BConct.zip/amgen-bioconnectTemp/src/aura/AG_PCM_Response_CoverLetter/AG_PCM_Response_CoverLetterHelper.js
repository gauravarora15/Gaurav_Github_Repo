({  
    doInit: function(component, event, helper) {
        component.set("v.displaySpinner", true);
        var action = component.get("c.getEmailTemplate");
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state == "SUCCESS") {
                
                var responseVar =response.getReturnValue();
                if (!$A.util.isEmpty(responseVar) && !$A.util.isUndefinedOrNull(responseVar)) {
                    component.set("v.selectedTemplate", $A.get("$Label.c.AG_Select_an_Option_Label") );
                    component.set("v.faxData", responseVar);
                    
                }
            }else if (state === "INCOMPLETE") {
                helper.showToast(component, event, helper, $A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"), $A.get("$Label.c.AG_Error_Toast_Type"));
            }
                else if (state =="ERROR") {
                    helper.showToast(component, event, helper, $A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"), $A.get("$Label.c.AG_Error_Toast_Type")); 
                    
                }
            component.set("v.displaySpinner", false);
        })
        
        $A.enqueueAction(action);
    },
    showToast: function(component, event, helper, title, message, type) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message,
            "type": type
        });
        toastEvent.fire();
    },
    handleCancel : function(component, event, helper) {
        component.find("overlayLib1").notifyClose();
    },
    save: function(component, event, helper) {
       
        var templateBody = component.get("v.faxData.messageBody");
        var rec = component.get("v.recordId");
        var selectedTemplate = component.get("v.selectedTemplate");
        if (!(selectedTemplate == $A.get("$Label.c.AG_Select_an_Option_Label"))) {
           
        component.set("v.displaySpinner", true);
        var action = component.get("c.updateResponse");
        action.setParams({
            "resp" :rec,
            "templateBody" :templateBody
        });
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            
            if (state == "SUCCESS") {
                var responseVar =response.getReturnValue();
                if(responseVar=='success'){
                $A.get('e.force:refreshView').fire();
                component.find("overlayLib1").notifyClose();
                }else{
                     helper.showToast(component, event, helper, $A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"), $A.get("$Label.c.AG_Error_Toast_Type"));
                }
                
            } else if (state === "INCOMPLETE") {
                helper.showToast(component, event, helper, $A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"), $A.get("$Label.c.AG_Error_Toast_Type"));
            }
                else if (state =="ERROR") {
                    
                    helper.showToast(component, event, helper, $A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"), $A.get("$Label.c.AG_Error_Toast_Type")); 
                    
                } 
            component.set("v.displaySpinner", false);
        })
        
        $A.enqueueAction(action);  
        }
         
    },
    
    
    handleTemplateSelect: function(component, event, helper) {
     
        var listTemplateData = component.get("v.faxData");
        var selectedTemplate = component.find("selectFaxTemplate").get("v.value");
        if (selectedTemplate == $A.get("$Label.c.AG_Select_an_Option_Label")) {
              listTemplateData.messageBody = '';
           } else {   
            component.set("v.displaySpinner", true);
            var action = component.get("c.mergeFieldReplace");
            action.setParams({
                resp : component.get("v.recordId"),
                template : selectedTemplate
                
            });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state == "SUCCESS") {
                    
                    var responseVar =response.getReturnValue();
                    if (!$A.util.isEmpty(responseVar) && !$A.util.isUndefinedOrNull(responseVar)) {
                        listTemplateData.messageBody = responseVar;
                        component.set("v.selectedTemplate", selectedTemplate);
                      }
                }else if (state === "INCOMPLETE") {
                   helper.showToast(component, event, helper, $A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"), $A.get("$Label.c.AG_Error_Toast_Type"));
                }else if (state =="ERROR") {
                       helper.showToast(component, event, helper, $A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"), $A.get("$Label.c.AG_Error_Toast_Type")); 
                    }
                component.set("v.faxData", listTemplateData);
                 component.set("v.displaySpinner", false);
               })
            
            $A.enqueueAction(action); 
            
            /*for (var key in listTemplateData.mapMessage) {
                if (selectedTemplate == key) {
                 
                    listTemplateData.messageBody = listTemplateData.mapMessage[key];
                    component.set("v.selectedTemplate", selectedTemplate);
                   
                   
                }
            }*/
            
        }
    }
})