({
	helperMethod : function() {
	}
})