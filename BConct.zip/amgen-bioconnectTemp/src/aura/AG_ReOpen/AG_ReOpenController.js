({
    doInit : function(component,event,helper) { 
        var userId = $A.get("$SObjectType.CurrentUser.Id");  
        component.set("v.loggedInUser",userId);
        var array = [];
        var fields = [];
        var recordFields='';
        
        if(component.get("v.sObjectName") == $A.get("$Label.c.AG_PCM_Assessment_Object_API_Name")){
            recordFields = $A.get("$Label.c.AG_Assessment_Fields");
            helper.setFieldsForLDS(component, event, helper, recordFields);
        } else if(component.get("v.sObjectName") == $A.get("$Label.c.AG_PCM_Inv_Notification_Reference")){
            recordFields = $A.get("$Label.c.AG_Inv_Notification_Ref_Fields");
            helper.setFieldsForLDS(component, event, helper, recordFields);
        } else if(component.get("v.sObjectName") == $A.get("$Label.c.AG_Case_Object_API_Name")){
            //recordFields = $A.get("$Label.c.AG_Case_PCM_Ref_Fields"); //contains fields for PCM as well as SR
            //helper.setFieldsForLDS(component, event, helper, recordFields);
            helper.profileCheck(component,event,helper);
        } else if(component.get("v.sObjectName") == $A.get("$Label.c.AG_PCM_Investigation_Object_API_Name")){
            //recordFields = $A.get("$Label.c.AG_PCM_Investigation_Ref_Fields");
            //helper.setFieldsForLDS(component, event, helper, recordFields);
            helper.profileCheck(component,event,helper);
        } else if(component.get("v.sObjectName") == $A.get("$Label.c.AG_PCM_Issue_Object_API_Name")){
            //recordFields = $A.get("$Label.c.AG_PCM_Issue_Field_Query_Reopen");
            //helper.setFieldsForLDS(component, event, helper, recordFields);
            helper.profileCheck(component,event,helper);
        } else if(component.get("v.sObjectName") == $A.get("$Label.c.AG_PCM_Return_Unit_Object_API_Name")){
            //recordFields = $A.get("$Label.c.AG_PCM_Return_Unit_Field_Query_Reopen");
            //helper.setFieldsForLDS(component, event, helper, recordFields);
            helper.profileCheck(component,event,helper);
        }
        //end

        /*
        array = recordFields.split(",");
        
        for(var i = 0; i < array.length; i++)
        {
            fields.push(array[i]);
        }
        component.set("v.fieldsList",fields);
        if(!$A.util.isUndefinedOrNull(component.get("v.fieldsList")) && !$A.util.isEmpty(component.get("v.fieldsList")))   
        {
            component.set("v.hasSObjectName",true);
        }*/
    },
    handleSave: function(component,event,helper){
        helper.formValidation(component,event,helper);
    },
    handleCancel : function(component,event,helper){
        helper.handleCancelOperation(component,event,helper);
    },
    checkJustificationRequired : function(component,event,helper){
        helper.checkJustificationRequired(component,event,helper);
    },
     handleOnBlur : function(component, event, helper){
        if(component.get("v.reopenReasonString") == $A.get("$Label.c.AG_Other")){
        var justificationField = component.find("justificationField");
        var value = justificationField.get("v.value");

        if(!$A.util.isEmpty(value) && !$A.util.isUndefinedOrNull(value)){
            if($A.util.isEmpty(value.trim())){
                
                    helper.handleCustomErrorForSpace(component, event, helper);
                
            } else{
                component.set("v.showJustificationError",false);
                $A.util.removeClass(justificationField,'slds-has-error');
            }
        } else{
            component.set("v.showJustificationError",false);
        }
        }
    }
})