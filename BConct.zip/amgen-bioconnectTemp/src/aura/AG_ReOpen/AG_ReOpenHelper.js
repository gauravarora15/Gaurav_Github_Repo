({
    handleView : function(component, event, helper){
        component.set("v.displaySpinner" , true);
        var objectName = component.get("v.sObjectName");

        if(!$A.util.isUndefinedOrNull(objectName) && !$A.util.isEmpty(objectName)){
            if(objectName == $A.get("$Label.c.AG_PCM_Assessment_Object_API_Name"))
            {
                // VALIDATION IF THE OBJECT IS PCM ASSESSMENT
                helper.pcmAssessmentValidation(component,event,helper);
            } else if(objectName == $A.get("$Label.c.AG_PCM_Inv_Notification_Reference")){
                // VALIDATION IF THE OBJECT IS PCM INV REFERENCE
                helper.invReferenceValidation(component,event,helper);
            } else if(objectName == $A.get("$Label.c.AG_Case_Object_API_Name")){
                // VALIDATION IF THE OBJECT IS CASE
                //helper.profileCheck(component,event,helper);
                helper.caseValidation(component, event, helper)
            } else if(objectName == $A.get("$Label.c.AG_PCM_Investigation_Object_API_Name")){
                // VALIDATION IF THE OBJECT IS PCM INVESTIGATION
                //helper.profileCheck(component,event,helper);
                helper.PCMInvestigationValidation(component, event, helper);
            } else if(objectName == $A.get("$Label.c.AG_PCM_Issue_Object_API_Name")){
                // VALIDATION IF THE OBJECT IS PCM ISSUE
                //helper.profileCheck(component,event,helper);
                helper.pcmIssueValidation(component, event, helper);
            } else if(objectName == $A.get("$Label.c.AG_PCM_Return_Unit_Object_API_Name")){
                // VALIDATION IF THE OBJECT IS PCM Return Unit
                //helper.profileCheck(component,event,helper);
                helper.pcmReturnUnitValidation(component, event, helper);
            }

        } else{
            helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_Generic_Reopen_Error"));
        }
        
        
		
    },
    //METHOD TO VALIDATE THE ASSESSMENT RECORD FOR REOPENING
    pcmAssessmentValidation : function(component, event, helper){
        var loggedInUser = component.get("v.loggedInUser");
        var recordData = component.get("v.reopenedRecord");
        var caseOwner = recordData.OwnerId;
        
        //SET THE REOPEN REASON AND JUSTIFICATION AS BLANK
        component.set("v.reopenedRecord.AG_Reopen_Reason__c",'');
        component.set("v.reopenedRecord.AG_Reopen_Justification__c",''); 
        
        //CONVERT THE 18 DIGIT USER ID IN TO 15 DIGIT
        if(!$A.util.isUndefinedOrNull(loggedInUser) && !$A.util.isEmpty(loggedInUser)){
            var loggedInUser = loggedInUser.substring(0,15);   
        }
        if(!$A.util.isUndefinedOrNull(caseOwner) && !$A.util.isEmpty(caseOwner)){
            var caseOwner = caseOwner.substring(0,15);   
        }
        if(!$A.util.isUndefinedOrNull(recordData.AG_Assessor__c) && !$A.util.isEmpty(recordData.AG_Assessor__c)){
            var assessor = recordData.AG_Assessor__c.substring(0,15);
        }
        //CHANGES AS PER FEEDBACK
        if(recordData.AG_Status__c != $A.get("$Label.c.AG_Completed") && recordData.AG_Status__c != $A.get("$Label.c.AG_Pending_Approval")){
            //THROW ERROR THAT THE USER IS NOT CORRECT
            helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_Reopen_Restriction_Message"));
        } else if(!$A.util.isEmpty(recordData.AG_PCM_Subcase__c) && !$A.util.isUndefinedOrNull(recordData.AG_PCM_Subcase__c) && recordData.AG_PCM_Subcase__r.Status == $A.get("$Label.c.AG_Ready_for_Closure_Status")){
            helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),"PCM Assessment cannot be updated for pcm sub case with 'Ready for Closure' status");
        }else if(!$A.util.isEmpty(recordData.AG_PCM_Issue__c) && !$A.util.isUndefinedOrNull(recordData.AG_PCM_Issue__c) && (recordData.AG_PCM_Issue__r.AG_Status__c == $A.get("$Label.c.AG_Closed") || recordData.AG_PCM_Issue__r.AG_Status__c == $A.get("$Label.c.AG_Void_Label"))){
            helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),"PCM Assessment cannot be updated for pcm Issue with 'Closed or Void' status");
        } else{
            if(recordData.AG_Status__c == $A.get("$Label.c.AG_Completed"))
            {
                if(loggedInUser == caseOwner)
                { 
                    // CALL THE GENERIC METHOD OF ONLOAD
                    helper.onLoadMethod(component,event,helper);
                }    
                else
                {
                    //THROW THE ERROR THAT COMPLETED CAN BE OPENED BY OWNER ONLY
                    helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_Completed_Assessment_Reopen_Error"));      
                }
            } 
            if(recordData.AG_Status__c == $A.get("$Label.c.AG_Pending_Approval") )
            {
                if(loggedInUser == assessor )
                { 
                    // CALL THE GENERIC METHOD OF ONLOAD
                    helper.onLoadMethod(component,event,helper);
                }      
                else{
                    //THROW THE ERROR THAT PENDING CAN BE OPENED BY ASSESSOR ONLY
                    helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_Pending_Assessment_Reopen_Error"));      
                }
            }
        }  
    },
    //METHOD TO VALIDATE THE INV REFERENCE RECORD FOR REOPENING
    invReferenceValidation : function(component, event, helper){
        //SET THE ATTRIBUTES BASED ON OBJECT 
        var loggedInUser = component.get("v.loggedInUser");
        var recordData = component.get("v.reopenedRecord");
        var caseOwner
        if(!$A.util.isUndefinedOrNull(recordData) && !$A.util.isEmpty(recordData)){
            caseOwner = recordData.AG_OwnerId_Apex__c;
            component.set("v.reopenedRecord.AG_Reopen_Reason__c",'');
            component.set("v.reopenedRecord.AG_Reopen_Justification__c",''); 
            //CONVERT THE 18 DIGIT USER ID IN TO 15 DIGIT
            if(!$A.util.isUndefinedOrNull(loggedInUser) && !$A.util.isEmpty(loggedInUser)){
                var loggedInUser = loggedInUser.substring(0,15);   
            }
            //CONVERT THE 18 DIGIT USER ID IN TO 15 DIGIT
            if(!$A.util.isUndefinedOrNull(caseOwner) && !$A.util.isEmpty(caseOwner)){
                var caseOwner = caseOwner.substring(0,15);   
            } 
            if(recordData.AG_Status__c != $A.get("$Label.c.AG_Completed"))
            {
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_IN_Reference_Reopen_Status_Error"));
            }
            else{
                if(loggedInUser == caseOwner){ 
                    // CALL THE GENERIC METHOD OF ONLOAD
                    helper.onLoadMethod(component,event,helper);
                }
                else{
                    helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_IN_Reference_Reopen_Owner_Error"));
                }  
            }
        }
        else{
            helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),'You donot have permission to perform this operation');
        }  
    },  
    //METHOD TO FETCH THE PICKLIST VALUES
    onLoadMethod : function(component, event, helper){
        // SERVER CALL TO FETCH THE DATA ON LOAD
        
        var action = component.get('c.onLoad');
        action.setParams({
            "recId": component.get("v.recordId"),
            "objectName" :component.get("v.sObjectName")
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            var returnValues = response.getReturnValue();
            if(state == 'SUCCESS'){
                if(!$A.util.isUndefinedOrNull(returnValues) && !$A.util.isEmpty(returnValues)){
                    component.set("v.reopenReason",response.getReturnValue());     
                    component.set("v.showFields",true); 
                }
                else{
                    helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_Generic_Reopen_Error"));
                }
            }
            else if(state === "INCOMPLETE"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_Generic_Reopen_Error"));
                
            } else if(state === "ERROR"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_Generic_Reopen_Error"));  
                
            }
            component.set("v.displaySpinner" , false);
        });    
        $A.enqueueAction(action); 
        
    }, 

    profileCheck : function(component, event, helper){
        var action = component.get("c.profileCheck");
        var errorMessage = '';
        var recordFields;
        action.setParams({
            "objectName" : component.get("v.sObjectName"),
            "recordId" : component.get("v.recordId")
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                if(response.getReturnValue()){
                    if(component.get("v.sObjectName") == $A.get("$Label.c.AG_PCM_Investigation_Object_API_Name")){
                        recordFields = $A.get("$Label.c.AG_PCM_Investigation_Ref_Fields");
                        helper.setFieldsForLDS(component, event, helper, recordFields);
                        //helper.PCMInvestigationValidation(component, event, helper);
                    } else if(component.get("v.sObjectName") == $A.get("$Label.c.AG_PCM_Return_Unit_Object_API_Name")){
                        recordFields = $A.get("$Label.c.AG_PCM_Return_Unit_Field_Query_Reopen");
                        helper.setFieldsForLDS(component, event, helper, recordFields);
                        //helper.pcmReturnUnitValidation(component, event, helper);
                    } else if(component.get("v.sObjectName") == $A.get("$Label.c.AG_PCM_Issue_Object_API_Name")){
                        recordFields = $A.get("$Label.c.AG_PCM_Issue_Field_Query_Reopen");
                        helper.setFieldsForLDS(component, event, helper, recordFields);
                        //helper.pcmIssueValidation(component, event, helper);
                    } else if(component.get("v.sObjectName") == $A.get("$Label.c.AG_Case_Object_API_Name")){
                        recordFields = $A.get("$Label.c.AG_Case_PCM_Ref_Fields"); //contains fields for PCM as well as SR
                        helper.setFieldsForLDS(component, event, helper, recordFields);
                        //helper.caseValidation(component, event, helper)
                    }
                } else{

                    /*

                    if(component.get("v.sObjectName") == $A.get("$Label.c.AG_PCM_Investigation_Object_API_Name")){
                        errorMessage =  $A.get("$Label.c.AG_PCM_Investigation_Notification_ReOpen_ProfileCheck");
                    } else if(component.get("v.sObjectName") == $A.get("$Label.c.AG_PCM_Return_Unit_Object_API_Name")){
                        errorMessage =  $A.get("$Label.c.AG_PCM_Return_Unit_Reopen_ProfileCheck");
                    } else if(component.get("v.sObjectName") == $A.get("$Label.c.AG_PCM_Issue_Object_API_Name")){
                        errorMessage = $A.get("$Label.c.AG_PCM_Issue_ProfileCheck");
                    } else if(component.get("v.sObjectName") == $A.get("$Label.c.AG_Case_Object_API_Name")){
                        if(component.get("v.reopenedRecord.RecordType.DeveloperName") == $A.get("$Label.c.AG_PCM_RecType")){
                            errorMessage = $A.get("$Label.c.AG_PCM_Subcase_ProfileCheck");
                        } else if(component.get("v.reopenedRecord.RecordType.DeveloperName") == $A.get("$Label.c.AG_SR_RT_DeveloperName")){
                            errorMessage = $A.get("$Label.c.AG_SR_Subcase_Profile_Check");
                        }
                    } */
                    helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_Profile_Check_Restriction"));  
                }
            } else{
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_Generic_Reopen_Error"));
            }
        });
        $A.enqueueAction(action);
    },

    // METHOD TO CHECK FOR VALIDATION ERROR ON SAVE 
    formValidation : function(component, event, helper){ 

        var reopenJustification = (component.get("v.reopenJustificationString"));
        
        var validity = component.find("formValidation").get("v.validity");

        if(!validity.valid)
        {
            component.find("formValidation").showHelpMessageIfInvalid();
        }
            // Displays error messages for invalid fields
        var justificationField = component.find("justificationField");

            //resetting error message
            component.set("v.showStandardError",false);
            component.set("v.showJustificationError",false);
            $A.util.removeClass(justificationField,'slds-has-error');
            var justificationValue = justificationField.get("v.value");
            if(component.get("v.reopenReasonString") == $A.get("$Label.c.AG_Other") && ($A.util.isEmpty(justificationValue) || $A.util.isUndefinedOrNull(justificationValue))){

                justificationField.set('v.validity', {valid:false, badInput :true});
                justificationField.showHelpMessageIfInvalid();
                component.set("v.showStandardError",true);
            }
            else if(component.get("v.reopenReasonString") == $A.get("$Label.c.AG_Other") && !$A.util.isEmpty(justificationValue) && ($A.util.isUndefinedOrNull(justificationValue.trim()) || $A.util.isEmpty(justificationValue.trim())))
            {
                component.set("v.showStandardError",false); 
                helper.handleCustomErrorForSpace(component, event, helper);
            } 

        if(validity.valid && !component.get("v.showJustificationError") && !component.get("v.showStandardError")){
          
          //SAVE THE RECORD IF NO VALIDATION ERROR IS FOUND           
            helper.handleSaveOperation(component, event, helper);
        }
    },
     handleCustomErrorForSpace: function(component, event, helper){
        var justificationError = component.find("justificationField");
        $A.util.addClass(justificationError,'slds-has-error');
        if(!component.get("v.showJustificationError")){
            component.set("v.showJustificationError",true);
            component.set("v.showStandardError",false);
        }
        
    },
    //SAVE OPERATION
    handleSaveOperation : function(component, event, helper){   
        component.set("v.displaySpinner",true);

        component.set("v.reopenedRecord.AG_Reopen_Justification__c",component.get("v.reopenJustificationString"));
        component.set("v.reopenedRecord.AG_Reopen_Reason__c",component.get("v.reopenReasonString"));

        
        /*
        if(component.get("v.sObjectName") == $A.get("$Label.c.AG_PCM_Inv_Notification_Reference"))
        {
            component.set("v.reopenedRecord.AG_Reopen_Reason__c",component.get("v.reopenReasonString"));  
        }
        else if(component.get("v.sObjectName") == $A.get("$Label.c.AG_PCM_Assessment_Object_API_Name"))
        {
            component.set("v.reopenedRecord.AG_Reopen_reason__c",component.get("v.reopenReasonString"));
            
        }
        else if(component.get("v.sObjectName") == $A.get("$Label.c.AG_Case_Object_API_Name"))
        {
            component.set("v.reopenedRecord.AG_Reopen_reason__c",component.get("v.reopenReasonString"));
        }
        else if(component.get("v.sObjectName") == $A.get("$Label.c.AG_PCM_Investigation_Object_API_Name"))
        {
            component.set("v.reopenedRecord.AG_Reopen_Reason__c",component.get("v.reopenReasonString"));
        }
        */
        var action = component.get('c.reOpenRecord');
        action.setParams({
            "reopenedRecord" : component.get("v.reopenedRecord"),
            "recId" : component.get("v.recordId"),
            "objectName" :component.get("v.sObjectName")
            
        });
        
        action.setCallback(this,function(response){
            var state = response.getState(); 
            if(state == 'SUCCESS'){
                if(!response.getReturnValue())
                {
                    $A.get("e.force:closeQuickAction").fire(); 
                    helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_Generic_Reopen_Error"));  
                }
                else{
                    helper.showToast($A.get("$Label.c.AG_Sucess_Toast_Type"),$A.get("$Label.c.AG_Sucess_Toast_Type"),$A.get("$Label.c.AG_Reopen_Success"));   
                    $A.get("e.force:closeQuickAction").fire(); 
                    $A.get('e.force:refreshView').fire();
                }
            }
            else if(state === "INCOMPLETE"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_Generic_Reopen_Error"));
            } 
                else if(state === "ERROR"){    
                    helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_Generic_Reopen_Error"));
                }
            component.set("v.displaySpinner" , false);
        });
        $A.enqueueAction(action);    
    },
    
    //TO HANDLE CANCEL OPERATION
    handleCancelOperation:function(component, event) {
        $A.get("e.force:closeQuickAction").fire();   
    },
    
    checkJustificationRequired:function(component, event) {
        var objectName = component.get("v.sObjectName");
        var reopenReason = component.get("v.reopenReasonString");
        
        if(!$A.util.isUndefinedOrNull(reopenReason) && reopenReason == $A.get("$Label.c.AG_Other"))
        {
            component.set("v.justificationRequired",true);

        }
        else{
            component.set("v.justificationRequired",false);
        }  
    },
    // METHOD FOR TOAST MESSAGE
    showToast: function(toastTitle, toastType, toastMessage){
        $A.get('e.force:refreshView').fire();
        $A.get("e.force:closeQuickAction").fire();
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": toastTitle,
            "type": toastType,
            "message": toastMessage
        });
        toastEvent.fire();
    },

    callServerForData : function(component, event, helper){
        var action = component.get("c.getRecordDetails");
        action.setParams({
            "objectName" : component.get("v.sObjectName"),
            "recordId" : component.get("v.recordId"),
            "fieldSet" : component.get("v.fieldsList")
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === 'SUCCESS'){
                component.set("v.reopenedRecord",response.getReturnValue());
                component.set("v.hasSObjectName",true);
                helper.handleView(component, event, helper);   
            } else{
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_Generic_Reopen_Error"));
            }
        });
        $A.enqueueAction(action);
    },
    
    caseValidation : function(component, event, helper){
        var loggedInUser = component.get("v.loggedInUser");
        var recordData = component.get("v.reopenedRecord");
        component.set("v.reopenedRecord.AG_Reopen_Reason__c",'');
        component.set("v.reopenedRecord.AG_Reopen_Justification__c",'');

        if(recordData.RecordType.DeveloperName == $A.get("$Label.c.AG_PCM_RecType")){
            if(recordData.Status != $A.get("$Label.c.AG_Completed")){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_Case_PCM_Reopen_Restriction_Message"));
            } else{
                // CALL THE GENERIC METHOD OF ONLOAD
                helper.onLoadMethod(component,event,helper);   
            }
        } else if(recordData.RecordType.DeveloperName == $A.get("$Label.c.AG_SR_RT_DeveloperName")){
            if(recordData.Status != $A.get("$Label.c.AG_Case_Status_RejectedInArgus")){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_SR_Reopen_Restriction_Message"));
            } else if(recordData.OwnerId != loggedInUser){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_SR_Subcase_Owner_Restriction"));
            } else{
                // CALL THE GENERIC METHOD OF ONLOAD
                helper.onLoadMethod(component,event,helper);   
            }
        }
    },
	PCMInvestigationValidation : function(component, event, helper){
        var loggedInUser = component.get("v.loggedInUser");
        var recordData = component.get("v.reopenedRecord");
        component.set("v.reopenedRecord.AG_Reopen_Reason__c",'');
        component.set("v.reopenedRecord.AG_Reopen_Justification__c",'');

        
        if(recordData.AG_Status__c != $A.get("$Label.c.AG_Completed") && recordData.AG_Status__c !=$A.get("$Label.c.AG_PendingReview")){
            helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_PCM_Investigation_Reopen_Restriction_Message"));
        }
        else{
            /*if(!$A.util.isUndefinedOrNull(recordData.AG_Originating_PCM_Record__c) && !$A.util.isEmpty(recordData.AG_Originating_PCM_Record__c)){
                //if PCM Notification is associated to PCM SubCase, only PCM Owner can reopen
                if(loggedInUser == recordData.AG_Originating_PCM_Record__r.OwnerId){
                    // CALL THE GENERIC METHOD OF ONLOAD
                    helper.onLoadMethod(component,event,helper);
                } else{
                    helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_PCM_Investigation_Notification_ReOpen_Not_Owner"));
                }
            } else{
                //if PCM Invetigation is not associated to PCM Subcase, then any valid profile can reopen
                helper.onLoadMethod(component,event,helper);
            }*/

            /*As per US-1517 anyone with the given profile set can reopen*/
            helper.onLoadMethod(component,event,helper);
        } 
    },

    setFieldsForLDS : function(component, event, helper, recordFields){
        component.set("v.fieldsList",recordFields);
        if(!$A.util.isUndefinedOrNull(component.get("v.fieldsList")) && !$A.util.isEmpty(component.get("v.fieldsList")))   
        {
            //component.set("v.hasSObjectName",true);
            helper.callServerForData(component, event, helper);
        }
    },

	pcmIssueValidation : function(component, event, helper){
        var recordData = component.get("v.reopenedRecord");
        var loggedInUser = component.get("v.loggedInUser");
        component.set("v.reopenedRecord.AG_Reopen_Reason__c",'');
        component.set("v.reopenedRecord.AG_Reopen_Justification__c",'');
        
        if(recordData.AG_Status__c != $A.get("$Label.c.AG_Closed")){
            helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_PCM_Issue_Reopen_Restriction_Message"));
        } else if(recordData.AG_PCM_Record__r.Status == $A.get("$Label.c.AG_Completed")){
            helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_Related_PCM_In_COmpleted_Status"));
        } else if(recordData.AG_PCM_Record__r.Status == $A.get("$Label.c.AG_Ready_for_Closure_Status")){
            helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),"PCM Issue cannot be updated for pcm sub case with 'Ready for Closure' status");
        } else if(loggedInUser != recordData.AG_PCM_Record__r.OwnerId){
            helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_PCM_Issue_Reopen_Not_Owner"));
        } else{
            helper.onLoadMethod(component,event,helper);
        }
         
    },

    pcmReturnUnitValidation : function(component, event, helper){
        var loggedInUser = component.get("v.loggedInUser");
        var recordData = component.get("v.reopenedRecord");
        component.set("v.reopenedRecord.AG_Reopen_Reason__c",'');
        component.set("v.reopenedRecord.AG_Reopen_Justification__c",'');

        //CONVERT THE 18 DIGIT USER ID IN TO 15 DIGIT
        var pcmReturnUnitOwner = recordData.AG_Sub_Case_Number__r.OwnerId;
            
        if(recordData.AG_Status__c != $A.get("$Label.c.AG_PCM_Return_Unit_Status_Return_Destroyed")){
            helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_PCM_Return_Unit_Reopen_Restriction"));
        } else{
            if(loggedInUser != pcmReturnUnitOwner){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_PCM_Return_Unit_ReOpen_Not_Owner"));
            } else{
                // CALL THE GENERIC METHOD OF ONLOAD
                helper.onLoadMethod(component,event,helper);
            }
        }
    }
})
