({
	doInit : function(component, event, helper) {
		helper.loadFulfillmentMethods(component , event , helper);
	},
    userSelect : function(component, event, helper) {
		helper.userSelectHelper(component , event , helper);	
	},
	handleMethodSelected : function(component,event,helper){
		 helper.methodSelectedHelper(component , event , helper);
	} 
})