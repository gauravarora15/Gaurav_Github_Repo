({
	loadFulfillmentMethods : function(component,event,helper) {
		component.set("v.displaySpinner" , true);
        component.set("v.validationMessage", "");
		/*The object is used to store user selected Fulfillment Methods*/ 
		var methods = {};
        methods.isNotified = false;
        methods.isCC = false;
		methods.email = false;
		methods.fax = false;
		methods.postalMail = false;
		methods.emailFacilitator = false;
		methods.PostalMailFacilitator = false;
		component.set("v.methodSelection" , methods);
		
		
        var packageId = component.get("v.fulfillmentPackageId");
        var userDataId = component.get("v.fulfillmentUserDataId");
        var masterCaseWrapper = component.get("v.masterCaseWrapper");
        if(!$A.util.isEmpty(masterCaseWrapper) && !$A.util.isUndefined(masterCaseWrapper)){
            component.set("v.disableButton", true);
        }
        /*Server call to fetch all validations with respect to Fulfillment Methods.*/
        var action = component.get("c.fetchFulfillmentPackage");
        action.setParams({"packageId" : packageId, 
                          "userDataId" : userDataId });
        action.setCallback(this,function(response){
            var state = response.getState();
            
            if(state === "SUCCESS"){
                var packageData = response.getReturnValue();
                
                if(!$A.util.isEmpty(packageData) && !$A.util.isUndefined(packageData) && !packageData.errorState){
                    if($A.util.isEmpty(packageData.errorMessage)){
                        component.set("v.responseData" , packageData);
                    }else{
                        component.set("v.validationMessage",packageData.errorMessage);
                    }
                    
                    }else{
                    helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                }  
            }else if(state === "ERROR"){
                	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }else if(state === "INCOMPLETE"){
                	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }
            component.set("v.displaySpinner" , false);
        });
        $A.enqueueAction(action);
		
	},
	/*Navigate to respective screens*/
    userSelectHelper : function(component , event , helper) {
        var key = event.getSource().getLocalId();
        if(key === 'prev'){
            //helper.enableUserData(component,event , helper);
            helper.navigateToComponents(component,event , helper,4);
        }else if(key === 'close'){
            helper.navigateToComponents(component,event , helper,0);
        }else if(key === 'cancel'){
            helper.navigateToComponents(component,event , helper,0);
        }else if(key === 'next'){
         	helper.validateNextMethod(component,event , helper); 
        }else if(key === 'preview'){
            helper.previewModeHelper(component , event , helper);
        }  
    },
    /*Helper to navigate to components based on component No.*/
    navigateToComponents  :function(component , event , helper,componentNo){
    	
        var compEvent = component.getEvent("navigateComponent");
        compEvent.setParams({"componentNo" : componentNo ,
                             "masterCaseWrapper" : JSON.stringify(component.get("v.masterCaseWrapper")),
                             "selectedRequests" : component.get("v.selectedRequestState"),
                             "documentsReordered" : component.get("v.documentsReordered"),
                             "fulfillmentPackageId" : component.get("v.fulfillmentPackageId"),
                             "fulfillmentUserData":component.get("v.fulfillmentUserDataId"),
                             "methodSelection" : JSON.stringify(component.get("v.methodSelection")),
                             });
        compEvent.fire();
    },
    /*Helper to navigate to components based on component No.*/
    methodSelectedHelper : function(component,event,helper){
    		component.set("v.errorMessage" , "");
            component.set("v.validationMessage", "");
    		var responseData = component.get("v.responseData");
    		var availableFor = event.getSource().getLocalId();
    		if(availableFor === 'Email'){
	    		var buttonstate = component.get('v.methodSelection.email');
	    		if(!responseData.isValid_emailMethod){
	    			var message = '';
	    			for(var i in responseData.error_emailMethod){
	    				message = message+'\n'+responseData.error_emailMethod[i];
	    			}
	    			helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error_Message") , message ,$A.get("$Label.c.AG_Error"));
	    		}else{
	    			component.set('v.methodSelection.email', !buttonstate);
	    		}
	    		
	    	}else if(availableFor === 'Fax'){
	    		var buttonstate = component.get('v.methodSelection.fax');
	    		if(!responseData.isValid_faxMethod){
	    			var message = '';
	    			for(var i in responseData.error_faxMethod){
	    				message = message+'\n'+responseData.error_faxMethod[i];
	    			}
	    			helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error_Message") , message ,$A.get("$Label.c.AG_Error"));
	    		}else{
	    			component.set('v.methodSelection.fax', !buttonstate);
	    		}
	    	}
	    	else if(availableFor === 'PostalMail'){
	    		var buttonstate = component.get('v.methodSelection.postalMail');
	    		
	    		if(!responseData.isValid_postalMailMethod){
	    			var message = '';
	    			for(var i in responseData.error_postalMailMethod){
	    				message = message+'\n'+responseData.error_postalMailMethod[i];
	    			}
	    			helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error_Message") , message ,$A.get("$Label.c.AG_Error"));
	    		}else{
	    			component.set('v.methodSelection.postalMail', !buttonstate);
	    		}
	    	}
	    	else if(availableFor === 'emailFacilitator'){
	    		var buttonstate = component.get('v.methodSelection.emailFacilitator');
	    		
	    		if(!responseData.isValid_emailFacilitatorMethod){
	    			var message = '';
	    			for(var i in responseData.error_emailFacilitatorMethod){
	    				message = message+'\n'+responseData.error_emailFacilitatorMethod[i];
	    			}
	    			helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error_Message") , message ,$A.get("$Label.c.AG_Error"));
	    		}else{
	    			component.set('v.methodSelection.emailFacilitator', !buttonstate);
                    var abc = component.get("v.methodSelection.emailFacilitator");
	    		}
	    	}
	    	else if(availableFor === 'PostalMailFacilitator'){
	    		var buttonstate = component.get('v.methodSelection.PostalMailFacilitator');
	    		
	    		if(!responseData.isValid_postalMailFacilitatorMethod){
	    			var message = '';
	    			for(var i in responseData.error_postalMailFacilitatorMethod){
	    				message = message+'\n'+responseData.error_postalMailFacilitatorMethod[i];
	    			}
	    			helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error_Message") , message ,$A.get("$Label.c.AG_Error"));
	    		}else{
	    			component.set('v.methodSelection.PostalMailFacilitator', !buttonstate);
	    		}
	    	}
    },
    /*Toast event to show message to user.*/
    showToast : function(component, event, helper,title , message , type) {
    	
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message,
            "type" : type,
            "duration" : 6000
        });
        toastEvent.fire();
    },
    /*Method to validate/navigate to next Fulfillment Method.*/
    validateNextMethod : function(component , event , helper){
    	var buttonSelected = component.get('v.methodSelection');
        component.set("v.validationMessage", "");
    	if(buttonSelected.email || buttonSelected.fax || buttonSelected.postalMail || buttonSelected.emailFacilitator || buttonSelected.PostalMailFacilitator){
    		if(component.get("v.reviewedMResponse") || $A.util.isEmpty(component.get("v.responseData").fulfillmentPackageId)){
    			helper.navigateToComponents(component,event , helper,6);
    		}else{
    			component.set("v.reviewedMResponse" , true);
         		helper.openPromptComponent(component,event,helper,$A.get("$Label.c.AG_Preview_Merge_Response_Error"));
         	}  
    	}else{
    		component.set("v.errorMessage" , $A.get("$Label.c.AG_Error_Message_Method"));
    	}
    },
 
    previewModeHelper : function(component ,event,helper){
		
            component.set("v.reviewedMResponse" , true);
            var urlEvent = $A.get("e.force:navigateToURL");
		    urlEvent.setParams({
		      "url": "/c/AG_PDFViewerApp.app?docId="+component.get("v.responseData").fulfillmentPackageId + ',' + $A.get("$Label.c.AG_Volt_Label")
		    });
		    urlEvent.fire();
    },
    /*On Previous Button to enable User Data to maintain state*/
    enableUserData : function(component , event , helper){
    	var action = component.get("c.enableUserData");
        var userDataId = component.get("v.fulfillmentUserDataId");
        var fulfillmentPackageId = component.get("v.fulfillmentPackageId");
        
        action.setParams({"userDataId" : userDataId ,"packageDataId" :fulfillmentPackageId});
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var isSuccess = response.getReturnValue();
                if(!$A.util.isEmpty(isSuccess) && !$A.util.isUndefined(isSuccess)){
                	if(!isSuccess){
                		helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                	}
                	helper.navigateToComponents(component,event , helper,4);
                	
                }else{
                    helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                }  
            }else if(state === "ERROR"){
                	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }else if(state === "INCOMPLETE"){
                	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }
            component.set("v.displaySpinner" , false);
        });
        $A.enqueueAction(action);
    },
    //SHOW ALERT TO REVIEW MERGE RESPONSE
    openPromptComponent : function(component,event,helper, message){
    	var modalBody;
        $A.createComponent("c:AG_Reusable_Prompt_Component", {"message" : message , 
        					"confirm":component.getReference('v.confirm') , "isPrompt":false},
           function(content, status) {
               if (status === "SUCCESS") {
                   modalBody = content;
                   component.find('overlayLib').showCustomModal({
                       header: $A.get("$Label.c.AG_Label_Warning"),
                       body: modalBody, 
                       showCloseButton: false,
                       cssClass: "mymodal",
                       closeCallback: function() {
                    	   component.set("v.displaySpinner" , false);
                       }
                   })
               }                               
           });
    }
})