({
	doInit: function(component, event, helper){
       	var action = component.get("c.createMasterCase");
        action.setCallback(this,function(response){
            //get the response state
            var state = response.getState();
            //check if result is successfull
            if(state === "SUCCESS"){
                component.set("v.Spinner",false);
                var returnMasterCase = response.getReturnValue();
                
                // Navigation to new Case
                if(returnMasterCase != $A.get("Label.c.AG_Case_Creation_Error")){
                    var focusedTabId = '';
                    var workspaceAPI = component.find("workspace");
                    workspaceAPI.getFocusedTabInfo().then(function(response) {
                        
                        focusedTabId = response.tabId;
                        workspaceAPI.openTab({
                            pageReference: {
                                "type": "standard__recordPage",
                                "attributes": {
                                    "recordId":returnMasterCase,
                                    "actionName":"view"
                                },
                                "state": {}
                            },
                            focus: true
                        }).then(function(response) {
                            workspaceAPI.closeTab({tabId: focusedTabId});
                        }).catch(function(error) {
                            console.log(error);
                        });
                        
                        // Show toast on success case
                        helper.showToast($A.get("$Label.c.AG_Case_Success_Title"),$A.get("$Label.c.AG_Sucess_Toast_Type"),$A.get("$Label.c.AG_Case_Save_Message"));
                        
                    }).catch(function(error) {
                        console.log(error);
                    });
                }else{
                    // Show toast on error case
                    helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_Case_Creation_Error"));
                }
            }
            else if(state === "INCOMPLETE"){
                // Show toast on error case
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_Case_Creation_Error"));
                
            }
                else if(state === "ERROR"){
                    // Show toast on error case
                    helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_Case_Creation_Error"));
                    
                }
            
        });
        $A.enqueueAction(action);
    },
    
    showToast: function(toastTitle, toastType, toastMessage){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": toastTitle,
            "type": toastType,
            "message": toastMessage
        });
        toastEvent.fire();
    } ,
    
    navigateToMasterCase : function(component , event , helper){
        
        var workspaceAPI = component.find("workspace");
        var focusedTabId;
        workspaceAPI.getFocusedTabInfo().then(function(response) {
            focusedTabId = response.tabId;
        })
        .catch(function(error) {
            
        });
        
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/lightning/o/Case/list"
        });
        urlEvent.fire();
        workspaceAPI.closeTab({tabId: focusedTabId});
        
    }
    
})