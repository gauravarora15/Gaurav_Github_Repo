({
	doInit : function(component, event, helper) {
		component.set("v.Spinner",false);
        var pageReference = component.get("v.pageReference");
        console.log(Date.now() - pageReference.state.c__createNewCase);
        if(Date.now() - pageReference.state.c__createNewCase < 1000){
        	helper.doInit(component, event, helper);    
        }else{
            helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_Restrict_Back_Button"));
            helper.navigateToMasterCase(component, event, helper);
        }
	}
})