({
	closeToast : function(component, event, helper) {
		component.destroy();
	}
})