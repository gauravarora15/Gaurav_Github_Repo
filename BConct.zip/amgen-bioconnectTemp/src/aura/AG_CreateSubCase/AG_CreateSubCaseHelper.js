({
	//Method fired on Init
	loadSubcaseCreation : function(component , event , helper) {
		component.set("v.displaySpinner" , true);
		component.set("v.errorMessage" , '');
		component.set("v.warnMessage" , '');
		var action = component.get("c.validateSubCaseCreation");
		var recordId = component.get("v.recordId");
        action.setParams({
            "masterCaseId": recordId 
        });
        action.setCallback(this,function(response){
            
            var state = response.getState();
            if(state === "SUCCESS"){
                var res = response.getReturnValue();
                if(!$A.util.isEmpty(res) && !$A.util.isUndefined(res)){
                	component.set("v.subCaseInstance" , res);
                	helper.showCaseProductList(component , event , helper);
                	if(res.errorMessage == $A.get("$Label.c.AG_SRSubCase_Create_Error_Message") || res.errorMessage == $A.get("$Label.c.AG_errorMessage")){
                		helper.showErrorMessage(component , event , helper , res.errorMessage);
                		return;
                	}else if(res.errorMessage == $A.get("$Label.c.AG_CreateSubcaseError") || res.errorMessage == $A.get("$Label.c.AG_OwnerSubcaseError")){
                		helper.showWarnMessage(component, event, helper, res.errorMessage);
                		return;
                	}
                	component.set("v.displaySpinner" , false);
                } else{
                    helper.showErrorMessage(component, event , helper, $A.get("$Label.c.AG_errorMessage"));
                }
            } else if(state === "INCOMPLETE"){
                helper.showErrorMessage(component, event , helper, $A.get("$Label.c.AG_errorMessage"));
            } else if(state === "ERROR"){
                helper.showErrorMessage(component, event , helper, $A.get("$Label.c.AG_errorMessage"));
            }
        });
        $A.enqueueAction(action);
	},

	//Method called onClick of Create Button
	createSubcase : function(component , event , helper){
		var recordId = component.get("v.recordId");
		component.set("v.displaySpinner" , true);
		component.set("v.errorMessage" , "");
		component.set("v.warnMessage" , "");
		var subCaseInstance = component.get("v.subCaseInstance");
		var inputCmp = component.find("caseProduct");
		var validity = inputCmp.get("v.validity");
		if((!subCaseInstance.isMICase && !subCaseInstance.isPCMCase && !subCaseInstance.isSRCase && !subCaseInstance.isRFCase) || (!validity.valid)){
			
			if(!validity.valid){
				inputCmp.showHelpMessageIfInvalid();
			}
			if((!subCaseInstance.isMICase && !subCaseInstance.isPCMCase && !subCaseInstance.isSRCase && !subCaseInstance.isRFCase)){
				component.set("v.noneChecked" , true);
			}
			component.set("v.displaySpinner" , false);
			return;
		}
		var action = component.get("c.createSubcase");
        action.setParams({
            "subCaseData": JSON.stringify(subCaseInstance),
           	"masterCaseId": recordId 
        });
        action.setCallback(this,function(response){
            
            var state = response.getState();
            if(state === "SUCCESS"){            	
                var res = response.getReturnValue();
                if(!$A.util.isEmpty(res) && !$A.util.isUndefined(res) && $A.util.isEmpty(res.errorMessage)){
                    if($A.util.isEmpty(res.caseProductList) || $A.util.isUndefined(res.caseProductList)){
                        helper.showToast('warning','warning','Sub case cannot be created with removed case product');
                    }
                    else{
                		helper.showToast($A.get("$Label.c.AG_Case_Success_Title"),$A.get("$Label.c.AG_Sucess_Toast_Type"),$A.get("$Label.c.AG_Create_Sub_Case_Success_Message"));
                    }
                    component.set("v.displaySpinner" , false);
                    $A.get('e.force:refreshView').fire(); 
                }else{
                    component.set("v.displaySpinner" , false);
                    helper.showErrorMessage(component, event , helper, res.errorMessage);
                }
            } else if(state === "INCOMPLETE"){
                helper.showErrorMessage(component, event , helper, $A.get("$Label.c.AG_errorMessage"));
            } else if(state === "ERROR"){
                helper.showErrorMessage(component, event , helper, $A.get("$Label.c.AG_errorMessage"));
            }
            
        });
        $A.enqueueAction(action);
	},

	//Method called for selecting Sub Cases
	subCases : function(component , event , helper){		
		component.set("v.errorMessage" , "");
		component.set("v.warnMessage" , "");
		var buttonId = event.getSource().getLocalId();
		var subCaseInstance = component.get("v.subCaseInstance");
		
		if(!$A.util.isEmpty(subCaseInstance) && !$A.util.isUndefinedOrNull(subCaseInstance)){
			if(buttonId == 'MI'){
				subCaseInstance.isMICase = !subCaseInstance.isMICase; 
				component.set("v.subCaseInstance" , subCaseInstance);
				if(subCaseInstance.isMICase){
					component.set("v.noneChecked" , false);
				}
			}else if(buttonId == 'PCM'){
				subCaseInstance.isPCMCase = !subCaseInstance.isPCMCase;
				component.set("v.subCaseInstance" , subCaseInstance);
				if(subCaseInstance.isPCMCase){
					component.set("v.noneChecked" , false);
				}
			}else if(buttonId == 'SR'){
				subCaseInstance.isSRCase = !subCaseInstance.isSRCase;
				component.set("v.subCaseInstance" , subCaseInstance);
				if(subCaseInstance.isSRCase){
					component.set("v.noneChecked" , false);
				}
			}else if(buttonId == 'RF'){
				subCaseInstance.isRFCase = !subCaseInstance.isRFCase;
				component.set("v.subCaseInstance" , subCaseInstance);
				if(subCaseInstance.isRFCase){
					component.set("v.noneChecked" , false);
				}
			}
		}else{
			helper.showErrorMessage(component, event , helper, $A.get("$Label.c.AG_errorMessage"));
		}
	},

	// Method to show error message on the Component itself
	showErrorMessage : function(component , event , helper , errorMessage){
		component.set("v.errorMessage" , errorMessage);
		component.set("v.displaySpinner" , false);
	},

	// Method to show warn message on the Component itself
	showWarnMessage : function(component, event, helper, errorMessage){
		component.set("v.warnMessage", errorMessage);
		component.set("v.displaySpinner" , false);
	},

	// Method to Refresh the component after closing the error toast
	closeMessage: function(component, event, helper){
		$A.get('e.force:refreshView').fire();
	},

	// Method to fetch the Case Product List on Init
	showCaseProductList : function(component , event , helper){
		
		var subCaseInstance =  component.get("v.subCaseInstance");
		var caseProducts = subCaseInstance.caseProductList;
		var caseProductArray = [];
		
		for(var i=0; i<caseProducts.length; i++){
			var caseProduct = {};
			caseProduct.Id = caseProducts[i].Id;
			var label ='';
			if(!$A.util.isEmpty(caseProducts[i].AG_Product__c) && !$A.util.isUndefinedOrNull(caseProducts[i].AG_Product__c)){
				label = caseProducts[i].AG_Product__r.Name;
			}
			
			if(!$A.util.isEmpty(caseProducts[i].AG_Lot_Batch_Number_NotOnView__c) && !$A.util.isUndefinedOrNull(caseProducts[i].AG_Lot_Batch_Number_NotOnView__c)){
				label = label + ' [LB No. ' + caseProducts[i].AG_Lot_Batch_Number_NotOnView__c + ']';
			}else{
				label = label + ' [LB No. ]';
			}
			
			caseProduct.Label = label;
			caseProductArray.push(caseProduct);
			
		}
		
		component.set("v.caseProductList" , caseProductArray);
		
	},
	
	showToast: function(toastTitle, toastType, toastMessage){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": toastTitle,
            "type": toastType,
            "message": toastMessage
        });
        toastEvent.fire();
    }
})
