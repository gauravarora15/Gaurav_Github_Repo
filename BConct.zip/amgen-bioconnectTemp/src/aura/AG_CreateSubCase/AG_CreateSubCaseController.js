({
	doInit : function(component, event, helper) {
		helper.loadSubcaseCreation(component , event , helper);
	},
	subCaseSelected : function(component, event, helper) {
		helper.subCases(component , event , helper);
	},
	handleCreate : function(component , event , helper){
		helper.createSubcase(component , event , helper);
	},
	closeMessage :function(component , event , helper){
		helper.closeMessage(component, event, helper);
	}
})