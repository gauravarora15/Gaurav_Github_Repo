({
	handleDoInit : function(component, event, helper) {
		component.set("v.errorMessage", '');
		component.set("v.Spinner" , true);
		var responseFromUser = {};
		responseFromUser.ParentId = component.get("v.parentId");
		responseFromUser.ProductId = '';
		responseFromUser.therapeuticId = '';
		responseFromUser.geography = '';
		responseFromUser.language = '';
		responseFromUser.MIClassification = '';
		if(component.get("v.forMasterCase")== true){
			responseFromUser.verbal = true;
		}else{
			responseFromUser.verbal = false;
		}
		responseFromUser.postal = false;
		responseFromUser.email = false;
		responseFromUser.fax = false;
		component.set("v.responseFromUser" , responseFromUser);
		component.set('v.myColumns', [
                {label: $A.get("$Label.c.AG_Document_Name"), fieldName: 'name', type: 'text'},
                {label: $A.get("$Label.c.AG_Sub_Type_Val"), fieldName: 'subType', type: 'text'},
                {label: $A.get("$Label.c.AG_CLASSIFICATION"), fieldName: 'classification', type: 'text'},
                {label: $A.get("$Label.c.AG_Country"), fieldName: 'country', type: 'text'},
                {label: $A.get("$Label.c.AG_Language"), fieldName: 'language', type: 'text'}  
             ]);
		var action = component.get("c.getAllPicklistValues");
		
        action.setCallback(this,function(response){
            var state = response.getState();
            
            if(state === "SUCCESS"){
                var response = response.getReturnValue();
                if(!$A.util.isEmpty(response) && !$A.util.isUndefined(response)){
                	if(!response.hasError){
                		if(!$A.util.isEmpty(response.lstLanguage) && !$A.util.isUndefined(response.lstLanguage)){
                			helper.createLanguageList(component , event , helper,response.lstLanguage);
                		}
                		if(!$A.util.isEmpty(response.mapProduct) && !$A.util.isUndefined(response.mapProduct)){
                			helper.createProductList(component , event , helper,response.mapProduct);
                		}
                		if(!$A.util.isEmpty(response.mapTherapeuticArea) && !$A.util.isUndefined(response.mapTherapeuticArea)){
                			helper.createTherapeuticAreaList(component , event , helper,response.mapTherapeuticArea);
                		}
                		if(!$A.util.isEmpty(response.mapCountry) && !$A.util.isUndefined(response.mapCountry)){
                			helper.createCountryList(component , event , helper,response.mapCountry);
                		}
                		if(!$A.util.isEmpty(response.mapMIClassification) && !$A.util.isUndefined(response.mapMIClassification)){
                			helper.createMIClassificationList(component , event , helper,response.mapMIClassification);
                		}
                		
                		
                	}else{
                		helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                	}
                }else{
                    helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                }  
            } else if(state === "ERROR"){
                	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }
            component.set("v.Spinner" , false);
        });
        $A.enqueueAction(action);	
	},
	showToast : function(component, event, helper,title , message , type) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message,
            "type" : type
        });
        toastEvent.fire();
    },
    createLanguageList : function(component , event , helper , languagesList){
    	var languageArray = [];
    	for( var key in languagesList ){
    		var language = {};
    		language.label = languagesList[key];
    		language.value = languagesList[key];
    		languageArray.push(language);
    	}
    	component.set("v.languageList" , languageArray);
    },
    createProductList : function(component , event , helper , productList){
    	var productArray = [];
    	for( var key in productList ){
    		var product = {};
    		product.label = key;
    		product.value = productList[key];
    		productArray.push(product);
    	}
    	component.set("v.productList" , productArray);
    },
    createTherapeuticAreaList : function(component , event , helper , therapeuticAreaListList){
    	var therapeuticAreaArray = [];
    	for( var key in therapeuticAreaListList ){
    		var therapeuticArea = {};
    		therapeuticArea.label = key;
    		therapeuticArea.value = therapeuticAreaListList[key];
    		therapeuticAreaArray.push(therapeuticArea);
    	}
    	component.set("v.therapeuticList" , therapeuticAreaArray);
    },
    createCountryList : function(component , event , helper , CountryList){
    	var countryArray = [];
    	for( var key in CountryList ){
    		var country = {};
    		country.label = key;
    		country.value = CountryList[key];
    		countryArray.push(country);
    	}
    	component.set("v.geographyList" , countryArray);
    },
    createMIClassificationList : function(component , event , helper , MIClassificationList){
        var MIClassificationArray = [];
        var parentId = component.get("v.parentId");
        var action = component.get("c.defaultMIClassification");
        action.setParams({
            "parentId" : parentId
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var response = response.getReturnValue();
               
                if(!$A.util.isEmpty(response) && !$A.util.isUndefined(response)){
                        for( var key in MIClassificationList ){
                        var MIClassification = {};
                        MIClassification.label = key;
                        MIClassification.value = MIClassificationList[key];
                        if(key.toLowerCase()==response.toLowerCase()){
                        MIClassification.selected=true;
                        component.set("v.responseFromUser.MIClassification", MIClassificationList[key]);
                        }
                        MIClassificationArray.push(MIClassification);
                    }
                    component.set("v.MIClassificationList" , MIClassificationArray);
                }
            }  else if(state === "ERROR"){
                    helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                }
            });
            $A.enqueueAction(action);
        
    },
    handleAvailableForHelper : function(component , event , helper){
        component.set("v.errorMessage", '');

    		var availableFor = event.getSource().getLocalId();
	    	if(availableFor === 'Verbal' && component.get("v.forMasterCase") == false){
	    		var buttonstate = component.get('v.responseFromUser.verbal');
	    		component.set('v.responseFromUser.verbal', !buttonstate);
	    	}else if(availableFor === 'Postal'){
	    		var buttonstate = component.get('v.responseFromUser.postal');
	    		component.set('v.responseFromUser.postal', !buttonstate);
	    	}
	    	else if(availableFor === 'Email'){
	    		var buttonstate = component.get('v.responseFromUser.email');
	    		component.set('v.responseFromUser.email', !buttonstate);
	    	}else if(availableFor === 'Fax'){
	    		var buttonstate = component.get('v.responseFromUser.fax');
	    		component.set('v.responseFromUser.fax', !buttonstate);
	    	}
    	
    },
    handleSearchHelper : function(component , event , helper){
    	component.set("v.errorMessage", '');
    	component.set("v.Spinner" , true);
    	var action = component.get("c.fetchResponseData");
    	action.setParams({"request" : JSON.stringify(component.get("v.responseFromUser"))});
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var resp = response.getReturnValue();
                
                if(!$A.util.isEmpty(resp) && !$A.util.isUndefined(resp)){
                	component.set('v.lstDocuments', resp);
                }else{
                	component.set('v.errorMessage', $A.get("$Label.c.AG_Volt_Document_Search_Error"));
                	component.set('v.lstDocuments', []);
                }  
            } else if(state === "ERROR"){
                	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }
            component.set("v.Spinner" , false);
        });
        $A.enqueueAction(action);	
    },
    SelectedDocumentsHelper : function(component , event , helper){
    	 component.set("v.errorMessage", '');
    	var selectedRows = event.getParam('selectedRows');
    	component.set("v.selectedDocumentsList" ,selectedRows);
    	var value = false;
    	if(selectedRows.length>0){
    		value = true;
    	}
    	component.set("v.docSelected" , value);
    },
    userSelectHelper : function(component , event , helper){
    	var userClick = event.getSource().getLocalId();
    	if(userClick === 'cancel'){
    		helper.navigateToComponents(component , event , helper);
    	}else if(userClick === 'create'){
    		helper.createResponses(component ,event , helper);
    	}
    },
    navigateToComponents  :function(component , event , helper){
    	component.find("overlayLib").notifyClose();
    },
    createResponses : function(component , event , helper){
    component.set("v.errorMessage", '');
    	component.set("v.Spinner" , true);
    	
    	var action = component.get("c.responseCreation");
    	action.setParams({"response" : JSON.stringify(component.get("v.selectedDocumentsList")),
    					"parentId" : component.get("v.parentId")});
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var resp = response.getReturnValue();
                if(!$A.util.isEmpty(resp) && !$A.util.isUndefined(resp)){
                	if(resp === $A.get("$Label.c.AG_Sucess_Toast_Type")){
                		component.find("overlayLib").notifyClose();
                		helper.showToast(component, event, helper,$A.get("$Label.c.AG_Sucess_Toast_Type") , $A.get("$Label.c.AG_Response_Create_Success"),$A.get("$Label.c.AG_Sucess_Toast_Type"));
                	}else{
                		component.find("overlayLib").notifyClose();
                		helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                	}
                }else{
                	component.find("overlayLib").notifyClose();
                    helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                }  
            } else if(state === "ERROR"){
            		component.find("overlayLib").notifyClose();
                	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }
            component.set("v.Spinner" , false);
        });
        $A.enqueueAction(action); 	
    },
    
})
