({
    doInit : function(component, event, helper) {
    	
        var recordId = component.get("v.recordId");
        var pageReference = {
            type: 'standard__component',
            attributes: {
                componentName: 'c__AG_CreateLotBatchCmp',
            },
            state: {
                "c__recordId": recordId
            }
        };
        component.set("v.pageReference", pageReference);
        var navService = component.find("navService");
        var pageReference = component.get("v.pageReference");
        //event.preventDefault();
        navService.navigate(pageReference); 
    }
})