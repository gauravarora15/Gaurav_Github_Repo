({
	 authenticate : function(component, event,helper) {
        component.set("v.displaySpinner" , true);
        var action = component.get("c.proceedToApprove");
        action.setParams({
            "currentRecordID" : component.get("v.recordId"),
            "objName" : component.get("v.sObjectName"),
            "usrname" : component.get("v.user"),
            "passwrd" : component.get("v.pass"),
            "sObjRec" : component.get("v.sObjectRecord")
        });
        action.setCallback(this,function(res){
        	var status = res.getState();
            if(status ==="SUCCESS"){
                var result =  res.getReturnValue();
                if(res.getReturnValue().isError){
                    component.set("v.errorMessage",res.getReturnValue().errorMessage);
                }else{
                    if(component.get("v.sObjectName") === $A.get("$Label.c.AG_PCM_Assessment_Object_API_Name")){
                         helper.showToast($A.get("$Label.c.AG_Sucess_Toast_Type"),$A.get("$Label.c.AG_Sucess_Toast_Type"),$A.get("$Label.c.AG_PCM_Assessment_Object_Label")+' '+$A.get("$Label.c.AG_E_Sign_Record_Update_Success"));
                    }
                    else if(component.get("v.sObjectName") === $A.get("$Label.c.AG_PCM_Investigation_Notification_Object_API_Name")){
                         helper.showToast($A.get("$Label.c.AG_Sucess_Toast_Type"),$A.get("$Label.c.AG_Sucess_Toast_Type"),$A.get("$Label.c.AG_PCM_Investigation_Notification_Object_Label")+' '+$A.get("$Label.c.AG_E_Sign_Record_Update_Success"));
                    }
                    else if(component.get("v.sObjectName") === $A.get("$Label.c.AG_PCM_Assessment_Reference_Object_API_Name")){
                         helper.showToast($A.get("$Label.c.AG_Sucess_Toast_Type"),$A.get("$Label.c.AG_Sucess_Toast_Type"),$A.get("$Label.c.AG_PCM_Assessment_Reference_Object_Label")+' '+$A.get("$Label.c.AG_E_Sign_Record_Update_Success"));
                    }
                    else if(component.get("v.sObjectName") === $A.get("$Label.c.AG_Case_Object_API_Name")){
                         helper.showToast($A.get("$Label.c.AG_Sucess_Toast_Type"),$A.get("$Label.c.AG_Sucess_Toast_Type"),$A.get("$Label.c.AG_Case_Object_API_Name")+' '+$A.get("$Label.c.AG_E_Sign_Record_Update_Success"));
                    }
                }
            }
             else if(status === "INCOMPLETE"){
                 helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_E_Sign_Authentication_Error_Message"));
            }
            else if(status === "ERROR"){
                 helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_E_Sign_Authentication_Error_Message"));
            }
             component.set("v.displaySpinner" , false);
        });
        $A.enqueueAction(action);     
	},
    reject:function(component, event, helper) {
        component.set("v.displaySpinner" , true);
        var action = component.get("c.proceedToReject");
        action.setParams({
            "currentRecordID" : component.get("v.recordId"),
            "objName" : component.get("v.sObjectName"),
            "reasonForRejection" : component.get("v.reasonForRejection"),
            "sObjRec" : component.get("v.sObjectRecord")
        });
        action.setCallback(this,function(res){
            var status = res.getState();
            if(status ==="SUCCESS"){
                if(res.getReturnValue().isError){
                    component.set("v.errorMessage",$A.get("$Label.c.AG_E_Sign_Username_and_Password_Error"));
                }
                else{
                    if(component.get("v.sObjectName") === $A.get("$Label.c.AG_PCM_Assessment_Object_API_Name")){
                        helper.showToast($A.get("$Label.c.AG_Sucess_Toast_Type"),$A.get("$Label.c.AG_Sucess_Toast_Type"),$A.get("$Label.c.AG_PCM_Assessment_Object_Label")+' '+$A.get("$Label.c.AG_E_Sign_Record_Update_Success"));
                    }
                    else if(component.get("v.sObjectName") === $A.get("$Label.c.AG_PCM_Investigation_Notification_Object_API_Name")){
                        helper.showToast($A.get("$Label.c.AG_Sucess_Toast_Type"),$A.get("$Label.c.AG_Sucess_Toast_Type"),$A.get("$Label.c.AG_PCM_Investigation_Notification_Object_Label")+' '+$A.get("$Label.c.AG_E_Sign_Record_Update_Success"));
                    }
                }
            }
            else if(status === "INCOMPLETE"){
                 helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_E_Sign_Authentication_Error_Message"));
            }
            else if(status === "ERROR"){
                 helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_E_Sign_Authentication_Error_Message"));
            }
             component.set("v.displaySpinner" , false);
        });
        $A.enqueueAction(action);   
    },

    handleCustomErrorForSpace: function(component, event, helper){
        var rejectionField = component.find("rejectionReason");
        $A.util.addClass(rejectionField,'slds-has-error');
        if(!component.get("v.showReasonForRejectionError")){
            component.set("v.showReasonForRejectionError",true);
        }
        
    },

    cancel:function(component, event) {
    	$A.get("e.force:closeQuickAction").fire();   
	},
    showToast: function(toastTitle, toastType, toastMessage){
        $A.get('e.force:refreshView').fire();
        $A.get("e.force:closeQuickAction").fire();
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": toastTitle,
            "type": toastType,
            "message": toastMessage
        });
        toastEvent.fire();
    }
    
})