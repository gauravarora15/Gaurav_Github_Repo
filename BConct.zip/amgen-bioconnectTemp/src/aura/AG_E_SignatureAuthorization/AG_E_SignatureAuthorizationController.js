({
	authenticate : function(component, event, helper) {
        var submitforApprovalOrApprove = component.get("v.submitforApprovalOrApprove");
        /* If the User is submitting the record for approval or approving the record user needs to E-Sign */
        if(submitforApprovalOrApprove){
            var validForm = component.find('requiredValidate').reduce(function (validSoFar, inputCmp) {
                inputCmp.showHelpMessageIfInvalid();
                return validSoFar && inputCmp.get('v.validity').valid;
                }, true); 
            if(validForm){ 
                helper.authenticate(component,event,helper);
            } 
        }
         /* If the User is rejecting the approval request then ReasonForRejection Is Mandate*/
        else{
            var rejectionField = component.find("rejectionReason");

            //resetting error message
            component.set("v.showReasonForRejectionError",false);
            $A.util.removeClass(rejectionField,'slds-has-error');

            var value = rejectionField.get("v.value");
            if($A.util.isEmpty(value) || $A.util.isUndefinedOrNull(value)){

                rejectionField.set('v.validity', {valid:false, badInput :true});
                rejectionField.showHelpMessageIfInvalid();

            } else if($A.util.isEmpty(value.trim())){
                helper.handleCustomErrorForSpace(component, event, helper);
            }
            else{
                helper.reject(component,event,helper);
            } 
        } 
    },

    handleOnBlur : function(component, event, helper){
        var rejectionField = component.find("rejectionReason");
        var value = rejectionField.get("v.value");

        if(!$A.util.isEmpty(value) && !$A.util.isUndefinedOrNull(value)){
            if($A.util.isEmpty(value.trim())){
                
                    helper.handleCustomErrorForSpace(component, event, helper);
                
            } else{
                component.set("v.showReasonForRejectionError",false);
                $A.util.removeClass(rejectionField,'slds-has-error');
            }
        } else{
            component.set("v.showReasonForRejectionError",false);
        }
    },

    

    cancel:function(component, event, helper) {
		helper.cancel(component,event);
	},
})