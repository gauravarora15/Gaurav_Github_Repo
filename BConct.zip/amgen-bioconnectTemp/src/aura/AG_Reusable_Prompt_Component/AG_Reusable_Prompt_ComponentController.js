({
	userInput : function(component, event, helper) {
		helper.userInputHelper(component , event , helper);	
	}
})