({
	userInputHelper : function(component , event , helper) {
		var userClick = event.getSource().getLocalId();
    	if(userClick === 'no' || userClick === 'ok'){
    		helper.navigateBack(component , event , helper);
    	}else if(userClick === 'yes'){
    		helper.proceedAhead(component ,event,helper);
    	}
	},
    navigateBack : function(component , event , helper){
        component.set("v.confirm" , false);
        component.find("overlayLib").notifyClose();
    },
    proceedAhead : function(component,event,helper){
    	component.set("v.confirm" , true);
        component.find("overlayLib").notifyClose();
    }
})