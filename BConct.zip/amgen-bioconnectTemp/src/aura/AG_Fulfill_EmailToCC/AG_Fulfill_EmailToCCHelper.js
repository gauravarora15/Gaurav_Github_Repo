({
	doInitHelper : function(component, event, helper){
   
	component.set("v.displaySpinner", true);
        var mapKeyList = component.get("v.mapkeyList");
	var fullFillMentPackageId = component.get("v.fulFillMentPackageId");
        var methodSelection = component.get("v.selectedMethodList");
        var isCCTemplate = component.get("v.isCCTemplate");
        var selectedValue = '';
        if(isCCTemplate){
                selectedValue = $A.get("$Label.c.AG_CC")
        }else{
                selectedValue = $A.get("$Label.c.AG_Notified");
        }
      
        var action = component.get("c.getEmailDetails");
        action.setParams({
        	 "fulfillMentPackageID": fullFillMentPackageId,
                 "selectedValue" :selectedValue
        });
        action.setCallback(this, function(response){
        	var state = response.getState();
        	if(state === 'SUCCESS'){
                        var responseVar = response.getReturnValue();
                       
                if (!$A.util.isEmpty(responseVar) && !$A.util.isUndefinedOrNull(responseVar)) {
                   if (responseVar != $A.get("$Label.c.AG_errorMessage")){
                        component.set("v.emailMethod", responseVar);
                   
                    for (var key in responseVar.mapMessage) {
                        mapKeyList.push(key);
                    }
                    component.set("v.mapkeyList", mapKeyList);
                    component.set('v.responsecolumns', [{
                            label: $A.get("$Label.c.AG_Fulfillment_Email_View"),
                            fieldName: 'view',
                            type: 'url',
                            typeAttributes: {
                                label: {
                                    fieldName: 'documentName'
                                }
                            }
                        },
                        {
                            label: $A.get("$Label.c.AG_Fulfillment_Email_Title"), 
                            fieldName: 'documentName',
                            type: 'text'
                        },
                        {
                            label: $A.get("$Label.c.AG_Fulfillment_Email_Type"),
                            fieldName: 'documentType',
                            type: 'text'
                        },
                        {
                            label: $A.get("$Label.c.AG_Fulfillment_Email_FileSize"),
                            fieldName: 'fileSize',
                            type: 'text'
                        },
                        {
                            label: $A.get("$Label.c.AG_Fulfillment_Email_Status"),
                            fieldName: 'status',
                            type: 'text'
                        }
                    ]);
                    component.set('v.responsedata', responseVar.listFulfillDoc);
                    component.set("v.mergeDocId",responseVar.mergedRespDocId);
                    component.set("v.masterCaseNumber", responseVar.masterCaseNumber);
                    component.set("v.mergeResponseDocSize", responseVar.mergeRespSize);

                   }else {
                    helper.showToast(component, event, helper,$A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error_Toast_Type"));
                }
                    
                    
                } else {
                    helper.showToast(component, event, helper,$A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error_Toast_Type"));
                }

        	}else if (state === "INCOMPLETE") {
                helper.showToast(component, event, helper,$A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error_Toast_Type"));
            } else if (state === "ERROR") {
                helper.showToast(component, event, helper,$A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error_Toast_Type"));
            }
            component.set("v.displaySpinner", false);


        });
        $A.enqueueAction(action);
	},

        handleTemplateSelect: function(component, event, helper) {
        var listTemplateData = component.get("v.emailMethod");
        var seletedTemplate = component.find("selectTemplate").get("v.value");
        if (seletedTemplate === $A.get("$Label.c.AG_Select_an_Option_Label")) {
            listTemplateData.mapMessageBody = '';
            listTemplateData.subject  = '';          
        } else {
            for (var key in listTemplateData.mapMessage) {
                if (seletedTemplate === key) {
                    listTemplateData.mapMessageBody = listTemplateData.mapMessage[key];
                    listTemplateData.message = seletedTemplate;
                    listTemplateData.subject = listTemplateData.mapSubject[key];
                }
            }
        }
		
		 if(!$A.util.isEmpty(listTemplateData.mapMessageBody) && !$A.util.isUndefinedOrNull(listTemplateData.mapMessageBody)){
              component.set("v.emailMethod.mapMessageBody" , helper.mergeDateField(component,listTemplateData.mapMessageBody));
            }else{
                component.set("v.emailMethod.mapMessageBody" , '');
        }
         component.set("v.emailMethod", listTemplateData);
         component.set("v.selectedTemplate",seletedTemplate);
         if(seletedTemplate == $A.get("$Label.c.AG_Select_an_Option_Label")){
             component.set("v.hideSubject",true);
         }
         else{
             component.set("v.hideSubject",false);
         }
        },
		
	mergeDateField: function(component,template){
        var language = component.get('v.emailMethod.selectedMomentLanguage');
        if(!$A.util.isEmpty(template) && !$A.util.isUndefinedOrNull(template)){
            template = template.replace(/\(\(\(Today_Date\[DD Month YYYY\]\)\)\)/g, moment().locale(language).format('LL'));
        template = template.replace(/\(\(\(Today_Date\[MM DD YYYY\]\)\)\)/g, moment().locale(language).format('L'));
        template = template.replace(/\(\(\(Today_Date\[DD MM YYYY\]\)\)\)/g, moment().locale(language).format('L'));
        template = template.replace(/\(\(\(Today_Date\[DD Mon YYYY\]\)\)\)/g, moment().locale(language).format('ll'));
        template = template.replace(/\(\(\(Today_Date\[Month DD YYYY\]\)\)\)/g, moment().locale(language).format('LL'));

        }else{
            template = '';
        }
        return template;        
    },

        /*Preview Merged Response.*/
     previewModeHelper : function(component ,event,helper){
        
            var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
              "url": "/c/AG_PDFViewerApp.app?docId="+component.get("v.mergeDocId")
            });
            urlEvent.fire();
    },

   userSelectHelper: function(component, event, helper) {
    var isNotified = component.get("v.isNotified");
        var key = event.getSource().getLocalId();
        if (key === 'nextEmail') {
            component.set("v.displaySpinner", true);
            var emailMethodData = component.get("v.emailMethod");
            var invalidEmails = [];
            var numberOfEmails = false;
            //Flag for checking subject
            var checkSubject = false;
            //Validate to address
            if(!$A.util.isEmpty(emailMethodData.toAddress) && !$A.util.isUndefinedOrNull(emailMethodData.toAddress)){
                var strEmail = emailMethodData.toAddress;
                var emails = strEmail.split(',');
                //VALIDATE EMIAL ADDRESS
                var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
                for (var i = 0; i < emails.length; i++) {
                    if (!re.test((emails[i].trim()))) {
                        invalidEmails.push(emails[i].trim())
                    }
                }
                if(emails.length >= 1){
                   numberOfEmails = true;
                }
            }
            // Validate cc
            if(!$A.util.isEmpty(emailMethodData.ccAddress) && !$A.util.isUndefinedOrNull(emailMethodData.ccAddress)){
                var strEmail = emailMethodData.ccAddress;
                var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
                var emails = strEmail.split(',');
                for (var i = 0; i < emails.length; i++) {
                    if (!re.test((emails[i].trim()))) {
                        invalidEmails.push(emails[i].trim())
                    }
                }
            }
            // Validate Bcc
            if(!$A.util.isEmpty(emailMethodData.bccAddress) && !$A.util.isUndefinedOrNull(emailMethodData.bccAddress)){
                var strEmail = emailMethodData.bccAddress;
                var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
                var emails = strEmail.split(',');
                for (var i = 0; i < emails.length; i++) {
                    if (!re.test((emails[i].trim()))) {
                        invalidEmails.push(emails[i].trim())
                    }
                }
            }
            // Validate Subject 
            if(  $A.util.isEmpty(emailMethodData.subject) || $A.util.isUndefinedOrNull(emailMethodData.subject)   || $A.util.isEmpty(emailMethodData.subject.trim()) ){
                checkSubject = true;
            }
            
            if (invalidEmails.length > 0 ) {
                helper.showToast(component , event , helper ,$A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_Fulfillment_Email_Error"), $A.get("$Label.c.AG_Error_Toast_Type"));
                component.set("v.displaySpinner", false);
            }else if(!numberOfEmails){
                 helper.showToast(component , event , helper ,$A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_Fulfill_Email_To_Field_Validation"), $A.get("$Label.c.AG_Error_Toast_Type"));
                component.set("v.displaySpinner", false);
            }
            //Show error if subject is null
            else if(checkSubject){
                helper.showToast(component , event , helper ,$A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Check_If_Subject_Is_Null"), $A.get("$Label.c.AG_Error_Toast_Type"));
                component.set("v.displaySpinner", false);
            }else{
                //1560 user prompt
                if(!emailMethodData.mapMessageBody.includes(emailMethodData.baseUrl) && !isNotified){
                	helper.warningPromptComponent(component,event,helper);
                }
                else{
                	helper.successSendEmail(component , event , helper);
                }
            }
                
        }else if (key === 'cancel') {
           helper.openPromptComponentForCancel(component,event , helper, $A.get("$Label.c.AG_Prompt_Cancel_Message"));
        }else if (key==='skip'){
            helper.navigateToMethodContainer(component,event , helper);
        }
    },
   //US-1560
     successSendEmail : function(component,event,helper){
                
                var emailMethodData = component.get("v.emailMethod");
               
                var fulFillMentPackageId = component.get("v.fulFillMentPackageId");
                var selectedDoc = [];
                var selectedDocIds = [];
              
                var listDocLenght = component.get("v.emailMethod").listFulfillDoc;
                var mapMessageBody = component.get("v.emailMethod").mapMessageBody;
                var responsedataList = component.get("v.responsedata");
                var responseWrapper=[];
                if(listDocLenght.length > 0){
                    var checkboxValue = component.find("checkContact");
                    for(var i = 0; i<responsedataList.length ; i++){
                        responseWrapper.push(responsedataList[i]);
                    }
                }
                var selectedDocString = '';
                 var contentDocIds = '';
                if (selectedDoc != undefined || selectedDoc.length > 0) {
                                selectedDocString = JSON.stringify(selectedDoc)
                }
                if(selectedDocIds != undefined || selectedDocIds.length > 0){
                    contentDocIds = JSON.stringify(selectedDocIds)
                }

                if(JSON.stringify(component.get("v.emailMethod").mapMessageBody).length > $A.get("$Label.c.AG_Max_Size_CoverLetter")){
                   helper.showToast(component , event , helper ,$A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Cover_Letter_Error"),$A.get("$Label.c.AG_Error_Toast_Type") );
                        return;
                }
                var isCCTemplate = component.get("v.isCCTemplate");
                var selectedValue = '';
                if(isCCTemplate){
                        selectedValue = $A.get("$Label.c.AG_CC");
                }else{
                        selectedValue = $A.get("$Label.c.AG_Notified");
                }
                
                var methodSelection = component.get("v.selectedMethodList");
                var action = component.get("c.sendEmailMethod");
                action.setParams({
                    emailWrapperString: JSON.stringify(emailMethodData),
                    packageId: fulFillMentPackageId,
                    responseWrapper : JSON.stringify(responseWrapper),
                    selectedValue : selectedValue

                });
                action.setCallback(this, function(response) {
                    var state = response.getState();
                       
                    if (state === 'SUCCESS') {
                        var responseVar = response.getReturnValue();
                       
                        if (responseVar == $A.get("$Label.c.AG_errorMessage")){
                            helper.showToast(component , event , helper ,$A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error_Toast_Type"));
                        }else if(responseVar == $A.get("$Label.c.AG_Fulfillment_Method_Document_Error_Message")){
                            helper.openPromptComponent(component,event , helper, $A.get("$Label.c.AG_Fulfillment_Method_Document_Error_Message"));
                        }else{
                        	helper.navigateToMethodContainer(component, event, helper);
                        }
                    } else if (state === "INCOMPLETE") {
                        helper.showToast(component , event , helper ,$A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error_Toast_Type") );
                       
                    } else if (state === "ERROR") {
                        helper.showToast(component , event , helper ,$A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error_Toast_Type"));
                        
                    }
                    component.set("v.displaySpinner", false);
                });
                $A.enqueueAction(action);
     },
   
     userPromptHelper : function(component , event , helper){ 
        
        if(component.get("v.confirm")){
            //helper.navigateToComponents(component,event , helper,0);
            helper.navigateToMethodContainer(component,event , helper);
        }else{
            component.set("v.displaySpinner" , false);
        }
        
    },
    userPromptHelperForCancel : function(component , event , helper){ 
        
        if(component.get("v.confirm")){
            helper.navigateToComponents(component,event , helper,0);
          
        }else{
            component.set("v.displaySpinner" , false);
        }
        
    },
    openPromptComponent : function(component,event,helper,message){
        var modalBody;
        $A.createComponent("c:AG_Reusable_Prompt_Component", {"message" : message,
        					"confirm":component.getReference('v.confirm'), "isPrompt":true},
           function(content, status) {
               if (status === "SUCCESS") {
                   modalBody = content;
                   component.find('overlayLib').showCustomModal({
                       header: $A.get("$Label.c.AG_Label_Warning"),
                       body: modalBody, 
                       showCloseButton: false,
                       cssClass: "mymodal",
                       closeCallback: function() {
                           helper.userPromptHelper(component , event,helper);
                       }
                   })
               }                               
           });
    },
    openPromptComponentForCancel : function(component,event,helper,message){
        var modalBody;
        $A.createComponent("c:AG_Reusable_Prompt_Component", {"message" : message,
        					"confirm":component.getReference('v.confirm'), "isPrompt":true},
           function(content, status) {
               if (status === "SUCCESS") {
                   modalBody = content;
                   component.find('overlayLib').showCustomModal({
                       header: $A.get("$Label.c.AG_Label_Warning"),
                       body: modalBody, 
                       showCloseButton: false,
                       cssClass: "mymodal",
                       closeCallback: function() {
                           helper.userPromptHelperForCancel(component , event,helper);
                       }
                   })
               }                               
           });
    },

    
    /* Warning Prompt if No Merge Reponse Url Found */
     warningPromptComponent : function(component,event,helper){
        var modalBody;
        $A.createComponent("c:AG_Reusable_Prompt_Component", {"message" : $A.get("$Label.c.AG_Forgot_Merge_Response_URL") , 
                            "confirm":component.getReference('v.confirm') , "isPrompt":true ,"negative" : $A.get("$Label.c.AG_No")},
           function(content, status) {
               if (status === "SUCCESS") {
                   modalBody = content;
                   component.find('overlayLib').showCustomModal({
                       header: $A.get("$Label.c.AG_Label_Warning"),
                       body: modalBody, 
                       showCloseButton: false,
                       cssClass: "mymodal",
                       closeCallback: function() {
                           helper.userPrompt(component,event,helper);
                       }
                   })
               }                               
           });
    },

     //method for navigation between screens
    navigateToComponents  :function(component , event , helper,componentNo){
        var compEvent = component.getEvent("navigateComponent");
        compEvent.setParams({"componentNo" : componentNo});
        compEvent.fire();
    },
    /*User Prompt if based on warning prompt found*/
     userPrompt : function(component ,event,helper){
        if(component.get("v.confirm")){
        helper.successSendEmail(component,event,helper);
        }
        else{
        component.set("v.displaySpinner", false);
        }
    },



    navigateToMethodContainer : function(component , event , helper){
        var methodSelection = component.get("v.selectedMethodList");        
        var fulfillmentPackageId = component.get("v.fulFillMentPackageId");
        var compEvent = component.getEvent("containerMethodEvent");
        var isNotified = component.get("v.isNotified");
        var returnCC;
        var returnNotified; 
        if(isNotified){
                returnCC = component.get("v.isCC");
                returnNotified = false;

        }else{
                returnCC = false;
        }
        compEvent.setParams({"fulfillmentPackageId" : fulfillmentPackageId, methodSelection : methodSelection, isNotified: returnNotified, isCC: returnCC});
        compEvent.fire();
    }, 

        showToast : function(component, event, helper,title , message , type) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message,
            "type" : type
        });
        toastEvent.fire();
    }
})
