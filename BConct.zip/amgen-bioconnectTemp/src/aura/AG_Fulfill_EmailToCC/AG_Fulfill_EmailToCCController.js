({
	doInit:function(component, event, helper){
		helper.doInitHelper(component, event, helper);
	},
	handleTemplateSelect : function(component, event, helper){
		helper.handleTemplateSelect(component, event, helper);
	},
	previewHelper : function(component , event,helper){
        helper.previewModeHelper(component , event,helper);
    },
    userSelect : function(component, event, helper){
    	helper.userSelectHelper(component,event, helper);
    }
})