({
	doInitHelper : function(component, event, helper) {
        component.set("v.displaySpinner" , true);
        component.set("v.selectedSection", '');
        var action = component.get("c.getWrapperBody");
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
            	component.set("v.displaySpinner" , false);
            	var returnedInitWrapper = response.getReturnValue();
            	if(returnedInitWrapper.hasError){
                    helper.showToast(component, event, helper,$A.get("$Label.c.AG_Label_Warning"), $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Label_Warning"));
                }
                else {
                	component.set("v.returnedWrapper", returnedInitWrapper);
            		component.set("v.pcmRetrnUnitList", returnedInitWrapper.returnWrapList);
                }
            }
            else if (state === "INCOMPLETE") {
            	component.set("v.displaySpinner" , false);
	            helper.showToast(component, event, helper,$A.get("$Label.c.AG_Label_Warning"), $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Label_Warning"));
	        }
	        else if (state === "ERROR") {
	        	component.set("v.displaySpinner" , false);
	            helper.showToast(component, event, helper,$A.get("$Label.c.AG_Label_Warning"), $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Label_Warning"));
	        }
	        else {
	        	component.set("v.displaySpinner" , false);
	        	helper.showToast(component, event, helper,$A.get("$Label.c.AG_Label_Warning"), $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Label_Warning"));
	        }
        });
        $A.enqueueAction(action);
	},
	handleSearch : function(component, event, helper) {

		component.set("v.displaySpinner" , true);
	    component.set("v.selectedSection", '');
	    var investOrgVar = component.get("v.selectedInvstgOrgRecord.Id");
	    var action = component.get("c.searchReturnUnit");
	    action.setParams({
	    	"investOrgVar" : investOrgVar
	    });

	    action.setCallback(this, function(response) {
	        var state = response.getState();
	        if(state === "SUCCESS") {
	            component.set("v.displaySpinner" , false);
	            var returnedWrapper = response.getReturnValue();
	            if(returnedWrapper.hasError){
                    helper.showToast(component, event, helper,$A.get("$Label.c.AG_Label_Warning"), $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Label_Warning"));
                } 
                else {
	                component.set("v.returnedWrapper.returnWrapList", returnedWrapper.returnWrapList);
	                component.set("v.returnedWrapper.returnUnitColomnsList",returnedWrapper.returnUnitColomnsList);
	                component.set("v.pcmRetrnUnitList", returnedWrapper.returnWrapList);
	                component.set("v.isSearch", true);
	                component.set("v.activeSectionName", 'relatedReturn');
                }
	        }
	        else if (state === "INCOMPLETE") {
	        	component.set("v.displaySpinner" , false);
	            helper.showToast(component, event, helper,$A.get("$Label.c.AG_Label_Warning"), $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Label_Warning"));
	        }
	        else if (state === "ERROR") {
	            component.set("v.displaySpinner" , false);
	            helper.showToast(component, event, helper,$A.get("$Label.c.AG_Label_Warning"), $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Label_Warning"));
	        }
	        else {
	        	component.set("v.displaySpinner" , false);
	            helper.showToast(component, event, helper,$A.get("$Label.c.AG_Label_Warning"), $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Label_Warning"));
	        }
		});
        $A.enqueueAction(action);
	},

	// Method on clear
    handleClear: function(component, event, helper){
        component.set("v.activeSectionName", 'filterSection');
        component.set("v.isSearch", false);
        component.set("v.pcmRetrnUnitList", '');
        component.find("invstgOrgRecord").invokeClose();
        component.set("v.selectedInvstgOrgRecord.Id" , '');
        component.set("v.selectedInvstgOrgRecord.Name" , '');
    },

    // Method for handling Cancel
    handleCancel: function(component, event, helper){
        var navService = component.find("navService");
        var pageReference =  {
            type: 'standard__namedPage',
            attributes: {
                pageName: 'home'
            }
        };
        navService.navigate(pageReference);
    },
    
    callPDFCreate : function(component, event, helper) {
        var action = component.get("c.createRUSnapShotPDF");
        action.setParams({
            "fullWrapperVal" : JSON.stringify(component.get("v.returnedWrapper"))
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
            	//response.getReturnValue()
            	component.set("v.displaySpinner" , false);
            }
            else if(state === "INCOMPLETE"){
                component.set("v.displaySpinner" , false);
                helper.showToast(component, event, helper,$A.get("$Label.c.AG_Label_Warning"), $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Label_Warning"));
            }
            else if(state === "ERROR"){
                component.set("v.displaySpinner" , false);
                helper.showToast(component, event, helper,$A.get("$Label.c.AG_Label_Warning"), $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Label_Warning"));
            }
        });
        $A.enqueueAction(action);
    },
    // Method for showing toast
    showToast : function(component, event, helper,title , message , type) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message,
            "type" : type
        });
        toastEvent.fire();
    },
})