({
	doInitHelper  : function(component, event, helper) {
		helper.doInitHelper(component, event, helper);
	},
	handleInvstOrgChange : function(component, event, helper) {
		if(!$A.util.isEmpty(component.get("v.selectedInvstgOrgRecord")) && !$A.util.isUndefinedOrNull(component.get("v.selectedInvstgOrgRecord")) && !$A.util.isEmpty(component.get("v.selectedInvstgOrgRecord.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedInvstgOrgRecord.Id"))){
            
            component.set("v.returnedWrapper.investigationOrgName",component.get("v.selectedInvstgOrgRecord.Name"));
        }
        else{
            component.set("v.selectedInvstgOrgRecord.Id" , '');
            component.set("v.selectedInvstgOrgRecord.Name",'');
            component.set("v.returnedWrapper.investigationOrgName",'');
        }

        component.set("v.isSearch",false); //everytime Investigating Organization
	},
	handleSearch : function(component, event, helper) {
		helper.handleSearch(component, event, helper);
	},
	handleClear : function(component, event, helper) {
		helper.handleClear(component, event, helper);
	},
	handleCancel: function(component, event, helper){
		helper.handleCancel(component, event, helper);
	},
	fromFilterValue : function(component, event, helper) {
		
	},
	callPDFCreate : function(component, event, helper) {
		helper.callPDFCreate(component, event, helper);	
	}
	
})