({
	getData : function(component,event,helper) {
        
        var allRequestIds = component.get("v.allRequestIds");
        var mapRequest = component.get("v.selectedRequestState");
        component.set("v.requestsSelection" ,mapRequest);
        component.set("v.Spinner" , true);
        var action = component.get("c.getSubCaseDetails"); 
        var masterCaseName;
        action.setParams({"CaseId" : component.get("v.CaseId")});
        action.setCallback(this,function(a){
            
            //get the response state
            var state = a.getState();
            if(state === "SUCCESS"){
                var custs = [];
                var response = a.getReturnValue();
                component.set("v.masterCaseWrapper" , response);
                
                
                if(response.responseCount == 0){
                	component.set("v.disableNext",true);
                	component.set("v.ErrorMessageOnNextButton",$A.get("$Label.c.AG_ErrorMessage_NoResponse"));//
                }
                else if(!$A.util.isEmpty(response.errorMessage)){
                	component.set("v.disableNext",true);
                	component.set("v.ErrorMessageOnNextButton", response.errorMessage);
                }
                if($A.util.isEmpty(response.exceptionMessage)){
                	var subcaseMap = response.subcaseNameVsWrittenResponse;
	                var conts = response.mapScaseReqWrap;
	                if(Object.keys(conts).length != 0){
	                    for ( var key in conts ) {
	                    	if(undefined != subcaseMap[key] && subcaseMap[key] > 0){
	                    		for ( var req in key ) {
	                    			if(undefined != conts[key] && undefined != mapRequest){
	                    				for ( var req in conts[key] ) {
	                    					allRequestIds[conts[key][req].reqRec.Id] = conts[key][req].reqRec.Id;
	                    					if(undefined != mapRequest[conts[key][req].reqRec.Id]){
	                    						conts[key][req].isSelected = mapRequest[conts[key][req].reqRec.Id];
	                    					}
	                    				}
	                    			}
	                    		}
		                        custs.push({key:key,value:conts[key]});
	                    	}
	                    	
	                    }
	                    component.set("v.reponses", custs);
	                    if(component.get("v.reponses").length == 0){
	                    	component.set("v.requestsSelection" ,{});
	                    	component.set("v.documentsReordered",[]);
	                    	helper.showErrorMessage(component , event , helper);
	                    }else{
	                    	var requestsSelection = component.get("v.requestsSelection");
	                    	var selectedRequests = {};
	                    	for ( var req in requestsSelection ) {
	                    		if(undefined != allRequestIds && undefined!= allRequestIds[req]){
	                    			selectedRequests[req] = requestsSelection[req];
	                    		}
	                    	}
	                    	component.set("v.requestsSelection" ,selectedRequests);
	                    }
	                }else{
	                	component.set("v.reponses", custs);
	                	component.set("v.requestsSelection" ,{});
	                	component.set("v.documentsReordered",[]);
	                	helper.showErrorMessage(component , event , helper);
	                }
                }else{
                	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                }
            } else if(state === "ERROR"){
            	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }
            component.set("v.Spinner" , false);
        });
        $A.enqueueAction(action);
    },
	userSelectHelper : function(component , event , helper) {
		component.set("v.Spinner" , true);
		helper.clearMessage(component,event,helper);
		var key = event.getSource().getLocalId();
        if(key === 'prev'){
        	helper.navigateToComponents(component,event , helper,1);
        }else if(key === 'next'){
            helper.navigateToComponents(component,event , helper,3);
        }else if(key === 'cancel' || key === 'saveClose'){
            helper.navigateToComponents(component,event , helper,0);
        }
        
	},
    navigateToComponents  :function(component , event , helper,componentNo){
    	
    	if(componentNo == 3){
    		var response = component.get("v.reponses");
    		var selectedReq = false;
	    	var requestMap = component.get("v.requestsSelection");
	    	
	    	for (var x in requestMap) {
			    
			    if(requestMap[x] == true){
			    	selectedReq = true;
			    	break;
			    }
			}
			if(!selectedReq || (response.length >0 && !selectedReq)){
				component.set("v.errorMessage" , $A.get("$Label.c.AG_Error_Request_Select"));
				component.set("v.Spinner" , false);
				return;
			}

            //US-1606 AC for having the 4 MB size restriction on the Second Screen
            var requestSize = 0;
            if(selectedReq){
                for(var key in response){
                    var resposneReqMap = [];
                    resposneReqMap = response[key].value;
                    for(var i in resposneReqMap){
                        if(resposneReqMap[i].isSelected == true){
                         requestSize = requestSize + parseInt(resposneReqMap[i].reqRec.AG_Response_Size__c);   
                        
                    }


                    } 
                    if(requestSize > $A.get("$Label.c.AG_File_Size")){
                           component.set("v.errorMessage" , $A.get("$Label.c.AG_Response_Size_Error_Message"));
                             component.set("v.Spinner" , false);
                             return; 
                        }
                

                }

            }

			
    	}
    	
        var compEvent = component.getEvent("navigateComponent");
        var saveAndClose = false;
        if(componentNo == 0){
        	if('cancel' == event.getSource().getLocalId()){
        		compEvent.setParams({"componentNo" : componentNo});
        		compEvent.fire();
        		component.set("v.Spinner" , false);
        		return;
        	}else{
        		saveAndClose = true;
        	}
        	
        }
        compEvent.setParams({"componentNo" : componentNo,
        					"masterCaseWrapper" : JSON.stringify(component.get("v.masterCaseWrapper")) ,
                             "selectedRequests" : component.get("v.requestsSelection"),
                             "documentsReordered" : component.get("v.documentsReordered"),
                             "saveAndClose" : saveAndClose ,
                             "saveData" : !saveAndClose,
                             "fulfillmentPackageId":component.get("v.fulfillmentPackageId"),
	        				 "fulfillmentUserData":component.get("v.fulfillmentUserDataId")});
		compEvent.fire();
		component.set("v.Spinner" , false);
    },
    showToast : function(component, event, helper,title , message , type) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message,
            "type" : type
        });
        toastEvent.fire();
    },
    handleRequestSelectHelper : function(component , event , helper){
    	helper.clearMessage(component,event,helper);
    	var requestSelected = event.getSource().get("v.checked");
    	var key = event.getSource().get("v.value");
    	var requestMap = component.get("v.requestsSelection");
    	requestMap[key] = !requestSelected;
    	component.set("v.requestsSelection" , requestMap);
    	component.set("v.documentsReordered",[]);
    },
    handleRequestEditHelper : function(component , event , helper){
    	
    	helper.clearMessage(component,event,helper);
    	component.set("v.selectedRequestState" , component.get("v.requestsSelection"));
    	var requestId = event.target.id;
		var editRecordEvent = $A.get("e.force:editRecord");
        editRecordEvent.setParams({
            "recordId": requestId
        });
        editRecordEvent.fire();
    },
    clearMessage : function(component , event , helper){
    	component.set("v.errorMessage" , "");
    },
    showErrorMessage : function(component , event  ,helper){
    	//For showing error.
    	
    	component.set("v.errorMessage" , $A.get("$Label.c.AG_NoMIRequest"));
    	component.set("v.disableNext",true);
    	component.set("v.ErrorMessageOnNextButton",$A.get("$Label.c.AG_ErrorMessage_NoRequest"));
    	component.set("v.Spinner" , false);
    }
})