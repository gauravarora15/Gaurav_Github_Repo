({
	doInitHelper: function(component) {
        var objectTypeVar = component.get("v.assistObjectType");
        var currentRecordVar = component.get("v.oRecord");

        if(component.get("v.showAssist")){
            if (!$A.util.isEmpty(objectTypeVar) && !$A.util.isUndefinedOrNull(objectTypeVar)) {
            	var listVar = [];
                if (objectTypeVar === $A.get("$Label.c.AG_Case_Product_Object_API_Name")) {
                    /*Add the fields for assist*/
                    listVar.push({key: 'CaseProductName',value: currentRecordVar.Name});
                    listVar.push({key: 'ProductType',value: currentRecordVar.AG_Product__r.AG_Product_Type__c});
                    component.set("v.asssitiveList", listVar);                
                } else if(objectTypeVar === $A.get("$Label.c.AG_Product")){
                    listVar.push({key: 'ProductType',value: currentRecordVar.AG_Product_Type__c});
                    component.set("v.asssitiveList", listVar);
                } else if(objectTypeVar === $A.get("$Label.c.AG_Quality_Defect_Category")){
                	listVar.push({key: 'CategoryName',value: currentRecordVar.Name});
                    component.set("v.asssitiveList", listVar);
                } else if(objectTypeVar === $A.get("$Label.c.AG_Quality_Defect_Code")){
                    listVar.push({key: 'CodeName',value: currentRecordVar.Name});
                    component.set("v.asssitiveList", listVar);
                } else if(objectTypeVar === $A.get("$Label.c.AG_Quality_Defect_Sub_Code")){
                    listVar.push({key: 'SubCodeName',value: currentRecordVar.Name});
                    component.set("v.asssitiveList", listVar);
                }
            }
        }

    },
    selectRecord: function(component) {
        // get the selected record from list  
        var getSelectRecord = component.get("v.oRecord");
        // call the event   
        var compEvent = component.getEvent("oSelectedRecordEvent");
        // set the Selected sObject Record to the event attribute.  
        compEvent.setParams({
            "recordByEvent": getSelectRecord
        });
        // fire the event  
        compEvent.fire();
    },
    
    toggleHelper: function(component, event) {
        var objTypeVar = component.get("v.assistObjectType");
        if (!$A.util.isEmpty(objTypeVar) && !$A.util.isUndefined(objTypeVar)) {
            var toggleText = component.find("tooltip");
            $A.util.toggleClass(toggleText, "slds-hide");
        }
    }
})