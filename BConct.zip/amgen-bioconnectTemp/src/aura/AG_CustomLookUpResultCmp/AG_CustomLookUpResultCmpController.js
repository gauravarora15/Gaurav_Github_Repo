({
	doInit: function(component, event, helper) {
		helper.doInitHelper(component);
	},

	selectRecord: function(component, event, helper) {
		helper.selectRecord(component);
	},
	display: function(component, event, helper) {
		helper.toggleHelper(component, event);
	},

	displayOut: function(component, event, helper) {
		helper.toggleHelper(component, event);
	}
})