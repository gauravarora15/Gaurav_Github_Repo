({
	// Your renderer method overrides go here
	afterRender : function(component, helper) {
        this.superAfterRender();
        var workspaceAPI = component.find("workspace");
        workspaceAPI.getAllTabInfo().then(function(response) {
        	response.forEach(function(element) {
			  if(undefined != element.pageReference.attributes.componentName && 
				  element.pageReference.attributes.componentName == 'c__AG_CreateEditPCMVocabularyWizard'){
					  workspaceAPI.setTabLabel({
		                tabId: element.tabId,
		                label: 'New PCM Vocabulary'
					  });
				  }
			});
        }).catch(function(error) {
            console.log(error);
        });
    }
})