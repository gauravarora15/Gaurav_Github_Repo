({
	handleInit : function(component, event, helper)  {
        component.set("v.displaySpinner",true);
        
        //check if create or edit mode
        var recordIdVar = component.get("v.recordId");
        if($A.util.isEmpty(recordIdVar) || $A.util.isUndefinedOrNull(recordIdVar)) {
            component.set("v.isCreateMode",true);
        }
        else {
            component.set("v.isCreateMode",false);
        }
        var isCreateMode = component.get("v.isCreateMode");
        //alert('recordId----> '+component.get("v.isCreateMode")); 
        helper.setTabLabel(component, event, helper);

        var action = component.get("c.handleInit");        
        action.setCallback(this,function(response){
            //component.get("v.sObjectName")
            var state = response.getState();
            if(state === "SUCCESS") {
                var returnValue = response.getReturnValue();
                component.set("v.pcmVocabularyWrapper",returnValue);
				component.set("v.isSystemAdmin",component.get("v.pcmVocabularyWrapper.isSystemAdmin"));
                //CREATE
                if (isCreateMode) {
                    component.set("v.pcmVocabRecord",returnValue.pcmVocabularyRecord);
                    component.set("v.record",component.get("v.pcmVocabularyWrapper.pcmVocabularyRecord"));
                    helper.setLookupFilters(component, event, helper);
                }
                else {
                    helper.setFieldsForLDS(component, event, helper);
                }
                
            }
            else if (state === "INCOMPLETE") {
                // do something
                console.log("INCOMPLETE state: ");
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } 
                else {
                    console.log("Unknown error");
                }
            }

            component.set("v.displaySpinner",false);
        });
        $A.enqueueAction(action); 
    },

    setTabLabel :function(component, event, helper) {
        var workspaceAPI = component.find("workspace");
        if(component.get("v.isCreateMode")) {
            workspaceAPI.getFocusedTabInfo().then(function(response) {
                var focusedTabId = response.tabId;
                workspaceAPI.setTabLabel({
                    tabId: focusedTabId,
                    label: "New PCM Vocabulary" //set label you want to set
                });
            })
        }
    },
    handleEditValidationsOnDataLoad : function(component, event, helper){
        component.set("v.stopChange",true);
        var pcmVocab = component.get("v.pcmVocabRecord");
        console.log('pcmVocab---> '+JSON.stringify(pcmVocab));
        
        if(!$A.util.isUndefinedOrNull(pcmVocab.Id) && !$A.util.isEmpty(pcmVocab.Id) && 
            !$A.util.isUndefinedOrNull(pcmVocab.AG_Product__c) && !$A.util.isEmpty(pcmVocab.AG_Product__c) && 
            !$A.util.isUndefinedOrNull(pcmVocab.AG_Product__r.Name) && !$A.util.isEmpty(pcmVocab.AG_Product__r.Name)) {
            //component.set("v.selectedCaseProductLookUpRecord.Id",pcmVocab.Id); 
            component.set("v.selectedCaseProductLookUpRecord.Id",pcmVocab.AG_Product__c);
            component.set("v.selectedCaseProductLookUpRecord.Name",pcmVocab.AG_Product__r.Name);
            component.find("product").preselectValue();

            // stuffing dummy value to avoid mandatory check voilation
            var lookupFilterMapForDosageForm = {}
            lookupFilterMapForDosageForm['AG_Product__c'] = component.get('v.selectedCaseProductLookUpRecord.Id');
            component.set('v.lookupFilterMapForDosageForm',lookupFilterMapForDosageForm);
        }
        
        if(!$A.util.isUndefinedOrNull(pcmVocab.AG_Dosage_Form__c) && !$A.util.isEmpty(pcmVocab.AG_Dosage_Form__c) &&
            !$A.util.isUndefinedOrNull(pcmVocab.AG_Dosage_Form__r.Name) && !$A.util.isEmpty(pcmVocab.AG_Dosage_Form__r.Name)){
            //set doses value
            component.set("v.selectedRelatedDosageForm.Id",pcmVocab.AG_Dosage_Form__c); // stuffing dummy value to avoid mandatory check voilation
            component.set("v.selectedRelatedDosageForm.AG_Dosage_Form__c",pcmVocab.AG_Dosage_Form__c);
            component.set("v.selectedRelatedDosageForm.AG_Dosage_Form__r.Name",pcmVocab.AG_Dosage_Form__r.Name);
            component.find("dosageForm").preselectValue();

            /*setting the lookup filter for Item Type based on Dosage Form Selected*/
            var lookupFilterMapForItemType = {};
            lookupFilterMapForItemType['AG_Dosage_Form__c'] = component.get("v.selectedRelatedDosageForm.AG_Dosage_Form__c");
            component.set('v.lookupFilterMapForItemType',lookupFilterMapForItemType);
        }

        if(!$A.util.isUndefinedOrNull(pcmVocab.AG_Item_Type__c) && !$A.util.isEmpty(pcmVocab.AG_Item_Type__c) &&
            !$A.util.isUndefinedOrNull(pcmVocab.AG_Item_Type__r.Name) && !$A.util.isEmpty(pcmVocab.AG_Item_Type__r.Name)) {
            //set doses value
            component.set("v.selectedRelatedItemTypeDosage.Id",pcmVocab.AG_Item_Type__c); // stuffing dummy value to avoid mandatory check voilation
            component.set("v.selectedRelatedItemTypeDosage.AG_Item_Type_Name__c",pcmVocab.AG_Item_Type__c);
            component.set("v.selectedRelatedItemTypeDosage.AG_Item_Type_Name__r.Name",pcmVocab.AG_Item_Type__r.Name);
            component.find("itemType").preselectValue();

            /*setting the lookup filter for Item Type based on Dosage Form Selected*/
            var lookupFilterMapForIssueCode = {};
            lookupFilterMapForIssueCode['AG_Item_Type__c'] = component.get("v.selectedRelatedItemTypeDosage.AG_Item_Type_Name__c");
            component.set('v.lookupFilterMapForIssueCode',lookupFilterMapForIssueCode);
        }
        
        if(!$A.util.isUndefinedOrNull(pcmVocab.AG_Cause_Code__c) && !$A.util.isEmpty(pcmVocab.AG_Cause_Code__c) &&
            !$A.util.isUndefinedOrNull(pcmVocab.AG_Cause_Code__r.Name) && !$A.util.isEmpty(pcmVocab.AG_Cause_Code__r.Name)) {
            //set doses value
            component.set("v.selectedItemTypeCodeIssue.Id",pcmVocab.AG_Cause_Code__c); // stuffing dummy value to avoid mandatory check voilation
            component.set("v.selectedItemTypeCodeIssue.AG_Issue_Code__c",pcmVocab.AG_Cause_Code__c);
            component.set("v.selectedItemTypeCodeIssue.AG_Issue_Code__r.Name",pcmVocab.AG_Cause_Code__r.Name);
            component.find("issueCode").preselectValue();
            var lookupFilterMapForIssueCodeFamily = {};
            lookupFilterMapForIssueCodeFamily['AG_PCM_Issue_Code__c'] = component.get("v.selectedItemTypeCodeIssue.AG_Issue_Code__c");
            component.set('v.lookupFilterMapForIssueCodeFamily',lookupFilterMapForIssueCodeFamily);
        }
        if(!$A.util.isUndefinedOrNull(pcmVocab.AG_Cause_Code_Family__c) && !$A.util.isEmpty(pcmVocab.AG_Cause_Code_Family__c) &&
            !$A.util.isUndefinedOrNull(pcmVocab.AG_Cause_Code_Family__r.Name) && !$A.util.isEmpty(pcmVocab.AG_Cause_Code_Family__r.Name)) {
            //set doses value
            component.set("v.selectedIssueCodeFamilyLookUpRecord.Id",pcmVocab.AG_Cause_Code_Family__c); // stuffing dummy value to avoid mandatory check voilation
            component.set("v.selectedIssueCodeFamilyLookUpRecord.AG_PCM_Issue_Code_Family__c",pcmVocab.AG_Cause_Code_Family__c);
            component.set("v.selectedIssueCodeFamilyLookUpRecord.AG_PCM_Issue_Code_Family__r.Name",pcmVocab.AG_Cause_Code_Family__r.Name);
            component.find("issueCodeFamily").preselectValue();

        }
        component.set("v.stopChange",false);
    },

    handleProductChange : function(component, event, helper) {
        
        component.find("dosageForm").invokeClose();
        component.set("v.selectedRelatedDosageForm.Id",'');
        component.set("v.selectedRelatedDosageForm.Name",'');

        component.find("itemType").invokeClose();
        component.set("v.selectedRelatedItemTypeDosage.Id",'');
        component.set("v.selectedRelatedItemTypeDosage.Name",'');
        component.set("v.selectedRelatedItemTypeDosage.AG_Item_Type_Name__c",'');

        component.find("issueCode").invokeClose();
        component.set("v.selectedItemTypeCodeIssue.Id",'');
        component.set("v.selectedItemTypeCodeIssue.Name",'');
        component.set("v.selectedItemTypeCodeIssue.AG_Issue_Code__c",'');

        //changed
        component.find("issueCodeFamily").invokeClose();
        component.set("v.selectedIssueCodeFamilyLookUpRecord.Id",'');
        component.set("v.selectedIssueCodeFamilyLookUpRecord.Name",'');
        //component.set("v.selectedIssueCodeFamilyLookUpRecord.Name",'');

        
        var lookupFilterMapForDosageForm = {};
        if(!$A.util.isEmpty(component.get("v.selectedCaseProductLookUpRecord")) && !$A.util.isUndefinedOrNull(component.get("v.selectedCaseProductLookUpRecord")) && !$A.util.isEmpty(component.get("v.selectedCaseProductLookUpRecord.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedCaseProductLookUpRecord.Id"))) {
            lookupFilterMapForDosageForm['AG_Product__c'] = component.get("v.selectedCaseProductLookUpRecord.Id");
            
            component.set("v.lookupFilterMapForDosageForm",lookupFilterMapForDosageForm);
            component.set("v.pcmVocabRecord.AG_Product__c",component.get("v.selectedCaseProductLookUpRecord.Id"));
        }
        else {
            component.set("v.selectedCaseProductLookUpRecord.Id",'');
            component.set("v.selectedCaseProductLookUpRecord.Name",'');
            component.set("v.pcmVocabRecord.AG_Product__c",'');
        }
    },

    handleRelatedDosageFormChange : function(component, event, helper){

        /*When Dosage form is changed, make Item Type, As a Reported COde and As Investigated code as Null*/
        component.find("itemType").invokeClose();
        component.set("v.selectedRelatedItemTypeDosage.Id",'');
        component.set("v.selectedRelatedItemTypeDosage.Name",'');
        component.set("v.selectedRelatedItemTypeDosage.AG_Item_Type_Name__c",'');

        component.find("issueCode").invokeClose();
        component.set("v.selectedItemTypeCodeIssue.Id",'');
        component.set("v.selectedItemTypeCodeIssue.Name",'');
        component.set("v.selectedItemTypeCodeIssue.AG_Issue_Code__c",'');

        //changed
        component.find("issueCodeFamily").invokeClose();
        component.set("v.selectedIssueCodeFamilyLookUpRecord.Id",'');
        component.set("v.selectedIssueCodeFamilyLookUpRecord.Name",'');
        //component.set("v.selectedIssueCodeFamilyLookUpRecord.Name",'');

        console.log('selectedRelatedDosageForm-->'+JSON.stringify(component.get("v.selectedRelatedDosageForm")));
        var lookupFilterMapForItemType={};

        if(!$A.util.isEmpty(component.get("v.selectedRelatedDosageForm")) && !$A.util.isUndefinedOrNull(component.get("v.selectedRelatedDosageForm")) && !$A.util.isEmpty(component.get("v.selectedRelatedDosageForm.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedRelatedDosageForm.Id"))){
            lookupFilterMapForItemType['AG_Dosage_Form__c'] = component.get("v.selectedRelatedDosageForm.AG_Dosage_Form__c");
            
            component.set('v.lookupFilterMapForItemType',lookupFilterMapForItemType);
            //set the changed value in PCM Issue Record
            component.set("v.pcmVocabRecord.AG_Dosage_Form__c",component.get('v.selectedRelatedDosageForm.AG_Dosage_Form__c'));
        }
        else{
            component.set("v.selectedRelatedDosageForm.Id",'');
            component.set("v.selectedRelatedDosageForm.Name",'');
            //set the changed value in PCM Issue Record
            component.set("v.pcmVocabRecord.AG_Dosage_Form__c",'');
        }
    },

    handleRelatedItemTypeChange : function(component, event, helper){
        //selectedItemTypeCodeIssue
        /*When Item Type is changed, make As reported code and Investigated code null*/
        component.find("issueCode").invokeClose();
        component.set("v.selectedItemTypeCodeIssue.Id",'');
        component.set("v.selectedItemTypeCodeIssue.Name",'');
        component.set("v.selectedItemTypeCodeIssue.AG_Issue_Code__c",'');

        //changed
        component.find("issueCodeFamily").invokeClose();
        component.set("v.selectedIssueCodeFamilyLookUpRecord.Id",'');
        component.set("v.selectedIssueCodeFamilyLookUpRecord.Name",'');
        //component.set("v.selectedIssueCodeFamilyLookUpRecord.Name",'');

        //alert('selectedRelatedItemTypeDosage--> '+JSON.stringify(component.get("v.selectedRelatedItemTypeDosage")));
        var lookupFilterMapForIssueCode = {};

        if(!$A.util.isEmpty(component.get("v.selectedRelatedItemTypeDosage")) && !$A.util.isUndefinedOrNull(component.get("v.selectedRelatedItemTypeDosage")) && !$A.util.isEmpty(component.get("v.selectedRelatedItemTypeDosage.AG_Item_Type_Name__c")) && !$A.util.isUndefinedOrNull(component.get("v.selectedRelatedItemTypeDosage.AG_Item_Type_Name__c"))) {
            lookupFilterMapForIssueCode['AG_Item_Type__c'] = component.get("v.selectedRelatedItemTypeDosage.AG_Item_Type_Name__c");
            
            component.set('v.lookupFilterMapForIssueCode',lookupFilterMapForIssueCode);
            
            //set the changed value in PCM Issue Record
            console.log('selectedRelatedItemTypeDosage.AG_Item_Type_Name__c---> '+component.get('v.selectedRelatedItemTypeDosage.AG_Item_Type_Name__c'));
            component.set("v.pcmVocabRecord.AG_Item_Type__c",component.get('v.selectedRelatedItemTypeDosage.AG_Item_Type_Name__c'));
        }
        else {
            console.log('selectedRelatedItemTypeDosage IS eMPTY-->');
            component.set("v.selectedRelatedItemTypeDosage.Id",'');
            component.set("v.selectedRelatedItemTypeDosage.Name",'');
            component.set("v.selectedRelatedItemTypeDosage.AG_Item_Type_Name__c",'');
            component.set("v.pcmVocabRecord.AG_Item_Type__c",'');
        }
    },

    handleIssueCodeLookChange : function(component, event, helper) {
        //changed
        component.find("issueCodeFamily").invokeClose();
        component.set("v.selectedIssueCodeFamilyLookUpRecord.Id",'');
        component.set("v.selectedIssueCodeFamilyLookUpRecord.Name",'');
        //component.set("v.selectedIssueCodeFamilyLookUpRecord.Name",'');

        if(!$A.util.isEmpty(component.get("v.selectedItemTypeCodeIssue")) && !$A.util.isUndefinedOrNull(component.get("v.selectedItemTypeCodeIssue")) && !$A.util.isEmpty(component.get("v.selectedItemTypeCodeIssue.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedItemTypeCodeIssue.Id"))) {
            //set the changed value in PCM Issue Record
            component.set("v.pcmVocabRecord.AG_Cause_Code__c",component.get('v.selectedItemTypeCodeIssue.AG_Issue_Code__c'));
            //lookupFilterMapForIssueCodeFamily map population
            
            var lookupFilterMapForIssueCodeFamily = {};
            lookupFilterMapForIssueCodeFamily['AG_PCM_Issue_Code__c'] = component.get("v.selectedItemTypeCodeIssue.AG_Issue_Code__c");
            component.set('v.lookupFilterMapForIssueCodeFamily',lookupFilterMapForIssueCodeFamily);

        }
        else {
            component.set("v.selectedRelatedItemTypeDosage.Id",'');
            component.set("v.selectedRelatedItemTypeDosage.Name",'');
            component.set("v.pcmVocabRecord.AG_Cause_Code__c",'');
        }
        //component.set("v.pcmVocabRecordOld",component.get("v.pcmVocabRecord"));
        console.log('pcmVocabRecordOld---> '+JSON.stringify(component.get("v.pcmVocabRecordOld")));
        console.log('pcmVocabRecord---> '+JSON.stringify(component.get("v.pcmVocabRecord")));
    },
    handleIssueCodeFamilyLookChange : function(component, event, helper) {

        if(!$A.util.isEmpty(component.get("v.selectedIssueCodeFamilyLookUpRecord")) && !$A.util.isUndefinedOrNull(component.get("v.selectedIssueCodeFamilyLookUpRecord")) && !$A.util.isEmpty(component.get("v.selectedIssueCodeFamilyLookUpRecord.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedIssueCodeFamilyLookUpRecord.Id"))) {
            //set the changed value in PCM Issue Record
            component.set("v.pcmVocabRecord.AG_Cause_Code_Family__c",component.get('v.selectedIssueCodeFamilyLookUpRecord.AG_PCM_Issue_Code_Family__c'));
            
        }
        else {
            component.set("v.selectedIssueCodeFamilyLookUpRecord.Id",'');
            component.set("v.selectedIssueCodeFamilyLookUpRecord.Name",'');
            component.set("v.pcmVocabRecord.AG_Cause_Code_Family__c",'');
        }
    },
    setLookupFilters : function(component, event, helper){
        //alert('from setLookupFilters');
        var lookupFilterMapForProduct = {};

        lookupFilterMapForProduct['AG_Status__c'] = 'Active';
        component.set("v.lookupFilterMapForProduct",lookupFilterMapForProduct);
    },

    handleUploadAction : function(component, event, helper) {
        
        if(!component.get("v.isCreateMode")) {
            //helper.checkAllOldRecorsActive (component, event, helper);
        }
        
        //required field UI validation
        var allValid = component.find("requiredField").get("v.validity");
        if (allValid.valid) {
            if(!component.get("v.isCreateMode") && !component.get("v.isSystemAdmin")){
                
                //AG_Business_Rule_on_Status_Updates validation rule handle
                if( component.get("v.pcmVocabRecord.AG_Status__c") != component.get("v.statusOldValue")) {
                    if((component.get("v.statusOldValue") == 'Draft' && component.get("v.pcmVocabRecord.AG_Status__c") == 'Active') || 
                        (component.get("v.statusOldValue") == 'Draft' && component.get("v.pcmVocabRecord.AG_Status__c") == 'Removed') ||
                        (component.get("v.statusOldValue") == 'Active' && component.get("v.pcmVocabRecord.AG_Status__c") == 'Archived')) {
                        helper.handleSavehelper(component, event, helper);
                    }
                    else {
                        component.set("v.errorMessage",'Only the following status changes are allowed: Draft to Active; Draft to Removed; Active to Archived!');
                        component.set("v.showError",true);
                    }
                }
                else {
                    //save reocrd
                    helper.handleSavehelper(component, event, helper);
                }
            }
            else {
                //save reocrd
                helper.handleSavehelper(component, event, helper);
            }
        }
        else {
            component.set("v.errorMessage",'Please fill all the required values!');
            component.set("v.showError",true);
        }
    },

    setFieldsForLDS : function(component, event, helper){
        var recordFields = component.get("v.pcmVocabularyWrapper.queryField");
        var array = [];
        var fields = [];
        array = recordFields.split(",");
        for(var i = 0; i < array.length; i++)
        {
            fields.push(array[i]);
        }
        component.set("v.fieldSet",fields);
        //alert(component.get("v.fieldSet"));
        component.set("v.runLDS",true);
    },

    handleSavehelper:function(component,event,helper){
     //component.set("v.displaySpinner", true);
        

        var action = component.get("c.createRecord");     
        action.setParams({
            "pcmVocabRecord" : component.get("v.pcmVocabRecord")
        });
            
        
        action.setCallback(this,function(response){
            //get the response state
            var state = response.getState();
            //check if result is successfull
            if(state === "SUCCESS"){
                if (response.getReturnValue().isSuccessVar) {
                    var recordId = response.getReturnValue().pcmVocabularyRecord.Id;
                    if(!$A.util.isEmpty(recordId) && !$A.util.isUndefinedOrNull(recordId)) {
                        helper.showToast(component, event, helper,$A.get("$Label.c.AG_Sucess_Toast_Type") , 'PCM Vocabulary record saved Successfully!' ,$A.get("$Label.c.AG_Sucess_Toast_Type"));
                        //helper.navigateToPCMVocabulary(component , event , helper,recordId);
                        if(!component.get("v.isCreateMode")) {
                            //helper.navigateToRecord(component , event , helper,recordId);
                            component.find("workspace").getFocusedTabInfo().then(function (response) {
                            	helper.navigateToRecord(component, event, helper, recordId, response.parentTabId); 
                            });
                        }
                        else {
                            helper.closeFocusedTabAndOpenNewTab(component , event , helper, recordId);
                        }
                        
                    }
                    else{
                        helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                    }
                }
                //exception scenario
                else {
                    component.set("v.errorMessage",response.getReturnValue().errorMessage);
                    component.set("v.showError",true);
                }
            }
            else if(state === "ERROR"){
                helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
               // component.set("v.displaySpinner", false);
            }else if(state === "INCOMPLETE"){
                helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }
        });
        $A.enqueueAction(action);
    },

	handleCancelhelper:function(component,event, helper){
        var workspaceAPI = component.find("workspace");
        workspaceAPI.getFocusedTabInfo().then(function(response) {
            var focusedTabId = response.tabId;
            workspaceAPI.closeTab({tabId: focusedTabId});
            workspaceAPI.openTab({
                recordId: component.get("v.recordId"),
                focus: true
            });
        })
        .catch(function(error) {
            console.log(error);
        });
    },

    showToast : function(component, event, helper,title , message , type) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message,
            "type" : type
        });
        toastEvent.fire();
    },
    navigateToRecord : function(component , event , helper, recordId, parentTabId){
    	var subTabId;
        

        helper.closeFocusedTab(component , event , helper);
        event.preventDefault();

        if(!component.get("v.isCreateMode")) {

                var workspaceAPI = component.find("workspace");
		        workspaceAPI.openSubtab({
		            parentTabId: parentTabId,
		            pageReference: {
		                "type": 'standard__recordPage',
		                "attributes": {
		                    "recordId": recordId,
		                    "actionName" : "view",
		                    "objectApiName" : 'AG_PCM_Vocabulary__c'
		                },
		                "state": {
		                    
		                }
		            },
		            focus: true
		        }).then(function(response){
		            subTabId = response
		            workspaceAPI.focusTab({tabId : subTabId});
		        }).catch(function(error){
		            console.log("this error: " + error);
		        });
		        
		        workspaceAPI.refreshTab({
	                tabId: parentTabId,
	                includeAllSubtabs: true
	            }).catch(function(error){
	                console.log("error here123" + error);
	            });
        }

    },

    closeFocusedTab : function(component, event, helper) {
        var workspaceAPI = component.find("workspace");
        workspaceAPI.getFocusedTabInfo().then(function(response) {
            var focusedTabId = response.tabId;
            workspaceAPI.closeTab({tabId: focusedTabId});
        })
        .catch(function(error) {
            
        });
    },
    closeFocusedTabAndOpenNewTab : function(component, event, helper, recordId) {
        var workspaceAPI = component.find("workspace");
            workspaceAPI.getFocusedTabInfo().then(function(response) {
            var focusedTabId = response.tabId;
            console.log(focusedTabId);

            //Opening New Tab
            workspaceAPI.openTab({
                url: '#/sObject/'+recordId+'/view'
            }).then(function(response) {
                workspaceAPI.focusTab({tabId : response});
            })
            .catch(function(error) {
                console.log(error);
            });

            //Closing old one
            workspaceAPI.closeTab({tabId: focusedTabId});
        })
        .catch(function(error) {
            console.log(error);
        });
    }
})