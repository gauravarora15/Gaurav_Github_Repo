({
	doInit : function(component, event, helper) {
		helper.handleInit(component, event, helper);
	},

	handleSave:function(component,event, helper ) {
        helper.handleUploadAction(component, event, helper);
    },

    handleCancel:function(component,event, helper ) {
        helper.handleCancelhelper(component, event, helper);
    },
    recordUpdated : function(component, event, helper){
        var eventParams = event.getParams();
        if(eventParams.changeType === "ERROR") {
            console.log(component.get("v.recordError"));
        }
        component.set("v.pcmVocabRecordOld",component.get("v.pcmVocabRecord"));
        if(!$A.util.isEmpty(component.get("v.pcmVocabRecord.AG_Status__c")) && !$A.util.isUndefinedOrNull(component.get("v.pcmVocabRecord.AG_Status__c"))) {
            //storing old status value for validation check
            component.set("v.statusOldValue",component.get("v.pcmVocabRecord.AG_Status__c"));
        }
        
        //component.set("v.displayContent",true);
        helper.setLookupFilters(component, event, helper);
        component.set("v.stopChange",true);
        helper.handleEditValidationsOnDataLoad(component, event, helper);
    },
    handleProductChange : function(component, event, helper) {
        if(!component.get("v.stopChange")) {
            helper.handleProductChange(component, event, helper);
        }
    },
    handleRelatedDosageFormChange : function(component, event, helper) {
        if(!component.get("v.stopChange")) {
            helper.handleRelatedDosageFormChange(component, event, helper);
        }
    },
    handleRelatedItemTypeChange : function(component, event, helper) {
        if(!component.get("v.stopChange")) {
            helper.handleRelatedItemTypeChange(component, event, helper);
        }
    },
    handleIssueCodeLookChange : function(component, event, helper) {
        if(!component.get("v.stopChange")) {
            helper.handleIssueCodeLookChange(component, event, helper);
        }
    },
    handleIssueCodeFamilyChange: function(component, event, helper) {
        if(!component.get("v.stopChange")) {
            helper.handleIssueCodeFamilyChange(component, event, helper);
        }
    },
    handleIssueCodeFamilyLookChange: function(component, event, helper) {
        if(!component.get("v.stopChange")) {
            helper.handleIssueCodeFamilyLookChange(component, event, helper);
        }
    }
})