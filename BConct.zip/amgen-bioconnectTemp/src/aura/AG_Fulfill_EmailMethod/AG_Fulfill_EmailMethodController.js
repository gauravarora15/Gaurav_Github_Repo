({
	doInit : function(component, event, helper) {
        helper.doInit(component, event, helper);
	},
    handleTemplateSelect : function(component, event, helper){
		helper.handleTemplateSelect(component, event, helper);
	},
    userSelect : function(component, event, helper) {
		helper.userSelectHelper(component , event , helper);	
	},
    getSelectedRows : function(component , event,helper){
        helper.getSelectedRows(component , event);
    },
    previewHelper : function(component , event,helper){
        helper.previewModeHelper(component , event,helper);
    }
})