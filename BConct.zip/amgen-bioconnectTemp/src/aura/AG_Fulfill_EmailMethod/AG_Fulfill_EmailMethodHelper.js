({
    doInit: function(component, event, helper) {
        component.set("v.displaySpinner", true);
        var mapKeyList = component.get("v.mapkeyList");
        var fullFillMentPackageId = component.get("v.fulFillMentPackageId");
        var methodSelection = component.get("v.selectedMethodList");
        var selectedValue = '';
        if(methodSelection.email == true){
                selectedValue = $A.get("$Label.c.AG_Email");
        }else if(methodSelection.emailFacilitator == true){
            selectedValue = $A.get("$Label.c.AG_Email_To_Facilitator");
        }
        var action = component.get("c.emailMethod");
        action.setParams({
            "fulfillMentPackageID": fullFillMentPackageId,
            "selectedValue" : selectedValue

        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === 'SUCCESS') {
                var responseVar = response.getReturnValue();
                if (!$A.util.isEmpty(responseVar) && !$A.util.isUndefinedOrNull(responseVar)) {
                    component.set("v.emailMethod", responseVar);
                    //Display Subject Based on Template Selected
                    if(!$A.util.isEmpty(responseVar.message) && !$A.util.isUndefinedOrNull(responseVar.message)){
                        component.set("v.hideSubject",false);
                    }
                    for (var key in responseVar.mapMessage) {
                        mapKeyList.push(key);
                    }
                    component.set("v.mapkeyList", mapKeyList);
                    component.set('v.responsecolumns', [{
                            label: $A.get("$Label.c.AG_Fulfillment_Email_View"),
                            fieldName: 'view',
                            type: 'url',
                            typeAttributes: {
                                label: {
                                    fieldName: 'documentName'
                                }
                            }
                        },
                        {
                            label: $A.get("$Label.c.AG_Fulfillment_Email_Title"), 
                            fieldName: 'documentName',
                            type: 'text'
                        },
                        {
                            label: $A.get("$Label.c.AG_Fulfillment_Email_Type"),
                            fieldName: 'documentType',
                            type: 'text'
                        },
                        {
                            label: $A.get("$Label.c.AG_Fulfillment_Email_FileSize"),
                            fieldName: 'fileSize',
                            type: 'text'
                        },
                        {
                            label: $A.get("$Label.c.AG_Fulfillment_Email_Status"),
                            fieldName: 'status',
                            type: 'text'
                        }
                    ]);
                    component.set('v.responsedata', responseVar.listFulfillDoc);
                    component.set("v.mergeDocId",responseVar.mergedRespDocId);
                    component.set("v.masterCaseNumber", responseVar.masterCaseNumber);
                    component.set("v.returnNotified", responseVar.isNotified);
                    component.set("v.CCnotified", responseVar.isCCed);
                    component.set("v.mergeResponseDocSize", responseVar.mergeRespSize);
                } else {
                    helper.showToast(component, event, helper,$A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error_Toast_Type"));
                }
            } else if (state === "INCOMPLETE") {
                helper.showToast(component, event, helper,$A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error_Toast_Type"));
            } else if (state === "ERROR") {
                helper.showToast(component, event, helper,$A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error_Toast_Type"));
            }
            component.set("v.displaySpinner", false);
        });
        $A.enqueueAction(action);

    },
    getSelectedRows: function(component, event) {
        var selectedRows = component.find('selectedRows');
        var addSelectedRows = component.get("v.rowsSelected");
        for (var i = 0; i < selectedRows.length; i++) {
            addSelectedRows.push(selectedRows[i].get("v. value"));
        }
        component.set('v.rowsSelected', addSelectedRows);
    },
    handleTemplateSelect: function(component, event, helper) {
        var listTemplateData = component.get("v.emailMethod");
        //Check Subject
        var mapSubjects = listTemplateData.mapSubject;
        var seletedTemplate = component.find("selectTemplate").get("v.value");
        if (seletedTemplate === 'Select an option') {
            listTemplateData.mapMessageBody = '';
        } else {
            for (var key in listTemplateData.mapMessage) {
                if (seletedTemplate === key) {
                    listTemplateData.mapMessageBody = listTemplateData.mapMessage[key];
                    listTemplateData.message = seletedTemplate;
                    if(listTemplateData.mapSubject[key] != 'undefined'){
                    listTemplateData.subject = listTemplateData.mapSubject[key];
                    }
                }
            }
        }
		
		if(!$A.util.isEmpty(listTemplateData.mapMessageBody) && !$A.util.isUndefinedOrNull(listTemplateData.mapMessageBody)){
              component.set("v.emailMethod.mapMessageBody" , helper.mergeDateField(component,listTemplateData.mapMessageBody));
            }else{
                component.set("v.emailMethod.mapMessageBody" , '');
        }
         component.set("v.emailMethod", listTemplateData);
         component.set("v.selectedTemplate",seletedTemplate);
         if(seletedTemplate != $A.get("$Label.c.AG_Select_an_Option_Label")){
             component.set("v.hideSubject",false);
         }
         else{
             component.set("v.hideSubject",true);
             component.set("v.emailMethod.subject",'');
         }
    },
	 mergeDateField: function(component,template){
        var language = component.get('v.emailMethod.selectedMomentLanguage');
        if(!$A.util.isEmpty(template) && !$A.util.isUndefinedOrNull(template)){
            template = template.replace(/\(\(\(Today_Date\[DD Month YYYY\]\)\)\)/g, moment().locale(language).format('LL'));
        template = template.replace(/\(\(\(Today_Date\[MM DD YYYY\]\)\)\)/g, moment().locale(language).format('L'));
        template = template.replace(/\(\(\(Today_Date\[DD MM YYYY\]\)\)\)/g, moment().locale(language).format('L'));
        template = template.replace(/\(\(\(Today_Date\[DD Mon YYYY\]\)\)\)/g, moment().locale(language).format('ll'));
        template = template.replace(/\(\(\(Today_Date\[Month DD YYYY\]\)\)\)/g, moment().locale(language).format('LL'));

        }else{
            template = '';
        }
        return template;        
    },
    userSelectHelper: function(component, event, helper) {
        var key = event.getSource().getLocalId();
        if (key === 'nextEmail') {
            component.set("v.displaySpinner", true);
            var emailMethodData = component.get("v.emailMethod");
            var invalidEmails = [];
            //Flag for checking subject
            var checkSubject = false;
            // Validate cc
            if(!$A.util.isEmpty(emailMethodData.ccAddress) && !$A.util.isUndefinedOrNull(emailMethodData.ccAddress)){
            	var strEmail = emailMethodData.ccAddress;
                var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
                var emails = strEmail.split(',');
                for (i = 0; i < emails.length; i++) {
                    if (!re.test((emails[i].trim()))) {
                        invalidEmails.push(emails[i].trim())
                    }
                }
            }
            // Validate Bcc
            if(!$A.util.isEmpty(emailMethodData.bccAddress) && !$A.util.isUndefinedOrNull(emailMethodData.bccAddress)){
            	var strEmail = emailMethodData.bccAddress;
                var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
                var emails = strEmail.split(',');
                for (var i = 0; i < emails.length; i++) {
                    if (!re.test((emails[i].trim()))) {
                        invalidEmails.push(emails[i].trim())
                    }
                }
            }
            // Validate Subject 
            if(  $A.util.isEmpty(emailMethodData.subject) || $A.util.isUndefinedOrNull(emailMethodData.subject)   || $A.util.isEmpty(emailMethodData.subject.trim()) ){
                checkSubject = true;
            }
            if (invalidEmails.length > 0) {
                helper.showToast(component , event , helper ,$A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_Fulfillment_Email_Error"), $A.get("$Label.c.AG_Error_Toast_Type"));
                component.set("v.displaySpinner", false);
            }
            //Show error if subject is null
            else if(checkSubject){
                helper.showToast(component , event , helper ,$A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Check_If_Subject_Is_Null"), $A.get("$Label.c.AG_Error_Toast_Type"));
                component.set("v.displaySpinner", false);
            }else{
				//US-1560 user prompt            
              if(!emailMethodData.mapMessageBody.includes(emailMethodData.baseUrl)){                helper.warningPromptComponent(component,event,helper);
                }
                else{
                helper.successSendEmail(component , event , helper);
                } 
			}
            
        } else if (key === 'close') {
            helper.navigateToComponents(component, event, helper, 0);
        } else if (key === 'cancel') {
            helper.navigateToComponents(component, event, helper, 0);
        }else if (key=='skip') {
            helper.navigateToMethodContainerOnSkip(component, event, helper);
        }else if(key === 'next'){
            helper.navigateToMethodContainer(component, event, helper);

        }
    },
    /*Success Send Email */
    successSendEmail : function(component,event,helper){
               
               var emailMethodData = component.get("v.emailMethod");
               
    
                var fulFillMentPackageId = component.get("v.fulFillMentPackageId");
                var selectedDoc = [];
                var selectedDocIds = [];
                //var listDocName = component.get("v.listDocName"); //by RR
                var listDocName = [];
                var listDocLenght = component.get("v.emailMethod").listFulfillDoc;
                var mapMessageBody = component.get("v.emailMethod").mapMessageBody;
                var responsedataList = component.get("v.responsedata");
                var responseWrapper=[];
                if(listDocLenght.length > 0){
                    var checkboxValue = component.find("checkContact");
                    for(var i = 0; i<responsedataList.length ; i++){
                        responseWrapper.push(responsedataList[i]);
                        if(responsedataList[i].isSelected == true){
                            listDocName.push(responsedataList[i].documentName);
                        }
                    }
                   

                    component.set("v.listDocName",listDocName);
                }
                var selectedDocString = '';
                 var contentDocIds = '';
                if (selectedDoc != undefined || selectedDoc.length > 0) {
    				selectedDocString = JSON.stringify(selectedDoc)
                }
                if(selectedDocIds != undefined || selectedDocIds.length > 0){
                    contentDocIds = JSON.stringify(selectedDocIds)
                }

                if(JSON.stringify(component.get("v.emailMethod").mapMessageBody).length > $A.get("$Label.c.AG_Max_Size_CoverLetter")){
                   helper.showToast(component , event , helper ,$A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Cover_Letter_Error"),$A.get("$Label.c.AG_Error_Toast_Type") );
                        return;
                }

                var methodSelection = component.get("v.selectedMethodList");
                var selectedValue = '';
                    if(methodSelection.email == true){
                            selectedValue = $A.get("$Label.c.AG_Email");
                    }else if(methodSelection.emailFacilitator == true){
                        selectedValue = $A.get("$Label.c.AG_Email_To_Facilitator");
                    }
                var action = component.get("c.emailMethodSave");
                action.setParams({
                    emailWrapperString: JSON.stringify(emailMethodData),
                    packageId: fulFillMentPackageId,
                    selectedValue : selectedValue,
                    responseWrapper : JSON.stringify(responseWrapper)

                });
                action.setCallback(this, function(response) {
                    var state = response.getState();
                    if (state === 'SUCCESS') {
                        var responseVar = response.getReturnValue();
                        if (!$A.util.isEmpty(responseVar) && !$A.util.isUndefinedOrNull(responseVar)) {
                             if(!$A.util.isEmpty(responseVar.errorMessageEmailNotSent) && !$A.util.isUndefinedOrNull(responseVar.errorMessageEmailNotSent)){
                                helper.openPromptComponentForAlert(component,event,helper, responseVar.errorMessageEmailNotSent);
		                     }
                             else if(!$A.util.isEmpty(responseVar.errorMessageForDocuments) && !$A.util.isUndefinedOrNull(responseVar.errorMessageForDocuments)){
		                        component.set("v.listDocName",[]);
                                helper.openPromptComponent(component,event,helper, responseVar.errorMessageForDocuments);
		                     }else{
                                component.set('v.responseEmailcolumns', [{
                                    label: $A.get("$Label.c.AG_Fulfillment_Request_Heading"),
                                    fieldName: 'requestName',
                                    type: 'text'
                                },
                                {
                                    label: $A.get("$Label.c.AG_Fulfillment_Subcase_Heading"),
                                    fieldName: 'subCase',
                                    type: 'text'
                                },
                                {
                                    label: $A.get("$Label.c.AG_Fulfillment_Request_Status_Heading"),
                                    fieldName: 'requestStatus',
                                    type: 'text'
                                }
                            ]);
                            component.set("v.responseEmaildata", responseVar.reponseWrapperList);
                            component.set("v.viaEmail", false);
                            
                            var methodSelection = component.get("v.selectedMethodList");
                            var returnNotified = component.get("v.returnNotified");
							var returnCC = component.get("v.CCnotified");
                            if(methodSelection.email == true){
                                methodSelection.email = false;
                                if(returnNotified || returnCC || methodSelection.fax || methodSelection.postalMail || methodSelection.emailFacilitator || methodSelection.PostalMailFacilitator){

                                 component.set("v.disableNextButton",false);     
                                }
                            
                         }else if(methodSelection.emailFacilitator == true){
                             methodSelection.emailFacilitator = false;
                             if(returnNotified || returnCC || methodSelection.fax || methodSelection.postalMail || methodSelection.emailFacilitator || methodSelection.PostalMailFacilitator){
                              component.set("v.disableNextButton",false); 
                              }        
                         }
                         }
                        } else {
                            helper.showToast(component , event , helper ,$A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error_Toast_Type"));
                            //component.set("v.displaySpinner", false);
                        }
                    } else if (state === "INCOMPLETE") {
                        helper.showToast(component , event , helper ,$A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error_Toast_Type") );
                        //component.set("v.displaySpinner", false);
                    } else if (state === "ERROR") {
                        helper.showToast(component , event , helper ,$A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error_Toast_Type"));
                        
                    }
                    component.set("v.displaySpinner", false);
                });
                $A.enqueueAction(action);
    
    
    },
    showToast : function(component, event, helper,title , message , type) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message,
            "type" : type
        });
        toastEvent.fire();
    },
    //method for navigation between screens
    navigateToComponents  :function(component , event , helper,componentNo){
        var compEvent = component.getEvent("navigateComponent");
        compEvent.setParams({"componentNo" : componentNo});
        compEvent.fire();
    },
    navigateToMethodContainer : function(component , event , helper){
        var methodSelection = component.get("v.selectedMethodList");        
        var fulfillmentPackageId = component.get("v.fulFillMentPackageId");
        var compEvent = component.getEvent("containerMethodEvent");
        var returnNotified = component.get("v.returnNotified");
        //Check if CCed
        var CCed = component.get("v.CCnotified");
        compEvent.setParams({"fulfillmentPackageId" : fulfillmentPackageId,methodSelection : methodSelection, isNotified:returnNotified, isCC:CCed});
        compEvent.fire();
    },
    
    navigateToMethodContainerOnSkip : function(component , event , helper){
        var methodSelection = component.get("v.selectedMethodList");
         if(methodSelection.email){
           methodSelection.email = false;
          
         }else if(methodSelection.emailFacilitator){
             methodSelection.emailFacilitator = false;
             
         }
        var fulfillmentPackageId = component.get("v.fulFillMentPackageId");
        var compEvent = component.getEvent("containerMethodEvent");
        compEvent.setParams({"fulfillmentPackageId" : fulfillmentPackageId,methodSelection : methodSelection, isNotified:false, isCC:false});
        compEvent.fire();
    },
    /* Warning Prompt if No Merge Reponse Url Found */
    warningPromptComponent : function(component,event,helper){
        var modalBody;
        $A.createComponent("c:AG_Reusable_Prompt_Component", {"message" : $A.get("$Label.c.AG_Forgot_Merge_Response_URL") , 
                            "confirm":component.getReference('v.confirm') , "isPrompt":true ,"negative" : $A.get("$Label.c.AG_No")},
           function(content, status) {
               if (status === "SUCCESS") {
                   modalBody = content;
                   component.find('overlayLib').showCustomModal({
                       header: $A.get("$Label.c.AG_Label_Warning"),
                       body: modalBody, 
                       showCloseButton: false,
                       cssClass: "mymodal",
                       closeCallback: function() {
                           helper.userPrompt(component,event,helper);
                       }
                   })
               }                               
           });
    },
        /*User Prompt if based on warning prompt found*/
    userPrompt : function(component ,event,helper){
        if(component.get("v.confirm")){
        helper.successSendEmail(component,event,helper);
        }
        else{
        component.set("v.displaySpinner", false);
        }
    },
     previewModeHelper : function(component ,event,helper){
            var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
              "url": "/c/AG_PDFViewerApp.app?docId="+component.get("v.mergeDocId")
            });
            urlEvent.fire();
    },
    //SHOW PROMPT TO INFORM THAT NEW VERSION CANNOT BE CREATED BASED ON CURRENT STATUS.
    openPromptComponent : function(component,event,helper, message){
        component.set("v.confirm",false);
        var modalBody;
        $A.createComponent("c:AG_Reusable_Prompt_Component", {"message" : message , 
                            "confirm":component.getReference('v.confirm') , "isPrompt":true, "negative":$A.get("$Label.c.AG_No")},
           function(content, status) {
               if (status === "SUCCESS") {
                   modalBody = content;
                   component.find('overlayLib').showCustomModal({
                       header: $A.get("$Label.c.AG_Label_Warning"),
                       body: modalBody, 
                       showCloseButton: false,
                       cssClass: "mymodal",
                       closeCallback: function() {
                           helper.userPromptHelper(component,event,helper);
                       }
                   })
               }                               
           });
    },
    //VALIDATE USER INPUT TO CREATE FP OR CANCEL.
    userPromptHelper : function(component , event , helper){ 
        if(component.get("v.confirm")){
            helper.navigateToMethodContainerOnSkip(component,event , helper);
        }else{
            component.set("v.displaySpinner" , false);
        }
    },
    //SHOW PROMPT TO INFORM THAT EMAIL CANNOT BE SEND WITH NON VERIFIED FROM ADDRESS EMAIL.
    openPromptComponentForAlert : function(component,event,helper, message){
        component.set("v.confirm",false);
        var modalBody;
        $A.createComponent("c:AG_Reusable_Prompt_Component", {"message" : message , 
                            "confirm":component.getReference('v.confirm') , "isPrompt":false, "negative":$A.get("$Label.c.AG_No")},
           function(content, status) {
               if (status === "SUCCESS") {
                   modalBody = content;
                   component.find('overlayLib').showCustomModal({
                       header: $A.get("$Label.c.AG_Label_Warning"),
                       body: modalBody, 
                       showCloseButton: false,
                       cssClass: "mymodal",
                       closeCallback: function() {
                           component.set("v.displaySpinner" , false);
                       }
                   })
               }                               
           });
    }
})