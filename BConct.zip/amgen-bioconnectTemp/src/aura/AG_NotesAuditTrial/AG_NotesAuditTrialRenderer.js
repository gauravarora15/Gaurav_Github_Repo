({
    afterRender : function(component, helper) {
        this.superAfterRender();
        var workspaceAPI = component.find("workspace");
        workspaceAPI.getAllTabInfo().then(function(response) {
        	response.forEach(function(element) {
			  if(undefined != element.pageReference.attributes.componentName && 
				  element.pageReference.attributes.componentName == $A.get("$Label.c.AG_Notes_Audit_Trail_Component")){
					  workspaceAPI.setTabLabel({
		                tabId: element.tabId,
		                label: $A.get("$Label.c.AG_Notes_Audit_Trail_Tab")
					  });
				  }
			});
        }).catch(function(error) {
            console.log(error);
        });
    }
})