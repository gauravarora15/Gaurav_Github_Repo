({
    doInitHelper: function(component,event,helper) {
        var pageReference = component.get("v.pageReference");
        component.set("v.recordId", pageReference.state.c__recordId);
        component.set("v.displaySpinner", true);
        component.find("errorToastPlaceholder").set("v.body", []);
        helper.showNoteRecordsAsOptions(component , event , helper , component.get("v.recordId"))
    },
    
    //logic to render the data table
    renderTable: function(component , event , helper , recordList) {
            var rowsPerPage = $A.get("$Label.c.AG_Audit_Trail_Rows_Per_Page");
            var pageNumber = component.get("v.pageNumber");
            var maxPage = component.get("v.maxPage");
        var historylst = component.get("v.currList");
         var pageRecords=[];
        if(!$A.util.isEmpty(historylst) && !$A.util.isUndefined(historylst)){
            var pageRecords = historylst.slice((pageNumber-1)*rowsPerPage, pageNumber*rowsPerPage);
            }
        
        if(pageNumber == 1){
            component.set("v.hideFirst",true);
            component.set("v.hidePrev",true);
        }
        else{
            component.set("v.hideFirst",false);
            component.set("v.hidePrev",false);
        }
        if(pageNumber==maxPage){
            component.set("v.hideLast",true);
            component.set("v.hideNext",true);
        }
        else{
            component.set("v.hideLast",false);
            component.set("v.hideNext",false);
        }
        var HighestPageNumber = pageNumber*$A.get("$Label.c.AG_Audit_Trail_Rows_Per_Page");
            if(HighestPageNumber>recordList.length){
                HighestPageNumber = recordList.length;
            }
        console.log('HighestPageNumber::'+HighestPageNumber);
// component.set("v.serializedrecs",JSON.stringify(pageRecords));
		var pageNumberHeader = (pageNumber*$A.get("$Label.c.AG_Audit_Trail_Rows_Per_Page"))-($A.get("$Label.c.AG_Audit_Trail_Rows_Per_Page")-1);
        pageNumberHeader = pageNumberHeader+ ' to ' + HighestPageNumber + ' of '+ recordList.length+' Notes Audit History Records';
        console.log('pageNumberHeader::'+pageNumberHeader);
        component.set("v.numberOfRecordsHeader",pageNumberHeader);
        component.set("v.currentList", pageRecords);
        component.set("v.displaySpinner", false);
        var currentHistoryListIds=[];
        for(var i=0;i<pageRecords.length;i++){
            currentHistoryListIds.push(pageRecords[i].historyRecId);
        }
        var action = component.get("c.createCacheForAuditTrail");
        action.setParams({
            "auditHistoryIds": JSON.stringify(currentHistoryListIds) 
        });
        action.setCallback(this,function(response){
            
            var state = response.getState();
            if(state === "SUCCESS"){
                var res = response.getReturnValue();
                if(!$A.util.isEmpty(res) && !$A.util.isUndefined(res)){
                   //alert('res'+res);
                } else{
                    helper.showErrorToast(component, $A.get("$Label.c.AG_AuditTableError"));
                }
            } else if(state === "INCOMPLETE"){
                helper.showErrorToast(component, $A.get("$Label.c.AG_AuditTableError"));
            } else if(state === "ERROR"){
                // Prepare a toast UI message
                helper.showErrorToast(component, $A.get("$Label.c.AG_AuditTableError"));
            }
            
        });
        $A.enqueueAction(action); 
    },

    showErrorToast: function(component, errorMsg) {
        $A.createComponent(
            "c:AG_ToastNotificationComponent", {
                "errorMsg": errorMsg
            },
            function(errorToast) {
                if (component.isValid()) {
                    var targetCmp = component.find("errorToastPlaceholder");
                    var body = targetCmp.get("v.body");
                    body.push(errorToast);
                    targetCmp.set("v.body", body);
                }
                component.set("v.displaySpinner", false);
            }
        );
    },
     showNoteRecordsAsOptions : function(component , event , helper , recordId){
    
        var action = component.get("c.getAllDocuments");
        action.setParams({
            "recordId": recordId 
        });
        action.setCallback(this,function(response){
            
            var state = response.getState();
            if(state === "SUCCESS"){
                var res = response.getReturnValue();
                if(!$A.util.isEmpty(res) && !$A.util.isUndefined(res) && !$A.util.isEmpty(response.getReturnValue().historyWrapperList)){
                    var allRecords = response.getReturnValue().historyWrapperList;
                    var allDocuments = response.getReturnValue().documentsList;
                    var rowsPerPage = $A.get("$Label.c.AG_Audit_Trail_Rows_Per_Page");
                    component.set("v.serializedrecs",allRecords.length); 
                    component.set("v.currList",response.getReturnValue().historyWrapperList);
                    component.set("v.historyList",response.getReturnValue()); 
                    component.set("v.recordName",response.getReturnValue().recordName);  
                    if(!$A.util.isEmpty(allRecords) && !$A.util.isUndefined(allRecords)){
                    component.set("v.maxPage", Math.ceil((allRecords.length)/rowsPerPage));
                    }
                    var allNotes = [];
                    for (var i in allDocuments) {
                      var note = {};
                      note.label = allDocuments[i].fieldLabel;
                      note.value = allDocuments[i].RecId;
                      allNotes.push(note)
                    }
                    component.set("v.noteList" , allNotes); 
                    if(!$A.util.isEmpty(allNotes) && !$A.util.isUndefined(allNotes)){
                        component.set("v.selectedDocId" , allNotes[0].value);
                    }
                    helper.renderTable(component , event , helper , allRecords);
                    
                } else{
                    helper.navigateCancel(component , event , helper);
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": $A.get("$Label.c.AG_Error"),
                        "type": $A.get("$Label.c.AG_Error"),
                        "message": $A.get("$Label.c.AG_Notes_Audit_Trail_Error")
                    });
                    toastEvent.fire();
                }
                component.set("v.displaySpinner", false);
            } else if(state === "INCOMPLETE"){
                helper.showErrorToast(component, $A.get("$Label.c.AG_AuditTableError"));
            } else if(state === "ERROR"){
                // Prepare a toast UI message
                helper.showErrorToast(component, $A.get("$Label.c.AG_AuditTableError"));
            }
            
        });
        $A.enqueueAction(action); 
    },
    fetchDocuments : function(component , event , helper){
        component.set("v.dateUpArrow",false);
        component.set("v.fieldUpArrow",true);
        component.set("v.userUpArrow",true);  
        component.set("v.dateAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"));
        component.set("v.fieldAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"));
        component.set("v.userAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"));
        component.set("v.displaySpinner", true);
        var docId = component.get("v.selectedDocId");
        
        component.set("v.maxPage", 1);
        component.set("v.pageNumber" , 1);
        component.set("v.currentList", []);
        component.find("errorToastPlaceholder").set("v.body", []);
        if($A.util.isEmpty(docId) || $A.util.isUndefined(docId)){
            var allRecords = [];
            component.set("v.displaySpinner", false);
            
            helper.renderTable(component , event , helper , allRecords);
            return;
        }
        var action = component.get("c.getAllNotesHistory");
        action.setParams({
            "noteId": docId 
        });
        action.setCallback(this,function(response){
            
            var state = response.getState();
            
            if(state === "SUCCESS"){
                var res = response.getReturnValue();
                if(!$A.util.isEmpty(res) && !$A.util.isUndefined(res)){
                    
                    var allRecords = res.historyWrapperList;
                    component.set("v.serializedrecs",allRecords.length); //Updated as per defect by RR
                    var rowsPerPage = $A.get("$Label.c.AG_Audit_Trail_Rows_Per_Page");
                    component.set("v.currList",response.getReturnValue().historyWrapperList);                   
                    component.set("v.historyList",response.getReturnValue());   
                    if(!$A.util.isEmpty(allRecords) && !$A.util.isUndefined(allRecords)){
                    component.set("v.maxPage", Math.ceil((allRecords.length)/rowsPerPage));
                    }
                    helper.renderTable(component , event , helper , allRecords);
                } else{
                    helper.showErrorToast(component, $A.get("$Label.c.AG_AuditTableError"));
                }
            } else if(state === "INCOMPLETE"){
                helper.showErrorToast(component, $A.get("$Label.c.AG_AuditTableError"));
            } else if(state === "ERROR"){
                // Prepare a toast UI message
                helper.showErrorToast(component, $A.get("$Label.c.AG_AuditTableError"));
            }
            
        });
        $A.enqueueAction(action); 
    },
    navigateCancel : function(component , event , helper){
        
        var workspaceAPI = component.find("workspace");
        workspaceAPI.getFocusedTabInfo().then(function(response) {
            var focusedTabId = response.tabId;
            workspaceAPI.closeTab({tabId: focusedTabId});
        })
        .catch(function(error) {
            
        });
    },
    fieldAscendingHelper : function(component,event,helper){
        //get the list of records that needs to be sorted
        var bands = component.get("v.currentList");
        //first time the arrow will be upArrow and the order is asc(default) 
        //or if the arrow is downarrow and the order you want to sort is Asc then show the uparrow and sort the data to ascending order
        if((component.get("v.fieldUpArrow") && component.get("v.fieldAscorDesc")===$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label")) ||(!component.get("v.fieldUpArrow") && component.get("v.fieldAscorDesc")===$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"))) {
            component.set("v.fieldUpArrow",true);
        }else{
            component.set("v.fieldUpArrow",false);
        }
        bands.sort(helper.compareValues(component,helper,$A.get("$Label.c.AG_Audit_Trail_fieldLabel_Label"), component.get("v.fieldAscorDesc")));
         if(component.get("v.fieldAscorDesc")===$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label")){
             component.set("v.fieldAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Descending_order_Label"));
        }else{
            component.set("v.fieldAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"));
        }
        component.set("v.currentList",bands);
        component.set("v.userUpArrow",true);
        component.set("v.dateUpArrow",true);
        component.set("v.userAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"));
        component.set("v.dateAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"));
        //Hightlight the Field tag and de highlight the other Date and User tags
        component.set("v.highlightField",true);
        component.set("v.highlightDate",false);
        component.set("v.highlightUser",false);
    },
    userAscendingHelper : function(component,event,helper){
         var bands = component.get("v.currentList");
        if((component.get("v.userUpArrow") && component.get("v.userAscorDesc")===$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label")) ||(!component.get("v.userUpArrow") && component.get("v.userAscorDesc")===$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"))) {
            component.set("v.userUpArrow",true);
        }else{
            component.set("v.userUpArrow",false);
        }
        bands.sort(helper.compareValues(component,helper,$A.get("$Label.c.AG_Audit_Trail_userName_Label"), component.get("v.userAscorDesc")));
         if(component.get("v.userAscorDesc")===$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label")){
             component.set("v.userAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Descending_order_Label"));
        }else{
            component.set("v.userAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"));
        }
        component.set("v.currentList",bands);
        component.set("v.fieldUpArrow",true);
        component.set("v.dateUpArrow",true);  
        component.set("v.fieldAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"));
        component.set("v.dateAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"));
        //Hightlight the Field tag and de highlight the other Date and User tags
        component.set("v.highlightUser",true);
        component.set("v.highlightDate",false);
        component.set("v.highlightField",false);
    },
    dateAscendingHelper : function(component,event,helper){
          component.set("v.displaySpinner", true);
        var bands = component.get("v.currentList");
        if((component.get("v.dateUpArrow") && component.get("v.dateAscorDesc")===$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label")) ||(!component.get("v.dateUpArrow") && component.get("v.dateAscorDesc")===$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"))) {
            component.set("v.dateUpArrow",true);
        }else{
            component.set("v.dateUpArrow",false);
        }
        bands.sort(helper.compareValues(component,helper,$A.get("$Label.c.AG_Audit_Trail_createdDate_Label"), component.get("v.dateAscorDesc")));
         if(component.get("v.dateAscorDesc")===$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label")){
             component.set("v.dateAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Descending_order_Label"));
        }else{
            component.set("v.dateAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"));
        }
        component.set("v.currentList",bands);
        component.set("v.fieldUpArrow",true);
        component.set("v.userUpArrow",true);  
        component.set("v.fieldAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"));
        component.set("v.userAscorDesc",$A.get("$Label.c.AG_Audit_Trail_Ascending_order_Label"));
        //Hightlight the Field tag and de highlight the other Date and User tags
        component.set("v.highlightDate",true);
        component.set("v.highlightUser",false);
        component.set("v.highlightField",false);
    },
    // function for dynamic sorting
    compareValues:function(component, helper,key, order) {
         component.set("v.displaySpinner", false);
      return function(a, b) {
       const varA = (typeof a[key] === $A.get("$Label.c.AG_Audit_Trail_string_Label")) ? 
          a[key].toUpperCase() : a[key];
        const varB = (typeof b[key] === $A.get("$Label.c.AG_Audit_Trail_string_Label")) ? 
          b[key].toUpperCase() : b[key];
        let comparison = 0;
        if (varA > varB) {
          comparison = 1;
        } else if (varA < varB) {
          comparison = -1;
        }
        return (
          (order == $A.get("$Label.c.AG_Audit_Trail_Descending_order_Label")) ? (comparison * -1) : comparison
        );
      };
    }
})