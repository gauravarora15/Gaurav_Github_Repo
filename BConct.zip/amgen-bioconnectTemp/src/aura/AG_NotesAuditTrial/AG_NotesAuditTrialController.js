({
    doInit : function(component,event,helper) {
       helper.doInitHelper(component, event, helper)
    },
    renderTable: function(component, event, helper) {
        helper.renderTable(component);
    },
    handleDocumentChange : function(component , event , helper){
    	helper.fetchDocuments(component , event , helper);
    },
    handleCancel : function(component , event , helper){
    	helper.navigateCancel(component , event , helper);
    },
    fieldAscending : function(component , event , helper){
      helper.fieldAscendingHelper(component , event , helper);
    },
    userAscending : function(component , event , helper){
      helper.userAscendingHelper(component , event , helper);
    },
    dateAscending : function(component , event , helper){
      helper.dateAscendingHelper(component , event , helper);
    }
})
