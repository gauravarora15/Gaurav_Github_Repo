({
	handleShowModal: function(component, evt, helper) {
        var modalBody;
         var rec = component.get("v.recordId");
        $A.createComponent("c:AG_PCM_Response_CoverLetter", { "recordId" : rec},
           function(content, status) {
               if (status === "SUCCESS") {
                   modalBody = content;
                   component.find('overlayLib').showCustomModal({
                       header: $A.get("$Label.c.AG_Generate_Cover_Letter"),
                       body: modalBody, 
                       showCloseButton: true,
                       cssClass: "slds-modal_large"
                   })
               }                               
           });
    }
})