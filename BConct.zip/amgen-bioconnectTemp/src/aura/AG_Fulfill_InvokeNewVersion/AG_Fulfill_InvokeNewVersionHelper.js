({
    doInitHelper : function(component,event,helper) {
        
        var action = component.get("c.fetchFulfillmentPackageData");
        action.setParams({"fulfillmentPackageId" : component.get("v.recordId")});
        action.setCallback(this,function(a){
            
            //get the response state
            var state = a.getState();
            
            if(state === "SUCCESS"){
                var custs = [];
                var response = a.getReturnValue();
                
                //VALIDATE FULFILLMENT PACKAGE LIST
                if(!$A.util.isEmpty(response.packageList) && !$A.util.isUndefined(response.packageList)){
                	if(!response.packageValidated){
                		helper.openPromptComponent(component,event,helper, $A.get("$Label.c.AG_Resend_FP_Owner_Check_Error_Message"));
                	}else if($A.get("$Label.c.AG_FP_Available_for_Use_Status") == response.packageList[0].AG_Status__c){
                		var recordId = component.get("v.recordId");
	                    var defaultScreen = component.get("v.defaultScreen");
	                    var fulfillmentUserDataId = response.packageList[0].AG_Fulfillment_User_Data__c;
	                    var caseId = response.packageList[0].AG_Case_Name__c;
	                    var pageReference = {
	                        type: 'standard__component',
	                        attributes: {
	                            componentName: 'c__AG_FulfillmentContainer', 
	                        },
	                        state: {
	                            "c__packageId": recordId,
	                            "c__defaultScreen" : defaultScreen,
	                            "c__userDataId" : fulfillmentUserDataId,
	                            "c__caseId":caseId,
	                            "c__navigateToCase" : false
	                        }
	                    };
	                    component.set("v.pageReference", pageReference);
	                    var navService = component.find("navService");
	                    var pageReference = component.get("v.pageReference");
	                    navService.navigate(pageReference);  
                	}else{
                		helper.openPromptComponent(component,event,helper, $A.get("$Label.c.AG_New_Version_Validation"));
                	}
                }else{
                    helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                }
                
                
            } else if(state === "ERROR"){
                helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }else if(state === "INCOMPLETE"){
                helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }
            component.set("v.Spinner" , false);
        });
        $A.enqueueAction(action);
        
    },
    //TOAST METHOD
    showToast : function(component, event, helper,title , message , type) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message,
            "type" : type
        });
        toastEvent.fire();
    },
    //SHOW PROMPT TO INFORM THAT NEW VERSION CANNOT BE CREATED BASED ON CURRENT STATUS.
    openPromptComponent : function(component,event,helper, message){
        
        var modalBody;
        $A.createComponent("c:AG_Reusable_Prompt_Component", {"message" : message ,"isPrompt":false},
           function(content, status) {
               if (status === "SUCCESS") {
                   modalBody = content;
                   component.find('overlayLib').showCustomModal({
                       header: $A.get("$Label.c.AG_Label_Warning"),
                       body: modalBody, 
                       showCloseButton: true,
                       cssClass: "mymodal",
                       closeCallback: function() {
                           helper.userPromptHelper(component,event,helper);
                       }
                   })
               }                               
           });
    },
    //NAVIGATE BASED ON USER SELECTION
    userPromptHelper : function(component , event , helper){ 
    	//NAVIGATE TO FULFILLMENT PACKAGE	
    	helper.navigateToFP(component, event, helper);
    },
    //NAVIGATE TO FULFILLMENT PACKAGE
    navigateToFP : function(component , event , helper){
        var recordId = component.get("v.recordId");
            var pageReference = {
                type: 'standard__recordPage',
                attributes: {
                    recordId: recordId,
                    actionName : 'view',
                    objectApiName : 'AG_Fulfillment_Package__c'
                },
                state: {
                    
                }
            };
            
            component.set("v.pageReference", pageReference);
            var navService = component.find("navService");
            var pageReference = component.get("v.pageReference");
            navService.navigate(pageReference);
    },
})