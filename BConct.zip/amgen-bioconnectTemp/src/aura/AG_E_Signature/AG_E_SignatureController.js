({
	doInit : function(component, event, helper) {
	   helper.validateUser(component, event, helper);
	},
    approve : function(component, event, helper) {
	   helper.approve(component, event);
	},
	reject : function(component, event, helper) {
	   helper.reject(component, event);
	},
})