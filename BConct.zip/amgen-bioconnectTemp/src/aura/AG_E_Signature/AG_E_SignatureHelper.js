({
    validateUser : function(component, event, helper) {
        component.set("v.displaySpinner" , true);
        var action = component.get("c.verifyLoggedInUser");
        action.setParams({
            "recordId" : component.get("v.recordId"),
            "objName" :component.get("v.sObjectName")
        });
        action.setCallback(this,function(res){
            var status = res.getState();
            if(status ==="SUCCESS"){
                var result = res.getReturnValue();
                if(!$A.util.isUndefinedOrNull(result.errorMessage) && !$A.util.isEmpty(result.errorMessage)){
                    helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),res.getReturnValue().errorMessage);
                }
                else{
                    component.set("v.eSignWrapper",result);
                }
                component.set("v.displaySpinner" , false);
            }
            else if(status === "INCOMPLETE"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_E_Sign_Authentication_Error_Message"));
            } 
                else if(status === "ERROR"){
                    helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_E_Sign_Authentication_Error_Message"));
                }
        });
        $A.enqueueAction(action);  
    },
    
    approve:function(component, event) {
        component.set("v.eSignWrapper.isPCMAssessmentOwnerorPCMINVApprover",false);
        component.set("v.isApproveRec",true);
        component.set("v.submitforApprovalOrApprove",true);
    }, 
    reject:function(component, event) {
        component.set("v.eSignWrapper.isPCMAssessmentAssessororPCMINVOwner",false);
        component.set("v.eSignWrapper.isPCMAssessmentOwnerorPCMINVApprover",false);
        component.set("v.isApproveRec",false);
        component.set("v.submitforApprovalOrApprove",false);
    }, 
    showToast: function(toastTitle, toastType, toastMessage){
        $A.get('e.force:refreshView').fire();
        $A.get("e.force:closeQuickAction").fire();
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": toastTitle,
            "type": toastType,
            "message": toastMessage
        });
        toastEvent.fire();
    }
    
})