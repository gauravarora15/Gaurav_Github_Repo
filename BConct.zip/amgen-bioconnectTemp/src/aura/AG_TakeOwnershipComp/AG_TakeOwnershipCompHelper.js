({
	doInit : function(component, event, helper) {

		var action = component.get("c.updateCaseOwner");
		var recordIdVar = component.get("v.recordId");
		action.setParams({
			'recordId': recordIdVar
		});
		action.setCallback(this, function(response){
			var state = response.getState();
			if(state === "SUCCESS"){
                component.set("v.displaySpinner", false);
                component.set("v.showMessage", true);
                var responseVar = response.getReturnValue();
                if(responseVar == $A.get("$Label.c.AG_Take_Ownership_Message")){
                    helper.showToast($A.get("$Label.c.AG_Take_Ownership_Header"),$A.get("$Label.c.AG_Sucess_Toast_Type"),$A.get("$Label.c.AG_Take_Ownership_Message"));
                } else{
                    helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),responseVar);
                }		
				
			} else if(state === "INCOMPLETE"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_Case_Owner_Change_Error_Message"));
                
            }
            else if(state === "ERROR"){
                // Prepare a toast UI message
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_Case_Owner_Change_Error_Message"));

            }
		});
		$A.enqueueAction(action);
    },

    showToast: function(toastTitle, toastType, toastMessage){
        $A.get('e.force:refreshView').fire();
        $A.get("e.force:closeQuickAction").fire();
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": toastTitle,
            "type": toastType,
            "message": toastMessage
        });
        toastEvent.fire();
    }

})