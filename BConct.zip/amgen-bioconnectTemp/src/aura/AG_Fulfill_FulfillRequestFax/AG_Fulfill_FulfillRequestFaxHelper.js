({
    doInit: function(component, event, helper) {
    	var fmData = {};
    	fmData.selectedTemplate = '';
    	fmData.selectedMessageBody = '';
    	fmData.responseDoc = '';
    	fmData.packgeDocLinkId = '';
    	fmData.acknowledgementId = '';
    	fmData.headerId = '';
    	component.set("v.fmData",fmData);
        component.set("v.displaySpinner", true);
        component.set("v.errorMessage","");
        var fullFillMentPackageId = component.get("v.fulFillMentPackageId");
        var methodSelection = component.get("v.selectedMethodList");
        var selectedValue = '';
        if(methodSelection.fax == true){
                selectedValue = 'Fax';
        }
        var action = component.get("c.faxMethod");
        action.setParams({
            fulfillMentPackageID: fullFillMentPackageId,
            selectedValue: selectedValue,
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === 'SUCCESS') {
                var responseVar = response.getReturnValue();
                if (!$A.util.isEmpty(responseVar) && !$A.util.isUndefinedOrNull(responseVar)) {
                    component.set("v.faxData", responseVar);
                    if(!$A.util.isEmpty(responseVar.selectedTemplate)){
                       component.set("v.disableButton", false);
                        }else{
                            component.set("v.disableButton", true);
                        }

                    component.set("v.returnNotified", responseVar.isNotified);
                    component.set("v.returnCCed", responseVar.isCCed);
                    component.set("v.displaySpinner", false);
                    if(!responseVar.errorMessageForDocuments == ''){
                        component.set("v.disablePrintComplete", true);
                        component.set("v.disableComplete",true);
                        helper.openPromptComponent(component,event,helper,responseVar.errorMessageForDocuments);
                    }
                } else {
                    helper.showToast(component, event, helper, $A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"), $A.get("$Label.c.AG_Error_Toast_Type"));
                    component.set("v.displaySpinner", false);
                }
            } else if (state === "INCOMPLETE") {
                helper.showToast(component, event, helper, $A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"), $A.get("$Label.c.AG_Error_Toast_Type"));
                component.set("v.displaySpinner", false);
                component.set("v.disableNextButton", true);
            } else if (state === "ERROR") {
                helper.showToast(component, event, helper, $A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"), $A.get("$Label.c.AG_Error_Toast_Type"));
                component.set("v.displaySpinner", false);
                component.set("v.disableNextButton", true);
            }
        });
        $A.enqueueAction(action);
    },
    handleTemplateSelect: function(component, event, helper) {
        var listTemplateData = component.get("v.faxData");
        var seletedTemplate = component.find("selectFaxTemplate").get("v.value");
        component.set("v.errorMessage","");
        if (seletedTemplate === 'Select an option') {
            if(component.get("v.skipFaxCoverLetter")){
            	component.set("v.disableButton", false);
            }else{
            	component.set("v.disableButton", true);
            }
            listTemplateData.messageBody = '';
            component.set("v.faxData", listTemplateData);
        } else {
            for (var key in listTemplateData.mapMessage) {
                if (seletedTemplate === key) {
                    listTemplateData.messageBody = listTemplateData.mapMessage[key];
                    component.set("v.selectedTemplate", seletedTemplate);
                    component.set("v.selectedMessageBody", listTemplateData.messageBody);
                    listTemplateData.message = seletedTemplate;
                    component.set("v.disableButton", false);
                }
            }
	    if(!$A.util.isEmpty(listTemplateData.messageBody) && !$A.util.isUndefinedOrNull(listTemplateData.messageBody)){
              component.set("v.faxData.messageBody" , helper.mergeDateField(component,listTemplateData.messageBody));
            }else{
                component.set("v.faxData.messageBody" , '');
            }
            component.set("v.faxData", listTemplateData);
            component.set("v.faxData", listTemplateData);
        }
    },
    mergeDateField: function(component,template){
        var language = component.get('v.faxData.selectedMomentLanguage');
        if(!$A.util.isEmpty(template) && !$A.util.isUndefinedOrNull(template)){
            template = template.replace(/\(\(\(Today_Date\[DD Month YYYY\]\)\)\)/g, moment().locale(language).format('LL'));
        template = template.replace(/\(\(\(Today_Date\[MM DD YYYY\]\)\)\)/g, moment().locale(language).format('L'));
        template = template.replace(/\(\(\(Today_Date\[DD MM YYYY\]\)\)\)/g, moment().locale(language).format('L'));
        template = template.replace(/\(\(\(Today_Date\[DD Mon YYYY\]\)\)\)/g, moment().locale(language).format('ll'));
        template = template.replace(/\(\(\(Today_Date\[Month DD YYYY\]\)\)\)/g, moment().locale(language).format('LL'));

        }else{
            template = '';
        }
        return template;    
    },
    
    userSelectHelper: function(component, event, helper) {
    	component.set("v.displaySpinner" , true);
        var key = event.getSource().getLocalId();
        component.set("v.errorMessage","");
        if (key === 'confirmDoc') {
        	if(!component.get("v.skipFaxCoverLetter")){
        		helper.createCacheHelper(component,event,helper);
        	}else{
        		helper.createFaxPDFHelper(component,event,helper);
        	}
        }
        if (key === "previous") {
            component.set("v.isDocConfirm", false);
            component.set("v.isFax", true);
            component.set("v.displaySpinner", false);
			component.set("v.disablePrintComplete", true);
        }
        if(key === "cancel"){
            helper.navigateToComponents(component, event, helper, 0);
        }
        if (key === "nextMethod") {
			helper.navigateToMethodContainer(component , event , helper);
        }
        if (key === "saveClose") {
            helper.navigateToComponents(component, event, helper, 0);
        }
        if (key === "skip") {
            helper.navigateToMethodContainerOnSkip(component, event, helper, 0);
        }
    },
    navigateToComponents  :function(component , event , helper,componentNo){
        var compEvent = component.getEvent("navigateComponent");
        compEvent.setParams({"componentNo" : componentNo});
        compEvent.fire();
    },
    navigateToMethodContainer : function(component , event , helper){
        var methodSelection = component.get("v.selectedMethodList");
        var fulfillmentPackageId = component.get("v.fulFillMentPackageId");
        var compEvent = component.getEvent("containerMethodEvent");
        var returnNotified = component.get("v.returnNotified");
        var returnCCed = component.get("v.returnCCed");
        compEvent.setParams({"fulfillmentPackageId" : fulfillmentPackageId,methodSelection : methodSelection, isCC:returnCCed, isNotified: returnNotified});
        compEvent.fire();
    },
    navigateToMethodContainerOnSkip : function(component , event , helper){
        var methodSelection = component.get("v.selectedMethodList");
        if(methodSelection.fax){
            methodSelection.fax = false;
        }
        var fulfillmentPackageId = component.get("v.fulFillMentPackageId");
        var compEvent = component.getEvent("containerMethodEvent");
        compEvent.setParams({"fulfillmentPackageId" : fulfillmentPackageId,methodSelection : methodSelection, isCC:false, isNotified: false});
        compEvent.fire();
    },
    showToast: function(component, event, helper, title, message, type) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message,
            "type": type
        });
        toastEvent.fire();
    },
    handleSkipTemplate: function(component, event, helper) {
        var faxData= component.get("v.faxData")
        if(component.get("v.skipFaxCoverLetter")){
        	component.set("v.disableButton", false);
        	component.set("v.requiredTemplate" , false);
        }else{
        	component.set("v.requiredTemplate" , true);
        	if (!$A.util.isEmpty(component.get("v.faxData.selectedTemplate")) && !$A.util.isUndefinedOrNull(component.get("v.faxData.selectedTemplate"))) {
                component.set("v.disableButton", false);
        	}else{
        		component.set("v.disableButton", true);
        	}
        }
        component.set("v.errorMessage","");
    },
    viewSuccessScreen: function(component, event, helper) {
    	
    	if(!event.getParam("createFM")){
    		var listAgResponse = event.getParam("listAgResponse");
    		component.set('v.responsecolumns', [{
	                            label: 'REQUESTS',
	                            fieldName: 'requestName',
	                            type: 'text'
	                        },
	                        {
	                            label: 'SUB CASE #',
	                            fieldName: 'subCase',
	                            type: 'text'
	                        },
	                        {
	                            label: 'REQUEST STATUS',
	                            fieldName: 'requestStatus',
	                            type: 'text'
	                        }
	                    ]);
                component.set("v.responsedata", listAgResponse);
                component.set("v.isPrintComplete", true);
                component.set("v.isDocConfirm", false);
    	}else{
	        var successScreen = event.getParam("successMessage");
	        var acknowledgementId = event.getParam("acknowledgementId");
	        var selectedTemplate = component.get("v.faxData.selectedTemplate");
	        var slectedMessageBody = component.get("v.faxData").messageBody;
	        
	        var fullFillMentPackageId = component.get("v.fulFillMentPackageId");
	        var fulFillResponseDoc = component.get("v.confirmDoc").listFulfillDoc;
	        var action = component.get("c.saveFaxMethod");
	        action.setParams({
	            "selectedTemplate": selectedTemplate,
	            "selectedMessageBody": slectedMessageBody,
	            "packageId": fullFillMentPackageId,
	            "responseDoc": JSON.stringify(fulFillResponseDoc),
	            "packgeDocLinkId": component.get("v.packgeDocLinkId"),
	            "acknowledgementId": acknowledgementId,
	            "headerId":component.get("v.faxData").headerTemplateId
	        });
	        action.setCallback(this, function(response) {
	            var state = response.getState();
	            
	            if (state === 'SUCCESS') {
	                var responseVar = response.getReturnValue();
	                if ($A.util.isEmpty(responseVar.errorMessage)) {
	                    component.set('v.responsecolumns', [{
	                            label: 'REQUESTS',
	                            fieldName: 'requestName',
	                            type: 'text'
	                        },
	                        {
	                            label: 'SUB CASE #',
	                            fieldName: 'subCase',
	                            type: 'text'
	                        },
	                        {
	                            label: 'REQUEST STATUS',
	                            fieldName: 'requestStatus',
	                            type: 'text'
	                        }
	                    ]);
	                    
	                    component.set("v.responsedata", responseVar.listAgResponse);
	                    component.set("v.isPrintComplete", successScreen);
	                    component.set("v.isDocConfirm", false);
	                }else{
	                	helper.showToast(component, event, helper, $A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"), $A.get("$Label.c.AG_Error_Toast_Type"));
	                	component.set("v.disablePrintComplete", true);
	                   
	                    component.set("v.disablePreviousButton",true);
	                }
	            } else if (state === "INCOMPLETE") {
	                helper.showToast(component, event, helper, $A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"), $A.get("$Label.c.AG_Error_Toast_Type"));
	               
	            } else if (state === "ERROR") {
	                helper.showToast(component, event, helper, $A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"), $A.get("$Label.c.AG_Error_Toast_Type"));
	               
	            }
	            component.set("v.displaySpinner", false);
	        });
	        $A.enqueueAction(action);
       }
        var methodSelection = component.get("v.selectedMethodList");
        	methodSelection.fax = false;
            component.set("v.disableNextButton",false);
       
        component.set("v.isFax", false);
    },
    createCacheHelper : function(component , event,helper){
    	var selectedMessageBody = component.get("v.faxData").messageBody;
    	var action = component.get("c.createCache");
            action.setParams({
                "templateBody": selectedMessageBody
            });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === 'SUCCESS') {
                    var responseVar = response.getReturnValue();
                    if (!$A.util.isEmpty(responseVar) && !$A.util.isUndefinedOrNull(responseVar) && responseVar) {
                    	helper.createFaxPDFHelper(component,event,helper);
                    }else{
						helper.showToast(component, event, helper, $A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"), $A.get("$Label.c.AG_Error_Toast_Type"));
                    	component.set("v.displaySpinner", false);                        
                    }
                } else if (state === "INCOMPLETE") {
                    helper.showToast(component, event, helper, $A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"), $A.get("$Label.c.AG_Error_Toast_Type"));
                    component.set("v.displaySpinner", false);
                } else if (state === "ERROR") {
                    helper.showToast(component, event, helper, $A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"), $A.get("$Label.c.AG_Error_Toast_Type"));
                    component.set("v.displaySpinner", false);
                }
            });
            $A.enqueueAction(action);
    },
    createFaxPDFHelper : function(component,event,helper){
    	
        	if(!component.get("v.skipFaxCoverLetter") && !$A.util.isEmpty(component.get("v.selectedMessageBody")) && !$A.util.isUndefinedOrNull(component.get("v.selectedMessageBody")) && JSON.stringify(component.get("v.selectedMessageBody")).length > $A.get("$Label.c.AG_Max_Size_CoverLetter")){
	        	component.set("v.errorMessage",$A.get("$Label.c.AG_Cover_Letter_Error"));
	        	component.set("v.displaySpinner" , false);
	        	return;
        	}
        	if(component.get("v.skipFaxCoverLetter")){
            	component.set("v.selectedMessageBody", "");
            	var listTemplateData = component.get("v.faxData");
            	listTemplateData.messageBody = '';
                listTemplateData.selectedTemplate = '';
                listTemplateData.headerTemplateId = '';
            	component.set("v.faxData", listTemplateData);
            }
        	
            var fullFillMentPackageId = component.get("v.fulFillMentPackageId");
            var selectedMessageBody = component.get("v.faxData").messageBody;
            var documentHeaderId = component.get("v.faxData").headerTemplateId;
            
            var action = component.get("c.confirmFaxDoc");
            action.setParams({
                "packageId": fullFillMentPackageId,
                "templateBody": selectedMessageBody,
                "documentHeader": documentHeaderId
            });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === 'SUCCESS') {
                    var responseVar = response.getReturnValue();
                    if (!$A.util.isEmpty(responseVar) && !$A.util.isUndefinedOrNull(responseVar)) {
                        component.set("v.confirmDoc", responseVar);
                        component.set("v.packgeDocLinkId", responseVar.faxCoverId);
                        component.set("v.displaySpinner", false);
                        component.set("v.isDocConfirm", true);
                        component.set("v.isFax", false);
                        component.set("v.displaySpinner", false);
                        //Create wrapper for efax
                        var fmData = component.get("v.fmData");
                        fmData.selectedTemplate = component.get("v.selectedTemplate");
                        fmData.selectedMessageBody = component.get("v.faxData").messageBody;
                        fmData.responseDoc = component.get("v.confirmDoc").listFulfillDoc;
                        fmData.packgeDocLinkId = component.get("v.packgeDocLinkId");
                        fmData.headerId = component.get("v.faxData").headerTemplateId;
                        component.set("v.fmData",fmData);
                    }else{
						helper.showToast(component, event, helper, $A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"), $A.get("$Label.c.AG_Error_Toast_Type"));
                    	component.set("v.displaySpinner", false);                        
                    }
                } else if (state === "INCOMPLETE") {
                    helper.showToast(component, event, helper, $A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"), $A.get("$Label.c.AG_Error_Toast_Type"));
                    component.set("v.displaySpinner", false);
                } else if (state === "ERROR") {
                    helper.showToast(component, event, helper, $A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"), $A.get("$Label.c.AG_Error_Toast_Type"));
                    component.set("v.displaySpinner", false);
                }
            });
            $A.enqueueAction(action);
    },
    //SHOW PROMPT TO INFORM THAT NEW VERSION CANNOT BE CREATED BASED ON CURRENT STATUS.
    openPromptComponent : function(component,event,helper, message){
        component.set("v.confirm",false);
        var modalBody;
        $A.createComponent("c:AG_Reusable_Prompt_Component", {"message" : message , 
                            "confirm":component.getReference('v.confirm') , "isPrompt":true, "negative":$A.get("$Label.c.AG_No")},
           function(content, status) {
               if (status === "SUCCESS") {
                   modalBody = content;
                   component.find('overlayLib').showCustomModal({
                       header: $A.get("$Label.c.AG_Label_Warning"),
                       body: modalBody, 
                       showCloseButton: false,
                       cssClass: "mymodal",
                       closeCallback: function() {
                           helper.userPromptHelper(component,event,helper);
                       }
                   })
               }                               
           });
    },
    //VALIDATE USER INPUT TO CREATE FP OR CANCEL.
    userPromptHelper : function(component , event , helper){ 
        if(component.get("v.confirm")){
            helper.navigateToMethodContainerOnSkip(component,event , helper);
        }else{
            component.set("v.displaySpinner" , false);
        }
    }
    
})
