({
    doInit : function(component , event , helper){
    	helper.reOrderDocumentsHelper(component , event , helper); 
    },
    handleChange: function (component, event, helper) {
        helper.handleChangeHelper(component, event, helper);
    },
    userSelect : function(component, event, helper) {
		helper.userSelectHelper(component , event , helper);	
	},
	closeMessage : function(component,event,helper){
		helper.closeErrorHelper(component,event,helper);
	}
})