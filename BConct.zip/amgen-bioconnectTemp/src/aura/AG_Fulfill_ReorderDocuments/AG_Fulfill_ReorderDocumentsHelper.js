({
    handleChangeHelper: function (component, event, helper){
    	helper.closeErrorHelper(component , event , helper);
    },
    userSelectHelper : function(component , event , helper){
        var key = event.getSource().getLocalId();
        
        if(key === 'next'){
        	component.set("v.Spinner" , true);
        	if(component.get("v.values").length != component.get("v.noOfRecords")){
        		component.set("v.errorMessage" , $A.get("$Label.c.AG_Documents_SelectAll"));
        		component.set("v.Spinner" , false);
        		return;
        	}
            helper.navigateToComponents(component,event , helper,4);
        }else if(key === 'cancel' || key === 'saveClose'){
            helper.navigateToComponents(component,event , helper,0);
        }else if(key === 'prev'){
            helper.navigateToComponents(component,event , helper,2);
        }
    },
    navigateToComponents  :function(component , event , helper,componentNo){
    	
        var compEvent = component.getEvent("navigateComponent");
        var saveAndClose = false;
        if(componentNo == 0){
        	if('cancel' == event.getSource().getLocalId()){
        		compEvent.setParams({"componentNo" : componentNo});
        		compEvent.fire();
        		component.set("v.Spinner" , false);
        		return;
        	}else{
        		saveAndClose = true;
        	}
        }
        compEvent.setParams({"componentNo" : componentNo ,
        					"masterCaseWrapper" : JSON.stringify(component.get("v.masterCaseWrapper")) ,
        					"selectedRequests" : component.get("v.requestsSelection"),
        					"documentsReordered" : component.get("v.values"),
        					"saveAndClose" : saveAndClose ,
                            "saveData" : !saveAndClose,
                            "fulfillmentPackageId":component.get("v.fulfillmentPackageId"),
	        				"fulfillmentUserData":component.get("v.fulfillmentUserDataId")});
		compEvent.fire();
		component.set("v.Spinner" , false);
    },
    reOrderDocumentsHelper : function(component , event , helper){
    	component.set("v.Spinner" , true);
    	
    	var response = component.get("v.masterCaseWrapper");
    	var conts = response.mapScaseReqWrap;
    	// Validate if data
    	var allResponseIds = [];
        if(Object.keys(conts).length != 0){
            for ( var key in conts ) {
            	if(undefined != conts[key]){
            		for(var res in conts[key]){
            			if(conts[key][res].isSelected == true){
            				for(var writtenResponse in conts[key][res].lstResp){
            					allResponseIds.push(conts[key][res].lstResp[writtenResponse].Id);
            				}
            			}
            		}
            	}
            }
        }
        component.set("v.allResponseIds",allResponseIds);
        helper.fetchAllResponses(component , event , helper);
    },
    closeErrorHelper : function(component , event , helper){
    	component.set("v.errorMessage" , '');
    },
    fetchAllResponses : function(component , event , helper){
    	
    	
    	var noOfRecords = 0;
    	var mapUniqueResponses = component.get("v.mapUniqueResponses");
    	var responseList = [];
    	var valueList = [];
    	var allResponseIdsMap = {};
    	var responseIds = component.get("v.allResponseIds");
    	var action = component.get("c.fetchResponsesBasedOnIds");
    	action.setParams({"responseIds" : responseIds});
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === 'SUCCESS'){
                var responseVar = response.getReturnValue();
                if(!$A.util.isEmpty(responseVar) && !$A.util.isUndefinedOrNull(responseVar)){
                	if(responseVar.length>0){
                		for(var writtenResponse in responseVar){
            					if(responseVar[writtenResponse].AG_Written__c == true && responseVar[writtenResponse].AG_Add_as_Enclosure__c == false){
            						var response = {};
            						var responseLabel= responseVar[writtenResponse].AG_Document_Name__c + '( '+ responseVar[writtenResponse].AG_Source__c+' )';
            						response.label = responseLabel;
            						response.value = responseVar[writtenResponse].Id;
            						if(responseVar[writtenResponse].AG_Source__c == $A.get("$Label.c.AG_Volt_Label")){
            							responseLabel = responseLabel+responseVar[writtenResponse].AG_Document_Id__c;
            						}
            						if(undefined == mapUniqueResponses[responseLabel]){
            							noOfRecords++;
	            						responseList.push(response);
	            						if(component.get("v.values").length == 0){
	            							valueList.push(responseVar[writtenResponse].Id);
	            						}else{
	            							allResponseIdsMap[responseVar[writtenResponse].Id] = responseVar[writtenResponse].Id;
	            						}
	            						mapUniqueResponses[responseLabel] = response.value;
            						}	
            					}
            				}
                	}
                	if(!$A.util.isEmpty(allResponseIdsMap) && !$A.util.isUndefinedOrNull(allResponseIdsMap)){
			        	var selectedResponseIds = component.get("v.values");
						var responseIdsMap = {};
						for(var i in selectedResponseIds){
							if(undefined != allResponseIdsMap[selectedResponseIds[i]]){
								valueList.push(selectedResponseIds[i]);
								responseIdsMap[selectedResponseIds[i]]=selectedResponseIds[i];
							}
						}
						for(var i in allResponseIdsMap){
							if(undefined == responseIdsMap[allResponseIdsMap[i]]){
								valueList.push(allResponseIdsMap[i]);
							}
						}
						
			        }
			        component.set("v.noOfRecords" , noOfRecords);
			        component.set("v.options" , responseList);
			        component.set("v.values" , valueList);
			        component.set("v.mapUniqueResponses",{});
			        component.set("v.Spinner" , false);  	
                }
            }else if(state === "INCOMPLETE"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
            } else if(state === "ERROR"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
            }
        });
        $A.enqueueAction(action); 
    },
    showToast: function(component, event, helper, title, message, type) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message,
            "type": type
        });
        toastEvent.fire();
    }    
})