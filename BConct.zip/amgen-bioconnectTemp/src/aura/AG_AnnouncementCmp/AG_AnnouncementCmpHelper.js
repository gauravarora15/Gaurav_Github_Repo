({
	doInitHelper : function(component, event, helper) {
        var action = component.get("c.getAnnouncement");       
        action.setCallback(this,function(response){        
        var state = response.getState();
            
            if (state === "SUCCESS") {     
                var retVal = response.getReturnValue();
                component.set('v.mycolumns', [
                    {label: $A.get("$Label.c.AG_Announcements_Label"), fieldName: $A.get("$Label.c.AG_Announcement_Field_API"), type: 'text'}
                ]);
                
                var newList = [];              
                for(var i = 0; i < retVal.length;i++){     
                    if(!$A.util.isEmpty(retVal[i].AG_Announcement__c) && !$A.util.isUndefinedOrNull(retVal[i].AG_Announcement__c)){
                        var annnouncementVar = { AG_Announcement__c : retVal[i].AG_Announcement__c }; 
                        newList.push(annnouncementVar); 
                    }       
                } 
                component.set("v.mydata",newList);
            }

            else if(state === "INCOMPLETE"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }
                else if(state === "ERROR"){
                 helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                }   
        });
        $A.enqueueAction(action); 
    },

    showToast: function(title,message,type){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message,
            "type": type
        });
        toastEvent.fire();
    }
})