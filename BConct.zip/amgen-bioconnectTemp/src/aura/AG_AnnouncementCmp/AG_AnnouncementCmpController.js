({
	doInit : function(component, event, helper) {
		helper.doInitHelper(component, event, helper);
	},
	navigateToListView : function(component, event, helper){
		var navService = component.find("navService");
		var pageReference = {
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'AG_Announcement__c',
                actionName: 'list'
            },
            state: {
                filterName: "Announcements"
            }
        };

        component.set("v.pageReference",pageReference);
        navService.navigate(pageReference);
	}
})