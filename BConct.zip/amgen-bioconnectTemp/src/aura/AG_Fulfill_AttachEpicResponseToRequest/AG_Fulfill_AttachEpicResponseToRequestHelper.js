({
    // Method On initialization of component
	handleDoInit : function(component, event, helper) {
        component.set("v.ErrorMessage", '');
		component.set("v.Spinner" , true);
		var responseFromUser = {};
		responseFromUser.ParentId = component.get("v.parentId");
		responseFromUser.ProductId = '';
		responseFromUser.geography = '';
		responseFromUser.language = '';
		if(component.get("v.forMasterCase")== true){
			responseFromUser.verbal = true;
		}else{
			responseFromUser.verbal = false;
		}
		component.set("v.responseFromUser" , responseFromUser);
		component.set('v.searchColumns', [
                {label: $A.get("$Label.c.AG_Document_Name"), fieldName: 'name', type: 'text'},
                {label: $A.get("$Label.c.AG_Product_Label"), fieldName: 'product', type: 'text'},
                {label: $A.get("$Label.c.AG_Language"), fieldName: 'language', type: 'text'},
                {label: $A.get("$Label.c.AG_Geography"), fieldName: 'geography', type: 'text'},
                {label: $A.get("$Label.c.AG_VERSION"), fieldName: 'version', type: 'text'}
                ]);
		var action = component.get("c.getAllPicklistValues");
		
        action.setCallback(this,function(response){
            var state = response.getState();
            
            if(state === "SUCCESS"){
                var response = response.getReturnValue();
                if(!$A.util.isEmpty(response) && !$A.util.isUndefined(response)){
                	if(!response.hasError){
                		if(!$A.util.isEmpty(response.lstLanguage) && !$A.util.isUndefined(response.lstLanguage)){
                			helper.createLanguageList(component , event , helper,response.lstLanguage);
                		}
                		if(!$A.util.isEmpty(response.mapProduct) && !$A.util.isUndefined(response.mapProduct)){
                			helper.createProductList(component , event , helper,response.mapProduct);
                		}
                		if(!$A.util.isEmpty(response.mapCountry) && !$A.util.isUndefined(response.mapCountry)){
                			helper.createCountryList(component , event , helper,response.mapCountry);
                		}
                		
                		
                	}else{
                		helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                	}
                }else{
                    helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                }  
            } else if(state === "ERROR"){
                	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }
            component.set("v.Spinner" , false);
        });
        $A.enqueueAction(action);	
	},

    // Method to show toast 
	showToast : function(component, event, helper,title , message , type) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message,
            "type" : type
        });
        toastEvent.fire();
    },

    //Method to get the Language Picklist values
    createLanguageList : function(component , event , helper , languagesList){
    	var languageArray = [];
    	for( var key in languagesList ){
    		var language = {};
    		language.label = languagesList[key];
    		language.value = languagesList[key];
    		languageArray.push(language);
    	}
    	component.set("v.languageList" , languageArray);
    },

    //Method to get the Product Picklist values
    createProductList : function(component , event , helper , productList){
    	var productArray = [];
    	for( var key in productList ){
    		var product = {};
    		product.label = key;
    		product.value = productList[key];
    		productArray.push(product);
    	}
    	component.set("v.productList" , productArray);
    },
   
     //Method to get the Product Picklist values
    createCountryList : function(component , event , helper , CountryList){
    	var countryArray = [];
    	for( var key in CountryList ){
    		var country = {};
    		country.label = key;
    		country.value = CountryList[key];
    		countryArray.push(country);
    	}
    	component.set("v.geographyList" , countryArray);
    },

     //Method to get the document list on search
    handleSearchHelper : function(component , event , helper){
    	component.set("v.Spinner" , true);
        component.set("v.ErrorMessage", '');
    	var action = component.get("c.fetchResponseData");
    	action.setParams({"request" : JSON.stringify(component.get("v.responseFromUser"))});
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var resp = response.getReturnValue();
                
                if(!$A.util.isEmpty(resp) && !$A.util.isUndefined(resp)){
                    if(!$A.util.isEmpty(resp.errorstring)){                
                            component.set("v.ErrorMessage", resp.errorstring);
                            component.set('v.currentData', []);
                        
                    }else{
                        var responseData = resp.responseList;
                        if(responseData.length > 10){
                             component.set("v.lstDocuments", responseData);
                             var currentData = responseData.slice(0,10);
                             component.set("v.currentData", currentData);
                             component.set("v.rowsDisplayed", 10);

                        }else{
                            component.set("v.currentData",responseData);
                            component.set('v.enableInfiniteLoading', false);

                        }
                        
                    }
                	
                }else{
                	component.set('v.currentData', []);
                }  
            } else if(state === "INCOMPLETE"){
                    helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }else if(state === "ERROR"){
                	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }
            component.set("v.Spinner" , false);
        });
        $A.enqueueAction(action);	
    },

    // Method to handle the selected documents
    SelectedDocumentsHelper : function(component , event , helper){
    	var selectedRows = event.getParam('selectedRows');
    	component.set("v.selectedDocumentsList" ,selectedRows);
    	var value = false;
    	if(selectedRows.length>0){
    		value = true;
    	}
    	component.set("v.docSelected" , value);
    },

    //Method to handle the different button action
    userSelectHelper : function(component , event , helper){
    	var userClick = event.getSource().getLocalId();
    	if(userClick === 'cancel'){
    		helper.navigateToComponents(component , event , helper);
    	}else if(userClick === 'create'){
    		helper.createResponses(component ,event , helper);
    	}
    },

    // Method to navigate to different component
    navigateToComponents  :function(component , event , helper){
    	component.find("overlayLib").notifyClose();
    },

    // Method to generate responses
    createResponses : function(component , event , helper){
        component.set("v.ErrorMessage", '');
    	component.set("v.Spinner" , true);
    	
    	var action = component.get("c.responseCreation");
    	action.setParams({"response" : JSON.stringify(component.get("v.selectedDocumentsList")),
    					"parentId" : component.get("v.parentId")});
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var resp = response.getReturnValue();
                if(!$A.util.isEmpty(resp) && !$A.util.isUndefined(resp)){
                	if(resp === $A.get("$Label.c.AG_Sucess_Toast_Type")){
                		component.find("overlayLib").notifyClose();
                		helper.showToast(component, event, helper,$A.get("$Label.c.AG_Sucess_Toast_Type") , $A.get("$Label.c.AG_Response_Create_Success"),$A.get("$Label.c.AG_Sucess_Toast_Type"));
                	}else{
                		component.find("overlayLib").notifyClose();
                		helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                	}
                }else{
                	component.find("overlayLib").notifyClose();
                    helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
                }  
            }else if(state === "INCOMPLETE"){
                    component.find("overlayLib").notifyClose();
                    helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }else if(state === "ERROR"){
            		component.find("overlayLib").notifyClose();
                	helper.showToast(component , event , helper , $A.get("$Label.c.AG_Error") , $A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }
            component.set("v.Spinner" , false);
        });
        $A.enqueueAction(action); 	
    },

    // Method for lazy load
    loadMoreData: function (component, event, helper) {
        var rowsDisplayed = component.get("v.rowsDisplayed");
        var actualData = component.get("v.lstDocuments");
        var currentData = component.get("v.currentData");

        if(currentData.length < actualData.length){
            var newRows = actualData.slice(rowsDisplayed,rowsDisplayed+10);
            var newData = currentData.concat(newRows);
            component.set("v.currentData",newData);
            component.set("v.rowsDisplayed",rowsDisplayed+10);

        }else{
            component.set("v.enableInfiniteLoading", false);
        }


    }
    
})
