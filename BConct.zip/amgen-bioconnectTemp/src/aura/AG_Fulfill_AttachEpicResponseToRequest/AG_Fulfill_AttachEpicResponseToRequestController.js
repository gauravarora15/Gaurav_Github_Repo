({
	doInit : function(component, event, helper) {
		helper.handleDoInit(component, event, helper);
	},
	handleSearch : function(component , event , helper){
		helper.handleSearchHelper(component , event , helper);
	},
	handleSelectedDocuments : function(component , event , helper){
		helper.SelectedDocumentsHelper(component , event , helper);
	},
    userSelect : function(component, event, helper) {
		helper.userSelectHelper(component , event , helper);	
	},
	loadMoreData: function (component, event, helper) {
		 helper.loadMoreData(component, event, helper) ;
	}
})