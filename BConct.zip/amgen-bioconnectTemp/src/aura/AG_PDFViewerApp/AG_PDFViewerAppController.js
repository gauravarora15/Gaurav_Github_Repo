({
	doInit : function(component, event, helper) {
        helper.handleDoInit(component, event, helper);
	},
	userSelect : function(component,event,helper){
		helper.navigateBack(component,event,helper);
	}
})