({
	handleDoInit : function(component,event,helper) {
        
        component.set("v.errorMessage" , "");
        component.set("v.showSpinner" , true);
        var document = component.get("v.docId");
    	var parameters = document.split(",");
        var docId = parameters[0];
        if(parameters.length === 3){
        	var docId = parameters[0];
            var docSize = parameters[1];
            var docSource = parameters[2];
            if(parseInt(docSize) > $A.get("$Label.c.AG_File_Size")){
            	helper.openPromptComponent(component , event , helper);
            }else{
                if(docSource ==  $A.get("$Label.c.AG_Volt_Label")){
                    helper.fetchVoltData(component,event,helper,docId);
                }else if(docSource ==  $A.get("$Label.c.AG_Source_Epic")){
                    helper.fetchEpicData(component,event,helper,docId);
                }
            }
        }else{
        	helper.fetchVoltData(component,event,helper,docId);
        }
	},
	openPromptComponent : function(component,event,helper){
		component.set("v.errorMessage",$A.get("$Label.c.AG_File_Size_Limit"));
		component.set("v.showSpinner" , false);
    },
    fetchVoltData : function(component,event,helper,documentId){
    	component.set("v.showSpinner",true);
		var action = component.get('c.getPdfContent');
        action.setParams({
            "docId":documentId
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                if(!$A.util.isEmpty(response.getReturnValue()) && !$A.util.isUndefinedOrNull(response.getReturnValue())){
                    component.set("v.pdfData",response.getReturnValue());
                } else{
                    component.set("v.errorMessage",$A.get("$Label.c.AG_errorMessage"));
                }
            } else{
            	component.set("v.errorMessage",$A.get("$Label.c.AG_errorMessage"));
            }
            component.set("v.showSpinner",false);
        });
        
        $A.enqueueAction(action);
    },
    fetchEpicData: function(component,event,helper,documentId){
        
        component.set("v.showSpinner",true);
        var action = component.get('c.getEpicContent');
        action.setParams({
            "docId":documentId
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                if(!$A.util.isEmpty(response.getReturnValue()) && !$A.util.isUndefinedOrNull(response.getReturnValue())){
                    console.log('INSIDE SUCCESS STATE:' + response.getReturnValue());
                    component.set("v.pdfData",response.getReturnValue());
                } else{
                    component.set("v.errorMessage",$A.get("$Label.c.AG_errorMessage"));
                }
            } else{
                component.set("v.errorMessage",$A.get("$Label.c.AG_errorMessage"));
            }
            component.set("v.showSpinner",false);
        });
        
        $A.enqueueAction(action);
    },
    navigateBack : function(component , event , helper){
    	window.close();
    }
})
