({
    fetchPcmIssueID : function(component, event,helper) {
        component.set("v.displaySpinner",true);
        var action = component.get("c.fetchPCMIssueProductId");
        action.setParams({
            "recId" : component.get("v.recordId")
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){  
                component.set("v.lotBatchWrapper",response.getReturnValue());
                if(!component.get("v.lotBatchWrapper.isError")){
                    /* set Pcm Issue id and name */
                    component.set("v.selectedPCMIssueLookUpRecord.Id",component.get("v.lotBatchWrapper.PCMIssue.Id"));
                    component.set("v.selectedPCMIssueLookUpRecord.Name",component.get("v.lotBatchWrapper.PCMIssue.Name"));
                    /* set product details of pcm issue on lot batch*/
                    component.set("v.selectedProductLookUpRecord.Id",component.get("v.lotBatchWrapper.PCMIssue.AG_Product__c"));
                    component.set("v.selectedProductLookUpRecord.Name",component.get("v.lotBatchWrapper.PCMIssue.AG_Product__r.Name"));
                } else{
                    // perform the error handling mechanism for validation errors
                    helper.navigateCancel(component, event, helper);
                    helper.showToast($A.get("$Label.c.AG_Error"),component.get("v.lotBatchWrapper.errorString"),$A.get("$Label.c.AG_Error"));
              }
            }else if(state === "INCOMPLETE"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            } else if(state === "ERROR"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }
            component.set("v.displaySpinner",false);
        });
        $A.enqueueAction(action);
        
    },
    validateLotNumberInODS : function(component, event, helper) {
        component.set("v.displaySpinner" , true);
        var action = component.get("c.validateLotBatch");
        action.setParams({
            "lotBatchNumber" : component.get("v.lotBatchWrapper.lotBatchRecord.AG_Lot_Batch_Number__c")
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){  
                var lotBatchWrapper = component.get("v.lotBatchWrapper");
                component.set("v.validatedLotBatchWrapper",response.getReturnValue().lotBatchInfo);
                var responsevalue = response.getReturnValue();
                if( !$A.util.isUndefinedOrNull(responsevalue.status) && responsevalue.status == "Success") {
                     //lot batch details found
                    if($A.util.isUndefinedOrNull(responsevalue.errors) || $A.util.isEmpty(responsevalue.errors)){
                          if(((!$A.util.isUndefinedOrNull(responsevalue.lotBatchInfo.TRADE_NAME) && !$A.util.isEmpty(responsevalue.lotBatchInfo.TRADE_NAME) )
                                 && ((component.get("v.selectedProductLookUpRecord.Name").trim()).toUpperCase() == ((responsevalue.lotBatchInfo.TRADE_NAME).trim()).toUpperCase()))||(!$A.util.isUndefinedOrNull(responsevalue.lotBatchInfo.GENERIC_NAME) && !$A.util.isEmpty(responsevalue.lotBatchInfo.GENERIC_NAME) && ((component.get("v.selectedProductLookUpRecord.Name").trim()).toUpperCase() == ((responsevalue.lotBatchInfo.GENERIC_NAME).trim()).toUpperCase()))){  
                               //lot batch details found,product details are matched
                                    //component.set("v.searchDisable",false);
                               		component.set("v.buttonDisable",false);
                                    component.set("v.errorType",$A.get("$Label.c.AG_Label_confirm"));
                                    component.set("v.hasErrors",true);
                                    component.set("v.errormessage",$A.get("$Label.c.AG_Lot_Batch_exists_and_matched_with_product_error"));
                               		lotBatchWrapper.validated = $A.get("$Label.c.AG_Yes_Lot_Batch_exists_and_matched_with_product_error");	
                              
                                } else{                                       
                                     //lot batch details found,product details are not matched
                                    //component.set("v.searchDisable",true);
                                    component.set("v.errorType",$A.get("$Label.c.AG_Label_Warning"));
                                    component.set("v.hasErrors",true);
                                    component.set("v.errormessage",$A.get("$Label.c.AG_Lot_Batch_exists_and_does_not_matched_with_product_error"));
                                 	lotBatchWrapper.validated = $A.get("$Label.c.AG_Yes_Lot_Batch_exists_and_does_not_matched_with_product_error");
                                    component.set("v.buttonDisable",false);
                                }
                                component.set("v.searchDisable",false);
                    //lot batch number not found
                    } else{
                        component.set("v.searchDisable",true);
                        component.set("v.errorType",$A.get("$Label.c.AG_Error"));
                        component.set("v.hasErrors",true);
                        component.set("v.errormessage", $A.get("$Label.c.AG_Lot_Batch_does_not_exists_in_ODS_error"));
                        lotBatchWrapper.validated = $A.get("$Label.c.AG_No_Lot_Batch_Number_does_not_exist");
                        component.set("v.buttonDisable",false);
                        component.set("v.showPackageLotCheck",true);
                    }
                   component.set("v.lotBatchWrapper",lotBatchWrapper);
                }else if($A.util.isUndefinedOrNull(responsevalue.status) || responsevalue.status != "Success"){
                    component.set("v.hasErrors",true);
                    component.set("v.errormessage",$A.get("$Label.c.AG_ODS_Connection_Failed"));
                }
            }else if(state === "ERROR"){
                    helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }
            component.set("v.displaySpinner" , false);
                
        });
        $A.enqueueAction(action);
        
    },
    searchLotNumberInODS : function(component, event, helper) {
        component.set("v.displaySpinner" , true);
        component.set("v.SublotBatchWrapper",[]);
        var action = component.get("c.getSubLotBatchRecords");
        action.setParams({
            "lotNumber" : component.get("v.lotBatchWrapper.lotBatchRecord.AG_Lot_Batch_Number__c")
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){  
                component.set("v.buttonDisable",false);
                var responsevalue = response.getReturnValue();
                if( !$A.util.isUndefinedOrNull(responsevalue.status) && responsevalue.status == "Success") {
                    //lot batch details found
                    if($A.util.isUndefinedOrNull(responsevalue.errors) || $A.util.isEmpty(responsevalue.errors)){
                        component.set("v.SublotBatchWrapper",responsevalue.lotBatchInfo);
                         component.set("v.showresults",true);
                    }else{
                        component.set("v.hasErrors",true);
                        component.set("v.errormessage",$A.get("$Label.c.AG_No_results_found"));
                    }
                }else if($A.util.isUndefinedOrNull(responsevalue.status) || responsevalue.status != "Success"){
                    component.set("v.hasErrors",true);
                    component.set("v.errormessage",$A.get("$Label.c.AG_ODS_Connection_Failed"));
                }
            }else if(state === "ERROR"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }
            component.set("v.displaySpinner" , false);
        });
        $A.enqueueAction(action);
    },
   updateSelectedTextHelper : function(component, event,helper) {
	   var selectedRow = event.getParam('selectedRows');
       component.set("v.selectedSublotBatchWrapperinfo", event.getParam('selectedRows'));
       
    },
    handleSave : function(component, event,helper) {
        var subLots = component.get("v.selectedSublotBatchWrapper");
        component.set("v.displaySpinner",true);
        var wrapper = component.get("v.lotBatchWrapper");
        wrapper.lotBatchRecInfoDetails= component.get("v.selectedSublotBatchWrapperinfo");
        wrapper.validatedLotBatchRecInfoDetails= component.get("v.validatedLotBatchWrapper");
        var action = component.get("c.createLotBatchRec");
        action.setParams({
            "wrapString" : JSON.stringify(wrapper)
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                if(response.getReturnValue().indexOf(wrapper.PCMIssue.Id)> -1){
                    helper.showToast($A.get("$Label.c.AG_Case_Intake_Status_SUCCESS"),$A.get("$Label.c.AG_Lot_Batch_record_created_Successfully"),	$A.get("$Label.c.AG_Sucess_Toast_Type"));
                    //helper.navigateToRecord(component, event, helper, wrapper.PCMIssue.Id);
                    component.find("workspace").getFocusedTabInfo().then(function (response) {
                    	helper.navigateToRecord(component, event, helper, wrapper.PCMIssue.Id, response.parentTabId); 
                    });
                }
				else if(response.getReturnValue() == $A.get("$Label.c.AG_Duplicate_Lot")){
					helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Duplicate_Lot_Error"),$A.get("$Label.c.AG_Error"));
				}
				else{
                    component.set("v.createValidateMessage",response.getReturnValue());
                }
            } else{
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_errorMessage"),$A.get("$Label.c.AG_Error"));
            }
            component.set("v.displaySpinner",false);
        });
        $A.enqueueAction(action);
    },
    navigateCancel : function(component , event , helper){
        var workspaceAPI = component.find("workspace");
        workspaceAPI.getFocusedTabInfo().then(function(response) {
            var focusedTabId = response.tabId;
            workspaceAPI.closeTab({tabId: focusedTabId});
        })
        .catch(function(error) {
            
        });
    },
    showToast: function(title,message,type){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message,
            "type": type
        });
        toastEvent.fire();
    },
    navigateToRecord : function(component , event , helper, recordId, parentTabId){
    	var subTabId;
        

        helper.closeFocusedTab(component , event , helper);
        event.preventDefault();

                var workspaceAPI = component.find("workspace");
		        workspaceAPI.openSubtab({
		            parentTabId: parentTabId,
		            pageReference: {
		                "type": 'standard__recordPage',
		                "attributes": {
		                    "recordId": recordId,
		                    "actionName" : "view",
		                    "objectApiName" : 'AG_PCM_Issue__c'
		                },
		                "state": {
		                    
		                }
		            },
		            focus: true
		        }).then(function(response){
		            subTabId = response
		            workspaceAPI.focusTab({tabId : subTabId});
		        }).catch(function(error){
		            console.log("this error: " + error);
		        });
		        
		        workspaceAPI.refreshTab({
	                tabId: parentTabId,
	                includeAllSubtabs: true
	            }).catch(function(error){
	                console.log("error here123" + error);
	            });
    },
     unknownLotBatchCreation : function(component, event, helper) {
                if(component.get("v.unknownCheck")){
                	component.set("v.lotBatchWrapper.lotBatchRecord.AG_Lot_Batch_Number__c","UNKNOWN");
                	component.set("v.showPackageLotCheck",true);
                    component.set("v.searchDisable",true);
                    component.set("v.showresults",false);
                    component.set("v.lotBatchWrapper.unKnownPkgLotNumber",false);
                	component.set("v.buttonDisable",false);
                	component.set("v.hasErrors",false)
                }else{
                	component.set("v.lotBatchWrapper.lotBatchRecord.AG_Lot_Batch_Number__c","");
                	component.set("v.showPackageLotCheck",false);
                	component.set("v.buttonDisable",true);
					component.set("v.lotBatchWrapper.unKnownPkgLotNumber",false);
                }
	},
	
    closeFocusedTab : function(component, event, helper) {
        var workspaceAPI = component.find("workspace");
        workspaceAPI.getFocusedTabInfo().then(function(response) {
            var focusedTabId = response.tabId;
            workspaceAPI.closeTab({tabId: focusedTabId});
        })
        .catch(function(error) {
            
        });
    },
})