({
    afterRender : function(component, helper) {
        this.superAfterRender();
        var workspaceAPI = component.find("workspace");
        workspaceAPI.getAllTabInfo().then(function(response) {
        	response.forEach(function(element) {
                //alert("cmp Name"+element.pageReference.attributes.componentName);
			  if(undefined != element.pageReference.attributes.componentName && 
				  element.pageReference.attributes.componentName == "c__AG_CreateLotBatchCmp"){
					  workspaceAPI.setTabLabel({
		                tabId: element.tabId,
		                label: "LotBatch"
					  });
				  }
			});
        }).catch(function(error) {
            console.log(error);
        });
    }
})