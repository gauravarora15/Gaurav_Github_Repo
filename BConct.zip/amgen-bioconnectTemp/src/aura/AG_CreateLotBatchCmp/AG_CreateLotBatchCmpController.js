({
    doInit: function(component,event,helper) {
        var pageReference = component.get("v.pageReference");
        component.set("v.recordId", pageReference.state.c__recordId);
        helper.fetchPcmIssueID(component , event , helper);
    },
    handleChange :function(component,event,helper) {
        component.set("v.searchDisable",true);
        component.set("v.buttonDisable",true);
        component.set("v.showresults",false);
        component.set("v.hasErrors",false);
        component.set("v.showPackageLotCheck",false);
		component.set("v.lotBatchWrapper.unKnownPkgLotNumber",false);
    },
    validateLotNumber : function(component,event, helper ) {
		var productId = component.get("v.selectedProductLookUpRecord.Id");
        var lotBatchSelection = component.get("v.lotBatchWrapper.lotBatchRecord.AG_Lot_Batch_Number__c");
         if(!$A.util.isUndefinedOrNull(productId) && !$A.util.isEmpty(productId) && !$A.util.isUndefinedOrNull(lotBatchSelection) && !$A.util.isEmpty(lotBatchSelection)){
            component.set("v.hasErrors",false);
            component.set("v.errormessage",'');
            component.set("v.showresults",false);
            helper.validateLotNumberInODS(component, event, helper);
        } else{
            //Error Message
            component.set("v.hasErrors",true);
            component.set("v.errormessage",$A.get("$Label.c.AG_Lot_Batch_Required_Validation_Message"));
        }
    },
     /* on click of Search validate the lotBatch Number in ODS*/
    searchLotNumber:function(component, event, helper) {
        var lotBatchSelection = component.get("v.lotBatchWrapper.lotBatchRecord.AG_Lot_Batch_Number__c");
        if(!$A.util.isUndefinedOrNull(lotBatchSelection) && !$A.util.isEmpty(lotBatchSelection)){
            component.set("v.hasErrors",false);
            component.set("v.errormessage",'');
            component.set('v.columns', [
                {label: 'Lot/Batch Number',initialWidth: 190, fieldName: 'BATCH_NUMBER', type: 'text'},
                {label: 'Description',initialWidth: 260, fieldName: 'MATERIAL_DESC', type: 'text'},
                {label: 'Is Package Lot/Batch Number?',initialWidth: 260, fieldName: 'isPackageLotNumber', type: 'text'},
                {label: 'Manufacturing Stage',initialWidth: 240, fieldName: 'MFG_STAGE_CODE', type: 'text'},
                {label: 'Manufacturing Site',initialWidth: 240, fieldName: 'MFG_SITE_BLDG', type: 'text'},
             
           ]);
            helper.searchLotNumberInODS(component, event, helper);
        } else{
            component.set("v.hasErrors",true);
            component.set("v.errormessage", $A.get("$Label.c.AG_Lot_Batch_Required_Validation_Message"));
        }
    },
    updateSelectedText : function(component, event,helper){
        helper.updateSelectedTextHelper(component, event,helper);
    },
     /* on click of Create button check all the validation and then save the lotbatch records*/
    createLotBatch:function(component, event, helper) {
        var lotBatchSelection = component.get("v.lotBatchWrapper.lotBatchRecord.AG_Lot_Batch_Number__c");
        if(!$A.util.isUndefinedOrNull(lotBatchSelection) && !$A.util.isEmpty(lotBatchSelection)){
            component.set("v.hasErrors",false);
            component.set("v.errormessage",''); 
            helper.handleSave(component, event, helper);
        } else{
            component.set("v.hasErrors",true);
            component.set("v.errormessage",$A.get("$Label.c.AG_Lot_Batch_Create_validation_Error"));
        }
    },
    handleSpace : function(component, event, helper){
        var fieldVale = event.getSource().get("v.value");
        if(!$A.util.isEmpty(fieldVale) && !$A.util.isUndefinedOrNull(fieldVale)){
            component.set("v.lotBatchWrapper.lotBatchRecord.AG_Lot_Batch_Number__c",fieldVale.trim());
        }
    },
    /* on click of select all check box mark all the below check boxes as true*/
    selectAllLotBatches : function(component, event, helper) {
        helper.selectAllCheckBox(component);
    },
     handleCancel : function(component , event , helper){
    	helper.navigateCancel(component , event , helper);
    },
    userSelect : function(component, event, helper) {
		helper.userSelectHelper(component , event , helper);	
	},
    unknownLotBatchRecCreation : function(component, event, helper) {
        helper.unknownLotBatchCreation(component , event , helper);	
	},
    
})
