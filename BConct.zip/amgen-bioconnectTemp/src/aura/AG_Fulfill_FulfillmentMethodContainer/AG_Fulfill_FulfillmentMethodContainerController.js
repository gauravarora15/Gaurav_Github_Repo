({
	doInit : function(component, event, helper) {
		helper.loadSelectedMethod(component , event , helper);	
	},
    loadComponents : function(component, event, helper) {
		helper.loadComponents(component , event , helper);	
	}
})