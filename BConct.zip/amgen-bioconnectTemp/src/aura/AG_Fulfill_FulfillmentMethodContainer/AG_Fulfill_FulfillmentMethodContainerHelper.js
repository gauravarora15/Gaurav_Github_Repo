({
	loadSelectedMethod : function(component, event, helper){
		var selectedMethodList = component.get("v.selectedMethodList");
		var fulfillmentPackageId = component.get("v.fulfillmentPackageId");
        var isNotified = component.get("v.isNotified");
        var isCC = component.get("v.isCC");
        if(isNotified){
            $A.createComponent(
                    "c:AG_Fulfill_EmailToCC",
                    {
                        "fulFillMentPackageId" : fulfillmentPackageId,
                        "selectedMethodList" : selectedMethodList,
                        "isCCTemplate" : false,
                        "isNotified" : isNotified,
                        "isCC": isCC
                    },
                    function(newChild){
                        if (component.isValid()) {
                            var parent = component.find("renderComp");
                            var body = parent.get("v.body");
                            body = newChild;
                            parent.set("v.body", body);
                        }
                    }
                ); 
        }else if(isCC){

            $A.createComponent(
                    "c:AG_Fulfill_EmailToCC",
                    {
                        "fulFillMentPackageId" : fulfillmentPackageId,
                        "selectedMethodList" : selectedMethodList,
                        "isCCTemplate" : true,
                        "isNotified" : isNotified,
                        "isCC": isCC
                    },
                    function(newChild){
                        if (component.isValid()) {
                            var parent = component.find("renderComp");
                            var body = parent.get("v.body");
                            body = newChild;
                            parent.set("v.body", body);
                        }
                    }
                ); 
        }else if(selectedMethodList.email == true){
			  $A.createComponent(
                    "c:AG_Fulfill_EmailMethod",
                    {
                        "fulFillMentPackageId" : fulfillmentPackageId,
                        "selectedMethodList" : selectedMethodList
                    },
                    function(newChild){
                        if (component.isValid()) {
                            var parent = component.find("renderComp");
                            var body = parent.get("v.body");
                            body = newChild;
                            parent.set("v.body", body);
                        }
                    }
            	); 

		}else if(selectedMethodList.fax == true){
			 $A.createComponent(
                    "c:AG_Fulfill_FulfillRequestFax",
                    {
                        "fulFillMentPackageId" : fulfillmentPackageId,
                        "selectedMethodList" : selectedMethodList
                    },
                    function(newChild){
                        if (component.isValid()) {
                            var parent = component.find("renderComp");
                            var body = parent.get("v.body");
                            body = newChild;
                            parent.set("v.body", body);
                        }
                    }
            	); 
		}
        else if(selectedMethodList.postalMail == true){
			$A.createComponent(
                    "c:AG_Fulfill_PostalMailMethod",
                    {
                        "fulfillmentPackageId" : fulfillmentPackageId,
                        "selectedMethodList" : selectedMethodList
                    },
                    function(newChild){
                        if (component.isValid()) {
                            var parent = component.find("renderComp");
                            var body = parent.get("v.body");
                            body = newChild;
                            parent.set("v.body", body);
                        }
                    }
            	); 

		}else if(selectedMethodList.emailFacilitator == true){
			$A.createComponent(
                    "c:AG_Fulfill_EmailMethod",
                    {
                        "fulFillMentPackageId" : fulfillmentPackageId,
                        "selectedMethodList" : selectedMethodList
                    },
                    function(newChild){
                        if (component.isValid()) {
                            var parent = component.find("renderComp");
                            var body = parent.get("v.body");
                            body = newChild;
                            parent.set("v.body", body);
                        }
                    }
            	); 

		}else if(selectedMethodList.PostalMailFacilitator == true){
			$A.createComponent(
                    "c:AG_Fulfill_PostalMailMethod",
                    {
                        "fulfillmentPackageId" : fulfillmentPackageId,
                        "selectedMethodList" : selectedMethodList
                    },
                    function(newChild){
                        if (component.isValid()) {
                            var parent = component.find("renderComp");
                            var body = parent.get("v.body");
                            body = newChild;
                            parent.set("v.body", body);
                        }
                    }
            	); 
		}else{
           helper.navigateToComponents(component , event , helper,0);

        }
	},


    navigateToComponents  :function(component , event , helper,componentNo){
        var compEvent = component.getEvent("navigateComponent");
        compEvent.setParams({"componentNo" : componentNo});
        compEvent.fire();
       helper.showToast($A.get("$Label.c.AG_Fullfillment_Success_Label"),$A.get("$Label.c.AG_Sucess_Toast_Type"),$A.get("$Label.c.AG_Fulfillment_Process_Success_Message"));
    },

    loadComponents : function(component, event, helper){
        var fulfillmentPackageId = event.getParam("fulfillmentPackageId");
       	var methodSelection = event.getParam("methodSelection");
        var isCC = event.getParam("isCC");
        var isNotified = event.getParam("isNotified");

        component.set("v.fulfillmentPackageId",fulfillmentPackageId);
        component.set("v.selectedMethodList",methodSelection);
        component.set("v.isCC",isCC);
        component.set("v.isNotified", isNotified);
       
        helper.loadSelectedMethod(component, event, helper);
    },

    showToast: function(toastTitle, toastType, toastMessage){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": toastTitle,
            "type": toastType,
            "message": toastMessage
        });
        toastEvent.fire();
    }
})