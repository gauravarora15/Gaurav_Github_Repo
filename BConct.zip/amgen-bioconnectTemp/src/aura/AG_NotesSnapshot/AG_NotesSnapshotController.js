({
	doInit : function(component, event, helper) {
		helper.doInitHelper(component, event, helper);
	},
	handleSearch : function(component, event, helper){
		helper.handleSearch(component, event, helper);
	},
	handleSelectedFilterSection : function(component, event, helper){
		helper.handleSelectedFilterSection(component, event, helper);
	},
	handleSubCaseTypeSelection : function(component, event, helper){
		helper.handleSubCaseTypeSelection(component, event, helper);
	},
	handleCaseChange : function(component, event, helper){
		helper.handleCaseChange(component, event, helper);
	},
	handleProductChange : function(component, event, helper){
		helper.handleProductChange(component, event, helper);
	},
	handleDosageChange : function(component, event, helper){
		helper.handleDosageChange(component, event, helper);		
	},
	handleCountryChange : function(component, event, helper){
		helper.handleCountryChange(component, event, helper);
	},
	handleItemChange : function(component, event, helper){
		helper.handleItemChange(component, event, helper);
	},
	handleIssueChange : function(component, event, helper){
		helper.handleIssueChange(component, event, helper);
	},
	handleSiteChange : function(component, event, helper){
		helper.handleSiteChange(component, event, helper);
	},
	fromFilterValue : function(component, event, helper){
		helper.fromFilterValue(component, event, helper);
	},
	handleClear: function(component, event, helper){
		helper.handleClear(component, event, helper);
	},
	handleCancel: function(component, event, helper){
		helper.handleCancel(component, event, helper);
	},
	callPDFCreate : function(component, event, helper) {
		helper.callPDFCreate(component, event, helper);
	}

})