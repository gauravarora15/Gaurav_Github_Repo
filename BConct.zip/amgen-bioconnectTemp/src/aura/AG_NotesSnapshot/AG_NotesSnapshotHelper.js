({
	doInitHelper : function(component, event, helper) {
		component.set("v.displaySpinner" , true);
		component.set("v.selectedSection", '');
		var action = component.get("c.getUserInfo");
		action.setCallback(this, function(response){
			var state = response.getState();
			if(state === "SUCCESS"){
				component.set("v.displaySpinner" , false);
				var userDetails = response.getReturnValue();
				if(!$A.util.isEmpty(userDetails) && !$A.util.isUndefined(userDetails)){
					component.set("v.userDetails", userDetails);
					var caseRecordMap = userDetails.caseRecordTypeMap;
					var caseRecordTypes = [];
					for(var key in caseRecordMap){
						if(key != $A.get("$Label.c.AG_Master_Case_RT_Developer_Name")){
							caseRecordTypes.push({value:caseRecordMap[key] , key:key});
						}
						
					}
					component.set("v.caseRecordTypesList", caseRecordTypes);
					component.set("v.caseRecordTypesMap", caseRecordMap);

					//selectedValues initialization
					component.set("v.selectedValues", response.getReturnValue().filterWrapRec);	
				}
				// checking the field profile access
				if(!$A.util.isEmpty(userDetails.sObjectNameToProfileListMap) && !$A.util.isUndefinedOrNull(userDetails.sObjectNameToProfileListMap)) {

					for(var key in userDetails.sObjectNameToProfileListMap){
                        if(key == 'AG_Site__c'){
                            if(userDetails.sObjectNameToProfileListMap[key].includes(userDetails.userProfileName))  {
                                component.set("v.hideIOSite",true);
                            }else{
                               component.set("v.hideIOSite",false);
                            }
                            
                        }
                        if(key == 'AG_Dosage_Form__c'){
                            if(userDetails.sObjectNameToProfileListMap[key].includes(userDetails.userProfileName))  {
                                component.set("v.hideDosageForm",true);
                            }else{
                               component.set("v.hideDosageForm",false);
                            }
                            
                        }
                        if(key == 'AG_Item_Type__c'){
                            if(userDetails.sObjectNameToProfileListMap[key].includes(userDetails.userProfileName))  {
                                component.set("v.hideItemType",true);
                            }else{
                               component.set("v.hideItemType",false);
                            }
                            
                        }
                        if(key == 'AG_PCM_Issue_Code__c'){
                            if(userDetails.sObjectNameToProfileListMap[key].includes(userDetails.userProfileName))  {
                                component.set("v.hideIssueCode",true);
                            }else{
                               component.set("v.hideIssueCode",false);
                            }
                            
                        }
                  
					}

					
				}

			}else if(state === "INCOMPLETE"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
                component.set("v.displaySpinner" , false);
            } else if(state === "ERROR"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
                component.set("v.displaySpinner" , false);
            }

		});
		$A.enqueueAction(action);
	},

	//On selection of a Filter type from the filter section
	handleSelectedFilterSection: function(component, event, helper){
		 var selectedSection = event.getParam('name');
		 if(selectedSection == 'filterSection1'){
		 	component.set("v.selectedSection" , 'filterSection1');
		 	component.set("v.selectedValues.productValue" , '');
		 	component.set("v.selectedValues.dosageValue" , '');
		 	component.set("v.selectedValues.countryValue" , '');
		 	component.set("v.selectedValues.itemTypeValue" , '');
		 	component.set("v.selectedValues.issueCodeValue" , '');
		 	component.set("v.selectedValues.ioSiteValue" , '');
		 	component.set("v.selectedValues.fromDate" , '');
		 	component.set("v.selectedValues.toDate" , '');
		 	component.set("v.selectedValues.caseTypeName", '');
		 	component.set("v.selectedValues.caseNumberValue", '');
		 	component.set("v.selectedValues.caseTypeValueName", '');
		 	component.set("v.selectedValues.productValueName", '');
		 	component.set("v.selectedValues.dosageValueName", '');
		 	component.set("v.selectedValues.countryValueName", '');
		 	component.set("v.selectedValues.itemTypeValueName", '');
		 	component.set("v.selectedValues.issueCodeValueName", '');
		 	component.set("v.selectedValues.ioSiteValueName", '');


		 }else if(selectedSection == 'filterSection2'){
		 	component.set("v.selectedValues.caseNumberValue",'');
		 	component.set("v.selectedSection" , 'filterSection2');
		 	component.set("v.selectedValues.caseValue" , '');
		 	
		 	/*var selectedValue = component.find("subCaseType").get("v.name");
		 	component.set("v.selectedValues.caseTypeValueName" , selectedValue);*/
		 	var selectedSubCase = component.find("subCaseType").get("v.value");

		 	var caseRecordTypesMap = component.get("v.caseRecordTypesMap");
			component.set("v.selectedValues.caseTypeValueName",caseRecordTypesMap[selectedSubCase]);

		 	if(selectedSubCase == $A.get("$Label.c.AG_PCM_Case_RT_Developer_Name")){
				component.set("v.pcmCaseFiltersSection", true);
			}else{
				component.set("v.pcmCaseFiltersSection", false);
			}

		 }else{
		 	component.set("v.selectedSection", '');
		 }

	},

	//On selection of the PCm Type SUb Case
	handleSubCaseTypeSelection : function(component, event, helper){
		var selectedSubCase = component.find("subCaseType").get("v.value");
		if(selectedSubCase == $A.get("$Label.c.AG_PCM_Case_RT_Developer_Name")){
			component.set("v.pcmCaseFiltersSection", true);
		}else{
			component.set("v.pcmCaseFiltersSection", false);
		}

		var caseRecordTypesMap = component.get("v.caseRecordTypesMap");
		
		component.set("v.selectedValues.caseTypeValueName",caseRecordTypesMap[selectedSubCase]);
	},

	//Handle case lookup
	handleCaseChange : function(component, event, helper){
		if(!$A.util.isEmpty(component.get("v.selectedCaseRecord")) && !$A.util.isUndefinedOrNull(component.get("v.selectedCaseRecord")) && !$A.util.isEmpty(component.get("v.selectedCaseRecord.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedCaseRecord.Id"))){
				component.set("v.selectedValues.caseValue" , component.get("v.selectedCaseRecord.Id"));
				//alert(component.get("v.selectedValues.AG_Custom_Case_Number__c"));
				component.set("v.selectedValues.caseNumberValue", component.get("v.selectedCaseRecord.AG_Custom_Case_Number__c"))
		}else{
			component.set("v.selectedValues.caseValue" , '');
			component.set("v.selectedValues.caseNumberValue" , '');
		}
	},

	//Handle Product lookup
	handleProductChange : function(component, event, helper){
			if(!$A.util.isEmpty(component.get("v.selectedProductRecord")) && !$A.util.isUndefinedOrNull(component.get("v.selectedProductRecord")) && !$A.util.isEmpty(component.get("v.selectedProductRecord.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedProductRecord.Id"))){
					component.set("v.selectedValues.productValue", component.get("v.selectedProductRecord.Id"));
					component.set("v.selectedValues.productValueName", component.get("v.selectedProductRecord.Name"));

			}else{
				component.set("v.selectedValues.productValue" , '');
				component.set("v.selectedValues.productValueName" , '');
			}		
	},

	//Handle Dosage lookup
	handleDosageChange : function(component, event, helper){
		if(!$A.util.isEmpty(component.get("v.selectedDosageRecord")) && !$A.util.isUndefinedOrNull(component.get("v.selectedDosageRecord")) && !$A.util.isEmpty(component.get("v.selectedDosageRecord.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedDosageRecord.Id"))){
				component.set("v.selectedValues.dosageValue" , component.get("v.selectedDosageRecord.Id"));
				component.set("v.selectedValues.dosageValueName" , component.get("v.selectedDosageRecord.Name"));

		}else{
			component.set("v.selectedValues.dosageValue" , '');
			component.set("v.selectedValues.dosageValueName" , '');
		}	
	},

	//Handle country lookup
	handleCountryChange : function(component, event, helper){
		if(!$A.util.isEmpty(component.get("v.selectedCountryRecord")) && !$A.util.isUndefinedOrNull(component.get("v.selectedCountryRecord")) && !$A.util.isEmpty(component.get("v.selectedCountryRecord.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedCountryRecord.Id"))){
				component.set("v.selectedValues.countryValue" , component.get("v.selectedCountryRecord.Id"));
				component.set("v.selectedValues.countryValueName" , component.get("v.selectedCountryRecord.Name"));
		}else{
			component.set("v.selectedValues.countryValue" , '');
			component.set("v.selectedValues.countryValueName" , '');
		}	
	},

	//Handle Item  lookup
	handleItemChange : function(component, event, helper){
		if(!$A.util.isEmpty(component.get("v.selectedItemRecord")) && !$A.util.isUndefinedOrNull(component.get("v.selectedItemRecord")) && !$A.util.isEmpty(component.get("v.selectedItemRecord.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedItemRecord.Id"))){
				component.set("v.selectedValues.itemTypeValue" , component.get("v.selectedItemRecord.Id"));
				component.set("v.selectedValues.itemTypeValueName" , component.get("v.selectedItemRecord.Name"));
		}else{
			component.set("v.selectedValues.itemTypeValue" , '');
			component.set("v.selectedValues.itemTypeValueName" , '');
		}	
	},
	//Handle issueCode lookup
	handleIssueChange : function(component, event, helper){
		if(!$A.util.isEmpty(component.get("v.selectedIssueCodeRecord")) && !$A.util.isUndefinedOrNull(component.get("v.selectedIssueCodeRecord")) && !$A.util.isEmpty(component.get("v.selectedIssueCodeRecord.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedIssueCodeRecord.Id"))){
				component.set("v.selectedValues.issueCodeValue" , component.get("v.selectedIssueCodeRecord.Id"));
				component.set("v.selectedValues.issueCodeValueName" , component.get("v.selectedIssueCodeRecord.Name"));
		}else{

			component.set("v.selectedValues.issueCodeValue" , '');
			component.set("v.selectedValues.issueCodeValueName" , '');
		}	
	},

	//Handle site lookup
	handleSiteChange : function(component, event, helper){
		if(!$A.util.isEmpty(component.get("v.selectedSiteRecord")) && !$A.util.isUndefinedOrNull(component.get("v.selectedSiteRecord")) && !$A.util.isEmpty(component.get("v.selectedSiteRecord.Id")) && !$A.util.isUndefinedOrNull(component.get("v.selectedSiteRecord.Id"))){
				component.set("v.selectedValues.ioSiteValue" , component.get("v.selectedSiteRecord.Id"));
				component.set("v.selectedValues.ioSiteValueName" , component.get("v.selectedSiteRecord.Name"));
		}else{
			component.set("v.selectedValues.ioSiteValue" , '');
			component.set("v.selectedValues.ioSiteValueName" , '');
		}	
	},

	//get the search resuls
	handleSearch : function(component, event, helper){
		//if other criteria Section is selected
		if(!component.get("v.otherCriteriaSelected")) {
			if($A.util.isEmpty(component.get("v.selectedValues.caseValue")) || $A.util.isUndefinedOrNull(component.get("v.selectedValues.caseValue"))){
				helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"), $A.get("$Label.c.AG_Filter_Criteria_Error_Message"));
				component.set("v.allowSearch",false);
			} else{
				component.set("v.allowSearch",true);
			}
		} else{
			helper.onSearchValidations(component, event, helper);
		}
		if(component.get("v.allowSearch")) {
			var selectedFilters = JSON.stringify(component.get("v.selectedValues"));
			component.set("v.displaySpinner" , true);
			var selectedCaseId = component.get("v.selectedCaseRecord.Id");
			var action = component.get("c.getSearchResults");
			action.setParams({
				"searchFilters" : selectedFilters
			});
			action.setCallback(this, function(response){
				var state = response.getState();
				if(state === "SUCCESS"){
					var caseNoteList = response.getReturnValue();
					if(!$A.util.isEmpty(caseNoteList) && !$A.util.isUndefinedOrNull(caseNoteList)){
						component.set("v.fullWrapper", caseNoteList);

						if($A.util.isEmpty(caseNoteList.errorString)){
							component.set("v.activeSectionName", 'notesSection');
							component.set("v.isSearch", true);
							component.set("v.caseNotesList", caseNoteList.caseNotesRecordList);

						}else{
							helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),caseNoteList.errorString);
                            /*Clear out the values if it shows error*/
                            component.set("v.activeSectionName", 'filterSection');
                            component.set("v.isSearch", false);
                            component.set("v.caseNotesList",[]); 
                            component.set("v.allowSearch", false);
						}
						
					}else{
						component.set("v.caseNoteList", []);
					}
				}
				else if(state === "INCOMPLETE"){

                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
            } else if(state === "ERROR"){
               helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"), $A.get("$Label.c.AG_Search_Critera_Error_Message"));
                
            }
            component.set("v.displaySpinner" , false);

			});
			$A.enqueueAction(action);
		}
		
		
		
	},

	//Handling Date VAlidation
	fromFilterValue : function(component, event, helper) {
		if(event.getSource().get("v.name") == 'filterSection2') {
			component.set("v.otherCriteriaSelected",true);
			component.set("v.allowSearch",false);
		}
		else {
			component.set("v.otherCriteriaSelected",false);
			component.set("v.allowSearch",true);
		}
	},

	//Handling Date VAlidation
	onSearchValidations: function (component, event, helper) {

        var allValid = component.find('mandatoryDate').reduce(function (validSoFar, inputCmp) {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true); 
        if (allValid) {
        	var fromDate = component.get("v.selectedValues.fromDate");
        	var toDate = component.get("v.selectedValues.toDate");
        	var todayDate = component.get("v.selectedValues.todayDate");
        	if(fromDate <= toDate) {
        			//all validations passed: positive condition for allowing search
        			component.set("v.allowSearch",true);        		
        	}
        	else {

        		helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_Amgen_Notified_Date_Validation_Message1"));
        		
        	}
            
        } else {
        	component.set("v.allowSearch",false);
        }
    },

   // Method on clear
    handleClear: function(component, event, helper){
    	component.set("v.activeSectionName", 'filterSection');
    	component.set("v.isSearch", false);
    	component.set("v.otherCriteriaSelected", false);
    	component.set("v.allowSearch", false);
    	helper.doInitHelper(component, event, helper);
    },

    // Method for showing toast
     showToast: function(toastTitle, toastType, toastMessage){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": toastTitle,
            "type": toastType,
            "message": toastMessage
        });
        toastEvent.fire();
    },

    // Method for handling Cancel
    handleCancel: function(component, event, helper){
    	var navService = component.find("navService");
        var pageReference =  {
            type: 'standard__namedPage',
            attributes: {
                pageName: 'home'
            }
        };
        //event.preventDefault();
        navService.navigate(pageReference);

    },
    callPDFCreate : function(component, event, helper) {
    	var action = component.get("c.createNoteSnapShotPDF");
    	//fullWrapper
    	
    	

    	action.setParams({
    		"fullWrapperVal" : JSON.stringify(component.get("v.fullWrapper"))
    	});
		action.setCallback(this, function(response){
			var state = response.getState();
			if(state === "SUCCESS"){
				//component.set("v.displaySpinner" , false);
				if(response.getReturnValue()) {
				}
				
			}
			else if(state === "INCOMPLETE"){
	            helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
	            component.set("v.displaySpinner" , false);
	        }
	        else if(state === "ERROR"){
	            helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
	            component.set("v.displaySpinner" , false);
	        }
	    });
	    $A.enqueueAction(action);
	}
})
