({
	doInit : function(component, event, helper) {
        
		var pageReference = {
            type: 'standard__component',
            attributes: {
                componentName: 'c__AG_CreateNewMasterCaseCmp',
            },
            state: {
                 "c__createNewCase": Date.now()
            }
        };
        component.set("v.pageReference", pageReference);
        var navService = component.find("navService");
        var pageReference = component.get("v.pageReference");
        
        navService.navigate(pageReference);
        helper.closecurrentTab(component,event,helper);
	}
})