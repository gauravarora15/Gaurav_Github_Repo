({ 
    doInit : function(component, event, helper) {
        helper.doInit(component, event, helper);
	},
    onClickItem : function(component, event, helper) {
        helper.onClickItem(component, event, helper);
	},
    onClickItemRes : function(component, event, helper) {
        helper.onClickItemRes(component, event, helper);
	},
    previewModeHelper : function(component, event, helper) {
        helper.previewModeHelper(component, event, helper);
	},
    handlePrintComplete : function(component, event, helper){
        helper.handlePrintComplete(component, event, helper);
    }
})