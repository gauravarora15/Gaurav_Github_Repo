({
    doInit : function(component, event, helper) {
    	var fmData = {};
    	fmData.selectedTemplate = '';
    	fmData.selectedMessageBody = '';
    	fmData.responseDoc = '';
    	fmData.packgeDocLinkId = '';
    	fmData.acknowledgementId = '';
    	fmData.headerId = ''; 
    	component.set("v.fmData",fmData);
        if(component.get("v.methodName") == 'fax'){
        	component.set("v.buttonName" , $A.get("$Label.c.AG_Print_Complete"));
        }else{
        	component.set("v.buttonName" , $A.get("$Label.c.AG_Print_Button"));
        }
	},
    onClickItem : function(component, event, helper) {
       var index = event.target.getAttribute('id');
        document.getElementById(index + 'Status').classList.add('slds-hide');
        document.getElementById(index + 'NewStatus').classList.remove('slds-hide');
        document.getElementById(index + 'NewStatus').classList.add('slds-show');
        var docSize = 0;
        if(component.get("v.confirmDoc")){
            docSize = component.get("v.confirmDoc").length;
        }
        var sldsShowSize = 0;
        for(var i=0;i<docSize;i++){
            if(document.getElementById(i+'CompNewStatus').classList == 'slds-show'){
               sldsShowSize ++; 
            }
        }
        if((sldsShowSize == docSize && $A.util.isEmpty(component.get("v.mergeDocId"))) || (!$A.util.isEmpty(component.get("v.mergeDocId")) && document.getElementById('mergeStatus').classList == 'slds-show')){
        	component.set("v.dis",false);
        }
        	
    },
    onClickItemRes : function(component, event, helper) {
        var in1Id = component.find("in1");
        $A.util.addClass(in1Id, 'slds-hide');
        var in2Id = component.find("in2");
        $A.util.removeClass(in2Id, 'slds-hide');
        $A.util.addClass(in2Id, 'slds-show');
        var docSize = 0;
        if(component.get("v.confirmDoc")){
            docSize = component.get("v.confirmDoc").length;
        }
        //var docSize = component.get("v.confirmDoc").length;
        var sldsShowSize = 0;
        for(var i=0;i<docSize;i++){
            if(document.getElementById(i+'CompNewStatus').classList == 'slds-show'){
               sldsShowSize ++; 
            }
        }
        if(sldsShowSize == docSize)
        	component.set("v.dis",false);
    },


    previewModeHelper : function(component ,event,helper){
        
            var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
              "url": "/c/AG_PDFViewerApp.app?docId="+component.get("v.mergeDocId")
            });
            urlEvent.fire();
    },
   
    handlePrintComplete:function(component, event, helper){
        
        var buttonClick = event.getSource().getLocalId();
        //HANDLE EFAX
        component.set("v.dis",true);
        if(component.get("v.methodName") == 'fax' && buttonClick == 'sendFax'){
        	component.set("v.displaySpinner",true);
        	helper.sendEfax(component,event,helper);
        }else{
        	//NAVIGATE TO NEXT SECTION IF CALLOUT IS SUCCESS
            var printEvent = component.getEvent("printCompleteEvent");
	        printEvent.setParams({
	            "successMessage" : true,
	            "createFM": true
	        });
	        printEvent.fire();
        }
        
    },
    showToast : function(component, event, helper,title , message , type) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": message,
            "type" : type
        });
        toastEvent.fire();
        component.set("v.displaySpinner",false);
    },
    //SEND FAX HELPER
    sendEfax: function(component, event, helper) {
        
        
        var fullFillMentPackageId = component.get("v.fulfillmentPackageId");
        var allDocs = component.get("v.confirmDoc");
        var action = component.get("c.invokeEFax");
        var fmData = component.get("v.fmData");
        
        action.setParams({
            "fPackageId": fullFillMentPackageId,
            "allDocuments": JSON.stringify(allDocs),
            "fmDataRecord" : JSON.stringify(fmData)
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === 'SUCCESS') {
                var responseVar = response.getReturnValue();
                
                if (!$A.util.isEmpty(responseVar.state) && !$A.util.isUndefinedOrNull(responseVar.state)) {
                	helper.showToast(component, event, helper, $A.get("$Label.c.AG_Error"), responseVar.state, $A.get("$Label.c.AG_Error_Toast_Type"));
                } else {
                	//NAVIGATE TO NEXT SECTION IF CALLOUT IS SUCCESS
                    var printEvent = component.getEvent("printCompleteEvent");
			        printEvent.setParams({
			            "successMessage" : true,
			            "createFM":false,
			            "listAgResponse": responseVar.listAgResponse
			        });
			        printEvent.fire();
                }
                component.set("v.dis",false);
            } else if (state === "INCOMPLETE") {
                helper.showToast(component, event, helper, $A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"), $A.get("$Label.c.AG_Error_Toast_Type"));
                component.set("v.dis",false);
            } else if (state === "ERROR") {
                helper.showToast(component, event, helper, $A.get("$Label.c.AG_Error"), $A.get("$Label.c.AG_errorMessage"), $A.get("$Label.c.AG_Error_Toast_Type"));
                component.set("v.dis",false);
            }
        });
        $A.enqueueAction(action);
    }
})