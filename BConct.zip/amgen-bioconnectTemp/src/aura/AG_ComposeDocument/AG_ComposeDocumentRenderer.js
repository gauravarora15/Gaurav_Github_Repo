({
	afterRender : function(component, helper) {
	  this.superAfterRender();
	  helper.navigateToTab(component , event , helper , 'tab-1'); 
	}
})