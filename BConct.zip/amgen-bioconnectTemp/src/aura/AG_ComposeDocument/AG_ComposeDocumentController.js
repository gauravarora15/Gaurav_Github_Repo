({
	doInit : function(component, event, helper) {
		helper.doInit(component, event, helper);
	},
	handleLanguagSelect : function(component, event, helper){
		helper.handleLanguagSelect(component, event, helper);
	},
	
	handleTemplateSelect : function(component, event, helper){
		helper.handleTemplateSelect(component, event, helper);
	},

	handleMultiSelect : function(component, event, helper){
		var initiateMultiselect = component.get("v.initiateMultiselect");
		if(initiateMultiselect){
			helper.handleMultiSelect(component, event, helper);
		}
		if(event.getSource().get("v.multiselectLabel") == $A.get("$Label.c.AG_Disclaimer_Statement_Selection")){
			component.set("v.initiateMultiselect", true);
		}			
		 
	},
	
    prodTemplateText : function(component, event, helper){
		helper.prodTemplateText(component, event, helper);
	},
    
	userSelect : function(component, event, helper) {
		helper.userSelectHelper(component , event , helper);	
	},

	handleSkipTemplate:function(component,event,helper) {
		helper.handleSkipTemplate(component, event, helper);
	},

	generateMergeResponse : function(component, event, helper){
		helper.generateMergeResponse(component, event, helper);
	},
	validate : function(component,event,helper){
		helper.validateRequiredFields(component , event , helper);
	},
	handleLoader : function(component,event,helper){
		helper.updatePackageHelper(component , event , helper);
	},
	handleBulletText : function(component, event, helper){
		helper.handleBulletText(component, event, helper);
	},
	handleWetSignature : function(component, event, helper){
		helper.handleWetSignature(component, event, helper);
	},
	handleToast : function(component,event,helper){
		component.set("v.displaySpinner",false);
	} 
})