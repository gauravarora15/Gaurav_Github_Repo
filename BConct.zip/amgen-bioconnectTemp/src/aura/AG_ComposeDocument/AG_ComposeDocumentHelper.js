({
    //Method on component initialisation 
    doInit: function(component, event, helper){
    	
        component.set("v.displaySpinner" , true);
        component.set("v.errorMessage" , "");
        var masterCaseWrapper = component.get("v.masterCaseWrapper");
        var action = component.get("c.getLanguageOptions");
        action.setParams({"masterCaseId" : component.get("v.masterCaseWrapper.masterCase.Id") ,
        				  "masterCaseWrapper" : JSON.stringify(masterCaseWrapper),
        				  "fulfillmentUserDataId": component.get("v.fulfillmentUserDataId"),
                        "documentIds" : component.get("v.documentsReordered")});
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === 'SUCCESS'){
                var responseVar = response.getReturnValue();
                if(!$A.util.isEmpty(responseVar) && !$A.util.isUndefinedOrNull(responseVar)){
                    component.set("v.templateInstance", responseVar);
		    component.set("v.organizationId" , responseVar.orgId);
                     component.set("v.baseURL" , responseVar.baseURL);
                    component.set("v.selectedIdsOpeningStatement" , responseVar.mapOpeningStatementIds);
                    component.set("v.selectedIdsProductStatement" , responseVar.mapProductIds);
                    component.set("v.selectedIdsDisclaimerStatement" , responseVar.mapDisclaimerIds);
                    
                    if(!$A.util.isEmpty(responseVar.selectedLanguage) || !$A.util.isEmpty(component.get("v.fulfillmentPackageId"))){
						component.set("v.initiateMultiselect", false); 
                    	helper.showTemplateOptions(component , event , helper);
                    	helper.showLanguages(component , event , helper);
                    	helper.showTemplatesSectedOnResume(component , event , helper);
                    }else{
                    	helper.showLanguages(component, event, helper);
                    	component.set("v.displaySpinner" , false);
                    }

                    //US-1535 Document List
                    if(!$A.util.isEmpty(responseVar.documentList)){
                        var documentList = responseVar.documentList;
                        var documentArray = [];
                        for(var i=0; i<documentList.length; i++){
                            if(documentList[i].AG_Full_Title__c!=''){
                             documentArray.push(documentList[i].AG_Full_Title__c);
                            }
                        }
                        component.set("v.documentsInfo" , documentArray);
                    }
                }else{
                	helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
                	component.set("v.displaySpinner" , false);
                }
            }else if(state === "INCOMPLETE"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
                component.set("v.displaySpinner" , false);
            } else if(state === "ERROR"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
                component.set("v.displaySpinner" , false);
            }
            
            
        });
        $A.enqueueAction(action); 
    },
    
    //Method to get the language options on the Language select field
    showLanguages: function(component, event, helper){
        var templateInstance = component.get("v.templateInstance");
        var languageList = templateInstance.languageList;
        var languageArray = [];
        for(var i=0; i<languageList.length; i++){
            languageArray.push({label : languageList[i],
                                value : languageList[i]});
            
        }
        
        component.set("v.languageOptions", languageArray);
        component.set("v.mergeResponseLayout",templateInstance.pageLayoutList);
        
    },
    
    //Method to handle the selected Language 
    handleLanguagSelect : function(component, event, helper){
        component.set("v.displaySpinner" , true);
        component.set("v.errorMessage" , "");
        var masterCaseData = component.get("v.masterCaseWrapper");
        var templateInstance = component.get("v.templateInstance");
        var caseId = component.get("v.masterCaseWrapper.masterCase.Id");
        var selectedLanguage = component.find("language").get("v.value");
        component.set("v.selectedIdsOpeningStatement",{});
    	component.set("v.selectedIdsProductStatement",{});
    	component.set("v.selectedIdsDisclaimerStatement",{});
        
        
        if(selectedLanguage == $A.get("$Label.c.AG_Select_an_Option_Label")){
        	component.set("v.templateInstance.selectedLanguage" , '');
            component.set("v.openingStatements", '');
            component.set("v.productStatements", '');
            component.set("v.disclaimerStatements", '');
            component.set("v.closingStatements", '');
            component.set("v.watermarkStatements", '');
            component.set("v.footerStatements", '');
	    component.set("v.signatureStatements", '');
            component.set("v.headerStatements", '');
            component.set("v.disableButton" , true);
            helper.blankAllTemplates(component , event , helper);
            helper.navigateToTab(component , event , helper , 'tab-1'); 
        }else{
		helper.blankAllTemplates(component , event , helper);
            var action = component.get("c.fetchTemplates");
        action.setParams({
           "selectedLanguage" : selectedLanguage,
            "masterCaseWrapper" : JSON.stringify(masterCaseData),
            "caseId" : caseId
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var template = response.getReturnValue();
                
                if(!$A.util.isEmpty(template) && !$A.util.isUndefinedOrNull(template)){
                    template.selectedLanguage = selectedLanguage;
                    component.set("v.templateInstance", template);  
                    helper.showTemplateOptions(component,event,helper);
		    
                    helper.navigateToTab(component , event , helper , 'tab-1'); 
                }               
                
            }else if(state === "INCOMPLETE"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
            } else if(state === "ERROR"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
            }
            component.set("v.displaySpinner" , false);
        });
        $A.enqueueAction(action);

        }
        
    },
    
    //Method to show the template options on the basis of the selected language
    showTemplateOptions : function(component, event, helper){
        var templateInstance = component.get("v.templateInstance");

        //US-1535 Opening template requirement change
        var openingTempList = templateInstance.openingTemplates;
        var openingTempArray = [];
        for(var i=0; i<openingTempList.length; i++){
            var openingTemps = {};
            openingTemps.Name = openingTempList[i].AG_Template_Name__c;
            if(!$A.util.isEmpty(templateInstance.mapOpeningStatementIds) && !$A.util.isUndefinedOrNull(templateInstance.mapOpeningStatementIds) && undefined != templateInstance.mapOpeningStatementIds[openingTempList[i].Id]){
                openingTemps.isSelected = true;
            }else{
                openingTemps.isSelected = false;
            }
            openingTemps.Id = openingTempList[i].Id;
            openingTempArray.push(openingTemps);
        }
        component.set("v.openingStatements", openingTempArray);

        var productList = templateInstance.productTemplates;
        var productTempArray = [];
        for(var i=0; i<productList.length; i++){
            var productTemps = {};
            productTemps.Name = productList[i].AG_Template_Name__c;
            if(!$A.util.isEmpty(templateInstance.mapProductIds) && !$A.util.isUndefinedOrNull(templateInstance.mapProductIds) && undefined != templateInstance.mapProductIds[productList[i].Id]){
            	productTemps.isSelected = true;
            }else{
            	productTemps.isSelected = false;
            }
            productTemps.Id = productList[i].Id;
            productTempArray.push(productTemps);
        }
        component.set("v.productStatements", productTempArray);

        var disclaimerList = templateInstance.disclaimerTemplates;
        var disclaimerArray = [];
        for(var i=0; i<disclaimerList.length; i++){
            var disclaimerTemps = {};
            disclaimerTemps.Name = disclaimerList[i].AG_Template_Name__c;
            if(!$A.util.isEmpty(templateInstance.mapDisclaimerIds) && !$A.util.isUndefinedOrNull(templateInstance.mapDisclaimerIds) && undefined != templateInstance.mapDisclaimerIds[disclaimerList[i].Id]){
            	disclaimerTemps.isSelected = true;
            }else{
            	disclaimerTemps.isSelected = false;
            }
            disclaimerTemps.Id = disclaimerList[i].Id;
            disclaimerArray.push(disclaimerTemps);
        }
        
        component.set("v.disclaimerStatements", disclaimerArray);
        component.set("v.footerStatements", templateInstance.footerTemplates);
	component.set("v.signatureStatements", templateInstance.signatureTemplates);
        component.set("v.closingStatements", templateInstance.closingTemplates);
        component.set("v.watermarkStatements", templateInstance.watermarkTemplates);
        component.set("v.headerStatements", templateInstance.headerTemplates);
	helper.validateRequiredFields(component,event,helper);
    },
    

    //method to handle the selected template for the opening, closing and watermark template
    handleTemplateSelect: function(component,event,helper){
        var templateInstance = component.get("v.templateInstance");
        var orgId = component.get("v.organizationId");
        var baseURL = component.get("v.baseURL");
    	component.set("v.displaySpinner" , true);
    	component.set("v.errorMessage","");
        var caseId = component.get("v.masterCaseWrapper.masterCase.Id");
        var action = component.get("c.fetchTemplateBody");
        if(event.getSource().get("v.name") == 'closingStatement'){
            action.setParams({
                'templateId' : component.find("selectClosingTemplate").get("v.value"),
                'caseId' : caseId
            });
            
            
        }if(event.getSource().get("v.name") == 'watermarkStatement'){
            action.setParams({
                'templateId' : component.find("selectWatermarkTemplate").get("v.value"),
                'caseId' : caseId
            });
            
        }
        //US-1481 : Footer Templates
        if(event.getSource().get("v.name") == 'footerStatement'){
            action.setParams({
                'templateId' : component.find("selectFooterTemplate").get("v.value"),
                'caseId' : caseId
            });
            
        }
	//US-1535
        if(event.getSource().get("v.name") == 'signatureStatement'){
            action.setParams({
                'templateId' : component.find("selectSignatureTemplate").get("v.value"),
                'caseId' : caseId
            });
            
        }
        //US-1536 Header Template
        if(event.getSource().get("v.name") == 'headerStatement'){
            action.setParams({
                'templateId' : component.find("selectHeaderTemplate").get("v.value"),
                'caseId' : caseId
            });
            
        }
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var templateVar = response.getReturnValue();
                if(event.getSource().get("v.name") == 'closingStatement'){
component.set("v.closingTemplate",helper.mergeDateField(component,templateVar.templateBody));
                        helper.navigateToTab(component , event , helper , 'tab-4');
                }if(event.getSource().get("v.name") == 'watermarkStatement'){
                     component.set("v.staticWatermark",helper.mergeDateField(component,templateVar.staticTemp));
                    component.set("v.dynamicWatermark",helper.mergeDateField(component,templateVar.dynamicTemp));
                        helper.navigateToTab(component , event , helper , 'tab-5');
                }if(event.getSource().get("v.name") == 'footerStatement'){
                    component.set("v.footerTemplate1",helper.mergeDateField(component,templateVar.footerTemp1));
                    component.set("v.footerTemplate2",helper.mergeDateField(component,templateVar.footerTemp2));
                        helper.navigateToTab(component , event , helper , 'tab-6');
                }if(event.getSource().get("v.name") == 'signatureStatement'){
                    //component.set("v.disableButton", false);
                    component.set("v.signatureImageDocId", templateVar.signatureImageId);  
                    component.set("v.signatureImageDocAlignment", templateVar.signatureImageFileExtension); // signatureImageAlignment
                    if(!$A.util.isEmpty(templateVar.signatureBody1) && !$A.util.isUndefinedOrNull(templateVar.signatureBody1)){
                        component.set("v.signatureTemplate1", templateVar.signatureBody1);
                    }else{
                        component.set("v.signatureTemplate1", '');
                    }
                    if(!$A.util.isEmpty(templateVar.signatureBody2) && !$A.util.isUndefinedOrNull(templateVar.signatureBody2)){
                        component.set("v.signatureTemplate2", templateVar.signatureBody2);
                    }else{
                        component.set("v.signatureTemplate2", '');
                    }
                        helper.navigateToTab(component , event , helper , 'tab-7');
                }
                 if(event.getSource().get("v.name") == 'headerStatement'){
                    component.set("v.headerId", templateVar.docId);
                    component.set("v.headerAlignment", templateVar.docAlignment);
                    var headerId = templateVar.docId;

                    var imageURL = 'https://'+baseURL+ '/servlet/servlet.ImageServer?id='+headerId+'&oid='+orgId;
                     component.set("v.headerTemplate", "<img src = "+imageURL+">");
                     helper.navigateToTab(component , event , helper , 'tab-1');
        }
                helper.validateRequiredFields(component , event , helper);
            }else if(state === "INCOMPLETE"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
            } else if(state === "ERROR"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
            }
            component.set("v.displaySpinner" , false);
        });
        
        $A.enqueueAction(action);
    },
    
    //Method to handle the selected multiple templates for product and disclaimer
    handleMultiSelect:function(component, event, helper){
    	var checkValue = component.find("checkBullet").get("v.checked");
    	component.set("v.displaySpinner" , true);
        //var templateData = event.getParam("templateIds");
        var docIds = event.getParam("selectedItem");
        var templateData = [];
        for(var key in docIds){
        	templateData.push(docIds[key]);
        }
        
        component.set("v.templateIds", templateData);
        var source = event.getSource().get("v.multiselectLabel");
        if(templateData.length>0){
            helper.createProductDisclaimerTemp(component , event , helper , templateData , source);
            if(event.getSource().get("v.multiselectLabel") == $A.get("$Label.c.AG_Product_Statement_Selection")){
            	component.set("v.selectedIdsProductStatement",event.getParam("selectedItem"));
                helper.navigateToTab(component , event , helper , 'tab-2');
            }else if(event.getSource().get("v.multiselectLabel") == $A.get("$Label.c.AG_Disclaimer_Statement_Selection")){
                component.set("v.selectedIdsDisclaimerStatement",event.getParam("selectedItem"));
                helper.navigateToTab(component , event , helper , 'tab-3');
            }
            //US-1535 Multiselect Opening templates
            else if(event.getSource().get("v.multiselectLabel") == $A.get("$Label.c.AG_Opening_Statement_Selection")){
                component.set("v.selectedIdsOpeningStatement",event.getParam("selectedItem"));
                helper.navigateToTab(component , event , helper , 'tab-8');
               
            }
        }else if(event.getSource().get("v.multiselectLabel") == $A.get("$Label.c.AG_Product_Statement_Selection")){
            component.set("v.productTemplate" , '');
            component.set("v.selectedIdsProductStatement",event.getParam("selectedItem"));
            helper.navigateToTab(component , event , helper , 'tab-2');
            
        }else if(event.getSource().get("v.multiselectLabel") == $A.get("$Label.c.AG_Disclaimer_Statement_Selection")){
        	component.set("v.disclaimerTemplate" , '');
        	component.set("v.selectedIdsDisclaimerStatement",event.getParam("selectedItem"));
        	helper.navigateToTab(component , event , helper , 'tab-3');
        }
        //US-1535 Multiselect Opening templates
        else if(event.getSource().get("v.multiselectLabel") == $A.get("$Label.c.AG_Opening_Statement_Selection")){
            component.set("v.selectedIdsOpeningStatement",event.getParam("selectedItem"));
            if(checkValue){
                component.set("v.openingTemplate" , '');
                 helper.handleBulletText(component, event, helper);
            }else{
                component.set("v.openingTemplate" , '');
                component.set("v.selectedOpeningtemplates", []);

            }            
            helper.navigateToTab(component , event , helper , 'tab-8');
            
            
        }
		//US-1535 Multiselect Opening templates
        helper.validateRequiredFields(component,event,helper);
        component.set("v.displaySpinner" , false);
    },
    
    //Method to get teh selected Product and Disclaimer templates 
    createProductDisclaimerTemp: function(component , event , helper , templateData , source){
        component.set("v.displaySpinner" , true);
        var caseId = component.get("v.masterCaseWrapper.masterCase.Id");
        var templateIds;
        for (var i in templateData) {
            if(i == 0){
                templateIds = templateData[i];
            }else{
                if(templateIds.indexOf(templateData[i]) === -1){
                    templateIds = templateIds + ',' + templateData[i];
                }
            }
        }
        
        
        var action = component.get("c.fetchMultipleTemplates");
        action.setParams({
            'templateIds' : templateIds,
            'caseId' : caseId
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var templateVar = response.getReturnValue();
                var templateArray = templateIds.split(',');
                if(!$A.util.isEmpty(templateVar) && !$A.util.isUndefinedOrNull(templateVar)){
                    var templateInstance = component.get("v.templateInstance");
                    if(source == $A.get("$Label.c.AG_Product_Statement_Selection") && !$A.util.isEmpty(templateVar.productTemp) && !$A.util.isUndefinedOrNull(templateVar.productTemp)){
                    	templateInstance.productTemp = templateVar.productTemp;
                    	var productIdMap = {};
                    	
                    	for(var i in templateArray){
                    		productIdMap[templateArray[i]] = templateArray[i];
                    	}
                    	templateInstance.mapProductIds = productIdMap;
                    }
                    else if(source == $A.get("$Label.c.AG_Disclaimer_Statement_Selection") && !$A.util.isEmpty(templateVar.disclaimerTemp) && !$A.util.isUndefinedOrNull(templateVar.disclaimerTemp)){
                    	templateInstance.disclaimerTemp = templateVar.disclaimerTemp;
                    	var mapDisclaimerIds = {};
                    	for(var i in templateArray){
                    		mapDisclaimerIds[templateArray[i]] = templateArray[i];
                    	}
                    	templateInstance.mapDisclaimerIds = mapDisclaimerIds;
                    }
                    //US-1535
                   else if(source == $A.get("$Label.c.AG_Opening_Statement_Selection") && !$A.util.isEmpty(templateVar.openingListTemp) && !$A.util.isUndefinedOrNull(templateVar.openingListTemp)){
                        templateInstance.openingListTemp = templateVar.openingListTemp;
                        var mapOpeningTempIds = {};
                        for(var i in templateArray){
                            mapOpeningTempIds[templateArray[i]] = templateArray[i];
                        }
                        templateInstance.mapOpeningStatementIds = mapOpeningTempIds;
                       
                    }
                    component.set("v.templateInstance", templateInstance);
                    helper.handleProductDiscliamerTemplate(component, event, helper , source);
                }
                
            }else if(state === "INCOMPLETE"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
            } else if(state === "ERROR"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
            }
            component.set("v.displaySpinner" , false);
        });
        $A.enqueueAction(action);
    },
    
    mergeDateField: function(component,template){
		if(!$A.util.isEmpty(template) && !$A.util.isUndefinedOrNull(template)){
        var language = component.get('v.templateInstance.selectedMomentLanguage');
        template = template.replace(/\(\(\(Today_Date\[DD Month YYYY\]\)\)\)/g, moment().locale(language).format('LL'));
        template = template.replace(/\(\(\(Today_Date\[MM DD YYYY\]\)\)\)/g, moment().locale(language).format('L'));
        template = template.replace(/\(\(\(Today_Date\[DD MM YYYY\]\)\)\)/g, moment().locale(language).format('L'));
        template = template.replace(/\(\(\(Today_Date\[DD Mon YYYY\]\)\)\)/g, moment().locale(language).format('ll'));
        template = template.replace(/\(\(\(Today_Date\[Month DD YYYY\]\)\)\)/g, moment().locale(language).format('LL')); 
        }else{
            template = '';
        }
        return template;        
    },
    
    //Method to populate the Product and Disclaimer Template
    handleProductDiscliamerTemplate : function(component, event, helper , source){
        var checkValue = component.find("checkBullet").get("v.checked");
        var openingTemplate = component.get("v.openingTemplate");
        var templateInstance = component.get("v.templateInstance");
        var productTempList = templateInstance.productTemp; 
        var disclaimerTempList = templateInstance.disclaimerTemp;
        var openingTempList = templateInstance.openingListTemp;
        var productString = '';
        var disclaimerString = '';
        var openingString = '';

         if(source == $A.get("$Label.c.AG_Product_Statement_Selection")){
        for(var i = 0; i<productTempList.length; i++){
            productString =  productString   +  (helper.mergeDateField(component,productTempList[i])) + '</br>';
            
        } 
        }

        else if(source == $A.get("$Label.c.AG_Disclaimer_Statement_Selection")){       
        for(var i= 0; i<disclaimerTempList.length; i++){
            disclaimerString = disclaimerString  + (helper.mergeDateField(component,disclaimerTempList[i])) + '</br>';
        }
        }
        else if(source == $A.get("$Label.c.AG_Opening_Statement_Selection")){
        for(var i= 0; i<openingTempList.length; i++){
            openingString = openingString  +  (helper.mergeDateField(component,openingTempList[i]))+ '</br>';
             
        }
        }
        if(!$A.util.isEmpty(productString) && !$A.util.isUndefinedOrNull(productString)){
        	component.set("v.productTemplate", productString);
        }
        if(!$A.util.isEmpty(disclaimerString) && !$A.util.isUndefinedOrNull(disclaimerString)){
        	component.set("v.disclaimerTemplate", disclaimerString);
        }
       
        if(!$A.util.isEmpty(openingString) && !$A.util.isUndefinedOrNull(openingString)){
            component.set("v.openingTemplate", openingString);
            if(checkValue){
                 helper.handleBulletText(component, event, helper);  

            }
           
        }
    },
    
    //Method to navigate to the tab of the selected template
    navigateToTab :  function(component, event, helper , tabId) {
    	
        var selectedTab = component.get("v.selectedTab");
        component.set("v.selectedTab", tabId);
        component.set("v.displaySpinner" , false);
    } ,
    
    //Method for navigation on click of buttons
    userSelectHelper : function(component , event , helper) {
    	component.set("v.displaySpinner" , true);
        var key = event.getSource().getLocalId();
        if(key === 'prev'){
            helper.navigateToComponents(component,event , helper,3);
        }else if(key === 'close'){
            helper.handleSaveAndClose(component, event, helper);
        }else if(key === 'next'){
        	//VALIDATE IF MERGE RESPONSE NEEDS TO BE CREATED
        	var skipLetter = component.find("checkTemplate").get("v.checked");
        	if(skipLetter && component.get("v.documentsReordered").length == 0){
        		//PROMPT USER THAT MERGE RESPONSE WILL NOT BE CREATED SO CAN WE PROCEED
        		helper.openPromptComponent(component,event,helper, $A.get("$Label.c.AG_Create_Merge_Response_Prompt_Message"));
        	}else{
        		//CREATE FP WITH MERGE RESPONSE
        		helper.generateMergeResponse(component, event, helper);
        	}
            
        }else if(key === 'cancel'){
            helper.navigateToComponents(component,event , helper,0);
        }
        
    },

    //method for navigation between screens
    navigateToComponents  :function(component , event , helper,componentNo){
    	component.set("v.displaySpinner" , true);
        var fulfillmentPackageId = component.get("v.fulfillmentPackageId");
        var compEvent = component.getEvent("navigateComponent");
        
        compEvent.setParams({"componentNo" : componentNo ,
                             "masterCaseWrapper" : JSON.stringify(component.get("v.masterCaseWrapper")),
                             "selectedRequests" : component.get("v.selectedRequestState"),
                             "documentsReordered" : component.get("v.documentsReordered"),
                            "fulfillmentPackageId" : component.get("v.fulfillmentPackageId"),
                            "fulfillmentUserData" : component.get("v.fulfillmentUserDataId")});
        compEvent.fire();
    },

    handleSaveAndClose : function(component, event, helper){
        var templateInstance = component.get("v.templateInstance");
        
        templateInstance.templateBody = component.get("v.openingTemplate");
        templateInstance.closingTemplateBody = component.get("v.closingTemplate");
        templateInstance.staticTemp = component.get("v.staticWatermark");
        templateInstance.dynamicTemp = component.get("v.dynamicWatermark");
        templateInstance.footerTemp1 = component.get("v.footerTemplate1");
        templateInstance.footerTemp2 = component.get("v.footerTemplate2");
        templateInstance.skipTemplate = component.get("v.skipTemplate");
		//US-1535 Multiselect Opening templates
        templateInstance.addBulletText = component.get("v.addBulletText");
	templateInstance.addWetSign = component.get("v.addWetSign");
        templateInstance.productBody = component.get("v.productTemplate");
        templateInstance.disclaimerBody = component.get("v.disclaimerTemplate");
        templateInstance.signatureBody1 = component.get("v.signatureTemplate1");//US-1536
        templateInstance.signatureBody2 = component.get("v.signatureTemplate2");//US-1536
        templateInstance.signatureImageId = component.get("v.signatureImageDocId");//US-1536 //updated by rachit signatureImageId
        templateInstance.signatureImageFileExtension = component.get("v.signatureImageDocAlignment");//US-1536 //updated by rachit signatureImageAlignment
        templateInstance.headerBody = component.get("v.headerTemplate");//US-1537
        templateInstance.docId = component.get("v.headerId");//US-1537
        templateInstance.docAlignment = component.get("v.headerAlignment");//US-1537
        
        if(!$A.util.isEmpty(templateInstance) && !$A.util.isUndefinedOrNull(templateInstance) && JSON.stringify(templateInstance).length > $A.get("$Label.c.AG_Max_Size_CoverLetter")){
        	component.set("v.errorMessage",$A.get("$Label.c.AG_Cover_Letter_Error"));
        	component.set("v.displaySpinner" , false);
        	return;
        }
        var caseId = component.get("v.masterCaseWrapper.masterCase.Id");
        var action = component.get("c.saveSelectedData");
        action.setParams({
                "templateData" : JSON.stringify(templateInstance),
                "masterCaseId" : caseId,
                "fulfillmentUserDataId":component.get("v.fulfillmentUserDataId")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            
            if(state === "SUCCESS"){
                    var fudData = response.getReturnValue();
                     if(!$A.util.isEmpty(fudData) && !$A.util.isUndefinedOrNull(fudData)){
                        component.set("v.fulfillmentUserDataId", fudData);
						helper.showToast($A.get("$Label.c.AG_Sucess_Toast_Type") , $A.get("$Label.c.AG_Sucess_Toast_Type"), $A.get("$Label.c.AG_Fulfillment_Data_Saved_Success_Message")); 
                        helper.navigateToComponents(component,event , helper,0);
                    }else{
                    	helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
                    }
            }else if(state === "INCOMPLETE"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
            } else if(state === "ERROR"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
            }
            component.set("v.displaySpinner" , false);
        });
        $A.enqueueAction(action);
    },
    
    //method for handling the skip checkbox
    handleSkipTemplate: function(component, event, helper){
        var checkValue = component.find("checkTemplate").get("v.checked");
        if(checkValue){
            component.set("v.requiredTemplate", false);
            //NEED TO VALIDATE FOR WRITTEN RESPONSE TO MAKE CERTAIN FIELDS REQUIRED
            if(component.get("v.documentsReordered").length>0){
            	component.set("v.noWrittenResponse",false);
            }else{
            	component.set("v.noWrittenResponse",true);
            }
        }else{
            component.set("v.requiredTemplate", true);
            component.set("v.noWrittenResponse",false);
        }
        helper.validateRequiredFields(component , event , helper);

    },

    //US-1535:Method to add the Bullet Text
    handleBulletText : function(component, event, helper){
        var documentList = component.get("v.documentsInfo");        
        var openingTemplate = component.get("v.openingTemplate");
        var checkValue = component.find("checkBullet").get("v.checked");
        if(checkValue){
            var originalOpeningTemp = component.get("v.openingTemplate");
            component.set("v.originalOpeningTemplate", originalOpeningTemp);
           
            openingTemplate = openingTemplate + '&lt;&lt;&lt;&lt;&lt;'+ '<ul>';
            for(var i=0; i<documentList.length; i++){
				if(!$A.util.isEmpty(documentList[i]) && !$A.util.isUndefinedOrNull(documentList[i])){
					openingTemplate =  openingTemplate + "<li>" + documentList[i] + "</li>";

				}
			}

            openingTemplate = openingTemplate + "</ul>" + '&gt;&gt;&gt;&gt;&gt;';
            component.set("v.openingTemplate" , openingTemplate);
        }else{
            var selectedOpeningTemplateMap = component.get("v.selectedIdsOpeningStatement");
            var selectedOpeningTemplateCount = helper.getLength(component,event,helper,selectedOpeningTemplateMap);
            if(!selectedOpeningTemplateCount > 0){
                component.set("v.openingTemplate" , '');   

            }else{
                var openingTemplateBody = component.get("v.openingTemplate");
                var mySubString = openingTemplateBody.replace(openingTemplateBody.substring(openingTemplateBody.lastIndexOf('&lt;&lt;&lt;&lt;&lt;') ,openingTemplateBody.lastIndexOf('&gt;&gt;&gt;&gt;&gt;')+20) , "");
                component.set("v.openingTemplate" , mySubString);  
            }
        }
    },

    // Adding Wet Signature on Sigfnature template
    handleWetSignature : function(component, event, helper){
        var checkValue = component.find("checkSignature").get("v.checked");
        var signatureImageId = component.get("v.signatureImageDocId");
        var signatureImageAlignment = component.get("v.signatureImageDocAlignment");

        if(checkValue){
            component.set("v.signatureImageId" , signatureImageId);
            component.set("v.signatureImageAlignment", signatureImageAlignment);
        }else{
             component.set("v.signatureImageId" , '');
             component.set("v.signatureImageAlignment", '');
        }
    },
    
    //Mwthos to create toast
    showToast: function(toastTitle, toastType, toastMessage){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": toastTitle,
            "type": toastType,
            "message": toastMessage
        });
        toastEvent.fire();
    },

    //method to generate merge response
    generateMergeResponse : function(component, event, helper){
    	
    	component.set("v.errorMessage" , "");
    	component.set("v.mergeResponseReceived",false);
    	component.set("v.isLoaderProgressing",true);
    	component.set("v.progress" , 0);
    	var templateInstance = component.get("v.templateInstance");

        var checkValue = component.find("checkSignature").get("v.checked");
        templateInstance.templateBody = component.get("v.openingTemplate");
        templateInstance.closingTemplateBody = component.get("v.closingTemplate");
        templateInstance.staticTemp = component.get("v.staticWatermark");
        templateInstance.dynamicTemp = component.get("v.dynamicWatermark");
        templateInstance.footerTemp1 = component.get("v.footerTemplate1");
        templateInstance.footerTemp2 = component.get("v.footerTemplate2");
        templateInstance.skipTemplate = component.get("v.skipTemplate");
		//US-1535 Multiselect Opening templates
        templateInstance.addBulletText = component.get("v.addBulletText");
	templateInstance.addWetSign = component.get("v.addWetSign");//US-1536
        templateInstance.productBody = component.get("v.productTemplate");
        templateInstance.disclaimerBody = component.get("v.disclaimerTemplate");
	templateInstance.signatureBody1 = component.get("v.signatureTemplate1");//US-1536
        templateInstance.signatureBody2 = component.get("v.signatureTemplate2");//US-1536
        templateInstance.signatureImageId = component.get("v.signatureImageDocId");//US-1536 //updated by rachit signatureImageId
        templateInstance.signatureImageFileExtension = component.get("v.signatureImageDocAlignment");//Us-1536  // updated by rachit signatureImageAlignment
        templateInstance.headerBody = component.get("v.headerTemplate");//US-1536
        templateInstance.docId = component.get("v.headerId");//US-1537
        templateInstance.docAlignment = component.get("v.headerAlignment");//US-1537
        templateInstance.selectedLanguageCode = component.get('v.templateInstance.selectedLanguageCode');


        
        if(!$A.util.isEmpty(templateInstance) && !$A.util.isUndefinedOrNull(templateInstance) && JSON.stringify(templateInstance).length > $A.get("$Label.c.AG_Max_Size_CoverLetter")){
        	component.set("v.errorMessage",$A.get("$Label.c.AG_Cover_Letter_Error"));
        	component.set("v.displaySpinner" , false);
        	return;
        }
        var action = component.get("c.generateTemplate");
        var masterCaseWrapper = component.get("v.masterCaseWrapper");
        var documentId = component.get("v.documentId");
        action.setParams({
            "masterCaseWrapper" : JSON.stringify(masterCaseWrapper),
            "documentId" : documentId,
            "templateData" : JSON.stringify(templateInstance),
            "documentsReordered" : component.get("v.documentsReordered"),
            "fulfillmentUserDataId" :component.get("v.fulfillmentUserDataId"),
            "fpId" : component.get("v.fulfillmentPackageId") 
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
            	//VALIDATE DML SUCCESS
            	var fulfillmentPackageRecord = response.getReturnValue();
            	if($A.util.isEmpty(fulfillmentPackageRecord.errorMessage)){
            		component.set("v.fulfillmentPackageId" , fulfillmentPackageRecord.fulfillmentPackageId);
	                component.set("v.fulfillmentUserDataId", fulfillmentPackageRecord.fulfillmentUserDataId);
	                component.set("v.disableButton", false);
	                helper.invokeAfterMergedResponse(component,event , helper,fulfillmentPackageRecord);  
            	}else{
            		//SHOW ERROR ON SCREEN
            		//helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
            		component.set("v.errorMessage", fulfillmentPackageRecord.errorMessage);
            		component.set("v.displaySpinner" , false);
            	}
            }else if(state === "ERROR"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
                component.set("v.displaySpinner" , false);
             }else if(state === "INCOMPLETE"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
                component.set("v.displaySpinner" , false);
              }
        });

        $A.enqueueAction(action);
    },
    //show saved templates
    showTemplatesSectedOnResume : function(component , event , helper){
    	var templatedata = component.get("v.templateInstance");
    	
    	if(!$A.util.isEmpty(templatedata.templateBody) && !$A.util.isUndefinedOrNull(templatedata.templateBody)){
    		component.set("v.openingTemplate" , templatedata.templateBody);
    	}
    	if(!$A.util.isEmpty(templatedata.closingTemplateId) && !$A.util.isUndefinedOrNull(templatedata.closingTemplateId)){
    		component.set("v.closingTemplate" , templatedata.closingTemplateBody);
    	}
    	if(!$A.util.isEmpty(templatedata.waterMarkTemplateId) && !$A.util.isUndefinedOrNull(templatedata.waterMarkTemplateId)){
    		component.set("v.staticWatermark", templatedata.staticTemp);
            component.set("v.dynamicWatermark", templatedata.dynamicTemp);
    	}
		if(!$A.util.isEmpty(templatedata.footerTemplateId) && !$A.util.isUndefinedOrNull(templatedata.footerTemplateId)){
            component.set("v.footerTemplate1", templatedata.footerTemp1);
            component.set("v.footerTemplate2", templatedata.footerTemp2);
        }
    	if(!$A.util.isEmpty(templatedata.productBody) && !$A.util.isUndefinedOrNull(templatedata.productBody)){
    		component.set("v.productTemplate", templatedata.productBody);
    	}
    	if(!$A.util.isEmpty(templatedata.disclaimerBody) && !$A.util.isUndefinedOrNull(templatedata.disclaimerBody)){
    		component.set("v.disclaimerTemplate", templatedata.disclaimerBody);
    	}
        if(!$A.util.isEmpty(templatedata.signatureTemplateId) && !$A.util.isUndefinedOrNull(templatedata.signatureTemplateId)){
            if(!$A.util.isEmpty(templatedata.signatureBody1) && !$A.util.isUndefinedOrNull(templatedata.signatureBody1)){
                        component.set("v.signatureTemplate1", templatedata.signatureBody1);
                    }else{
                        component.set("v.signatureTemplate1", '');
                    }
                    if(!$A.util.isEmpty(templatedata.signatureBody2) && !$A.util.isUndefinedOrNull(templatedata.signatureBody2)){
                        component.set("v.signatureTemplate2", templatedata.signatureBody2);
                    }else{
                        component.set("v.signatureTemplate2", '');
                    }
            component.set("v.signatureImageDocId", templatedata.signatureImageId);  //updated by rachit signatureImageId
            component.set("v.signatureImageDocAlignment", templatedata.signatureImageFileExtension); // updated by rachit signatureImageAlignment
        }
        if(!$A.util.isEmpty(templatedata.headerTemplateId) && !$A.util.isUndefinedOrNull(templatedata.headerTemplateId)){
            component.set("v.headerTemplate", templatedata.headerBody);
            component.set("v.headerId", templatedata.docId);
            component.set("v.headerAlignment", templatedata.docAlignment);

        }
    	
    	component.set("v.skipTemplate",templatedata.skipTemplate);
        component.set("v.addBulletText",templatedata.addBulletText);
        component.set("v.addWetSign",templatedata.addWetSign);
    	helper.handleSkipTemplate(component , event , helper);
    	helper.navigateToTab(component , event , helper , 'tab-1');
    },
    blankAllTemplates : function(component , event , helper){
    	component.set("v.openingTemplate" , '');
    	component.set("v.productTemplate" , '');
    	component.set("v.disclaimerTemplate" , '');
    	component.set("v.closingTemplate" , '');
    	component.set("v.staticWatermark" , '');
    	component.set("v.dynamicWatermark" , '');
        component.set("v.footerTemplate1", '');
        component.set("v.footerTemplate2", '' );
        component.set("v.signatureTemplate1", '');
        component.set("v.signatureTemplate2", '');
        component.set("v.headerTemplate" , '');
		 component.set("v.addWetSign", false);
        component.set("v.addBulletText", false);
    	component.set("v.displaySpinner" , false);
    	
    },
    validateRequiredFields : function(component , event , helper){ 
    	//DESELECT BULLET CHECKBOX
    	if($A.util.isEmpty(component.get("v.documentsReordered")) || $A.util.isEmpty(component.get("v.openingTemplate"))){
    		component.set("v.addBulletText",false);
    	} 
    	component.set("v.errorMessage","");
    	var isSelected = component.get("v.skipTemplate");
    	var selectedLanguage = component.find("language").get("v.value");
    	var selectedMergeLayout = component.find("mergeResponseLayout").get("v.value");
    	if( $A.get("$Label.c.AG_Select_An_Option") == selectedLanguage){
    		selectedLanguage = '';
    	}
    	
    	var selectWatermarkTemplate = component.find("selectWatermarkTemplate").get("v.value");
        var selectFooterTemplate = component.find("selectFooterTemplate").get("v.value");
        var selectSignatureTemplate = component.find("selectSignatureTemplate").get("v.value");
        var selectHeaderTemplate = component.find("selectHeaderTemplate").get("v.value");

    	
    	if(isSelected){
    		
    		if((component.get("v.documentsReordered").length>0 && ($A.util.isEmpty(selectedMergeLayout) || $A.util.isUndefinedOrNull(selectedMergeLayout)  || $A.util.isEmpty(selectedLanguage) || $A.util.isUndefinedOrNull(selectedLanguage) || 
    		   $A.util.isEmpty(selectWatermarkTemplate) || $A.util.isUndefinedOrNull(selectWatermarkTemplate))) || ($A.util.isEmpty(selectedLanguage) || $A.util.isUndefinedOrNull(selectedLanguage))){
    				component.set("v.disableButton" , true);
    		   }
    		   else{
    			   component.set("v.disableButton" , false);
    		   }
    		
    	}else{
    	   var selectOpeningTemplate = component.get("v.selectedOpeningtemplates");
    		var selectClosingTemplate = component.find("selectClosingTemplate").get("v.value");
    		if($A.util.isEmpty(selectedMergeLayout) || $A.util.isUndefinedOrNull(selectedMergeLayout)  ||
    		   $A.util.isEmpty(selectedLanguage) || $A.util.isUndefinedOrNull(selectedLanguage) || 
    		   $A.util.isEmpty(selectWatermarkTemplate) || $A.util.isUndefinedOrNull(selectWatermarkTemplate) ||
    		   $A.util.isEmpty(selectClosingTemplate) || $A.util.isUndefinedOrNull(selectClosingTemplate) ||
               $A.util.isEmpty(selectOpeningTemplate) || $A.util.isUndefinedOrNull(selectOpeningTemplate) ||
                $A.util.isEmpty(selectFooterTemplate) || $A.util.isUndefinedOrNull(selectFooterTemplate) ||
                $A.util.isEmpty(selectSignatureTemplate) || $A.util.isUndefinedOrNull(selectSignatureTemplate) ||
                $A.util.isEmpty(selectHeaderTemplate) || $A.util.isUndefinedOrNull(selectHeaderTemplate) ){
    				component.set("v.disableButton" , true);
    		   }else{
    			   component.set("v.disableButton" , false);
    		   }
    		
    	}
    	component.set("v.displaySpinner" , false);
    },
    invokeAfterMergedResponse : function(component , event , helper,fulfillmentPackageRecord){
    	var empApi = component.find("empApi");
        
        // Error handler function that prints the error to the console.
        var errorHandler = function (message) {
        }.bind(this);
        
        // Register error listener and pass in the error handler function.
        empApi.onError(errorHandler);
        
        var channel='/event/AG_Fulfillment_Package_Events__e';
        var sub;
        
        // new events
        var replayId=-1;
        
        var callback = function (message) {
        	if(fulfillmentPackageRecord.fulfillmentPackageId == message.data.payload.AG_Package_Id__c && component.get("v.isLoaderProgressing")){
        		helper.saveMergeResponse(component,event,helper, message.data.payload.AG_Response__c , message.data.payload.AG_Status__c,message.data.payload.AG_Package_Id__c);
        	}
			        
        }.bind(this);

        empApi.subscribe(channel, replayId, callback).then(function(value) {
        });
        helper.loadProgressBar(component,event,helper);
    },
    saveMergeResponse : function(component , event , helper, response,responseState,packageId){
    	
    	component.set("v.mergeResponseReceived",true);
    	var action = component.get("c.saveResponse");
    	action.setParams({"response" : response,
        				  "state" : responseState,
        				  "packageId":packageId,
        				  "masterCaseWrapper" : JSON.stringify(component.get("v.masterCaseWrapper")),
        				  "templateData" : JSON.stringify(component.get("v.templateInstance"))});
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === 'SUCCESS'){
                var responseVar = response.getReturnValue();
                
                if(!$A.util.isEmpty(responseVar) && !$A.util.isUndefinedOrNull(responseVar)){
                    
                	if(responseVar.isSuccess){
                			if('SUCCESS' === responseState.toUpperCase()){
                				component.set("v.progress" , 100);
                				helper.showToast($A.get("$Label.c.AG_Sucess_Toast_Type") , $A.get("$Label.c.AG_Sucess_Toast_Type"), $A.get("$Label.c.AG_Success_Compose_Document"));
                				helper.navigateToComponents(component,event , helper,5);
                			}else{
                				component.set("v.progress" , 100);
                				helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_errorMessage"));
                				component.set("v.displaySpinner" , false);
                			}
                	}else{
                        
                        if(!$A.util.isEmpty(responseVar.errorString)){
                           component.set("v.errorMessage", responseVar.errorString);
                           component.set("v.displaySpinner" , false);


                        }else{
                            component.set("v.progress" , 100);
                            helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
                            component.set("v.displaySpinner" , false);

                        }
                		
                	}
                }
            }else if(state === "INCOMPLETE"){
            	component.set("v.progress" , 100);
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
                component.set("v.displaySpinner" , false);
            } else if(state === "ERROR"){
            	component.set("v.progress" , 100);
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
                component.set("v.displaySpinner" , false);
            }
        });
        $A.enqueueAction(action); 
    },
    //VALIDATE USER INPUT TO CREATE FP OR CANCEL.
    userPromptHelper : function(component , event , helper){ 
    	
    	if(component.get("v.confirm")){
    		helper.createFPWithoutMergeResponse(component,event , helper);
    	}else{
    		component.set("v.displaySpinner" , false);
    	}
    	
    },
    
    loadProgressBar : function(component,event,helper){
    	var modalBody;
        $A.createComponent("c:AG_LoadProgressBar", {"isSuccess" : component.getReference("v.mergeResponseReceived"),"isProgressing":component.getReference("v.isLoaderProgressing"),
        					"progress":component.getReference("v.progress")},
           function(content, status) {
               if (status === "SUCCESS") {
                   modalBody = content;
                   component.find('overlayLib').showCustomModal({
                       header: $A.get("$Label.c.AG_Processing_Merged_Response"),
                       body: modalBody, 
                       showCloseButton: true,
                       cssClass: "mymodal",
                       closeCallback: function() {
                    	   
                       }
                   })
               }                               
           });
    },
    updatePackageHelper : function(component,event,helper){
    	var isProcessing = event.getParam("value");
    	if(!isProcessing){
    		helper.saveMergeResponse(component,event,helper,$A.get("$Label.c.AG_Timeout_Response"),'FAILURE',component.get("v.fulfillmentPackageId"));
    	}
    },
    //SHOW PROMPT TO INFORM THAT FULFILLMENT PACKAGE WITHOUT MERGE RESPONSE LINK WILL BE CREATED.
    openPromptComponent : function(component,event,helper, message){
    	component.set("v.confirm",false);
    	var modalBody;
        $A.createComponent("c:AG_Reusable_Prompt_Component", {"message" : message , 
        					"confirm":component.getReference('v.confirm') , "isPrompt":true, "negative":$A.get("$Label.c.AG_No")},
           function(content, status) {
               if (status === "SUCCESS") {
                   modalBody = content;
                   component.find('overlayLib').showCustomModal({
                       header: $A.get("$Label.c.AG_Label_Warning"),
                       body: modalBody, 
                       showCloseButton: false,
                       cssClass: "mymodal",
                       closeCallback: function() {
                    	   helper.userPromptHelper(component,event,helper);
                       }
                   })
               }                               
           });
    },
    //CREATE FP WITHOUT MERGE RESPONSE DOCUMENT
    createFPWithoutMergeResponse : function(component,event,helper){
    	var checkValue = component.find("checkTemplate").get("v.checked");
        var checkAddBulletValue = component.find("checkBullet").get("v.checked");
        var addWetSign = component.find("checkSignature").get("v.checked");
        var masterCaseWrapper = component.get("v.masterCaseWrapper");
    	var templateInstance = component.get("v.templateInstance");
        templateInstance.templateBody = component.get("v.openingTemplate");
        templateInstance.closingTemplateBody = component.get("v.closingTemplate");
        templateInstance.staticTemp = component.get("v.staticWatermark");
        templateInstance.dynamicTemp = component.get("v.dynamicWatermark");
		templateInstance.footerTemp1 = component.get("v.footerTemplate1");
        templateInstance.footerTemp2 = component.get("v.footerTemplate2");
        templateInstance.skipTemplate = checkValue;
		//US-1535 Multiselect Opening templates
        templateInstance.addBulletText = checkAddBulletValue;
	templateInstance.addWetSign = addWetSign;//US-1536
        templateInstance.productBody = component.get("v.productTemplate");
        templateInstance.disclaimerBody = component.get("v.disclaimerTemplate");
	templateInstance.signatureBody1 = component.get("v.signatureTemplate1");//US-1536
        templateInstance.signatureBody2 = component.get("v.signatureTemplate2");//US-1536
        templateInstance.signatureImageId = component.get("v.signatureImageId");//US-1536
        templateInstance.signatureImageFileExtension = component.get("v.signatureImageAlignment");//US-1536  signatureImageAlignment
        templateInstance.headerBody = component.get("v.headerTemplate");//US-1537
        templateInstance.docId = component.get("v.headerId");//US-1537
        templateInstance.docAlignment = component.get("v.headerAlignment");//US-1537
        templateInstance.selectedLanguageCode = component.get('v.templateInstance.selectedLanguageCode');

        
    	var action = component.get("c.createFPWithoutMergeResponse");
    	action.setParams({"fudId" : component.get("v.fulfillmentUserDataId"),
        				  "masterCaseWrapper" : JSON.stringify(masterCaseWrapper),
        				  "templateData" : JSON.stringify(templateInstance),
        				  "fpId" : component.get("v.fulfillmentPackageId")});
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === 'SUCCESS'){
                var responseVar = response.getReturnValue();
                if($A.util.isEmpty(responseVar.errorMessage) || $A.util.isUndefinedOrNull(responseVar.errorMessage)){
                	
                	component.set("v.fulfillmentPackageId" , responseVar.fulfillmentPackageId);
	                component.set("v.disableButton", false);
                	helper.showToast($A.get("$Label.c.AG_Sucess_Toast_Type") , $A.get("$Label.c.AG_Sucess_Toast_Type"), $A.get("$Label.c.AG_Success_Compose_Document"));
                    helper.navigateToComponents(component,event , helper,5);
                }else{
                	component.set("v.errorMessage", responseVar.errorMessage);
		        	component.set("v.displaySpinner" , false);
		        	return;
                }
            }else if(state === "INCOMPLETE"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
                component.set("v.displaySpinner" , false);
            } else if(state === "ERROR"){
                helper.showToast($A.get("$Label.c.AG_Error"),$A.get("$Label.c.AG_Error_Toast_Type"),$A.get("$Label.c.AG_errorMessage"));
                component.set("v.displaySpinner" , false);
            }
        });
        $A.enqueueAction(action); 
    },
    getLength : function(component, event, helper,mapToCount) {
		  
		  var count = 0;
		  var i;
		   for (i in mapToCount){
		    if(mapToCount.hasOwnProperty(i)){
		       count++;
		     }
		   }
	       return count;
	 }
    	
})