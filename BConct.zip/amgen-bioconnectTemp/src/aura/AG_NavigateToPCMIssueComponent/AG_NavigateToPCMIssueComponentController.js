({
    doInit : function(component, event, helper) {
    	
        var recordId = component.get("v.recordId");
        var objectName = component.get("v.sObjectName");
        var pageReference = {
            type: 'standard__component',
            attributes: {
                componentName: 'c__AG_CreateEditPCMIssueComponent',
            },
            state: {
                "c__currentRecordId": recordId,
                "c__currentObjectName":objectName
            }
        };
        component.set("v.pageReference", pageReference);
        var navService = component.find("navService");
        var pageReference = component.get("v.pageReference");
        
        navService.navigate(pageReference); 
    }
})