({
	doInitHelper: function(component, event, helper){
		var recordId = component.get("v.recordId");
        
        var action = component.get("c.fetchPackageRelatedMasterCase");
        action.setParams({"caseId" : recordId});
        action.setCallback(this, function(response){
             var state = response.getState();
             
             if(state === 'SUCCESS'){
                var responseVar = response.getReturnValue();
                
                if($A.util.isEmpty(responseVar) || $A.util.isUndefinedOrNull(responseVar)){
                    helper.navigateToFulfillmentWizard(component, event, helper);
                }else{
                    helper.openPromptComponent(component, event, helper, $A.get("$Label.c.AG_New_Fulfillmet_Message"));
                }
             }

        });
        $A.enqueueAction(action); 
	},

	 navigateToFulfillmentWizard : function(component, event, helper){
        var recordId = component.get("v.recordId");
        var defaultScreen = component.get("v.defaultScreen");

        var pageReference = {
            type: 'standard__component',
            attributes: {
                componentName: 'c__AG_FulfillmentContainer',
            },
            state: {
                "c__caseId": recordId,
                "c__defaultScreen" : defaultScreen,
                "c__navigateToCase" : true
            }
        };
        component.set("v.pageReference", pageReference);
        var navService = component.find("navService");
        var pageReference = component.get("v.pageReference");
        
        navService.navigate(pageReference); 


    },

     navigateToMasterCase : function(component , event , helper){
        var recordId = component.get("v.recordId");
            var pageReference = {
                type: 'standard__recordPage',
                attributes: {
                    recordId: recordId,
                    actionName : 'view',
                    objectApiName : 'Case'
                },
                state: {
                    
                }
            };
            
            component.set("v.pageReference", pageReference);
            var navService = component.find("navService");
            var pageReference = component.get("v.pageReference");
            navService.navigate(pageReference);
    },

    //SHOW PROMPT TO INFORM THAT FULFILLMENT PACKAGE WITHOUT MERGE RESPONSE LINK WILL BE CREATED.
    openPromptComponent : function(component,event,helper, message){
        component.set("v.confirm",false);
        var modalBody;
        $A.createComponent("c:AG_Reusable_Prompt_Component", {"message" : message , 
                            "confirm":component.getReference('v.confirm') , "isPrompt":true, "negative":$A.get("$Label.c.AG_No")},
           function(content, status) {
               if (status === "SUCCESS") {
                   modalBody = content;
                   component.find('overlayLib').showCustomModal({
                       header: $A.get("$Label.c.AG_Label_Warning"),
                       body: modalBody, 
                       showCloseButton: false,
                       cssClass: "mymodal",
                       closeCallback: function() {
                           helper.userPromptHelper(component,event,helper);
                       }
                   })
               }                               
           });
    },

    userPromptHelper : function(component , event , helper){ 
        
        if(component.get("v.confirm")){
             helper.navigateToFulfillmentWizard(component, event, helper);
        }else{
             helper.navigateToMasterCase(component, event, helper);
        }
        
    },

     closeFocusedTab : function(component, event, helper) {
        var workspaceAPI = component.find("workspace");
        workspaceAPI.getFocusedTabInfo().then(function(response) {
            var focusedTabId = response.tabId;
            workspaceAPI.closeTab({tabId: focusedTabId});
        })
        .catch(function(error) {
            
        });
    }
})